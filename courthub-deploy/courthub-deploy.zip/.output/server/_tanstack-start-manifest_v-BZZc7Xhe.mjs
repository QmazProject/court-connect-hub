//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BZZc7Xhe.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/explore",
			"/landing",
			"/privacy",
			"/reset-password",
			"/terms",
			"/courts/$courtId",
			"/explore_/guest",
			"/payment/return",
			"/venues/$venueId",
			"/api/public/paymongo/webhook"
		],
		preloads: [
			"/assets/index-BuGUVsgt.js",
			"/assets/rolldown-runtime-QTnfLwEv.js",
			"/assets/useStore-D1mDm7_j.js",
			"/assets/link-D0k-KuKw.js",
			"/assets/createMiddleware-TJw9Iamk.js",
			"/assets/qss-Bqk2G4CH.js",
			"/assets/root-DLTE-HSj.js",
			"/assets/matchContext-D7bezmO-.js",
			"/assets/lazyRouteComponent-ULsYENI0.js",
			"/assets/useSearch-DvfwELy4.js",
			"/assets/useNavigate-CVy7zOf2.js",
			"/assets/client-CDfnPfN4.js",
			"/assets/useQuery-Mesbs5ll.js",
			"/assets/mutation-DoG0DLXT.js",
			"/assets/popover-umowRxiC.js",
			"/assets/user-plus-DDse-ud8.js",
			"/assets/types-DW7RyVIj.js",
			"/assets/x-DNYue3gi.js",
			"/assets/ph-places-BY3fl4rJ.js",
			"/assets/LegalDocument-Cl2ogdqU.js",
			"/assets/PlayerShell-D-7FPT1d.js",
			"/assets/dashboard-DVXHJgCB.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BuGUVsgt.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-By9xGszP.js"]
	},
	"/_authenticated": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/dashboard"],
		preloads: ["/assets/route-YwUXq5QN.js"]
	},
	"/explore": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/explore.tsx",
		children: void 0,
		preloads: ["/assets/explore-B4DveN_Q.js"]
	},
	"/landing": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/landing.tsx",
		children: void 0,
		preloads: ["/assets/landing-C4ApRfhr.js"]
	},
	"/privacy": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-BH8EsDlV.js"]
	},
	"/reset-password": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/reset-password.tsx",
		children: void 0,
		preloads: ["/assets/reset-password-DAtenQaz.js"]
	},
	"/terms": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-ybUNDEPj.js"]
	},
	"/_authenticated/dashboard": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-C8j0NmQa.js",
			"/assets/paymongo.functions-CZ72D76K.js",
			"/assets/booking-groups-BarswKL5.js",
			"/assets/FavoriteButton-C_K6nkZE.js"
		]
	},
	"/courts/$courtId": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/courts.$courtId.tsx",
		children: void 0,
		preloads: ["/assets/courts._courtId-BhmI9QGm.js"]
	},
	"/explore_/guest": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/explore_.guest.tsx",
		children: void 0,
		preloads: ["/assets/explore_.guest-DJC7XUT1.js"]
	},
	"/payment/return": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/payment.return.tsx",
		children: void 0,
		preloads: [
			"/assets/payment.return-B-UnVH0D.js",
			"/assets/paymongo.functions-CZ72D76K.js",
			"/assets/booking-groups-BarswKL5.js"
		]
	},
	"/venues/$venueId": {
		filePath: "C:/Users/edujk/Desktop/court-connect-hub/src/routes/venues.$venueId.tsx",
		children: void 0,
		preloads: [
			"/assets/venues._venueId-CUx1pWGr.js",
			"/assets/paymongo.functions-CZ72D76K.js",
			"/assets/FavoriteButton-C_K6nkZE.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
