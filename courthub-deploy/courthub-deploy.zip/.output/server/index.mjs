globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { a as toEventHandler, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/courthub-badge.png": {
		"type": "image/png",
		"etag": "\"110a0-/4Wh5ymVtJesulk4HAbGEq3Cp/g\"",
		"mtime": "2026-08-21T06:33:01.567Z",
		"size": 69792,
		"path": "../public/courthub-badge.png"
	},
	"/CHicon.png": {
		"type": "image/png",
		"etag": "\"20e0b-PspF0F9JTrXmdn/rzBPFGtrpc5I\"",
		"mtime": "2026-07-28T08:12:56.037Z",
		"size": 134667,
		"path": "../public/CHicon.png"
	},
	"/favicon-16.png": {
		"type": "image/png",
		"etag": "\"3e7-mVgaPE/xJoa4n/zVG+h9XkJGTD0\"",
		"mtime": "2026-08-21T06:19:30.956Z",
		"size": 999,
		"path": "../public/favicon-16.png"
	},
	"/courthub-wordmark.png": {
		"type": "image/png",
		"etag": "\"e9bf-2dNQB9+MPp8yzviAmrnZDjoICZ4\"",
		"mtime": "2026-08-21T05:31:58.796Z",
		"size": 59839,
		"path": "../public/courthub-wordmark.png"
	},
	"/favicon-32.png": {
		"type": "image/png",
		"etag": "\"bfe-+DePmJnHWhh0xs7OZiqwPzyn/KI\"",
		"mtime": "2026-08-21T06:19:30.925Z",
		"size": 3070,
		"path": "../public/favicon-32.png"
	},
	"/assets/booking-groups-BarswKL5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5fc-JqSymi6uvZz/RnHD5SPHMsnmFAE\"",
		"mtime": "2026-08-25T07:10:21.944Z",
		"size": 1532,
		"path": "../public/assets/booking-groups-BarswKL5.js"
	},
	"/assets/createMiddleware-TJw9Iamk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7b7f-nD/rE3WszSnN5Z8FiW41izLGWRA\"",
		"mtime": "2026-08-25T07:10:21.945Z",
		"size": 31615,
		"path": "../public/assets/createMiddleware-TJw9Iamk.js"
	},
	"/assets/courts._courtId-BhmI9QGm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5c1-I8dTy2TZdPF4BlfOSkvBEOlFfEY\"",
		"mtime": "2026-08-25T07:10:21.945Z",
		"size": 1473,
		"path": "../public/assets/courts._courtId-BhmI9QGm.js"
	},
	"/assets/dashboard-DVXHJgCB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4bc-SFzd5kKuMCQ3jIPBqe19HF1T8fM\"",
		"mtime": "2026-08-25T07:10:21.947Z",
		"size": 1212,
		"path": "../public/assets/dashboard-DVXHJgCB.js"
	},
	"/assets/explore-B4DveN_Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c0-S8rKU4qou2+yI4NgYvKh2DzYzEQ\"",
		"mtime": "2026-08-25T07:10:21.947Z",
		"size": 192,
		"path": "../public/assets/explore-B4DveN_Q.js"
	},
	"/assets/explore_.guest-DJC7XUT1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cd-CDPc7mOkz0txGcPuCCPoY6KKlBg\"",
		"mtime": "2026-08-25T07:10:21.948Z",
		"size": 205,
		"path": "../public/assets/explore_.guest-DJC7XUT1.js"
	},
	"/assets/client-CDfnPfN4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"332e7-vu7NCfkhbikWXkxibKobCgKHEqM\"",
		"mtime": "2026-08-25T07:10:21.944Z",
		"size": 209639,
		"path": "../public/assets/client-CDfnPfN4.js"
	},
	"/assets/FavoriteButton-C_K6nkZE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2dc4-8GKZFD/jv5kCkFPdbX/Vmbzossg\"",
		"mtime": "2026-08-25T07:10:21.943Z",
		"size": 11716,
		"path": "../public/assets/FavoriteButton-C_K6nkZE.js"
	},
	"/assets/landing-C4ApRfhr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d4-FhJpGB6Mgr2AXcX6myOCVAw51Vk\"",
		"mtime": "2026-08-25T07:10:21.948Z",
		"size": 212,
		"path": "../public/assets/landing-C4ApRfhr.js"
	},
	"/assets/lazyRouteComponent-ULsYENI0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f87-RSHETBBD7KzHt+2DkWA5o6EuSts\"",
		"mtime": "2026-08-25T07:10:21.949Z",
		"size": 3975,
		"path": "../public/assets/lazyRouteComponent-ULsYENI0.js"
	},
	"/courthub-logo.png": {
		"type": "image/png",
		"etag": "\"5905c-IvHRiLixZ6pWVHtEVRACde8k284\"",
		"mtime": "2026-08-21T06:49:01.251Z",
		"size": 364636,
		"path": "../public/courthub-logo.png"
	},
	"/assets/LegalDocument-Cl2ogdqU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"671d-Q3FVjSlMsGh7TcrG0nMpomDRAyU\"",
		"mtime": "2026-08-25T07:10:21.943Z",
		"size": 26397,
		"path": "../public/assets/LegalDocument-Cl2ogdqU.js"
	},
	"/assets/leaflet-src-AD9ZoK5_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2455b-mE/M9aQb7obISMbNaGyDSoxgSvc\"",
		"mtime": "2026-08-25T07:10:21.949Z",
		"size": 148827,
		"path": "../public/assets/leaflet-src-AD9ZoK5_.js"
	},
	"/assets/link-D0k-KuKw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e97-Pl4dsYtPg3SDwSUkdq11szV3yxc\"",
		"mtime": "2026-08-25T07:10:21.950Z",
		"size": 7831,
		"path": "../public/assets/link-D0k-KuKw.js"
	},
	"/role-tenant.png": {
		"type": "image/png",
		"etag": "\"2cdc-XVqgVN9QX51TTAAXnvmMI3BJkbQ\"",
		"mtime": "2026-08-24T04:46:04.292Z",
		"size": 11484,
		"path": "../public/role-tenant.png"
	},
	"/assets/dashboard-C8j0NmQa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4c4cd-fihACZSI0sQydY+ltTDLDGdrq5U\"",
		"mtime": "2026-08-25T07:10:21.946Z",
		"size": 312525,
		"path": "../public/assets/dashboard-C8j0NmQa.js"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"91b8-xF1XRKBKd6Lrr0ZNHKAYNhcoLm8\"",
		"mtime": "2026-08-21T06:19:30.881Z",
		"size": 37304,
		"path": "../public/favicon.png"
	},
	"/role-player.png": {
		"type": "image/png",
		"etag": "\"2c98-LBOFXBTPxb1iYDT+MNVBNctI6GY\"",
		"mtime": "2026-08-24T04:46:04.262Z",
		"size": 11416,
		"path": "../public/role-player.png"
	},
	"/assets/index-BuGUVsgt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"62d31-kRG1JqAnKuE5P+lke8ThRJvPWo4\"",
		"mtime": "2026-08-25T07:10:21.942Z",
		"size": 404785,
		"path": "../public/assets/index-BuGUVsgt.js"
	},
	"/courthub-name-transparent.png": {
		"type": "image/png",
		"etag": "\"be7f2-dz9tUN6ozigQW9G14Z82a4HBoMo\"",
		"mtime": "2026-08-24T07:47:12.471Z",
		"size": 780274,
		"path": "../public/courthub-name-transparent.png"
	},
	"/assets/mutation-DoG0DLXT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d32-Lo97tcGGgYSsZnugWSgVHQF6+n8\"",
		"mtime": "2026-08-25T07:10:21.950Z",
		"size": 3378,
		"path": "../public/assets/mutation-DoG0DLXT.js"
	},
	"/assets/payment.return-B-UnVH0D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ca2-An/Gu4utvNZA1rKjqFDwY9MoYho\"",
		"mtime": "2026-08-25T07:10:21.951Z",
		"size": 7330,
		"path": "../public/assets/payment.return-B-UnVH0D.js"
	},
	"/assets/paymongo.functions-CZ72D76K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13d6-Doe8jEjxck/dodDVerDXkMzNdtU\"",
		"mtime": "2026-08-25T07:10:21.951Z",
		"size": 5078,
		"path": "../public/assets/paymongo.functions-CZ72D76K.js"
	},
	"/assets/matchContext-D7bezmO-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a3-cwcrOW2ky5VueoJDHvlrwPhtc50\"",
		"mtime": "2026-08-25T07:10:21.950Z",
		"size": 675,
		"path": "../public/assets/matchContext-D7bezmO-.js"
	},
	"/assets/ph-places-BY3fl4rJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2e0-bvntLeVlsayCFP4cAwAQrL9gqUk\"",
		"mtime": "2026-08-25T07:10:21.952Z",
		"size": 45792,
		"path": "../public/assets/ph-places-BY3fl4rJ.js"
	},
	"/assets/PlayerShell-D-7FPT1d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"292d-nDczoXnkCKbfS5irbTDA+GSf/lk\"",
		"mtime": "2026-08-25T07:10:21.943Z",
		"size": 10541,
		"path": "../public/assets/PlayerShell-D-7FPT1d.js"
	},
	"/assets/privacy-BH8EsDlV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"163-BoO0682dHMbnHos3kYTq6nF4zIM\"",
		"mtime": "2026-08-25T07:10:21.956Z",
		"size": 355,
		"path": "../public/assets/privacy-BH8EsDlV.js"
	},
	"/assets/qss-Bqk2G4CH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bc-2N+JPG3965eWSB0QcbrDwgkqrgU\"",
		"mtime": "2026-08-25T07:10:21.956Z",
		"size": 444,
		"path": "../public/assets/qss-Bqk2G4CH.js"
	},
	"/assets/rolldown-runtime-QTnfLwEv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b6-wnqLLSlp3SaE+lbe74bKNe5Rpds\"",
		"mtime": "2026-08-25T07:10:21.957Z",
		"size": 694,
		"path": "../public/assets/rolldown-runtime-QTnfLwEv.js"
	},
	"/assets/root-DLTE-HSj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20-vSYConOtSP6ciwr9zKsPixNwWmc\"",
		"mtime": "2026-08-25T07:10:21.958Z",
		"size": 32,
		"path": "../public/assets/root-DLTE-HSj.js"
	},
	"/assets/popover-umowRxiC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cf59-cA33K6RB7e/w0Pmn7p5wjby7gAw\"",
		"mtime": "2026-08-25T07:10:21.953Z",
		"size": 118617,
		"path": "../public/assets/popover-umowRxiC.js"
	},
	"/assets/reset-password-DAtenQaz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1395-9HdLNNfkXOM4mxhTVHV7EDEREhM\"",
		"mtime": "2026-08-25T07:10:21.957Z",
		"size": 5013,
		"path": "../public/assets/reset-password-DAtenQaz.js"
	},
	"/assets/routes-By9xGszP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23144-6f5aEsfh+kr9ibmonQwNxFK41rY\"",
		"mtime": "2026-08-25T07:10:21.959Z",
		"size": 143684,
		"path": "../public/assets/routes-By9xGszP.js"
	},
	"/assets/route-YwUXq5QN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a-RwE9pBvqMaj8wS6iGbohcRCb/DA\"",
		"mtime": "2026-08-25T07:10:21.958Z",
		"size": 138,
		"path": "../public/assets/route-YwUXq5QN.js"
	},
	"/assets/terms-ybUNDEPj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"161-yeRLKFvLZQNs6DSR+3m284wznLU\"",
		"mtime": "2026-08-25T07:10:21.962Z",
		"size": 353,
		"path": "../public/assets/terms-ybUNDEPj.js"
	},
	"/assets/types-DW7RyVIj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dd36-+7cHfuFDDrk/ep5ilqLkyrvTktI\"",
		"mtime": "2026-08-25T07:10:21.963Z",
		"size": 56630,
		"path": "../public/assets/types-DW7RyVIj.js"
	},
	"/assets/styles-DUH0z3Fd.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"2f0d4-VWct7HbJUttB76eLSRnTwX5YXEU\"",
		"mtime": "2026-08-25T07:10:21.978Z",
		"size": 192724,
		"path": "../public/assets/styles-DUH0z3Fd.css"
	},
	"/assets/useNavigate-CVy7zOf2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e3-W5eNl4UHnRWrbizlNZgWpLDvscU\"",
		"mtime": "2026-08-25T07:10:21.973Z",
		"size": 227,
		"path": "../public/assets/useNavigate-CVy7zOf2.js"
	},
	"/assets/useQuery-Mesbs5ll.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5d2c-4Zj6OfJUt28E3GZq6Fkvw0rx3UA\"",
		"mtime": "2026-08-25T07:10:21.973Z",
		"size": 23852,
		"path": "../public/assets/useQuery-Mesbs5ll.js"
	},
	"/assets/user-plus-DDse-ud8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"110b-hfK/l/C44p8gb0OVQEJ6pDhiwII\"",
		"mtime": "2026-08-25T07:10:21.976Z",
		"size": 4363,
		"path": "../public/assets/user-plus-DDse-ud8.js"
	},
	"/assets/useSearch-DvfwELy4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"31e-ewF0laYB8Yi9g8xTL0h+KlaXm+E\"",
		"mtime": "2026-08-25T07:10:21.973Z",
		"size": 798,
		"path": "../public/assets/useSearch-DvfwELy4.js"
	},
	"/assets/useStore-D1mDm7_j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6992-DVuPdsnlaWootEWN8FSw6movj0E\"",
		"mtime": "2026-08-25T07:10:21.975Z",
		"size": 27026,
		"path": "../public/assets/useStore-D1mDm7_j.js"
	},
	"/assets/x-DNYue3gi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"534-fcfzQaBZnYtjt4Kp7bhQkc0oqgM\"",
		"mtime": "2026-08-25T07:10:21.977Z",
		"size": 1332,
		"path": "../public/assets/x-DNYue3gi.js"
	},
	"/assets/venues._venueId-CUx1pWGr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2af93-zj972y9MuPvh68tN0/KmvfI/L1c\"",
		"mtime": "2026-08-25T07:10:21.977Z",
		"size": 176019,
		"path": "../public/assets/venues._venueId-CUx1pWGr.js"
	},
	"/payments/grabpay.svg": {
		"type": "image/svg+xml",
		"etag": "\"b22-q87PHLyMAyu2OkRK9ehR9HK0GUo\"",
		"mtime": "2026-08-24T03:03:23.442Z",
		"size": 2850,
		"path": "../public/payments/grabpay.svg"
	},
	"/payments/mastercard.svg": {
		"type": "image/svg+xml",
		"etag": "\"367-K0R/sAzVrrBedYE9BF9fTvFZn3I\"",
		"mtime": "2026-08-24T03:03:23.397Z",
		"size": 871,
		"path": "../public/payments/mastercard.svg"
	},
	"/payments/maya.svg": {
		"type": "image/svg+xml",
		"etag": "\"1b5d-6k5dgwFKHHdCqzdwAWmEpKfExcI\"",
		"mtime": "2026-08-24T02:56:27.014Z",
		"size": 7005,
		"path": "../public/payments/maya.svg"
	},
	"/fonts/pencerio-hairline.woff2": {
		"type": "font/woff2",
		"etag": "\"91e8-KvjrSCyN1kjgnVPeZyK73DdSCtM\"",
		"mtime": "2026-08-21T07:52:44.379Z",
		"size": 37352,
		"path": "../public/fonts/pencerio-hairline.woff2"
	},
	"/fonts/cabinet-grotesk-variable.woff2": {
		"type": "font/woff2",
		"etag": "\"a384-UUXkPq43I89lzgRMxdgrbFoPDBU\"",
		"mtime": "2026-08-22T05:01:36.833Z",
		"size": 41860,
		"path": "../public/fonts/cabinet-grotesk-variable.woff2"
	},
	"/payments/gcash.svg": {
		"type": "image/svg+xml",
		"etag": "\"2a34-OOdvXFEYHdbNxzp5haVUQ00MxRw\"",
		"mtime": "2026-08-24T02:56:26.933Z",
		"size": 10804,
		"path": "../public/payments/gcash.svg"
	},
	"/payments/visa.svg": {
		"type": "image/svg+xml",
		"etag": "\"32d-AcixKPxztBiB6pj7BZa5XeEAz1s\"",
		"mtime": "2026-08-24T03:03:23.355Z",
		"size": 813,
		"path": "../public/payments/visa.svg"
	},
	"/payments/qrph.svg": {
		"type": "image/svg+xml",
		"etag": "\"2082-UD2rzoWG9NcCklIfBGz/A7KNdKk\"",
		"mtime": "2026-08-24T03:09:31.462Z",
		"size": 8322,
		"path": "../public/payments/qrph.svg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_jmmkkz = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_jmmkkz
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
