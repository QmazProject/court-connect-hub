//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-B3LTXT2r.js
var manifest = {
	"26fd7c53c370fd96e0e67e35bf95d425edea2701038c7097f1bdf6cd22226fe6": {
		functionName: "startBookingCheckout_createServerFn_handler",
		importer: () => import("./_ssr/paymongo.functions-BND0fiHI.mjs")
	},
	"3be948fb1c3eba65ff6979d4d5666c9a95208cfe5a608cbc3a5239159e4a9362": {
		functionName: "refundBookingFn_createServerFn_handler",
		importer: () => import("./_ssr/paymongo.functions-BND0fiHI.mjs")
	},
	"6081a66a0be53dc472b738bb285741ca4f94b199f4d4bf8e3ad705abfb1051c5": {
		functionName: "getCheckoutStatus_createServerFn_handler",
		importer: () => import("./_ssr/paymongo.functions-BND0fiHI.mjs")
	},
	"be439ce63edc5e5594bbd7284bd1ac44c879681c4b4dd145f5a24ed9cc21d269": {
		functionName: "retryBookingPayment_createServerFn_handler",
		importer: () => import("./_ssr/paymongo.functions-BND0fiHI.mjs")
	},
	"c2aa49c683db0cb78455296515329f39bb48aa934e9e71e23722a9e6e5eed05f": {
		functionName: "cancelPendingBookings_createServerFn_handler",
		importer: () => import("./_ssr/paymongo.functions-BND0fiHI.mjs")
	},
	"e6d797fc46af27ae0c4dcdb2f89d05cd9cd84f62316651b2a5967f2632668ebb": {
		functionName: "cancelBookingsWithRefund_createServerFn_handler",
		importer: () => import("./_ssr/refunds.functions-B8isndCU.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
