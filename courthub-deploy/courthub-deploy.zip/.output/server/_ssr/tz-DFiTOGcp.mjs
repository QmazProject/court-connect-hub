import { n as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tz-DFiTOGcp.js
var tz_DFiTOGcp_exports = /* @__PURE__ */ __exportAll({
	a: () => zonedDayOfWeek,
	i: () => zonedDayBoundsUtc,
	n: () => tz_exports,
	o: () => zonedHour,
	r: () => zonedDateISO,
	s: () => zonedHourToUtc,
	t: () => addZonedDays
});
var tz_exports = /* @__PURE__ */ __exportAll$1({
	DEFAULT_TIMEZONE: () => DEFAULT_TIMEZONE,
	addZonedDays: () => addZonedDays,
	zonedDateISO: () => zonedDateISO,
	zonedDayBoundsUtc: () => zonedDayBoundsUtc,
	zonedDayOfWeek: () => zonedDayOfWeek,
	zonedHour: () => zonedHour,
	zonedHourToUtc: () => zonedHourToUtc
});
var DEFAULT_TIMEZONE = "Asia/Manila";
/** Offset (ms) of `timeZone` from UTC at the given instant. */
function tzOffsetMs(instant, timeZone) {
	const dtf = new Intl.DateTimeFormat("en-US", {
		timeZone,
		hour12: false,
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	});
	const parts = Object.fromEntries(dtf.formatToParts(instant).map((p) => [p.type, p.value]));
	return Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day), Number(parts.hour) === 24 ? 0 : Number(parts.hour), Number(parts.minute), Number(parts.second)) - instant.getTime();
}
/** The UTC instant for `dateISO` (YYYY-MM-DD) at `hour`:00 local to `timeZone`. */
function zonedHourToUtc(dateISO, hour, timeZone = DEFAULT_TIMEZONE) {
	const naive = Date.UTC(Number(dateISO.slice(0, 4)), Number(dateISO.slice(5, 7)) - 1, Number(dateISO.slice(8, 10)), hour);
	let ts = naive - tzOffsetMs(new Date(naive), timeZone);
	ts = naive - tzOffsetMs(new Date(ts), timeZone);
	return new Date(ts);
}
/** Calendar date at an instant in the venue timezone. */
function zonedDateISO(instant = /* @__PURE__ */ new Date(), timeZone = DEFAULT_TIMEZONE) {
	const parts = Object.fromEntries(new Intl.DateTimeFormat("en-CA", {
		timeZone,
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).formatToParts(instant).map((part) => [part.type, part.value]));
	return `${parts.year}-${parts.month}-${parts.day}`;
}
/** Adds calendar days without involving the browser's local timezone. */
function addZonedDays(dateISO, days) {
	const date = /* @__PURE__ */ new Date(`${dateISO}T00:00:00Z`);
	date.setUTCDate(date.getUTCDate() + days);
	return date.toISOString().slice(0, 10);
}
/** Day of week for a date-only value: Sunday is 0, matching JS Date#getDay. */
function zonedDayOfWeek(dateISO) {
	return (/* @__PURE__ */ new Date(`${dateISO}T00:00:00Z`)).getUTCDay();
}
/** UTC bounds for a venue-local calendar date. */
function zonedDayBoundsUtc(dateISO, timeZone = DEFAULT_TIMEZONE) {
	return {
		start: zonedHourToUtc(dateISO, 0, timeZone),
		end: zonedHourToUtc(addZonedDays(dateISO, 1), 0, timeZone)
	};
}
/** Venue-local hour for a stored UTC instant. */
function zonedHour(instant, timeZone = DEFAULT_TIMEZONE) {
	const parts = new Intl.DateTimeFormat("en-US", {
		timeZone,
		hour: "2-digit",
		hourCycle: "h23"
	}).formatToParts(new Date(instant));
	return Number(parts.find((part) => part.type === "hour")?.value ?? "0");
}
//#endregion
export { zonedDayOfWeek as a, zonedDayBoundsUtc as i, tz_DFiTOGcp_exports as n, zonedHour as o, zonedDateISO as r, zonedHourToUtc as s, addZonedDays as t };
