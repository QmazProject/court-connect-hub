import { i as __toESM } from "../_runtime.mjs";
import { C as minRate, E as normalizeRules, I as rateInBounds, S as maxRate, T as normalizeHours, a as HOUR_DAY_KEYS, f as describeWindow, m as effectiveHours, p as distinctRates, v as hasVariablePricing } from "./court-pricing-CFeeeUa8.mjs";
import { t as supabase } from "./client-Dd0V2lPq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { M as redirect, _ as useNavigate, g as Link, m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as PopoverTrigger, i as PopoverContent, n as MapPicker, r as Popover } from "./popover-Z5PgJyYY.mjs";
import { $ as Eye, A as ReceiptText, B as MapPin, C as ShieldCheck, Ct as Accessibility, D as Search, I as Music2, J as Info, L as Menu, M as Play, N as Phone, Q as Facebook, R as Maximize2, S as SlidersHorizontal, V as Mail, X as Heart, Z as Handshake, at as CirclePlay, b as Star, c as User, ct as ChevronLeft, d as Twitter, et as Crosshair, f as Trophy, ht as Building2, l as UserPlus, lt as ChevronDown, mt as CalendarCheck2, ot as ChevronUp, pt as CalendarDays, q as Instagram, r as Wifi, rt as Clock3, s as UsersRound, st as ChevronRight, t as X, x as Sparkles, xt as ArrowLeft, yt as BellRing, z as Map$1 } from "../_libs/lucide-react.mjs";
import { n as PlayerShell } from "./PlayerShell-Re8It3Mk.mjs";
import { n as booleanType, o as objectType, s as stringType } from "../_libs/zod.mjs";
import { a as zonedDayOfWeek, r as zonedDateISO } from "./tz-DFiTOGcp.mjs";
import { t as RateCard } from "./RateCard-BjVMWMb4.mjs";
import { n as VenueMap, r as searchPhPlaces, t as PaymentRally } from "./ph-places-Ce4rPAEJ.mjs";
import { a as TERMS, i as PRIVACY, r as LegalReader, t as LEGAL_VERSION } from "./LegalDocument-B84apQRn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dvn3UgEW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var $$splitComponentImporter = () => import("./routes-C1A_oPeL.mjs");
function haversineKm(a, b) {
	const toRad = (v) => v * Math.PI / 180;
	const R = 6371;
	const dLat = toRad(b.lat - a.lat);
	const dLng = toRad(b.lng - a.lng);
	const s = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
	return 2 * R * Math.asin(Math.sqrt(s));
}
function GoogleGlyph({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 24 24",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#4285F4",
				d: "M23.52 12.27c0-.85-.08-1.67-.22-2.45H12v4.64h6.47a5.53 5.53 0 0 1-2.4 3.63v3h3.88c2.27-2.09 3.57-5.17 3.57-8.82Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#34A853",
				d: "M12 24c3.24 0 5.96-1.07 7.95-2.91l-3.88-3c-1.08.72-2.45 1.15-4.07 1.15-3.13 0-5.78-2.11-6.73-4.96H1.27v3.11A11.99 11.99 0 0 0 12 24Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#FBBC05",
				d: "M5.27 14.28A7.2 7.2 0 0 1 4.89 12c0-.79.14-1.56.38-2.28V6.61H1.27A11.99 11.99 0 0 0 0 12c0 1.94.46 3.77 1.27 5.39l4-3.11Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#EA4335",
				d: "M12 4.77c1.76 0 3.34.61 4.59 1.8l3.44-3.44C17.95 1.19 15.24 0 12 0A11.99 11.99 0 0 0 1.27 6.61l4 3.11C6.22 6.88 8.87 4.77 12 4.77Z"
			})
		]
	});
}
var GOOGLE_PENDING_ROLE_KEY = "courthub_google_pending_role";
function hasGoogleProvider(user) {
	return (user.app_metadata?.providers ?? (user.app_metadata?.provider ? [user.app_metadata.provider] : [])).includes("google");
}
function isFreshGoogleAccount(user) {
	if (!hasGoogleProvider(user)) return false;
	const createdAt = new Date(user.created_at).getTime();
	const lastSignIn = user.last_sign_in_at ? new Date(user.last_sign_in_at).getTime() : createdAt;
	return Math.abs(lastSignIn - createdAt) < 1e4;
}
var searchSchema = objectType({
	sport: stringType().optional(),
	explore: booleanType().optional().catch(false),
	signin: booleanType().optional().catch(false)
});
var Route = createFileRoute("/")({
	validateSearch: searchSchema,
	beforeLoad: ({ search }) => {
		if (search.explore) throw redirect({
			to: "/explore",
			search: { sport: search.sport }
		});
		throw redirect({
			to: "/landing",
			search: {
				signin: search.signin,
				sport: search.sport
			}
		});
	},
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: () => ({ meta: [
		{ title: "CourtHub — Find & book premium sports courts" },
		{
			name: "description",
			content: "Discover courts near you on the map, filter by sport and price, and book in seconds."
		},
		{
			property: "og:title",
			content: "CourtHub — Find & book premium sports courts"
		},
		{
			property: "og:description",
			content: "Map-first court discovery. Filter, browse and book premium venues."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] })
});
/** Shown under the Min/Max ₱/hr inputs and as their tooltip. The filter matches a
*  court's rate *range*, not every hour of it, so say so — otherwise "Max ₱500"
*  reads as a promise that no hour of the booking can cost more. */
/** Shown one at a time on the blurred backdrop beside the sign-in drawer. The first is the
*  brand line; the rest keep a long sign-in from staring at the same sentence. Each is
*  revealed, held, glazed and faded by `handwrite-loop`, and the next one is swapped in on
*  the animation's own iteration event, so the copy can never drift out of step with it. */
var SIGN_IN_TAGLINES = [
	"Where Every Game Feels Like Home",
	"Find Your Court, Find Your People",
	"Every Great Game Starts Here",
	"The Court Is Calling",
	"Play More, Plan Less"
];
var PRICE_FILTER_HINT = "Matches courts with at least one time slot in this price range. A court with time-based pricing counts if any hour falls inside it.";
function VenueExplorer({ sport, guestMode }) {
	const navigate = useNavigate({ from: "/" });
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const [collapsed, setCollapsed] = (0, import_react.useState)(false);
	const { data: player } = useQuery({
		queryKey: ["auth-player-session"],
		queryFn: async () => {
			const { data: { session } } = await supabase.auth.getSession();
			const user = session?.user;
			if (!user) return null;
			const { data: profile } = await supabase.from("profiles").select("role, full_name").eq("id", user.id).maybeSingle();
			const metadata = user.user_metadata;
			const role = profile?.role === "tenant" || metadata.role === "tenant" ? "tenant" : "player";
			return {
				id: user.id,
				email: user.email ?? "",
				name: profile?.full_name || (typeof metadata.full_name === "string" ? metadata.full_name : "") || user.email?.split("@")[0] || "Player",
				role
			};
		},
		staleTime: 1e3 * 60 * 10
	});
	const explorerQueryClient = useQueryClient();
	(0, import_react.useEffect)(() => {
		const { data: subscription } = supabase.auth.onAuthStateChange(() => {
			explorerQueryClient.invalidateQueries({ queryKey: ["auth-player-session"] });
		});
		return () => subscription.subscription.unsubscribe();
	}, [explorerQueryClient]);
	const { data: sports } = useQuery({
		queryKey: ["sports"],
		queryFn: async () => {
			const { data, error } = await supabase.from("sports").select("id, name, slug").order("name");
			if (error) throw error;
			return data;
		}
	});
	const [placeQuery, setPlaceQuery] = (0, import_react.useState)("");
	const [placeResults, setPlaceResults] = (0, import_react.useState)([]);
	/** Map viewport centre, used to bias place suggestions to what is on screen. */
	const mapCenterRef = (0, import_react.useRef)(null);
	/** Mirrors `nearby` so the debounced search can read it without re-subscribing. */
	const nearbyRef = (0, import_react.useRef)(null);
	const [placeNote, setPlaceNote] = (0, import_react.useState)(void 0);
	const [placeSearching, setPlaceSearching] = (0, import_react.useState)(false);
	const [placeOpen, setPlaceOpen] = (0, import_react.useState)(false);
	/** Full structured record for the place the user picked, kept for downstream use. */
	const [selectedPlace, setSelectedPlace] = (0, import_react.useState)(null);
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [filterSport, setFilterSport] = (0, import_react.useState)(sport ?? "");
	const [filterCity, setFilterCity] = (0, import_react.useState)("");
	const [minPrice, setMinPrice] = (0, import_react.useState)("");
	const [maxPrice, setMaxPrice] = (0, import_react.useState)("");
	const [nearby, setNearby] = (0, import_react.useState)(null);
	const [nearbyLoading, setNearbyLoading] = (0, import_react.useState)(false);
	const [nearbyError, setNearbyError] = (0, import_react.useState)(null);
	const [radiusKm, setRadiusKm] = (0, import_react.useState)(5);
	const [nationwide, setNationwide] = (0, import_react.useState)(false);
	const [manualPickerOpen, setManualPickerOpen] = (0, import_react.useState)(false);
	const [locationMode, setLocationMode] = (0, import_react.useState)(null);
	const [activeVenueId, setActiveVenueId] = (0, import_react.useState)(null);
	const [sheetExpanded, setSheetExpanded] = (0, import_react.useState)(false);
	const [dCity, setDCity] = (0, import_react.useState)(filterCity);
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => setDCity(filterCity), 250);
		return () => clearTimeout(t);
	}, [filterCity]);
	(0, import_react.useEffect)(() => {
		nearbyRef.current = nearby;
	}, [nearby]);
	(0, import_react.useEffect)(() => {
		const q = placeQuery.trim();
		if (q.length < 3) {
			setPlaceResults([]);
			setPlaceNote(void 0);
			setPlaceSearching(false);
			return;
		}
		const ctrl = new AbortController();
		const t = setTimeout(async () => {
			setPlaceSearching(true);
			try {
				const r = await searchPhPlaces(q, {
					signal: ctrl.signal,
					limit: 10,
					near: nearbyRef.current ?? mapCenterRef.current
				});
				if (ctrl.signal.aborted) return;
				setPlaceResults(r.results);
				setPlaceNote(r.note);
			} catch {} finally {
				if (!ctrl.signal.aborted) setPlaceSearching(false);
			}
		}, 400);
		return () => {
			ctrl.abort();
			clearTimeout(t);
		};
	}, [placeQuery]);
	const hasFilters = !!(filterSport || filterCity.trim() || minPrice || maxPrice);
	const { data: venues, isFetching } = useQuery({
		queryKey: [
			"venues-map",
			filterSport,
			dCity.trim().toLowerCase()
		],
		placeholderData: (prev) => prev,
		queryFn: async () => {
			const courtsSelect = !!filterSport ? "courts!inner(id, name, hourly_rate, rate_rules, inherit_venue_hours, operating_hours, map_emoji, images, sports!inner(slug, name))" : "courts(id, name, hourly_rate, rate_rules, inherit_venue_hours, operating_hours, map_emoji, images, sports(slug, name))";
			let q = supabase.from("venues").select(`id, name, address, latitude, longitude, map_emoji, images, operating_hours, ${courtsSelect}`).eq("is_active", true).order("name").limit(500);
			if (dCity.trim()) q = q.ilike("address", `%${dCity.trim()}%`);
			if (filterSport) q = q.eq("courts.sports.slug", filterSport);
			const { data, error } = await q;
			if (error) throw error;
			const sportDefault = (slug) => {
				switch (slug) {
					case "pickleball": return "🥎";
					case "tennis": return "🎾";
					case "basketball": return "🏀";
					case "table-tennis": return "🏓";
					case "badminton": return "🏸";
					case "volleyball": return "🏐";
					case "football":
					case "soccer": return "⚽";
					default: return null;
				}
			};
			return data.map((v) => {
				const courtHours = (c) => effectiveHours({
					inherit_venue_hours: c.inherit_venue_hours,
					operating_hours: c.operating_hours
				}, v.operating_hours);
				const courtRanges = v.courts?.map((c) => {
					const rules = normalizeRules(c.rate_rules);
					const base = Number(c.hourly_rate);
					const hrs = courtHours(c);
					return {
						lo: minRate(base, rules, hrs),
						hi: maxRate(base, rules, hrs)
					};
				}) ?? [];
				const sportSet = /* @__PURE__ */ new Map();
				v.courts?.forEach((c) => c.sports && sportSet.set(c.sports.slug, c.sports.name));
				return {
					id: v.id,
					name: v.name,
					address: v.address,
					latitude: v.latitude,
					longitude: v.longitude,
					courtCount: v.courts?.length ?? 0,
					minRate: courtRanges.length ? Math.min(...courtRanges.map((r) => r.lo)) : null,
					maxRate: courtRanges.length ? Math.max(...courtRanges.map((r) => r.hi)) : null,
					mapEmoji: v.map_emoji ?? null,
					images: v.images ?? [],
					operatingHours: v.operating_hours ?? null,
					courts: (v.courts ?? []).map((c) => {
						const base = Number(c.hourly_rate);
						const rules = normalizeRules(c.rate_rules);
						const hrs = courtHours(c);
						const lo = minRate(base, rules, hrs);
						const hi = maxRate(base, rules, hrs);
						return {
							id: c.id,
							name: c.name,
							hourly_rate: lo,
							rateMin: lo,
							rateMax: hi,
							baseRate: base,
							rateRules: rules,
							openHours: hrs,
							rateValues: distinctRates(base, rules, hrs),
							variableRate: hasVariablePricing(base, rules, hrs),
							mapEmoji: c.map_emoji ?? v.map_emoji ?? sportDefault(c.sports?.slug) ?? null,
							images: c.images ?? [],
							sportName: c.sports?.name ?? null
						};
					}),
					sports: Array.from(sportSet.values())
				};
			});
		}
	});
	/** Applies the Min/Max ₱/hr bounds to the *effective* price a court charges —
	*  the same figure its tile prints — rather than the raw `hourly_rate` column.
	*  A court with time-based pricing keeps a range, and matches when that range
	*  overlaps the filter at any hour (₱400–800 is a hit for "Min ₱450"). Venues
	*  survive only if at least one of their courts does, and `courtCount`/`minRate`
	*  are recomputed from the survivors so the card never advertises a price that
	*  was just filtered out. */
	/** The Min/Max ₱/hr as numbers, or null when the filter is off. Parsed once so
	*  the venue list and the rate card's highlighting read the same bounds. */
	const priceBounds = (0, import_react.useMemo)(() => {
		const lo = Number(minPrice);
		const hi = Number(maxPrice);
		const min = minPrice.trim() !== "" && Number.isFinite(lo) ? lo : null;
		const max = maxPrice.trim() !== "" && Number.isFinite(hi) ? hi : null;
		return min == null && max == null ? null : {
			min,
			max
		};
	}, [minPrice, maxPrice]);
	const priceFilteredVenues = (0, import_react.useMemo)(() => {
		if (!venues || !priceBounds) return venues;
		const kept = [];
		for (const v of venues) {
			const courts = v.courts.filter((c) => (c.rateValues ?? [c.hourly_rate]).some((r) => rateInBounds(r, priceBounds)));
			if (!courts.length) continue;
			kept.push({
				...v,
				courts,
				courtCount: courts.length,
				minRate: Math.min(...courts.map((c) => c.rateMin ?? c.hourly_rate)),
				maxRate: Math.max(...courts.map((c) => c.rateMax ?? c.hourly_rate))
			});
		}
		return kept;
	}, [venues, priceBounds]);
	const { list: sortedVenues, empty: nearbyEmpty, nearestSuggestion } = (0, import_react.useMemo)(() => {
		const venues = priceFilteredVenues;
		if (!venues) return {
			list: [],
			empty: false,
			nearestSuggestion: []
		};
		if (!nearby) return {
			list: venues,
			empty: false,
			nearestSuggestion: []
		};
		const withDistance = venues.map((v) => ({
			...v,
			distanceKm: v.latitude != null && v.longitude != null ? haversineKm(nearby, {
				lat: v.latitude,
				lng: v.longitude
			}) : null
		})).filter((v) => v.distanceKm != null).sort((a, b) => (a.distanceKm ?? 0) - (b.distanceKm ?? 0));
		if (nationwide) return {
			list: withDistance,
			empty: false,
			nearestSuggestion: []
		};
		const inRadius = withDistance.filter((v) => (v.distanceKm ?? 0) <= radiusKm);
		return {
			list: inRadius,
			empty: inRadius.length === 0,
			nearestSuggestion: withDistance.slice(0, 5)
		};
	}, [
		priceFilteredVenues,
		nearby,
		radiusKm,
		nationwide
	]);
	const [showNearestPeek, setShowNearestPeek] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!nearbyEmpty) setShowNearestPeek(false);
	}, [nearbyEmpty]);
	const requestNearby = () => {
		if (!("geolocation" in navigator)) {
			setNearbyError("Location not supported on this device.");
			return;
		}
		setNearbyLoading(true);
		setNearbyError(null);
		navigator.geolocation.getCurrentPosition((pos) => {
			setNearby({
				lat: pos.coords.latitude,
				lng: pos.coords.longitude
			});
			setLocationMode("gps");
			setNearbyLoading(false);
		}, (err) => {
			setNearbyError(err.message || "Please allow location access.");
			setNearbyLoading(false);
		}, {
			enableHighAccuracy: true,
			timeout: 1e4
		});
	};
	const saveManualLocation = (lat, lng) => {
		setNearby({
			lat,
			lng
		});
		setLocationMode("manual");
		setManualPickerOpen(false);
	};
	const resetAll = () => {
		setPlaceQuery("");
		setPlaceResults([]);
		setSelectedPlace(null);
		setFilterSport("");
		setFilterCity("");
		setMinPrice("");
		setMaxPrice("");
		setNearby(null);
		setNationwide(false);
		setActiveVenueId(null);
		setLocationMode(null);
		if (sport) navigate({ search: {} });
	};
	const displayVenues = showNearestPeek && nearbyEmpty ? nearestSuggestion : sortedVenues;
	const activeVenue = activeVenueId != null ? displayVenues.find((v) => v.id === activeVenueId) : null;
	const listRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (activeVenueId == null || !listRef.current) return;
		listRef.current.querySelector(`[data-vid="${activeVenueId}"]`)?.scrollIntoView({
			behavior: "smooth",
			block: "nearest"
		});
	}, [activeVenueId]);
	const exploreContent = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky top-0 z-900 border-b-2 border-[#b8f05a]/50 bg-linear-to-br from-[#0f4a40] to-[#09231f]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex w-full flex-col gap-2.5 px-4 py-3 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-lg font-extrabold tracking-tight text-[#b8f05a] sm:text-xl",
								children: "What are you playing today?"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-0.5 text-xs font-medium text-white/70 sm:text-sm",
								children: guestMode ? "Browse every venue and court. Booking opens once you sign in." : "Explore the map, filter by sport or price, and lock in your slot."
							})] }), guestMode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex shrink-0 flex-col items-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 rounded-full border border-[#b8f05a]/45 bg-[#b8f05a]/10 px-3 py-1 text-[11px] font-bold uppercase tracking-[.14em] text-[#d9ff9b]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-3.5 w-3.5" }), " Guest mode"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/landing",
										search: {},
										className: "inline-flex items-center gap-1 rounded-full border border-white/25 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[.1em] text-white/85 transition hover:-translate-y-0.5 hover:border-[#b8f05a] hover:bg-white/10 hover:text-white",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-3 w-3" }), " Back to home"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/landing",
										search: { signin: true },
										className: "inline-flex items-center gap-1 rounded-full bg-[#b8f05a] px-3 py-1.5 text-[11px] font-bold uppercase tracking-[.1em] text-[#102521] shadow-sm transition hover:-translate-y-0.5 hover:bg-[#d3ff87]",
										children: ["Sign in to book ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" })]
									})]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-1.5 border-t border-white/10 pt-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setFilterSport(""),
								className: "rounded-full border px-3 py-1 text-xs font-semibold transition " + (!filterSport ? "border-[#b8f05a] bg-[#b8f05a] text-[#102521] shadow-sm" : "border-white/20 bg-white/5 text-white/80 hover:border-[#b8f05a] hover:text-[#b8f05a]"),
								children: "All sports"
							}), (sports ?? []).map((s) => {
								const emoji = s.slug === "pickleball" ? "🥎" : s.slug === "tennis" ? "🎾" : s.slug === "basketball" ? "🏀" : s.slug === "table-tennis" ? "🏓" : s.slug === "badminton" ? "🏸" : s.slug === "volleyball" ? "🏐" : s.slug === "football" || s.slug === "soccer" ? "⚽" : "🏟️";
								const active = filterSport === s.slug;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setFilterSport(active ? "" : s.slug),
									className: "flex items-center gap-1 rounded-full border px-3 py-1 text-xs font-semibold transition " + (active ? "border-[#b8f05a] bg-[#b8f05a] text-[#102521] shadow-sm" : "border-white/20 bg-white/5 text-white/80 hover:border-[#b8f05a] hover:text-[#b8f05a]"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											"aria-hidden": true,
											children: emoji
										}),
										" ",
										s.name
									]
								}, s.id);
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-2 transition focus-within:border-[#b8f05a] focus-within:ring-2 focus-within:ring-[#b8f05a]/30",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
												className: "h-4 w-4 shrink-0 text-[#b8f05a]",
												"aria-hidden": true
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "text",
												value: placeQuery,
												onChange: (e) => {
													setPlaceQuery(e.target.value);
													setPlaceOpen(true);
												},
												onFocus: () => setPlaceOpen(true),
												onBlur: () => setTimeout(() => setPlaceOpen(false), 150),
												placeholder: "Search a place or landmark — e.g. Ayala Center Cebu…",
												className: "w-full min-w-0 bg-transparent text-sm text-white outline-none placeholder:text-white/50"
											}),
											placeQuery && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => {
													setPlaceQuery("");
													setPlaceResults([]);
												},
												className: "text-white/60 hover:text-[#b8f05a]",
												"aria-label": "Clear",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
											})
										]
									}), placeOpen && placeQuery.trim().length >= 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "absolute left-0 right-0 top-full z-1000 mt-1 max-h-72 overflow-y-auto rounded-2xl border-2 border-[#0f4a40] bg-[#09231f] py-1 shadow-xl ring-1 ring-[#b8f05a]/50",
										children: [
											placeSearching && placeResults.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
												className: "px-3 py-2 text-xs text-white/60",
												children: "Searching…"
											}),
											!placeSearching && placeResults.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
												className: "px-3 py-2 text-xs text-white/60",
												children: placeNote ?? "No places found."
											}),
											placeResults.length > 0 && placeNote && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
												className: "border-b border-white/10 px-3 py-1.5 text-[10px] italic text-white/50",
												children: placeNote
											}),
											placeResults.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													setSelectedPlace(r);
													setNearby({
														lat: r.lat,
														lng: r.lng
													});
													setLocationMode("manual");
													setNationwide(false);
													setActiveVenueId(null);
													setPlaceQuery(r.label);
													setPlaceOpen(false);
												},
												className: "flex w-full items-start gap-2 px-3 py-2 text-left transition hover:bg-[#b8f05a]/15",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-3.5 w-3.5 shrink-0 text-[#b8f05a]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "min-w-0 flex-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "flex items-center gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "min-w-0 truncate text-xs font-bold text-[#b8f05a]",
															children: r.label
														}), r.approximate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "shrink-0 rounded-full bg-amber-400/20 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-amber-200",
															children: "approx"
														})]
													}), r.displaySuffix && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "block truncate text-[11px] text-white/60",
														children: r.displaySuffix.replace(/^,\s*/, "")
													})]
												})]
											}) }, r.id))
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setFilterOpen((v) => !v),
									className: "flex h-10 shrink-0 items-center gap-1.5 rounded-full border px-3 text-sm font-semibold transition " + (hasFilters || filterOpen ? "border-[#b8f05a] bg-[#b8f05a]/20 text-[#b8f05a]" : "border-white/20 bg-white/5 text-white/80 hover:border-[#b8f05a] hover:text-[#b8f05a]"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "h-4 w-4" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden sm:inline",
											children: "Filters"
										}),
										hasFilters && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-[#b8f05a] px-1.5 text-[10px] font-bold text-[#102521]",
											children: "•"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: requestNearby,
									disabled: nearbyLoading,
									className: "flex h-10 shrink-0 items-center gap-1.5 rounded-full border px-3 text-sm font-semibold transition " + (nearby && locationMode === "gps" ? "border-[#b8f05a] bg-[#b8f05a] text-[#102521]" : "border-white/20 bg-white/5 text-white/80 hover:border-[#b8f05a] hover:text-[#b8f05a]"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: nearbyLoading ? "Locating…" : "Nearby"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setManualPickerOpen(true),
									className: "flex h-10 shrink-0 items-center gap-1.5 rounded-full border px-3 text-sm font-semibold transition " + (nearby && locationMode === "manual" ? "border-[#b8f05a] bg-[#b8f05a] text-[#102521]" : "border-white/20 bg-white/5 text-white/80 hover:border-[#b8f05a] hover:text-[#b8f05a]"),
									title: "Pin your location manually — search a place or paste coordinates",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crosshair, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: "Pin manually"
									})]
								})
							]
						}),
						filterOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 rounded-2xl border border-white/15 bg-white/5 p-3 sm:grid-cols-2 lg:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-semibold uppercase tracking-wider text-[#b8f05a]",
										children: "Sport"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: filterSport,
										onChange: (e) => setFilterSport(e.target.value),
										className: "mt-1 w-full rounded-lg border border-white/20 bg-[#09231f] px-3 py-2 text-sm text-white outline-none placeholder:text-white/40 focus:border-[#b8f05a]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Any sport"
										}), (sports ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: s.slug,
											children: s.name
										}, s.id))]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-semibold uppercase tracking-wider text-[#b8f05a]",
										children: "City / Province"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										value: filterCity,
										onChange: (e) => setFilterCity(e.target.value),
										placeholder: "e.g. Cebu, Makati",
										className: "mt-1 w-full rounded-lg border border-white/20 bg-[#09231f] px-3 py-2 text-sm text-white outline-none placeholder:text-white/40 focus:border-[#b8f05a]"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									title: PRICE_FILTER_HINT,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-semibold uppercase tracking-wider text-[#b8f05a]",
										children: "Min available ₱/hr"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										min: 0,
										value: minPrice,
										onChange: (e) => setMinPrice(e.target.value),
										placeholder: "0",
										"aria-describedby": "price-filter-hint",
										className: "mt-1 w-full rounded-lg border border-white/20 bg-[#09231f] px-3 py-2 text-sm text-white outline-none placeholder:text-white/40 focus:border-[#b8f05a]"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									title: PRICE_FILTER_HINT,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[11px] font-semibold uppercase tracking-wider text-[#b8f05a]",
										children: "Max available ₱/hr"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										min: 0,
										value: maxPrice,
										onChange: (e) => setMaxPrice(e.target.value),
										placeholder: "Any",
										"aria-describedby": "price-filter-hint",
										className: "mt-1 w-full rounded-lg border border-white/20 bg-[#09231f] px-3 py-2 text-sm text-white outline-none placeholder:text-white/40 focus:border-[#b8f05a]"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									id: "price-filter-hint",
									className: "col-span-full text-[11px] leading-snug text-white/60",
									children: PRICE_FILTER_HINT
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "col-span-full flex items-center justify-between pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-white/70",
										children: [
											sortedVenues.length,
											" ",
											sortedVenues.length === 1 ? "venue" : "venues",
											" match"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: resetAll,
										className: "text-xs font-semibold text-[#b8f05a] hover:underline",
										children: "Clear all"
									})]
								})
							]
						}),
						nearby && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 rounded-2xl border border-[#b8f05a]/30 bg-[#b8f05a]/10 px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 text-xs font-semibold text-[#b8f05a]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-3.5 w-3.5" }),
											nationwide ? "Nationwide · sorted by distance" : selectedPlace ? `Within ${radiusKm} km of ${selectedPlace.label}` : `Within ${radiusKm} km`,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "ml-1 rounded-full bg-[#b8f05a]/20 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[#b8f05a]",
												children: locationMode === "manual" ? "Manual pin" : "GPS"
											}),
											locationMode === "manual" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setManualPickerOpen(true),
												className: "text-[11px] font-semibold text-[#b8f05a] underline underline-offset-2 hover:opacity-80",
												children: "Edit"
											})
										]
									}),
									!nationwide && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "range",
										min: 1,
										max: 100,
										step: 1,
										value: radiusKm,
										onChange: (e) => setRadiusKm(Number(e.target.value)),
										className: "h-1.5 flex-1 min-w-35 cursor-pointer accent-primary",
										"aria-label": "Search radius in kilometers"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1",
										children: [
											[
												2,
												5,
												10,
												25
											].map((km) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setRadiusKm(km),
												className: "rounded-full border px-2 py-0.5 text-[11px] font-semibold transition " + (radiusKm === km ? "border-[#b8f05a] bg-[#b8f05a] text-[#102521]" : "border-white/20 bg-white/5 text-white/80 hover:border-[#b8f05a] hover:text-[#b8f05a]"),
												children: [km, "km"]
											}, km)),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												min: 1,
												max: 500,
												value: radiusKm,
												onChange: (e) => {
													const n = Number(e.target.value);
													if (Number.isFinite(n) && n > 0) setRadiusKm(Math.min(500, Math.max(1, Math.round(n))));
												},
												className: "w-14 rounded-full border border-white/20 bg-white/10 px-2 py-0.5 text-[11px] font-semibold text-white outline-none focus:border-[#b8f05a]",
												"aria-label": "Custom radius in kilometers"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] text-white/70",
												children: "km"
											})
										]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setNationwide((v) => !v),
										className: "rounded-full border px-2.5 py-0.5 text-[11px] font-semibold transition " + (nationwide ? "border-[#b8f05a] bg-[#b8f05a] text-[#102521]" : "border-white/20 bg-white/5 text-white/80 hover:border-[#b8f05a] hover:text-[#b8f05a]"),
										children: "🌏 Nationwide"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] text-white/70",
										children: [
											sortedVenues.length,
											" ",
											sortedVenues.length === 1 ? "venue" : "venues"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											setNearby(null);
											setNationwide(false);
											setShowNearestPeek(false);
											setLocationMode(null);
										},
										className: "ml-auto text-[11px] font-semibold text-white/70 hover:text-[#b8f05a]",
										children: "Clear location"
									})
								]
							}), !nationwide && nearbyEmpty && radiusKm >= 25 && nearestSuggestion.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2 rounded-lg border border-amber-400/40 bg-amber-50 px-2.5 py-1.5 text-[11px] text-amber-900 dark:bg-amber-500/10 dark:text-amber-200",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-semibold",
										children: [
											"No venues within ",
											radiusKm,
											" km."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Try a wider search:" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "ml-auto flex flex-wrap items-center gap-1",
										children: [
											[
												50,
												100,
												200
											].filter((km) => km > radiusKm).map((km) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setRadiusKm(km),
												className: "rounded-full border border-amber-500/50 bg-white/60 px-2 py-0.5 font-semibold text-amber-900 hover:bg-white dark:bg-transparent dark:text-amber-100",
												children: [
													"Expand to ",
													km,
													"km"
												]
											}, km)),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setShowNearestPeek((v) => !v),
												className: "rounded-full border border-amber-500/50 bg-white/60 px-2 py-0.5 font-semibold text-amber-900 hover:bg-white dark:bg-transparent dark:text-amber-100",
												children: showNearestPeek ? "Hide nearest" : "Show 5 nearest"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setNationwide(true),
												className: "rounded-full border border-primary bg-primary px-2 py-0.5 font-semibold text-primary-foreground hover:opacity-90",
												children: "Show nationwide"
											})
										]
									})
								]
							})]
						}),
						nearbyError && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: nearbyError }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setNearbyError(null),
								"aria-label": "Dismiss",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5" })
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative flex w-full flex-1 min-h-0 flex-col",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex flex-1 min-h-0 overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative m-3 flex-1 min-h-0 overflow-hidden rounded-2xl border-2 border-[#0f4a40] shadow-sm ring-1 ring-[#b8f05a]/50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenueMap, {
								venues: displayVenues,
								activeVenueId,
								onSelectVenue: setActiveVenueId,
								onOpenVenue: (id) => navigate({
									to: "/venues/$venueId",
									params: { venueId: String(id) },
									search: {}
								}),
								onOpenCourt: (id) => navigate({
									to: "/courts/$courtId",
									params: { courtId: String(id) },
									search: {}
								}),
								nearby,
								radiusKm: nearby && !nationwide ? radiusKm : null,
								radiusHasMatches: !nearbyEmpty,
								centerRef: mapCenterRef
							}), isFetching && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute right-3 top-3 z-500 rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold text-muted-foreground shadow-md",
								children: "Updating…"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
							className: "my-3 mr-3 hidden w-[38%] min-w-[380px] shrink-0 min-h-0 overflow-hidden rounded-2xl border-2 border-[#0f4a40] bg-[#f6f8f7] shadow-sm ring-1 ring-[#b8f05a]/50 dark:bg-[#0b2b26] md:flex md:flex-col",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenueList, {
								venues: displayVenues,
								activeVenueId,
								onSelectVenue: setActiveVenueId,
								activeVenue,
								listRef,
								priceFilter: priceBounds
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pointer-events-none absolute inset-x-0 bottom-0 z-600 md:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pointer-events-auto flex flex-col rounded-t-3xl border-t border-[#0f4a40]/15 bg-[#f6f8f7] shadow-2xl transition-[height] duration-300 dark:border-white/10 dark:bg-[#0b2b26] " + (sheetExpanded ? "h-[70vh]" : "h-[42vh]"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setSheetExpanded((v) => !v),
									className: "flex flex-col items-center gap-1 py-2",
									"aria-label": sheetExpanded ? "Collapse list" : "Expand list",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-10 rounded-full bg-border" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground",
										children: [
											sheetExpanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3 w-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "h-3 w-3" }),
											sortedVenues.length,
											" ",
											sortedVenues.length === 1 ? "venue" : "venues"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenueList, {
									venues: displayVenues,
									activeVenueId,
									onSelectVenue: (id) => {
										setActiveVenueId(id);
										if (id != null) setSheetExpanded(false);
									},
									activeVenue,
									listRef,
									priceFilter: priceBounds
								})]
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPicker, {
				open: manualPickerOpen,
				initialLat: nearby?.lat ?? null,
				initialLng: nearby?.lng ?? null,
				onClose: () => setManualPickerOpen(false),
				onSave: saveManualLocation,
				title: "Pin your location"
			})
		]
	});
	if (player && player.role !== "tenant") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerShell, {
		section: "explore",
		mobileOpen,
		setMobileOpen,
		collapsed,
		setCollapsed,
		userId: player.id,
		fullName: player.name,
		onSignOut: async () => {
			await supabase.auth.signOut();
			window.location.href = "/";
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full w-full flex-1 min-h-0",
			children: exploreContent
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-full w-full flex-1 min-h-0",
		children: exploreContent
	});
}
/** Keep this in the order the sections appear down the page. It drives both the desktop
*  pill nav and the mobile menu, and the scroll spy lights the entry matching whichever
*  section is on screen — so a mismatch makes the highlight jump backwards as you scroll. */
var landingNav = [
	"Home",
	"Venues",
	"How It Works",
	"Learn Sports",
	"Upcoming Events",
	"Features",
	"Highlights",
	"About",
	"Contact"
];
/** Content for the Learn Sports panel. Editorial copy, not database rows — these are the
*  rules of each game, which do not change per venue and have no business being fetched. */
/** Dots thrown by the back-to-top burst. Angles are evenly spread with a small per-dot
*  offset so it does not read as a wheel, distances vary, and every dy carries a +12px
*  downward bias so the dots fall as they fade — that fall is the difference between a
*  shower and a ring. Derived from the index, not Math.random, so it is identical every
*  time it fires and stays reviewable. */
/** Embers that drip off the fuse while it travels. One shared 1.2s loop with offset delays
*  reads as continuous rain without needing five separate animation utilities. */
var FUSE_EMBERS = [
	{
		ex: -3,
		delay: 0
	},
	{
		ex: 1,
		delay: .24
	},
	{
		ex: 4,
		delay: .48
	},
	{
		ex: -1,
		delay: .72
	},
	{
		ex: 3,
		delay: .96
	}
];
var SHOWER_DOTS = Array.from({ length: 14 }, (_, i) => {
	const angle = i / 14 * Math.PI * 2 + i % 3 * .22;
	const distance = 20 + i * 7 % 16;
	return {
		dx: Math.cos(angle) * distance,
		dy: Math.sin(angle) * distance + 12,
		size: i % 3 === 0 ? 3 : 2,
		delay: i % 5 * 28
	};
});
var learnSports = [
	{
		slug: "pickleball",
		photo: "https://images.pexels.com/photos/34618472/pexels-photo-34618472.jpeg?auto=compress&cs=tinysrgb&w=900&h=560&fit=crop",
		facts: [
			{
				label: "Players",
				value: "Singles or doubles"
			},
			{
				label: "Court",
				value: "20 × 44 ft"
			},
			{
				label: "Game",
				value: "First to 11, win by 2"
			}
		],
		name: "Pickleball",
		emoji: "🥎",
		blurb: "The fastest-growing racket sport in the country. Easy to pick up in an afternoon, hard to put down.",
		rules: [
			"Serve underhand and diagonally, with both feet behind the baseline.",
			"The two-bounce rule: the serve and the return must each bounce before anyone volleys.",
			"Stay out of the non-volley zone — the kitchen — when hitting a ball out of the air.",
			"Games run to 11, win by 2. Only the serving side scores."
		]
	},
	{
		slug: "basketball",
		photo: "https://images.pexels.com/photos/16599399/pexels-photo-16599399.jpeg?auto=compress&cs=tinysrgb&w=900&h=560&fit=crop",
		facts: [
			{
				label: "Players",
				value: "5 a side"
			},
			{
				label: "Ring height",
				value: "10 ft / 3.05 m"
			},
			{
				label: "Format",
				value: "Four quarters"
			}
		],
		name: "Basketball",
		emoji: "🏀",
		blurb: "Five a side, one ring, endless variations. The half-court game is the backbone of local play.",
		rules: [
			"Two points inside the arc, three from beyond it, one from the free-throw line.",
			"Keep your dribble alive — picking the ball up and restarting is a double dribble.",
			"Move the ball past half-court within eight seconds and shoot within the shot clock.",
			"Five fouls and you are out; team fouls send the other side to the line."
		]
	},
	{
		slug: "tennis",
		photo: "https://images.pexels.com/photos/28625142/pexels-photo-28625142.jpeg?auto=compress&cs=tinysrgb&w=900&h=560&fit=crop",
		facts: [
			{
				label: "Players",
				value: "Singles or doubles"
			},
			{
				label: "Points",
				value: "15 · 30 · 40 · game"
			},
			{
				label: "Set",
				value: "First to 6, win by 2"
			}
		],
		name: "Tennis",
		emoji: "🎾",
		blurb: "Singles or doubles, the classic court game — long rallies, sharp angles, and a scoring system all its own.",
		rules: [
			"Serve diagonally into the opposite service box; you get two attempts.",
			"Points climb 15, 30, 40, game — and deuce needs two clear points to settle.",
			"Six games take a set, but you must lead by two; 6–6 goes to a tiebreak.",
			"The ball may bounce once on your side before you return it."
		]
	},
	{
		slug: "badminton",
		photo: "https://images.pexels.com/photos/19902436/pexels-photo-19902436.jpeg?auto=compress&cs=tinysrgb&w=900&h=560&fit=crop",
		facts: [
			{
				label: "Players",
				value: "Singles or doubles"
			},
			{
				label: "Game",
				value: "Rally to 21, win by 2"
			},
			{
				label: "Hard cap",
				value: "30 points"
			}
		],
		name: "Badminton",
		emoji: "🏸",
		blurb: "The quickest racket sport there is. Deceptive, tactical, and brutal on the calves.",
		rules: [
			"Serve underarm below the waist, diagonally into the service court.",
			"Rally scoring to 21, win by 2, with a hard cap at 30.",
			"The shuttle may only be struck once per side — no carrying, no double hits.",
			"A shuttle landing on the line is in."
		]
	},
	{
		slug: "volleyball",
		photo: "https://images.pexels.com/photos/6203559/pexels-photo-6203559.jpeg?auto=compress&cs=tinysrgb&w=900&h=560&fit=crop",
		facts: [
			{
				label: "Players",
				value: "6 a side"
			},
			{
				label: "Touches",
				value: "3 per side"
			},
			{
				label: "Set",
				value: "Rally to 25, win by 2"
			}
		],
		name: "Volleyball",
		emoji: "🏐",
		blurb: "Six a side, three touches, one net. Positioning and communication beat raw power most nights.",
		rules: [
			"Three touches per side at most, and no player may touch it twice in a row.",
			"Rally scoring to 25, win by 2; the deciding set is played to 15.",
			"Win the rally on serve-receive and your team rotates one position clockwise.",
			"Back-row players cannot attack from in front of the attack line."
		]
	},
	{
		slug: "table-tennis",
		photo: "https://images.pexels.com/photos/38446271/pexels-photo-38446271.jpeg?auto=compress&cs=tinysrgb&w=900&h=560&fit=crop",
		facts: [
			{
				label: "Players",
				value: "Singles or doubles"
			},
			{
				label: "Game",
				value: "First to 11, win by 2"
			},
			{
				label: "Serve",
				value: "Alternates every 2 points"
			}
		],
		name: "Table Tennis",
		emoji: "🏓",
		blurb: "Small table, tiny margins. Spin does most of the work once you know how to read it.",
		rules: [
			"The serve must bounce on your half first, then clear the net onto theirs.",
			"Serves alternate every two points, whoever wins them.",
			"Games run to 11, win by 2.",
			"Let the ball bounce once on your side — volleying it is a lost point."
		]
	}
];
var headerMegaMenuItems = {
	Venues: {
		eyebrow: "Partner venues",
		title: "Places to play, right now",
		copy: "Real courts from venues already on CourtHub — hours, sports, and starting rates, straight from the venue.",
		items: []
	},
	"Upcoming Events": {
		eyebrow: "Coming soon",
		title: "More ways to get in the game",
		copy: "Partner venues will soon share local activities directly on CourtHub.",
		items: [
			{
				title: "Tournaments",
				copy: "Competition dates, brackets, and venue announcements.",
				soon: true
			},
			{
				title: "Open play & leagues",
				copy: "Find recurring games and community sessions.",
				soon: true
			},
			{
				title: "Community events",
				copy: "Local gatherings, clinics, and special game days.",
				soon: true
			}
		]
	},
	Highlights: {
		eyebrow: "Community highlights",
		title: "The stories behind the game",
		copy: "Browse the moments, people, and events that make the CourtHub community move.",
		items: []
	}
};
var heroImages = [
	"https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?auto=format&fit=crop&w=1800&q=85",
	"https://images.unsplash.com/photo-1518065896235-a4c93e088e7a?auto=format&fit=crop&w=1800&q=85",
	"https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=1800&q=85",
	"https://images.unsplash.com/photo-1592656094267-764a45160876?auto=format&fit=crop&w=1800&q=85"
];
/** Mounted by /landing. `signin` arrives as a prop rather than via Route.useSearch(), which
*  would have kept reading the "/" route's search and broken once this moved. `from` still
*  names /landing so the search updater below types against that route's schema. */
function LandingPage({ signin, signup }) {
	const navigate = useNavigate({ from: "/landing" });
	const queryClient = useQueryClient();
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [activeSection, setActiveSection] = (0, import_react.useState)("Home");
	const howItWorksRef = (0, import_react.useRef)(null);
	const [stepsLit, setStepsLit] = (0, import_react.useState)(false);
	const [openStep, setOpenStep] = (0, import_react.useState)(null);
	const featuresRef = (0, import_react.useRef)(null);
	const [featuresLit, setFeaturesLit] = (0, import_react.useState)(false);
	const whyRef = (0, import_react.useRef)(null);
	const [whyLit, setWhyLit] = (0, import_react.useState)(false);
	const venuesRef = (0, import_react.useRef)(null);
	const [venuesLit, setVenuesLit] = (0, import_react.useState)(false);
	const [activeSport, setActiveSport] = (0, import_react.useState)("pickleball");
	const [heroIndex, setHeroIndex] = (0, import_react.useState)(0);
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	const [highlightOpen, setHighlightOpen] = (0, import_react.useState)(null);
	const [stripPaused, setStripPaused] = (0, import_react.useState)(false);
	const [contactNotice, setContactNotice] = (0, import_react.useState)(false);
	const venueRailRef = (0, import_react.useRef)(null);
	const [headerHighlightKey, setHeaderHighlightKey] = (0, import_react.useState)("tournament");
	const [likedStories, setLikedStories] = (0, import_react.useState)({});
	const stripRef = (0, import_react.useRef)(null);
	const stripResumeTimer = (0, import_react.useRef)(void 0);
	const [socialSoon, setSocialSoon] = (0, import_react.useState)(null);
	const socialSoonTimer = (0, import_react.useRef)(void 0);
	const [headerSolid, setHeaderSolid] = (0, import_react.useState)(false);
	const [headerHidden, setHeaderHidden] = (0, import_react.useState)(false);
	const [headerHovering, setHeaderHovering] = (0, import_react.useState)(false);
	const [showBackToTop, setShowBackToTop] = (0, import_react.useState)(false);
	const [scrollProgress, setScrollProgress] = (0, import_react.useState)(0);
	const [burstKey, setBurstKey] = (0, import_react.useState)(0);
	const wasAtBottom = (0, import_react.useRef)(false);
	const [activeHeaderMenu, setActiveHeaderMenu] = (0, import_react.useState)(null);
	const [signInOpen, setSignInOpen] = (0, import_react.useState)(false);
	const [signInClosing, setSignInClosing] = (0, import_react.useState)(false);
	const signInCloseTimer = (0, import_react.useRef)(void 0);
	const [taglineIndex, setTaglineIndex] = (0, import_react.useState)(0);
	const [signInEmail, setSignInEmail] = (0, import_react.useState)("");
	const [signInPassword, setSignInPassword] = (0, import_react.useState)("");
	const [signInError, setSignInError] = (0, import_react.useState)(null);
	const [signInBusy, setSignInBusy] = (0, import_react.useState)(false);
	const [authSheetStep, setAuthSheetStep] = (0, import_react.useState)("signin");
	const [signupRole, setSignupRole] = (0, import_react.useState)(null);
	const [showRoleGuide, setShowRoleGuide] = (0, import_react.useState)(false);
	const [signupName, setSignupName] = (0, import_react.useState)("");
	const [signupPhone, setSignupPhone] = (0, import_react.useState)("");
	const [legalAccepted, setLegalAccepted] = (0, import_react.useState)(false);
	const [legalOpen, setLegalOpen] = (0, import_react.useState)(null);
	const [legalTouched, setLegalTouched] = (0, import_react.useState)(false);
	const [player, setPlayer] = (0, import_react.useState)(null);
	const [bookingPromptOpen, setBookingPromptOpen] = (0, import_react.useState)(false);
	const [bookingPromptClosing, setBookingPromptClosing] = (0, import_react.useState)(false);
	const bookingPromptTimer = (0, import_react.useRef)(void 0);
	const pendingVenueRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		let mounted = true;
		const hydrateAccount = async () => {
			const { data: { user } } = await supabase.auth.getUser();
			if (!user) {
				if (mounted) setPlayer(null);
				return;
			}
			const pendingRole = sessionStorage.getItem(GOOGLE_PENDING_ROLE_KEY);
			if ((pendingRole === "player" || pendingRole === "tenant") && hasGoogleProvider(user)) {
				sessionStorage.removeItem(GOOGLE_PENDING_ROLE_KEY);
				await supabase.from("profiles").update({ role: pendingRole }).eq("id", user.id);
				await supabase.auth.updateUser({ data: { role: pendingRole } });
			} else if (isFreshGoogleAccount(user)) {
				await supabase.auth.signOut();
				if (mounted) {
					setPlayer(null);
					setAuthSheetStep("signin");
					setSignInError("We couldn't find a CourtHub account for that Google account. Please create one first.");
					setSignInOpen(true);
				}
				return;
			}
			const { data: profile } = await supabase.from("profiles").select("role, full_name").eq("id", user.id).maybeSingle();
			const metadata = user.user_metadata;
			if ((profile?.role === "tenant" || metadata.role === "tenant" ? "tenant" : "player") === "tenant") {
				navigate({
					to: "/dashboard",
					replace: true
				});
				return;
			}
			if (mounted) {
				setPlayer({
					id: user.id,
					email: user.email ?? "",
					name: profile?.full_name || (typeof metadata.full_name === "string" ? metadata.full_name : "") || user.email?.split("@")[0] || "Player"
				});
				const intendedVenue = pendingVenueRef.current;
				pendingVenueRef.current = null;
				navigate(intendedVenue ? {
					to: "/venues/$venueId",
					params: { venueId: intendedVenue },
					search: {},
					replace: true
				} : {
					to: "/explore",
					search: {},
					replace: true
				});
			}
		};
		hydrateAccount();
		const { data: subscription } = supabase.auth.onAuthStateChange(() => {
			hydrateAccount();
			queryClient.invalidateQueries({ queryKey: ["auth-player-session"] });
		});
		return () => {
			mounted = false;
			subscription.subscription.unsubscribe();
		};
	}, [navigate]);
	const featuredQ = useQuery({
		queryKey: ["landing-featured-venues"],
		queryFn: async () => {
			const { data, error } = await supabase.from("venues").select("id, name, address, images, map_emoji, operating_hours, courts(id, name, hourly_rate, rate_rules, operating_hours, inherit_venue_hours, sports(name))").eq("is_active", true).order("created_at", { ascending: false }).limit(25);
			if (error) throw error;
			return data ?? [];
		}
	});
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setHeroIndex((index) => (index + 1) % heroImages.length), 6e3);
		return () => window.clearInterval(timer);
	}, []);
	(0, import_react.useEffect)(() => {
		const scroller = document.querySelector("main");
		let settleTimer;
		const update = () => {
			const scrollTop = scroller?.scrollTop ?? window.scrollY;
			setHeaderSolid(scrollTop > 24);
			setShowBackToTop(scrollTop > 360);
			const maxScroll = scroller ? scroller.scrollHeight - scroller.clientHeight : document.documentElement.scrollHeight - window.innerHeight;
			setScrollProgress(maxScroll > 0 ? Math.min(1, Math.max(0, scrollTop / maxScroll)) : 0);
			setHeaderHidden(false);
			if (settleTimer) window.clearTimeout(settleTimer);
			if (scrollTop > 24 && !headerHovering && !activeHeaderMenu) settleTimer = window.setTimeout(() => setHeaderHidden(true), 1100);
		};
		update();
		scroller?.addEventListener("scroll", update, { passive: true });
		window.addEventListener("scroll", update, { passive: true });
		return () => {
			if (settleTimer) window.clearTimeout(settleTimer);
			scroller?.removeEventListener("scroll", update);
			window.removeEventListener("scroll", update);
		};
	}, [activeHeaderMenu, headerHovering]);
	(0, import_react.useEffect)(() => {
		const sections = landingNav.map((name) => document.getElementById(name.toLowerCase().replaceAll(" ", "-"))).filter(Boolean);
		const observer = new IntersectionObserver((entries) => {
			const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
			if (visible) setActiveSection(visible.target.dataset.nav);
		}, {
			rootMargin: "-35% 0px -55% 0px",
			threshold: [
				.01,
				.2,
				.5
			]
		});
		sections.forEach((section) => observer.observe(section));
		return () => observer.disconnect();
	}, []);
	const shardStyle = (i, delayBase) => {
		const col = i % 4;
		const row = Math.floor(i / 4);
		const rot = (i % 2 === 0 ? 1 : -1) * (10 + i * 13 % 16);
		return {
			"--dx": `${(col - 1.5) * 46}px`,
			"--dy": `${(row - 1.5) * 46}px`,
			"--rot": `${rot}deg`,
			animationDelay: `${delayBase + col * 18 + row * 26}ms`
		};
	};
	(0, import_react.useEffect)(() => {
		const el = featuresRef.current;
		if (!el) return;
		const observer = new IntersectionObserver(([entry]) => setFeaturesLit(entry.isIntersecting), { threshold: .12 });
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		const el = whyRef.current;
		if (!el) return;
		const observer = new IntersectionObserver(([entry]) => setWhyLit(entry.isIntersecting), { threshold: .15 });
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		const el = venuesRef.current;
		if (!el) return;
		const observer = new IntersectionObserver(([entry]) => setVenuesLit(entry.isIntersecting), { threshold: .15 });
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		const el = howItWorksRef.current;
		if (!el) return;
		const observer = new IntersectionObserver(([entry]) => setStepsLit(entry.isIntersecting), { threshold: .3 });
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	const scrollTo = (name) => {
		document.getElementById(name.toLowerCase().replaceAll(" ", "-"))?.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
		setMenuOpen(false);
	};
	const pauseStrip = () => {
		if (stripResumeTimer.current) window.clearTimeout(stripResumeTimer.current);
		setStripPaused(true);
	};
	const resumeStrip = (delay = 0) => {
		if (stripResumeTimer.current) window.clearTimeout(stripResumeTimer.current);
		if (delay <= 0) {
			setStripPaused(false);
			return;
		}
		stripResumeTimer.current = window.setTimeout(() => setStripPaused(false), delay);
	};
	(0, import_react.useEffect)(() => () => {
		if (stripResumeTimer.current) window.clearTimeout(stripResumeTimer.current);
	}, []);
	const noteSocialSoon = (network) => {
		if (socialSoonTimer.current) window.clearTimeout(socialSoonTimer.current);
		setSocialSoon(network);
		socialSoonTimer.current = window.setTimeout(() => setSocialSoon(null), 2400);
	};
	(0, import_react.useEffect)(() => () => {
		if (socialSoonTimer.current) window.clearTimeout(socialSoonTimer.current);
	}, []);
	const openExplorer = () => {
		setMenuOpen(false);
		navigate({
			to: player ? "/explore" : "/explore/guest",
			search: {}
		});
	};
	const startBooking = () => {
		if (player) {
			openExplorer();
			return;
		}
		setBookingPromptOpen(true);
	};
	const startVenueBooking = (venueId) => {
		if (player) {
			navigate({
				to: "/venues/$venueId",
				params: { venueId },
				search: {}
			});
			return;
		}
		pendingVenueRef.current = venueId;
		setBookingPromptOpen(true);
	};
	const closeBookingPrompt = (keepIntent = false) => {
		if (!keepIntent) pendingVenueRef.current = null;
		if (bookingPromptTimer.current) window.clearTimeout(bookingPromptTimer.current);
		setBookingPromptClosing(true);
		bookingPromptTimer.current = window.setTimeout(() => {
			setBookingPromptOpen(false);
			setBookingPromptClosing(false);
		}, 200);
	};
	(0, import_react.useEffect)(() => {
		if (!bookingPromptOpen) return;
		const onKey = (event) => {
			if (event.key === "Escape") closeBookingPrompt();
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [bookingPromptOpen]);
	(0, import_react.useEffect)(() => () => {
		if (bookingPromptTimer.current) window.clearTimeout(bookingPromptTimer.current);
	}, []);
	const openSignIn = () => {
		if (signInCloseTimer.current) window.clearTimeout(signInCloseTimer.current);
		setSignInClosing(false);
		setMenuOpen(false);
		setSignInError(null);
		setAuthSheetStep("signin");
		setSignInOpen(true);
	};
	const closeSignIn = () => {
		if (signInBusy || signInClosing) return;
		if (signInCloseTimer.current) window.clearTimeout(signInCloseTimer.current);
		setSignInClosing(true);
		signInCloseTimer.current = window.setTimeout(() => {
			setSignInOpen(false);
			setSignInClosing(false);
		}, 320);
	};
	(0, import_react.useEffect)(() => () => {
		if (signInCloseTimer.current) window.clearTimeout(signInCloseTimer.current);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!signup) return;
		setMenuOpen(false);
		setSignInError(null);
		setAuthSheetStep("role");
		setSignInOpen(true);
		navigate({
			search: (prev) => ({
				...prev,
				signup: void 0
			}),
			replace: true
		});
	}, [signup]);
	(0, import_react.useEffect)(() => {
		if (!signin) return;
		openSignIn();
		navigate({
			search: (prev) => ({
				...prev,
				signin: void 0
			}),
			replace: true
		});
	}, [signin]);
	(0, import_react.useEffect)(() => {
		if (authSheetStep === "role" || authSheetStep === "signup") {
			setLegalAccepted(false);
			setLegalTouched(false);
		}
	}, [authSheetStep]);
	(0, import_react.useEffect)(() => {
		if (authSheetStep !== "signup") {
			setShowRoleGuide(false);
			return;
		}
		setShowRoleGuide(true);
		const timer = window.setTimeout(() => setShowRoleGuide(false), 4e3);
		return () => window.clearTimeout(timer);
	}, [authSheetStep]);
	const legalReadLinks = [["terms", "Read the Terms & Conditions"], ["privacy", "Read the Privacy Policy"]].map(([doc, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => setLegalOpen(doc),
		className: "text-xs font-bold text-[#12806d] underline underline-offset-2 transition hover:text-[#0b3d35]",
		children: label
	}, doc));
	const handleGoogleAuth = async (role) => {
		setSignInError(null);
		if (role) sessionStorage.setItem(GOOGLE_PENDING_ROLE_KEY, role);
		else sessionStorage.removeItem(GOOGLE_PENDING_ROLE_KEY);
		const { error } = await supabase.auth.signInWithOAuth({
			provider: "google",
			options: { redirectTo: window.location.origin }
		});
		if (error) {
			sessionStorage.removeItem(GOOGLE_PENDING_ROLE_KEY);
			setSignInError(error.message);
		}
	};
	const sendPasswordReset = async (event) => {
		event.preventDefault();
		setSignInError(null);
		setSignInBusy(true);
		const { error } = await supabase.auth.resetPasswordForEmail(signInEmail, { redirectTo: `${window.location.origin}/reset-password` });
		setSignInBusy(false);
		if (error) {
			setSignInError(error.message);
			return;
		}
		setAuthSheetStep("forgot-sent");
	};
	const submitAuth = async (event) => {
		event.preventDefault();
		if (authSheetStep === "signup" && !legalAccepted) {
			setLegalTouched(true);
			setSignInError("Please read and agree to the Terms & Conditions and the Privacy Policy to continue.");
			return;
		}
		setSignInBusy(true);
		setSignInError(null);
		try {
			if (authSheetStep === "signup") {
				if (!signupRole) throw new Error("Please choose an account type.");
				if (signInPassword.length < 8) throw new Error("Use a password with at least 8 characters.");
				const { data, error } = await supabase.auth.signUp({
					email: signInEmail,
					password: signInPassword,
					options: {
						emailRedirectTo: window.location.origin,
						data: {
							full_name: signupName,
							phone: signupPhone,
							role: signupRole,
							terms_version: LEGAL_VERSION,
							terms_accepted_at: (/* @__PURE__ */ new Date()).toISOString()
						}
					}
				});
				if (error) throw error;
				if (!data.session) {
					setAuthSheetStep("confirmation");
					return;
				}
				setSignInOpen(false);
				if (signupRole === "tenant") navigate({
					to: "/dashboard",
					replace: true
				});
				else if (data.user) setPlayer({
					id: data.user.id,
					email: data.user.email ?? signInEmail,
					name: signupName || data.user.email?.split("@")[0] || "Player"
				});
				return;
			}
			const { error } = await supabase.auth.signInWithPassword({
				email: signInEmail,
				password: signInPassword
			});
			if (error) throw error;
			const { data: { user } } = await supabase.auth.getUser();
			if (!user) throw new Error("Sign-in succeeded, but no active session was found. Please try again.");
			const { data: profile } = await supabase.from("profiles").select("role, full_name").eq("id", user.id).maybeSingle();
			const metadata = user.user_metadata;
			const isTenant = profile?.role === "tenant" || metadata.role === "tenant";
			setSignInOpen(false);
			if (isTenant) navigate({
				to: "/dashboard",
				replace: true
			});
			else setPlayer({
				id: user.id,
				email: user.email ?? signInEmail,
				name: profile?.full_name || (typeof metadata.full_name === "string" ? metadata.full_name : "") || user.email?.split("@")[0] || "Player"
			});
		} catch (error) {
			setSignInError(error instanceof Error ? error.message : "Unable to sign in. Please try again.");
		} finally {
			setSignInBusy(false);
		}
	};
	(0, import_react.useEffect)(() => {
		if (!signInOpen) return;
		const onKeyDown = (event) => {
			if (event.key === "Escape") closeSignIn();
		};
		window.addEventListener("keydown", onKeyDown);
		return () => window.removeEventListener("keydown", onKeyDown);
	}, [signInOpen, signInBusy]);
	(0, import_react.useEffect)(() => {
		const atBottom = scrollProgress > .995;
		if (atBottom && !wasAtBottom.current) setBurstKey((key) => key + 1);
		wasAtBottom.current = atBottom;
	}, [scrollProgress]);
	const scrollToTop = () => {
		const scroller = document.querySelector("main");
		if (scroller) scroller.scrollTo({
			top: 0,
			behavior: "smooth"
		});
		else window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	const featureCards = [
		[
			CalendarCheck2,
			"Real-time availability",
			"See open courts instantly and reserve the time that fits your day."
		],
		[
			Sparkles,
			"Easy booking",
			"A clear, guided booking flow from venue discovery to confirmation."
		],
		[
			ShieldCheck,
			"Secure payments",
			"Protected online checkout with reliable booking records."
		],
		[
			Map$1,
			"Venue discovery",
			"Find courts around the Philippines or search close to a pinned location."
		],
		[
			BellRing,
			"Live booking status",
			"Keep track of your reservations and payment progress in one place."
		],
		[
			ReceiptText,
			"Digital confirmation",
			"Get a booking reference as soon as your reservation is confirmed."
		],
		[
			UsersRound,
			"Court groups",
			"Smart shared-facility handling for courts that play together."
		],
		[
			Trophy,
			"Community ready",
			"A better home for open play, local events, and growing sports communities."
		],
		[
			Accessibility,
			"Made for every device",
			"Discover and book on desktop, tablet, or right from your phone."
		]
	];
	const highlightCategories = [
		{
			key: "tournament",
			label: "Tournament",
			copy: "Competition highlights and match days",
			images: [
				"https://images.unsplash.com/photo-1518604666860-9ed391f76460?auto=format&fit=crop&w=1200&q=80",
				"https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=1200&q=80",
				"https://images.unsplash.com/photo-1592656094267-764a45160876?auto=format&fit=crop&w=1200&q=80"
			]
		},
		{
			key: "player-action",
			label: "Player action",
			copy: "On-court moments from the community",
			images: [
				"https://images.unsplash.com/photo-1554068865-24cecd4e34b8?auto=format&fit=crop&w=1200&q=80",
				"https://images.unsplash.com/photo-1566577739112-5180d4bf9390?auto=format&fit=crop&w=1200&q=80",
				"https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?auto=format&fit=crop&w=1200&q=80"
			]
		},
		{
			key: "community-events",
			label: "Community events",
			copy: "Open play, leagues, and local gatherings",
			images: [
				"https://images.unsplash.com/photo-1504450758481-7338eba7524a?auto=format&fit=crop&w=1200&q=80",
				"https://images.unsplash.com/photo-1521412644187-c49fa049e84d?auto=format&fit=crop&w=1200&q=80",
				"https://images.unsplash.com/photo-1518065896235-a4c93e088e7a?auto=format&fit=crop&w=1200&q=80"
			]
		},
		{
			key: "happy-customers",
			label: "Happy customers",
			copy: "Player stories and winning smiles",
			images: [
				"https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=1200&q=80",
				"https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=1200&q=80",
				"https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&w=1200&q=80"
			]
		}
	];
	const highlightFrames = highlightCategories.flatMap((category) => category.images.map((src) => ({
		src,
		category
	})));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-[#f6f8f7] text-[#102521]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: scrollToTop,
				"aria-label": "Back to top",
				className: `fixed bottom-5 right-5 z-1100 flex h-12 w-12 items-center justify-center rounded-full bg-[#0b3d35] text-[#b8f05a] shadow-lg shadow-[#09231f]/25 transition-all duration-300 hover:-translate-y-1 hover:bg-[#126152] focus:outline-none focus:ring-2 focus:ring-[#b8f05a] focus:ring-offset-2 motion-reduce:transition-none sm:bottom-7 sm:right-7 ${showBackToTop ? "translate-y-0 scale-100 opacity-100" : "pointer-events-none translate-y-5 scale-90 opacity-0"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 48 48",
						"aria-hidden": true,
						className: "pointer-events-none absolute inset-0 h-full w-full -rotate-90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "24",
							cy: "24",
							r: "22",
							fill: "none",
							stroke: "rgb(184 240 90 / 0.2)",
							strokeWidth: "2.5"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "24",
							cy: "24",
							r: "22",
							fill: "none",
							stroke: "#b8f05a",
							strokeWidth: "2.5",
							strokeLinecap: "round",
							strokeDasharray: 138.23,
							strokeDashoffset: 138.23 * (1 - scrollProgress),
							className: "transition-[stroke-dashoffset] duration-150 ease-out motion-reduce:transition-none"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						"aria-hidden": true,
						className: "pointer-events-none absolute inset-0 transition-transform duration-150 ease-out motion-reduce:transition-none",
						style: { transform: `rotate(${scrollProgress * 360}deg)` },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-1/2 top-[2px] h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#d3ff87] shadow-[0_0_8px_1.5px_rgba(184,240,90,0.85)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute left-1/2 top-[2px] transition-transform duration-150 ease-out motion-reduce:transition-none",
							style: { transform: `rotate(${-scrollProgress * 360}deg)` },
							children: FUSE_EMBERS.map((ember, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								style: {
									"--ex": `${ember.ex}px`,
									animationDelay: `${ember.delay}s`
								},
								className: "absolute h-[3px] w-[3px] rounded-full bg-[#b8f05a] opacity-0 shadow-[0_0_5px_1px_rgba(184,240,90,0.7)] motion-safe:animate-[fuse-ember_1.2s_linear_infinite]"
							}, i))
						})]
					}),
					burstKey > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						className: "pointer-events-none absolute inset-0",
						children: SHOWER_DOTS.map((dot, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							style: {
								width: dot.size,
								height: dot.size
							},
							className: "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								style: {
									"--dx": `${dot.dx.toFixed(1)}px`,
									"--dy": `${dot.dy.toFixed(1)}px`,
									animationDelay: `${dot.delay}ms`
								},
								className: "absolute inset-0 rounded-full bg-[#d3ff87] opacity-0 shadow-[0_0_6px_1px_rgba(184,240,90,0.8)] motion-safe:animate-[fuse-shower_.75s_ease-out_forwards]"
							})
						}, i))
					}, burstKey),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, {
						className: "relative h-6 w-6",
						strokeWidth: 2.5
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				onMouseEnter: () => {
					setHeaderHovering(true);
					setHeaderHidden(false);
				},
				onMouseLeave: () => {
					setHeaderHovering(false);
					setActiveHeaderMenu(null);
				},
				className: `fixed inset-x-0 top-0 z-1200 px-3 pt-3 transition-transform ease-[cubic-bezier(0.22,1,0.36,1)] will-change-transform motion-reduce:transition-none sm:px-6 ${headerHidden ? "pointer-events-none -translate-y-[calc(100%+1rem)] duration-700" : "translate-y-0 duration-500"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `mx-auto max-w-7xl overflow-hidden rounded-2xl text-white transition duration-300 ${headerSolid || activeHeaderMenu ? "border border-[#b8f05a] bg-[#09231f]/90 shadow-[0_0_28px_-4px_rgba(184,240,90,0.45)] backdrop-blur-xl" : "border border-transparent bg-transparent"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => scrollTo("Home"),
								className: "flex items-center",
								"aria-label": "CourtHub home",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "logo-glaze",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/courthub-wordmark.png",
										alt: "",
										width: 983,
										height: 240,
										className: "h-8 w-auto object-contain sm:h-9"
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
								className: "hidden items-center gap-1 lg:flex",
								"aria-label": "Landing navigation",
								children: landingNav.map((name) => {
									const hasMegaMenu = name === "Venues" || name === "Upcoming Events" || name === "Highlights";
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onPointerEnter: () => setActiveHeaderMenu(hasMegaMenu ? name : null),
										onFocus: () => setActiveHeaderMenu(hasMegaMenu ? name : null),
										onClick: () => {
											setActiveHeaderMenu(null);
											scrollTo(name);
										},
										"aria-expanded": hasMegaMenu ? activeHeaderMenu === name : void 0,
										className: `rounded-full px-3 py-1.5 text-xs font-semibold transition ${activeSection === name ? "bg-[#b8f05a] text-[#102521]" : "text-white/75 hover:bg-white/10 hover:text-white"}`,
										children: name
									}, name);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									player ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => navigate({ to: "/dashboard" }),
										className: "hidden rounded-full bg-white/10 p-2 text-white/85 transition hover:bg-white/20 hover:text-white sm:inline-flex",
										title: player.name,
										"aria-label": "Open player workspace",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-5 w-5" })
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: openSignIn,
										className: "hidden items-center rounded-full border border-white/30 px-4 py-2 text-sm font-semibold text-white/90 transition hover:border-[#b8f05a] hover:bg-white/10 hover:text-white sm:inline-flex",
										children: "Sign in"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: startBooking,
										className: "inline-flex items-center gap-1 rounded-full bg-[#b8f05a] px-3.5 py-2 text-sm font-bold text-[#102521] transition hover:bg-[#d3ff87]",
										children: ["Book now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setMenuOpen((open) => !open),
										className: "rounded-full p-2 hover:bg-white/10 lg:hidden",
										"aria-label": "Toggle navigation",
										"aria-expanded": menuOpen,
										children: menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
									})
								]
							})
						]
					}), activeHeaderMenu && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden border-t border-white/15 px-4 pb-4 pt-3 lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-2 pb-1 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-extrabold uppercase tracking-[.22em] text-[#b8f05a]",
										children: headerMegaMenuItems[activeHeaderMenu].eyebrow
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-2 font-display text-2xl font-bold",
										children: headerMegaMenuItems[activeHeaderMenu].title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 max-w-lg text-sm leading-relaxed text-white/65",
										children: headerMegaMenuItems[activeHeaderMenu].copy
									})
								] }), activeHeaderMenu === "Upcoming Events" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 rounded-full border border-[#b8f05a]/35 bg-[#b8f05a]/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[.14em] text-[#d9ff9b]",
									children: "Soon"
								})]
							}), activeHeaderMenu === "Venues" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative mt-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									ref: venueRailRef,
									className: "flex snap-x snap-mandatory gap-3 overflow-x-auto scroll-smooth py-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
									children: [
										(featuredQ.data ?? []).slice(0, 24).map((venue) => {
											const courts = venue.courts ?? [];
											const ranges = courts.map((court) => {
												const hrs = effectiveHours({
													inherit_venue_hours: court.inherit_venue_hours,
													operating_hours: court.operating_hours
												}, venue.operating_hours);
												const rules = normalizeRules(court.rate_rules);
												const base = Number(court.hourly_rate);
												return {
													lo: minRate(base, rules, hrs),
													hi: maxRate(base, rules, hrs)
												};
											});
											const lo = ranges.length ? Math.min(...ranges.map((r) => r.lo)) : null;
											const hi = ranges.length ? Math.max(...ranges.map((r) => r.hi)) : null;
											const sports = Array.from(new Set(courts.map((c) => c.sports?.name).filter(Boolean)));
											const todayWindow = describeWindow(normalizeHours(venue.operating_hours)[HOUR_DAY_KEYS[zonedDayOfWeek(zonedDateISO())]]);
											const closed = todayWindow === "Closed";
											const image = venue.images?.[0];
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/venues/$venueId",
												params: { venueId: String(venue.id) },
												search: {},
												onClick: () => setActiveHeaderMenu(null),
												className: "group flex h-36 w-[calc((100%-1.5rem)/3)] shrink-0 snap-start flex-row overflow-hidden rounded-2xl text-left ring-1 ring-white/15 transition-all duration-200 hover:shadow-md hover:ring-2 hover:ring-[#b8f05a]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative h-full w-1/2 shrink-0 overflow-hidden bg-[#0b3d35]",
													children: [
														image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
															src: image,
															alt: "",
															loading: "lazy",
															className: "h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "flex h-full w-full items-center justify-center bg-linear-to-br from-[#b8f05a]/10 to-[#0b3d35] text-3xl",
															children: venue.map_emoji || "🏟️"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-linear-to-t from-black/50 via-transparent to-transparent" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "absolute left-2 top-2 flex items-center gap-1.5 rounded-full bg-white/95 py-1 pl-1.5 pr-2 shadow-sm",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 w-1.5 shrink-0 rounded-full ${closed ? "bg-neutral-400" : "bg-emerald-500"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "whitespace-nowrap text-[9px] font-bold text-[#102521]",
																children: closed ? "Closed today" : todayWindow
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "absolute bottom-2 right-2",
															children: courts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center gap-1.5 rounded-full bg-white/95 py-0.5 pl-0.5 pr-2 shadow-md",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "flex h-4 w-4 items-center justify-center rounded-full bg-[#12806d] text-[10px] font-extrabold text-white",
																	children: courts.length
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "text-[9px] font-bold text-[#102521]",
																	children: courts.length === 1 ? "court" : "courts"
																})]
															}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "rounded-full bg-black/60 px-2 py-0.5 text-[9px] font-semibold text-white/80 backdrop-blur-sm",
																children: "No courts yet"
															})
														})
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-1 flex-col gap-1.5 overflow-hidden bg-linear-to-br from-[#0f4a40] to-[#09231f] p-2.5",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "truncate rounded-lg bg-[#b8f05a]/15 px-2 py-1 font-display text-[12px] font-bold leading-tight text-[#b8f05a] ring-1 ring-[#b8f05a]/25 transition-colors group-hover:text-[#d3ff87]",
															children: venue.name
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-start gap-1.5 text-[10px] text-white/65",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-3 w-3 shrink-0 text-[#b8f05a]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "line-clamp-1",
																children: venue.address
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex h-[20px] items-center gap-1 overflow-hidden",
															children: [sports.slice(0, 2).map((sport) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "shrink-0 whitespace-nowrap rounded-full bg-[#b8f05a]/15 px-1.5 py-0.5 text-[9px] font-semibold text-[#b8f05a] ring-1 ring-[#b8f05a]/25",
																children: sport
															}, sport)), sports.length > 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "shrink-0 rounded-full bg-white/10 px-1.5 py-0.5 text-[9px] font-medium text-white/70",
																children: ["+", sports.length - 2]
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "mt-auto flex min-h-[24px] items-center justify-between gap-1.5 border-t border-white/10 pt-1.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "truncate text-[10px] font-medium text-white/60",
																children: "Available now"
															}), lo != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "shrink-0 whitespace-nowrap rounded-md bg-[#b8f05a]/15 px-1.5 py-0.5 text-[10px] font-bold text-[#b8f05a] ring-1 ring-[#b8f05a]/25",
																children: hi != null && hi > lo ? `₱${lo.toFixed(0)}–${hi.toFixed(0)}/hr` : `₱${lo.toFixed(0)}/hr`
															}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "shrink-0 text-[9px] text-white/40",
																children: "No courts"
															})]
														})
													]
												})]
											}, venue.id);
										}),
										(featuredQ.data?.length ?? 0) > 24 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: player ? "/explore" : "/landing",
											search: player ? {} : { signin: true },
											onClick: () => setActiveHeaderMenu(null),
											className: "group flex h-36 w-[calc((100%-1.5rem)/3)] shrink-0 snap-start flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-[#b8f05a]/40 bg-[#b8f05a]/5 p-4 text-center transition hover:border-[#b8f05a] hover:bg-[#b8f05a]/12",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "flex h-9 w-9 items-center justify-center rounded-full bg-[#b8f05a] text-[#102521] transition group-hover:scale-110",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-5 w-5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-cabinet text-sm font-bold text-white",
													children: player ? "Browse every venue" : "Sign in to see them all"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] leading-snug text-white/55",
													children: player ? "Open the full map and filters." : "This menu shows the 24 newest. Sign in to search the full map."
												})
											]
										}),
										(featuredQ.data?.length ?? 0) === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "w-full rounded-2xl border border-dashed border-white/15 py-8 text-center text-xs text-white/50",
											children: featuredQ.isLoading ? "Loading venues…" : "Venues will appear here as they join CourtHub."
										})
									]
								}), (featuredQ.data?.length ?? 0) > 3 && [{
									dir: -1,
									Icon: ChevronLeft,
									side: "-left-3",
									label: "Previous venues"
								}, {
									dir: 1,
									Icon: ChevronRight,
									side: "-right-3",
									label: "More venues"
								}].map(({ dir, Icon, side, label }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": label,
									onClick: () => {
										const rail = venueRailRef.current;
										if (!rail) return;
										rail.scrollBy({
											left: dir * (rail.clientWidth / 3 + 12),
											behavior: "smooth"
										});
									},
									className: `absolute top-1/2 z-10 -translate-y-1/2 rounded-full border border-[#b8f05a]/40 bg-[#09231f] p-2 text-[#b8f05a] shadow-lg transition hover:bg-[#b8f05a] hover:text-[#102521] ${side}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
								}, label))]
							}) : activeHeaderMenu === "Highlights" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: highlightCategories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setHeaderHighlightKey(category.key),
										"aria-pressed": headerHighlightKey === category.key,
										className: `inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-bold transition ${headerHighlightKey === category.key ? "border-[#b8f05a] bg-[#b8f05a] text-[#102521]" : "border-white/20 bg-white/5 text-white/80 hover:border-[#b8f05a] hover:text-[#b8f05a]"}`,
										children: [category.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded-full px-1.5 text-[9px] font-extrabold ${headerHighlightKey === category.key ? "bg-[#102521]/15 text-[#102521]" : "bg-white/10 text-white/60"}`,
											children: category.images.length
										})]
									}, category.key))
								}), (() => {
									const category = highlightCategories.find((c) => c.key === headerHighlightKey) ?? highlightCategories[0];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-4 grid grid-cols-3 gap-3",
										children: category.images.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => {
												setActiveHeaderMenu(null);
												setHighlightOpen({
													key: category.key,
													idx: i
												});
											},
											"aria-label": `View ${category.label.toLowerCase()} photo ${i + 1} full screen`,
											className: "group relative h-36 overflow-hidden rounded-2xl text-left ring-1 ring-white/15 transition-all duration-200 hover:shadow-md hover:ring-2 hover:ring-[#b8f05a]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src,
													alt: `${category.label} highlight ${i + 1}`,
													loading: "lazy",
													className: "h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-0 bg-linear-to-t from-[#061a17]/80 via-transparent to-transparent" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "absolute bottom-2 left-2 rounded-full bg-[#b8f05a] px-2 py-0.5 font-cabinet text-[9px] font-bold uppercase tracking-[.1em] text-[#102521]",
													children: category.label
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "absolute bottom-2 right-2 flex items-center gap-1 rounded-full bg-white/15 px-2 py-0.5 text-[9px] font-bold uppercase tracking-[.1em] text-white opacity-0 backdrop-blur-sm transition-opacity duration-200 group-hover:opacity-100",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "h-3 w-3" }), " Full view"]
												})
											]
										}, src))
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-3 text-[11px] text-white/55",
										children: [category.copy, ". Open a photo for the full-screen viewer — full sets on Facebook, X, and TikTok are linked from there."]
									})] });
								})()]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 grid gap-2 sm:grid-cols-3",
								children: headerMegaMenuItems[activeHeaderMenu].items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "block rounded-2xl border border-white/10 bg-white/[0.06] p-4 text-left transition hover:border-[#b8f05a]/50 hover:bg-white/[0.1]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-display text-base font-bold text-white",
											children: item.title
										}), item.soon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-[#b8f05a] px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wide text-[#102521]",
											children: "Soon"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs leading-relaxed text-white/60",
										children: item.copy
									})]
								}, item.title))
							})]
						})
					})]
				}), menuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "mx-auto mt-2 grid max-w-7xl grid-cols-2 gap-1 rounded-2xl border border-[#102521]/10 bg-white p-2 shadow-xl lg:hidden",
					children: [landingNav.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: name === "Venues" ? openExplorer : () => scrollTo(name),
						className: "rounded-xl px-3 py-3 text-left text-sm font-semibold hover:bg-[#eaf5d8]",
						children: name
					}, name)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => player ? navigate({ to: "/dashboard" }) : openSignIn(),
						className: "truncate rounded-xl px-3 py-3 text-sm font-semibold hover:bg-[#eaf5d8]",
						children: player?.name ?? "Sign in"
					})]
				})]
			}),
			(signInOpen || signInClosing) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `fixed inset-0 z-1300 flex justify-end bg-[#061a17]/60 backdrop-blur-sm ${signInClosing ? "motion-safe:animate-[landing-overlay-out_.3s_ease-in_both]" : "motion-safe:animate-[landing-overlay-in_.2s_ease-out_both]"}`,
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "sign-in-title",
				onMouseDown: closeSignIn,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none hidden flex-1 items-center justify-center px-10 md:flex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						onAnimationIteration: (event) => {
							if (event.animationName === "handwrite-loop") setTaglineIndex((index) => (index + 1) % SIGN_IN_TAGLINES.length);
						},
						className: `tagline-glaze max-w-lg text-center font-cabinet text-5xl font-bold leading-[1.08] tracking-tight text-[#b8f05a] [text-shadow:0_0_36px_rgba(184,240,90,0.35)] lg:text-6xl ${signInClosing ? "opacity-0 transition-opacity duration-200" : "motion-safe:animate-[handwrite-loop_9.4s_linear_0.35s_infinite_backwards]"}`,
						"data-text": SIGN_IN_TAGLINES[taglineIndex],
						children: SIGN_IN_TAGLINES[taglineIndex]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: `drawer-edge-glow relative flex h-full w-full max-w-md flex-col overflow-y-auto bg-[#f6f8f7] shadow-2xl ${signInClosing ? "motion-safe:animate-[landing-drawer-out_.32s_cubic-bezier(0.4,0,1,1)_both]" : "motion-safe:animate-[landing-drawer-in_.38s_cubic-bezier(0.22,1,0.36,1)_both]"}`,
					onMouseDown: (event) => event.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative shrink-0 overflow-hidden bg-[#09231f] px-6 pb-10 pt-6 text-white sm:px-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-14 -top-20 h-52 w-52 rounded-full bg-[#b8f05a]/20 blur-3xl" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "logo-glaze",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: "/courthub-wordmark.png",
											alt: "CourtHub",
											width: 983,
											height: 240,
											className: "h-7 w-auto object-contain"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: closeSignIn,
										"aria-label": "Close sign in",
										className: "rounded-full border border-white/20 p-2 text-white/80 transition hover:bg-white/10 hover:text-white",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: `relative text-xs font-bold uppercase tracking-[.2em] text-[#b8f05a] ${authSheetStep === "role" ? "mt-6" : "mt-12"}`,
									children: authSheetStep === "signin" ? "Welcome back" : authSheetStep === "forgot" || authSheetStep === "forgot-sent" ? "Account security" : "Join CourtHub"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									id: "sign-in-title",
									className: `relative mt-2 font-display font-bold tracking-tight ${authSheetStep === "role" ? "text-2xl" : "text-4xl"}`,
									children: authSheetStep === "signin" ? "Ready to play?" : authSheetStep === "confirmation" || authSheetStep === "forgot-sent" ? "Check your email" : authSheetStep === "forgot" ? "Forgot your password?" : "Let’s get you playing."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "relative mt-3 max-w-sm text-sm leading-relaxed text-white/70",
									children: authSheetStep === "signin" ? "Sign in to manage bookings and get back on the court." : authSheetStep === "confirmation" ? "We sent a confirmation link to finish setting up your account." : authSheetStep === "forgot" ? "Enter the email you used to sign up and we’ll send you a link to reset it." : authSheetStep === "forgot-sent" ? "We sent a password reset link to your email." : "Create your account in a few quick steps."
								})
							]
						}),
						authSheetStep === "role" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-1 flex-col px-6 py-8 sm:px-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-relaxed text-[#5e746e]",
									children: "How will you use CourtHub?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6 space-y-3",
									children: [[
										"player",
										"🎾",
										"I’m a player",
										"Browse and book courts near you."
									], [
										"tenant",
										"🏟️",
										"I manage a venue",
										"List courts, rates, and availability."
									]].map(([role, icon, title, copy]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setSignupRole(role),
										className: `w-full rounded-2xl border-2 p-4 text-left transition ${signupRole === role ? "border-[#12806d] bg-[#eaf5d8]" : "border-[#d8e4df] bg-white hover:border-[#12806d]/40"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center justify-between gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-2xl",
													children: icon
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "logo-glaze shrink-0",
													style: { "--logo-glaze-src": `url(/role-${role}.png)` },
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
														src: `/role-${role}.png`,
														alt: "",
														className: "h-6 w-auto object-contain"
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-3 block font-display text-lg font-bold text-[#102521]",
												children: title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1 block text-sm text-[#5e746e]",
												children: copy
											})
										]
									}, role))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: !signupRole,
									onClick: () => setAuthSheetStep("signup"),
									className: "mt-6 rounded-full bg-[#0b3d35] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#126152] disabled:cursor-not-allowed disabled:opacity-50",
									children: "Continue"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAuthSheetStep("signin"),
									className: "mt-5 text-sm font-bold text-[#12806d] hover:underline",
									children: "Already have an account? Sign in"
								})
							]
						}),
						authSheetStep === "confirmation" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-1 flex-col px-6 py-8 text-center sm:px-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mx-auto grid h-14 w-14 place-items-center rounded-full bg-[#eaf5d8] text-2xl",
									children: "📧"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-6 text-sm leading-relaxed text-[#5e746e]",
									children: [
										"Check ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-[#102521]",
											children: signInEmail
										}),
										" and follow the confirmation link to activate your account."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAuthSheetStep("signin"),
									className: "mt-7 rounded-full bg-[#0b3d35] px-5 py-3.5 text-sm font-bold text-white hover:bg-[#126152]",
									children: "Back to sign in"
								})
							]
						}),
						authSheetStep === "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: sendPasswordReset,
							className: "flex flex-1 flex-col px-6 py-8 sm:px-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm font-bold text-[#102521]",
									children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "email",
										autoComplete: "email",
										value: signInEmail,
										onChange: (event) => setSignInEmail(event.target.value),
										className: "mt-2 w-full rounded-xl border border-[#d8e4df] bg-white px-3 py-3 outline-none transition focus:border-[#12806d] focus:ring-2 focus:ring-[#b8f05a]/50",
										placeholder: "you@example.com",
										required: true
									})]
								}),
								signInError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-700",
									children: signInError
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: signInBusy,
									className: "mt-7 rounded-full bg-[#0b3d35] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#126152] disabled:cursor-wait disabled:opacity-60",
									children: signInBusy ? "Sending…" : "Send reset link"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setSignInError(null);
										setAuthSheetStep("signin");
									},
									className: "mt-5 text-sm font-bold text-[#12806d] hover:underline",
									children: "Back to sign in"
								})
							]
						}),
						authSheetStep === "forgot-sent" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-1 flex-col px-6 py-8 text-center sm:px-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mx-auto grid h-14 w-14 place-items-center rounded-full bg-[#eaf5d8] text-2xl",
									children: "📧"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-6 text-sm leading-relaxed text-[#5e746e]",
									children: [
										"If ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-[#102521]",
											children: signInEmail
										}),
										" has a CourtHub account, we sent a link to reset its password. Open it on this device to choose a new one."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setAuthSheetStep("signin"),
									className: "mt-7 rounded-full bg-[#0b3d35] px-5 py-3.5 text-sm font-bold text-white hover:bg-[#126152]",
									children: "Back to sign in"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: submitAuth,
							className: `flex flex-1 flex-col px-6 py-8 sm:px-8 ${authSheetStep === "signin" || authSheetStep === "signup" ? "" : "hidden"}`,
							children: [
								authSheetStep === "signin" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => handleGoogleAuth(null),
										className: "flex w-full items-center justify-center gap-2.5 rounded-full border-2 border-[#d8e4df] bg-white px-5 py-3.5 text-sm font-bold text-[#102521] transition hover:border-[#12806d]/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleGlyph, { className: "h-4 w-4" }), "Continue with Google"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										role: "tooltip",
										className: "pointer-events-none absolute left-1/2 top-full z-20 mt-2 w-64 -translate-x-1/2 scale-95 rounded-lg bg-[#0b3d35] px-3 py-2 text-center text-xs font-semibold leading-snug text-white opacity-0 shadow-lg transition duration-150 group-hover:scale-100 group-hover:opacity-100",
										children: ["Use the same Google account you signed up with — a different one won’t be able to continue.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 left-1/2 h-2 w-2 -translate-x-1/2 rotate-45 bg-[#0b3d35]" })]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "my-5 flex items-center gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-[#d8e4df]" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold uppercase tracking-wider text-[#8a9c96]",
											children: "or"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-[#d8e4df]" })
									]
								})] }),
								authSheetStep === "signup" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-bold text-[#102521] capitalize",
											children: signupRole === "tenant" ? "Venue manager account" : "Player account"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative shrink-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => {
													setSignupRole(signupRole === "tenant" ? "player" : "tenant");
													setShowRoleGuide(false);
												},
												"aria-label": signupRole === "tenant" ? "Switch to a player account" : "Switch to a venue manager account",
												className: "relative h-9 w-36",
												children: ["player", "tenant"].map((bannerRole) => {
													return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `logo-glaze right-0 top-0 origin-right transition-all duration-300 ease-out motion-reduce:transition-none ${bannerRole === (signupRole ?? "player") ? "z-10 translate-y-3 scale-100 opacity-100" : "z-0 translate-y-0 scale-90 opacity-40"}`,
														style: {
															position: "absolute",
															"--logo-glaze-src": `url(/role-${bannerRole}.png)`
														},
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
															src: `/role-${bannerRole}.png`,
															alt: "",
															className: "h-6 w-auto object-contain"
														})
													}, bannerRole);
												})
											}), showRoleGuide && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												role: "status",
												className: "bubble-pop pointer-events-none absolute right-2 top-full z-20 mt-2 w-36 rounded-lg bg-[#0b3d35] px-2.5 py-1.5 text-center text-[11px] font-semibold leading-tight text-white shadow-lg",
												children: ["Tap here to switch between player & venue manager", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 right-6 h-2 w-2 rotate-45 bg-[#0b3d35]" })]
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "mt-5 text-sm font-bold text-[#102521]",
										children: ["Full name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											autoComplete: "name",
											value: signupName,
											onChange: (event) => setSignupName(event.target.value),
											className: "mt-2 w-full rounded-xl border border-[#d8e4df] bg-white px-3 py-3 outline-none transition focus:border-[#12806d] focus:ring-2 focus:ring-[#b8f05a]/50",
											placeholder: "Your name",
											required: true
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "mt-5 text-sm font-bold text-[#102521]",
										children: [
											"Phone ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-normal text-[#5e746e]",
												children: "(optional)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "tel",
												autoComplete: "tel",
												value: signupPhone,
												onChange: (event) => setSignupPhone(event.target.value),
												className: "mt-2 w-full rounded-xl border border-[#d8e4df] bg-white px-3 py-3 outline-none transition focus:border-[#12806d] focus:ring-2 focus:ring-[#b8f05a]/50",
												placeholder: "Your phone number"
											})
										]
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "text-sm font-bold text-[#102521]",
									children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "email",
										autoComplete: "email",
										value: signInEmail,
										onChange: (event) => setSignInEmail(event.target.value),
										className: "mt-2 w-full rounded-xl border border-[#d8e4df] bg-white px-3 py-3 outline-none transition focus:border-[#12806d] focus:ring-2 focus:ring-[#b8f05a]/50",
										placeholder: "you@example.com",
										required: true
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "signin-password",
										className: "text-sm font-bold text-[#102521]",
										children: "Password"
									}), authSheetStep === "signin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											setSignInError(null);
											setAuthSheetStep("forgot");
										},
										className: "text-xs font-bold text-[#12806d] hover:underline",
										children: "Forgot password?"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "signin-password",
									type: "password",
									autoComplete: authSheetStep === "signup" ? "new-password" : "current-password",
									value: signInPassword,
									onChange: (event) => setSignInPassword(event.target.value),
									className: "mt-2 w-full rounded-xl border border-[#d8e4df] bg-white px-3 py-3 outline-none transition focus:border-[#12806d] focus:ring-2 focus:ring-[#b8f05a]/50",
									placeholder: authSheetStep === "signup" ? "At least 8 characters" : "Your password",
									required: true,
									minLength: authSheetStep === "signup" ? 8 : 6
								}),
								authSheetStep === "signup" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `mt-6 rounded-2xl border p-4 transition ${legalTouched && !legalAccepted ? "border-red-300 bg-red-50" : "border-[#d8e4df] bg-white"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "legal-consent",
												type: "checkbox",
												required: true,
												checked: legalAccepted,
												onChange: (event) => {
													setLegalAccepted(event.target.checked);
													setLegalTouched(true);
													if (event.target.checked) setSignInError(null);
												},
												"aria-describedby": "legal-consent-help",
												className: "mt-0.5 h-5 w-5 shrink-0 cursor-pointer rounded border-[#9db3ac] accent-[#12806d] focus:ring-2 focus:ring-[#b8f05a]"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												htmlFor: "legal-consent",
												className: "cursor-pointer text-sm leading-relaxed text-[#41564f]",
												children: "I have read, understood and agree to CourtHub’s Terms & Conditions and Privacy Policy."
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											id: "legal-consent-help",
											className: "mt-2.5 pl-8 text-xs leading-relaxed text-[#5e746e]",
											children: "This includes the restrictions on copying, scraping and reverse engineering the platform, its workflow and its underlying system design."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 pl-8",
											children: legalReadLinks
										})
									]
								}) : null,
								signInError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-700",
									children: signInError
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									disabled: signInBusy,
									className: "mt-7 rounded-full bg-[#0b3d35] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#126152] disabled:cursor-wait disabled:opacity-60",
									children: signInBusy ? authSheetStep === "signup" ? "Creating account…" : "Signing in…" : authSheetStep === "signup" ? "Create account" : "Sign in"
								}),
								authSheetStep === "signup" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "my-5 flex items-center gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-[#d8e4df]" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold uppercase tracking-wider text-[#8a9c96]",
											children: "or"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-[#d8e4df]" })
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => handleGoogleAuth(signupRole),
									className: "flex items-center justify-center gap-2.5 rounded-full border-2 border-[#d8e4df] bg-white px-5 py-3.5 text-sm font-bold text-[#102521] transition hover:border-[#12806d]/40",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleGlyph, { className: "h-4 w-4" }), "Continue with Google"]
								})] }),
								authSheetStep === "signin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5",
									children: legalReadLinks
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-6 text-center text-sm text-[#5e746e]",
									children: [
										authSheetStep === "signup" ? "Already have an account?" : "New to CourtHub?",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setAuthSheetStep(authSheetStep === "signup" ? "signin" : "role"),
											className: "font-bold text-[#12806d] hover:underline",
											children: authSheetStep === "signup" ? "Sign in" : "Create an account"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-auto pt-8 text-center text-xs leading-relaxed text-[#5e746e]",
									children: "Your next game is closer than you think."
								})
							]
						})
					]
				})]
			}),
			legalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalReader, {
				doc: legalOpen === "terms" ? TERMS : PRIVACY,
				onClose: () => setLegalOpen(null),
				onAgree: authSheetStep === "signup" ? () => {
					setLegalAccepted(true);
					setLegalTouched(true);
					setSignInError(null);
					setLegalOpen(null);
				} : void 0
			}),
			(bookingPromptOpen || bookingPromptClosing) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `fixed inset-0 z-1300 grid place-items-center bg-[#061a17]/60 p-4 backdrop-blur-sm ${bookingPromptClosing ? "motion-safe:animate-[landing-overlay-out_.2s_ease-in_both]" : "motion-safe:animate-[landing-overlay-in_.2s_ease-out_both]"}`,
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "booking-sign-in-title",
				onMouseDown: () => closeBookingPrompt(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `relative w-full max-w-md overflow-hidden rounded-3xl border border-[#b8f05a]/40 bg-white text-[#102521] shadow-2xl shadow-[#09231f]/30 ${bookingPromptClosing ? "motion-safe:animate-[modal-pop-out_.2s_ease-in_both]" : "motion-safe:animate-[modal-pop-in_.32s_cubic-bezier(0.22,1,0.36,1)_both]"}`,
					onMouseDown: (event) => event.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden bg-[#09231f] px-6 pb-7 pt-6 text-white sm:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-12 -top-16 h-44 w-44 rounded-full bg-[#b8f05a]/20 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex items-start justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex h-11 w-11 items-center justify-center rounded-2xl bg-[#b8f05a] text-[#102521]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarCheck2, { className: "h-5 w-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-xs font-bold uppercase tracking-[.18em] text-[#b8f05a]",
									children: "Player booking"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									id: "booking-sign-in-title",
									className: "mt-2 font-display text-2xl font-bold tracking-tight",
									children: "Sign in to book a court"
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => closeBookingPrompt(),
								"aria-label": "Close",
								className: "rounded-full border border-white/20 p-2 text-white/80 transition hover:bg-white/10 hover:text-white",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-6 pb-6 pt-5 sm:px-8 sm:pb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm leading-relaxed text-[#5e746e]",
							children: [
								"Already have a player account? Sign in to book. New to CourtHub? Create an account and choose the ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-[#102521]",
									children: "Player"
								}),
								" option."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									closeBookingPrompt(true);
									openSignIn();
								},
								className: "inline-flex items-center justify-center gap-1.5 rounded-full bg-[#0b3d35] px-4 py-3 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-[#126152]",
								children: ["Sign in ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									closeBookingPrompt(true);
									setAuthSheetStep("role");
									setSignInOpen(true);
								},
								className: "rounded-full border border-[#0b3d35] px-4 py-3 text-sm font-bold text-[#0b3d35] transition hover:-translate-y-0.5 hover:bg-[#eff5ed]",
								children: "Create account"
							})]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "home",
				"data-nav": "Home",
				className: "relative isolate min-h-175 overflow-hidden bg-[#09231f] pt-24 text-white sm:min-h-190",
				children: [
					heroImages.map((image, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: image,
						alt: "Players enjoying sport",
						className: `absolute inset-0 h-full w-full object-cover transition-opacity duration-1000 ${index === heroIndex ? "opacity-100" : "opacity-0"}`,
						fetchPriority: index === 0 ? "high" : "auto"
					}, image)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[linear-gradient(100deg,rgba(5,25,21,.92)_5%,rgba(5,25,21,.68)_48%,rgba(5,25,21,.24))]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 bottom-0 h-48 bg-linear-to-t from-[#09231f] to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto flex min-h-155 max-w-7xl flex-col justify-end px-5 pb-16 sm:min-h-170 sm:px-8 sm:pb-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-3xl animate-[sport-fade-in-up_.7s_ease-out_both]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-2 rounded-full border border-[#b8f05a]/50 bg-[#b8f05a]/10 px-3 py-1.5 text-xs font-bold uppercase tracking-[.15em] text-[#d9ff9b]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-[#b8f05a]" }), " Dedicated court booking platform"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "mt-5 font-display text-5xl font-bold leading-[.95] tracking-[-.055em] sm:text-7xl",
									children: ["Your game starts ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#b8f05a]",
										children: "here."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-2xl text-base leading-relaxed text-white/78 sm:text-lg",
									children: "Find and reserve badminton, basketball, pickleball, volleyball, tennis, football, and more across the Philippines with real-time availability and secure online booking."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-wrap gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: startBooking,
										className: "inline-flex items-center gap-2 rounded-full bg-[#b8f05a] px-6 py-3.5 font-bold text-[#102521] transition hover:-translate-y-0.5 hover:bg-[#d3ff87]",
										children: ["Book a court ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: openExplorer,
										className: "inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-6 py-3.5 font-bold backdrop-blur transition hover:bg-white/20",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4 fill-current" }), " Explore venues"]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 flex items-center gap-2",
							children: heroImages.map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": `Show slide ${index + 1}`,
								onClick: () => setHeroIndex(index),
								className: `h-1.5 rounded-full transition-all ${index === heroIndex ? "w-10 bg-[#b8f05a]" : "w-4 bg-white/40"}`
							}, index))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flow-root bg-[#e9f2e5]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "relative z-10 mx-auto -mt-7 grid max-w-6xl grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/30 bg-white/30 shadow-2xl shadow-[#09231f]/15 sm:grid-cols-5",
					children: [
						"50+|Partner venues",
						"300+|Sports courts",
						"15k+|Bookings completed",
						"8k+|Registered players",
						"99%|Booking success"
					].map((stat) => {
						const [value, label] = stat.split("|");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white px-4 py-5 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-display text-2xl font-bold text-[#0b3d35] sm:text-3xl",
								children: value
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-[10px] font-bold uppercase tracking-wider text-[#52716a]",
								children: label
							})]
						}, label);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "venues",
				"data-nav": "Venues",
				ref: venuesRef,
				className: "bg-[#e9f2e5] py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-5 sm:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
						eyebrow: "Play nearby",
						title: "Featured places to make your next move.",
						highlight: "next move.",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: player ? "/explore" : "/explore/guest",
							search: {},
							className: "inline-flex shrink-0 items-center gap-2 rounded-full border border-[#0b3d35] px-5 py-3 font-cabinet text-sm font-bold text-[#0b3d35] transition hover:-translate-y-0.5 hover:bg-[#0b3d35] hover:text-white",
							children: ["Browse every venue ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 grid gap-5 md:grid-cols-3",
						children: [(featuredQ.data ?? []).slice(0, 3).map((venue, cardIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturedVenueCard, {
							venue,
							index: cardIndex,
							lit: venuesLit,
							onOpen: () => navigate({
								to: "/venues/$venueId",
								params: { venueId: String(venue.id) },
								search: {}
							}),
							onBook: () => startVenueBooking(String(venue.id))
						}, venue.id)), !featuredQ.isLoading && (featuredQ.data?.length ?? 0) === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "col-span-full rounded-2xl border border-dashed border-[#aac2b8] p-10 text-center text-[#5e746e]",
							children: "Venues will appear here as they join CourtHub."
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "how-it-works",
				"data-nav": "How It Works",
				ref: howItWorksRef,
				className: "bg-[#0b3d35] py-20 text-white",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-5 sm:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold uppercase tracking-[.2em] text-[#b8f05a]",
							children: "How it works as a player"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 max-w-xl font-display text-4xl font-bold tracking-tight sm:text-5xl",
							children: "From search to game time in four simple moves."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-5",
							children: [
								[
									UserPlus,
									"Create your account",
									"Sign up as a player to keep your bookings in one place."
								],
								[
									Building2,
									"Choose a venue",
									"Browse trusted facilities that fit your sport and location."
								],
								[
									CalendarCheck2,
									"Select court & time",
									"See availability, pick your court, then lock in your slot."
								],
								[
									ShieldCheck,
									"Complete payment",
									"Pay securely online where the venue offers online checkout."
								],
								[
									Trophy,
									"Enjoy your game",
									"Receive your confirmation and get ready to play."
								]
							].map(([Icon, title, copy], index) => {
								const open = openStep === index;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									style: { animationDelay: `${index * 260}ms` },
									onClick: () => !open && setOpenStep(index),
									className: `group relative isolate overflow-hidden rounded-2xl border bg-white/5 p-5 transition-[border-color,box-shadow] duration-300 ${open ? "cursor-default border-[#b8f05a] shadow-[0_0_26px_-4px_rgba(184,240,90,0.6)]" : "cursor-pointer border-white/15 hover:border-[#b8f05a] hover:shadow-[0_0_26px_-4px_rgba(184,240,90,0.6)] focus-within:border-[#b8f05a] focus-within:shadow-[0_0_26px_-4px_rgba(184,240,90,0.6)]"} ${stepsLit && !open ? "motion-safe:animate-[step-edge-light_1.1s_ease-out]" : ""}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: open ? "invisible" : "",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												style: { animationDelay: `${index * 260}ms` },
												className: `font-display text-5xl font-bold text-[#b8f05a]/35 transition-colors duration-300 group-hover:text-[#b8f05a] group-focus-within:text-[#b8f05a] ${stepsLit ? "motion-safe:animate-[step-number-light_1.1s_ease-out]" : ""}`,
												children: ["0", index + 1]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "mt-8 h-6 w-6 text-[#b8f05a]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "mt-4 font-display text-xl font-bold",
												children: title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-sm leading-relaxed text-white/65",
												children: copy
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "mt-4 inline-flex items-center gap-1.5 rounded-full border border-[#b8f05a]/40 bg-[#b8f05a]/10 px-3 py-1 text-[11px] font-bold uppercase tracking-[.14em] text-[#d9ff9b] opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-focus-within:opacity-100",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlay, { className: "h-3.5 w-3.5" }), "Tap to view tutorials"]
											})
										]
									}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pointer-events-none absolute inset-0 z-30 grid grid-cols-4 grid-rows-4",
											children: Array.from({ length: 16 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												style: shardStyle(i, 0),
												className: "bg-[#17473f] motion-safe:animate-[step-shatter-out_.5s_cubic-bezier(0.4,0,1,1)_forwards]"
											}, i))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "pointer-events-none absolute inset-0 z-10 grid grid-cols-4 grid-rows-4",
											children: Array.from({ length: 16 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												style: shardStyle(i, 300),
												className: "bg-[#061a17] opacity-0 motion-safe:animate-[step-shatter-in_.5s_cubic-bezier(0.22,1,0.36,1)_forwards]"
											}, i))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute inset-0 z-20 flex flex-col justify-between p-4 opacity-0 motion-safe:animate-[step-player-in_.4s_ease-out_.78s_forwards]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start justify-between",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-[10px] font-bold uppercase tracking-[.18em] text-[#b8f05a]",
														children: ["Step 0", index + 1]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														"aria-label": "Close tutorial preview",
														onClick: (event) => {
															event.stopPropagation();
															setOpenStep(null);
														},
														className: "rounded-full border border-white/20 p-1 text-white/70 transition hover:bg-white/10 hover:text-white",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5" })
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col items-center",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "flex h-12 w-12 items-center justify-center rounded-full bg-[#b8f05a] text-[#102521]",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlay, { className: "h-7 w-7" })
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "mt-3 text-center font-display text-sm font-bold",
															children: title
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "mt-1 text-center text-[10px] uppercase tracking-[.14em] text-white/45",
															children: "Tutorial coming soon"
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "h-1 w-full overflow-hidden rounded-full bg-white/15",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-1/3 rounded-full bg-[#b8f05a]/70" })
												})
											]
										})
									] })]
								}, title);
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "learn-sports",
				"data-nav": "Learn Sports",
				className: "py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-5 sm:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
							eyebrow: "Learn sports",
							title: "New to the game? Start here.",
							highlight: "Start here."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 flex flex-wrap gap-2",
							children: learnSports.map((sport) => {
								const active = sport.slug === activeSport;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setActiveSport(sport.slug),
									"aria-pressed": active,
									className: `flex items-center gap-2 rounded-full border px-4 py-2 font-cabinet text-sm font-semibold transition duration-300 ${active ? "-translate-y-0.5 border-[#12806d] bg-[#12806d] text-white shadow-md shadow-[#12806d]/25" : "border-[#d8e4df] bg-white text-[#102521] hover:-translate-y-0.5 hover:border-[#12806d]/50 hover:bg-[#eaf5d8]"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											"aria-hidden": true,
											children: sport.emoji
										}),
										" ",
										sport.name
									]
								}, sport.slug);
							})
						}),
						(() => {
							const sport = learnSports.find((s) => s.slug === activeSport) ?? learnSports[0];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 grid gap-6 motion-safe:animate-[learn-panel-in_.45s_cubic-bezier(0.22,1,0.36,1)_both] lg:grid-cols-[1.05fr_.95fr]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-3xl border border-[#dce8e2] bg-white p-6 sm:p-8",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-[#eaf5d8] text-2xl",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													"aria-hidden": true,
													children: sport.emoji
												})
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "font-cabinet text-2xl font-bold tracking-tight text-[#102521]",
												children: sport.name
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 text-sm leading-relaxed text-[#5e746e]",
											children: sport.blurb
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-6 grid gap-2 sm:grid-cols-3",
											children: sport.facts.map((fact, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												style: { animationDelay: `${120 + i * 80}ms` },
												className: "rounded-xl border border-[#dce8e2] bg-[#f6f8f7] p-3 motion-safe:animate-[learn-rule-in_.4s_ease-out_both]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-[9px] font-bold uppercase tracking-[.14em] text-[#5e746e]",
													children: fact.label
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 block font-cabinet text-xs font-bold leading-snug text-[#102521]",
													children: fact.value
												})]
											}, fact.label))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-7 text-xs font-bold uppercase tracking-[.18em] text-[#12806d]",
											children: "How it is played"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "mt-4 space-y-3",
											children: sport.rules.map((rule, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
												style: { animationDelay: `${360 + i * 90}ms` },
												className: "flex gap-3 text-sm leading-relaxed text-[#102521] motion-safe:animate-[learn-rule-in_.4s_ease-out_both]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[#b8f05a] ring-2 ring-[#b8f05a]/25" }), rule]
											}, rule))
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group relative isolate flex aspect-video flex-col justify-between overflow-hidden rounded-3xl border border-[#0f4a40] bg-[#061a17] p-5 text-white",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: sport.photo,
											alt: `${sport.name} being played`,
											loading: "lazy",
											className: "absolute inset-0 -z-10 h-full w-full object-cover opacity-45 transition duration-700 group-hover:scale-105 group-hover:opacity-60"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 -z-10 bg-linear-to-t from-[#061a17] via-[#061a17]/55 to-transparent" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[10px] font-bold uppercase tracking-[.18em] text-[#b8f05a]",
											children: [sport.name, " tutorial"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col items-center",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "flex h-14 w-14 items-center justify-center rounded-full bg-[#b8f05a] text-[#102521] shadow-lg shadow-[#b8f05a]/25 transition duration-300 group-hover:scale-110",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlay, { className: "h-8 w-8" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "mt-3 text-center font-cabinet text-base font-bold",
													children: [
														"Watch how ",
														sport.name.toLowerCase(),
														" is played"
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1 text-center text-[10px] uppercase tracking-[.14em] text-white/50",
													children: "Video coming soon"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-1 w-full overflow-hidden rounded-full bg-white/15",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-1/4 rounded-full bg-[#b8f05a]/70" })
										})
									]
								})]
							}, sport.slug);
						})()
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "upcoming-events",
				"data-nav": "Upcoming Events",
				className: "relative isolate overflow-hidden border-t border-[#b8f05a]/25 bg-[#09231f] py-20 text-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-24 top-1/2 -z-10 h-80 w-80 -translate-y-1/2 rounded-full bg-[#b8f05a]/10 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-7xl gap-8 px-5 sm:px-8 lg:grid-cols-[1fr_.9fr] lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-bold uppercase tracking-[.2em] text-[#b8f05a]",
							children: "Upcoming events"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-4xl font-bold tracking-tight sm:text-5xl",
							children: "Your next game could be bigger than a booking."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-2xl text-base leading-relaxed text-white/70",
							children: "Soon, partner venues will be able to share tournaments, leagues, open play, and community events directly on CourtHub."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl border border-white/15 bg-white/[0.07] p-6 shadow-2xl backdrop-blur-sm sm:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-[#b8f05a] text-[#102521]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "h-6 w-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-6 inline-flex rounded-full border border-[#b8f05a]/35 bg-[#b8f05a]/10 px-3 py-1 text-[11px] font-bold uppercase tracking-[.16em] text-[#d9ff9b]",
								children: "Tenant event posting · coming soon"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 font-display text-2xl font-bold",
								children: "A home for local game days."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-white/65",
								children: "Check back for event schedules, tournament details, venue announcements, and ways to join in."
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "features",
				"data-nav": "Features",
				ref: featuresRef,
				className: "relative isolate overflow-hidden bg-[#e9f2e5] py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -right-24 top-24 -z-10 h-96 w-96 rounded-full bg-[#b8f05a]/20 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-5 sm:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
						eyebrow: "Built around game time",
						title: "Everything between finding a court and stepping onto it.",
						highlight: "stepping onto it."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
						children: featureCards.map(([Icon, title, description], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							style: { animationDelay: `${index * 60}ms` },
							className: `group relative overflow-hidden rounded-2xl border border-[#dce8e2] bg-white p-5 transition duration-300 hover:-translate-y-1.5 hover:border-[#b8f05a] hover:shadow-xl hover:shadow-[#102521]/8 ${featuresLit ? "motion-safe:animate-[sport-fade-in-up_.5s_cubic-bezier(0.2,0.8,0.2,1)_both]" : ""}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-y-0 left-0 w-1 origin-top scale-y-0 bg-linear-to-b from-[#b8f05a] to-[#12806d] transition-transform duration-500 group-hover:scale-y-100" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex h-11 w-11 items-center justify-center rounded-xl bg-[#eaf5d8] text-[#126152] transition duration-300 group-hover:bg-[#b8f05a] group-hover:text-[#102521]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-5 font-cabinet text-lg font-bold tracking-tight text-[#102521] transition-colors duration-300 group-hover:text-[#12806d]",
									children: title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-[#5e746e]",
									children: description
								})
							]
						}, title))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "highlights",
				"data-nav": "Highlights",
				className: "mx-auto max-w-7xl px-5 py-20 sm:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
						eyebrow: "The CourtHub community",
						title: "More than a booking. A reason to show up."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "group relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex items-center gap-2 rounded-full border border-[#0b3d35] bg-white px-4 py-2.5 text-sm font-bold text-[#0b3d35] shadow-sm transition group-hover:bg-[#0b3d35] group-hover:text-white focus:bg-[#0b3d35] focus:text-white",
							"aria-haspopup": "true",
							children: ["Browse highlights ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "invisible absolute right-0 top-full z-20 mt-2 w-64 translate-y-1 rounded-2xl border border-[#dce8e2] bg-white p-2 opacity-0 shadow-xl transition duration-200 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:visible group-focus-within:translate-y-0 group-focus-within:opacity-100",
							children: highlightCategories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setHighlightOpen({
									key: category.key,
									idx: 0
								}),
								className: "flex w-full items-start justify-between gap-3 rounded-xl px-3 py-2.5 text-left transition hover:bg-[#eff5ed]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-bold text-[#0b3d35]",
									children: category.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 block text-[11px] leading-relaxed text-[#5e746e]",
									children: category.copy
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 rounded-full bg-[#eaf5d8] px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-[#126152]",
									children: category.images.length
								})]
							}, category.key))
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group/strip relative mt-10",
					onMouseEnter: pauseStrip,
					onMouseLeave: () => resumeStrip(),
					onFocusCapture: pauseStrip,
					onBlurCapture: () => resumeStrip(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: stripRef,
							onTouchStart: pauseStrip,
							onTouchEnd: () => resumeStrip(2500),
							onTouchCancel: () => resumeStrip(2500),
							className: "overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								style: { animationPlayState: stripPaused ? "paused" : "running" },
								className: "flex w-max gap-3 motion-safe:animate-[highlight-marquee_40s_linear_infinite]",
								children: [...highlightFrames, ...highlightFrames].map((frame, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setHighlightOpen({
										key: frame.category.key,
										idx: frame.category.images.indexOf(frame.src)
									}),
									"aria-label": `View ${frame.category.label.toLowerCase()} highlights`,
									"aria-hidden": index >= highlightFrames.length,
									tabIndex: index >= highlightFrames.length ? -1 : 0,
									className: "group/tile relative h-44 w-64 shrink-0 overflow-hidden rounded-2xl bg-[#0b3d35] ring-1 ring-[#dce8e2] transition duration-300 hover:ring-2 hover:ring-[#b8f05a] focus:outline-none focus:ring-2 focus:ring-[#b8f05a] sm:h-52 sm:w-72",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: frame.src,
											alt: `${frame.category.label} highlight`,
											loading: "lazy",
											className: "h-full w-full object-cover transition duration-700 group-hover/tile:scale-105"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 bg-linear-to-t from-[#061a17]/85 via-[#061a17]/20 to-transparent opacity-0 transition-opacity duration-300 group-hover/tile:opacity-100" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "absolute inset-x-3 bottom-3 flex translate-y-2 items-center justify-between gap-2 opacity-0 transition duration-300 group-hover/tile:translate-y-0 group-hover/tile:opacity-100",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate rounded-full bg-[#b8f05a] px-2.5 py-1 font-cabinet text-[10px] font-bold uppercase tracking-[.1em] text-[#102521]",
												children: frame.category.label
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "shrink-0 rounded-full bg-white/15 px-2 py-1 text-[9px] font-bold uppercase tracking-[.1em] text-white backdrop-blur-sm",
												children: [frame.category.images.length, " photos"]
											})]
										})
									]
								}, `${frame.src}-${index}`))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-y-0 left-0 w-10 bg-linear-to-r from-white to-transparent sm:w-16" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-y-0 right-0 w-10 bg-linear-to-l from-white to-transparent sm:w-16" }),
						[{
							dir: -1,
							Icon: ChevronLeft,
							side: "left-2 sm:left-3",
							label: "Scroll highlights left"
						}, {
							dir: 1,
							Icon: ChevronRight,
							side: "right-2 sm:right-3",
							label: "Scroll highlights right"
						}].map(({ dir, Icon, side, label }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": label,
							onClick: () => stripRef.current?.scrollBy({
								left: dir * 300,
								behavior: "smooth"
							}),
							className: `absolute top-1/2 z-10 -translate-y-1/2 rounded-full border border-[#dce8e2] bg-white/95 p-2 text-[#0b3d35] shadow-md transition duration-200 hover:border-[#b8f05a] hover:text-[#12806d] ${side} ${stripPaused ? "opacity-100" : "pointer-events-none opacity-0"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
						}, label))
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "testimonials",
				className: "bg-[#e9f2e5] py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-5 sm:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
							eyebrow: "Player stories",
							title: "People trust people. So do we."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-2xl text-base leading-relaxed text-[#5e746e]",
							children: "From finding a nearby court to getting a confirmed slot, CourtHub keeps game plans simple."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 grid gap-4 md:grid-cols-3",
							children: [
								{
									quote: "Booking was fast and hassle-free. I could see which hours were open before I left home.",
									name: "Maria",
									role: "Badminton player",
									rating: 5,
									avatar: "https://images.pexels.com/photos/29088255/pexels-photo-29088255.jpeg?auto=compress&cs=tinysrgb&w=240&h=240&fit=crop",
									likes: 200
								},
								{
									quote: "Finally an easy way to reserve courts online. The confirmation made it easy to organize our group.",
									name: "John",
									role: "Weekend basketball captain",
									rating: 5,
									avatar: "https://images.pexels.com/photos/37437993/pexels-photo-37437993.jpeg?auto=compress&cs=tinysrgb&w=240&h=240&fit=crop",
									likes: 500
								},
								{
									quote: "I like that each venue shows its court details and payment options clearly. No more back-and-forth messages.",
									name: "Alyssa",
									role: "Pickleball player",
									rating: 5,
									avatar: "https://images.pexels.com/photos/29341356/pexels-photo-29341356.jpeg?auto=compress&cs=tinysrgb&w=240&h=240&fit=crop",
									likes: 1e3
								}
							].map(({ quote, name, role, rating, avatar, likes }) => {
								const liked = !!likedStories[name];
								const total = likes + (liked ? 1 : 0);
								const likeLabel = total >= 1e3 ? `${Math.floor(total / 100) / 10}k` : `${total}`;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
									className: "group flex min-h-64 flex-col rounded-2xl border border-[#dce8e2] bg-white p-6 shadow-[0_12px_30px_rgba(16,37,33,0.08)] transition duration-300 hover:-translate-y-1 hover:border-[#b8f05a] hover:shadow-[0_18px_38px_rgba(16,37,33,0.12)]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex min-w-0 items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "relative flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-full bg-[#eaf5d8] font-cabinet text-sm font-bold text-[#12806d] ring-2 ring-white",
													children: [name.charAt(0), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
														src: avatar,
														alt: "",
														loading: "lazy",
														className: "absolute inset-0 h-full w-full object-cover"
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "min-w-0",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "block truncate font-cabinet text-sm font-bold text-[#102521]",
														children: name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "mt-0.5 block truncate text-[11px] text-[#5e746e]",
														children: role
													})]
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "flex shrink-0 items-center gap-0.5",
												"aria-label": `${rating} out of 5 stars`,
												children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
													"aria-hidden": true,
													className: `h-3.5 w-3.5 ${i < rating ? "fill-[#f0b429] text-[#f0b429]" : "text-[#dce8e2]"}`
												}, i))
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
											className: "mt-5 font-cabinet text-lg font-bold leading-snug text-[#0b3d35]",
											children: [
												"“",
												quote,
												"”"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
											className: "mt-auto flex items-center justify-between gap-3 border-t border-[#dce8e2] pt-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] text-[#5e746e]",
												children: "Verified player story"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												"aria-pressed": liked,
												"aria-label": liked ? `Unlike ${name}'s story` : `Like ${name}'s story`,
												onClick: () => setLikedStories((prev) => ({
													...prev,
													[name]: !prev[name]
												})),
												className: `relative inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-bold transition duration-300 ${liked ? "border-[#e5484d]/40 bg-[#e5484d]/10 text-[#e5484d]" : "border-[#dce8e2] text-[#5e746e] hover:border-[#e5484d]/40 hover:text-[#e5484d]"}`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: `h-3.5 w-3.5 ${liked ? "fill-current motion-safe:animate-[like-pop_.45s_ease-out]" : ""}` }, String(liked)),
													likeLabel,
													liked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														"aria-hidden": true,
														className: "pointer-events-none absolute left-[13px] top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#e5484d] opacity-0 motion-safe:animate-[like-ring_.55s_ease-out_forwards]"
													})
												]
											})]
										})
									]
								}, name);
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "why-courthub",
				ref: whyRef,
				className: "relative isolate overflow-hidden bg-[#09231f] py-20 text-white",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-24 top-0 -z-10 h-80 w-80 rounded-full bg-[#b8f05a]/10 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-32 -left-20 -z-10 h-80 w-80 rounded-full bg-[#12806d]/40 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-7xl gap-10 px-5 sm:px-8 lg:grid-cols-[.9fr_1.1fr] lg:items-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:sticky lg:top-24",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative mb-6 w-fit",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-6 -z-10 rounded-full bg-[#b8f05a]/10 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: "/courthub-logo.png",
										alt: "",
										width: 500,
										height: 500,
										loading: "lazy"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-sm font-bold uppercase tracking-[.2em] text-[#b8f05a] sm:text-base",
									children: "Why choose CourtHub"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "mt-2 text-balance font-display text-4xl font-bold leading-[1.08] tracking-tight sm:text-5xl",
									children: ["Less coordinating. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[#b8f05a]",
										children: "More playing."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-xl text-base leading-relaxed text-white/70",
									children: "CourtHub brings venue details, live court availability, and the right payment flow into one place—so your next game is easier to plan and easier to keep."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/explore",
									search: {},
									className: "mt-7 inline-flex items-center gap-2 rounded-full bg-[#b8f05a] px-5 py-3 text-sm font-bold text-[#102521] transition hover:-translate-y-0.5 hover:bg-[#d3ff87]",
									children: ["Find a court ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [
								[
									CalendarCheck2,
									"Instant booking",
									"Choose available hours and reserve them in a guided flow."
								],
								[
									Clock3,
									"Real-time availability",
									"See open, held, and booked time slots before you commit."
								],
								[
									ShieldCheck,
									"Secure payments",
									"Pay online when a venue requires it, with a clear payment status."
								],
								[
									Building2,
									"Trusted venue details",
									"Review court information, amenities, hours, and venue policies upfront."
								],
								[
									CalendarDays,
									"Organized schedules",
									"Get a booking reference and keep your game plan clear."
								],
								[
									MapPin,
									"Built for local play",
									"Discover partner venues and more ways to get your community on court."
								],
								[
									Wifi,
									"Play from anywhere",
									"Use CourtHub on any connected phone, tablet, or computer—whether you are planning at home or on the way to the venue."
								],
								[
									Sparkles,
									"Mobile-first, installable next",
									"The booking experience is designed for phones today and ready for a future installable CourtHub app experience."
								]
							].map(([Icon, title, copy], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								style: { animationDelay: `${index * 70}ms` },
								className: `group relative flex flex-col overflow-hidden rounded-2xl border border-white/15 bg-white/6 p-5 backdrop-blur-sm transition duration-300 hover:-translate-y-1.5 hover:border-[#b8f05a]/60 hover:bg-white/10 hover:shadow-lg hover:shadow-[#b8f05a]/10 ${whyLit ? "motion-safe:animate-[sport-fade-in-up_.5s_cubic-bezier(0.2,0.8,0.2,1)_both]" : ""}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#b8f05a]/15 text-[#b8f05a] ring-1 ring-[#b8f05a]/25 transition duration-300 group-hover:bg-[#b8f05a] group-hover:text-[#102521] group-hover:ring-[#b8f05a]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "shrink-0 rounded-full border border-white/10 px-2 py-0.5 font-cabinet text-[10px] font-bold tracking-[.1em] text-white/35 transition duration-300 group-hover:border-[#b8f05a]/40 group-hover:text-[#b8f05a]",
											children: ["0", index + 1]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-4 font-cabinet text-lg font-bold tracking-tight transition-colors duration-300 group-hover:text-[#b8f05a]",
										children: title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1.5 text-sm leading-relaxed text-white/65",
										children: copy
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-auto block pt-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-px w-0 bg-linear-to-r from-[#b8f05a] to-transparent transition-all duration-500 group-hover:w-full" })
									})
								]
							}, title))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "about",
				"data-nav": "About",
				className: "bg-[#e9f2e5] py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-7xl gap-12 px-5 sm:px-8 lg:grid-cols-[1.1fr_.9fr] lg:items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
							eyebrow: "About CourtHub",
							title: "More access to sport starts with a better way to book.",
							highlight: "a better way to book."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-2xl text-base leading-relaxed text-[#5e746e]",
							children: "CourtHub connects players with quality sports venues across the Philippines. We are building the trusted place to discover a court, understand availability, and make a reservation without the back-and-forth."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-2xl text-base leading-relaxed text-[#5e746e]",
							children: "Our mission is to make sports more accessible for everyone through simpler court reservations and stronger local sports communities."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							[
								Handshake,
								"Community",
								"Built around local players and the venues they play at."
							],
							[
								Sparkles,
								"Innovation",
								"Booking tools that keep pace with how people actually play."
							],
							[
								ShieldCheck,
								"Trust",
								"Clear policies, clear prices, and a record of every booking."
							],
							[
								Wifi,
								"Accessibility",
								"Usable on whatever device is in your hand right now."
							],
							[
								Trophy,
								"Sportsmanship",
								"Time on court is easier to share when it is easy to plan."
							],
							[
								Clock3,
								"Reliability",
								"Availability you can act on, not a guess to be confirmed."
							]
						].map(([Icon, label, copy]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group rounded-2xl border border-[#dce8e2] bg-white p-4 transition duration-300 hover:-translate-y-1 hover:border-[#b8f05a] hover:shadow-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex h-10 w-10 items-center justify-center rounded-xl bg-[#eaf5d8] text-[#12806d] transition group-hover:bg-[#b8f05a] group-hover:text-[#102521]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-cabinet text-sm font-bold text-[#102521]",
									children: label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-[11px] leading-relaxed text-[#5e746e]",
									children: copy
								})
							]
						}, label))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "faq",
				className: "mx-auto max-w-5xl px-5 py-20 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-sm font-bold uppercase tracking-[.2em] text-[#12806d] sm:text-base",
								children: "FAQ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mx-auto mt-2 max-w-2xl text-balance font-display text-4xl font-bold leading-[1.08] tracking-tight sm:text-5xl",
								children: ["Booking questions, ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[#4d7c0f]",
									children: "answered."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mt-4 max-w-2xl text-base leading-relaxed text-[#5e746e]",
								children: "Everything you need to know before you choose a court and lock in a game."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 space-y-3",
						children: [
							["Can I cancel my booking?", "Yes, when the venue’s cancellation window allows it. Open your booking details to review the venue’s policy and cancel before its stated cutoff time."],
							["How do refunds work?", "Refund eligibility follows the cancellation policy set by each venue. If your booking qualifies, CourtHub records the request and the refund is handled through the venue’s configured payment process."],
							["Can I pay at the venue?", "Some venues accept payment at the venue, while others require the full amount online. The booking panel shows the exact payment requirement before you confirm."],
							["What sports are supported?", "CourtHub supports the sports offered by its partner venues, including badminton, basketball, football, pickleball, tennis, volleyball, and more. Use the sport filter to see what is available near you."],
							["How do I know my court is reserved?", "After you confirm a booking—or complete online payment where required—you’ll receive a booking reference. Your selected hours are then reflected in the court’s live availability."]
						].map(([question, answer]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "group overflow-hidden rounded-2xl border border-[#dce8e2] bg-white shadow-sm transition duration-300 hover:border-[#b8f05a] open:border-[#12806d]/40 open:shadow-[0_12px_28px_rgba(16,37,33,0.08)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
								className: "flex cursor-pointer list-none items-center gap-4 px-5 py-5 marker:content-none",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-8 w-1 shrink-0 rounded-full bg-transparent transition-colors duration-300 group-open:bg-[#b8f05a]" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 font-cabinet text-base font-bold text-[#0b3d35] transition-colors duration-300 group-hover:text-[#12806d] sm:text-lg",
										children: question
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#eff5ed] text-[#12806d] transition duration-300 group-hover:bg-[#eaf5d8] group-open:rotate-180 group-open:bg-[#b8f05a] group-open:text-[#102521]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4" })
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ml-5 max-w-3xl border-t border-[#e9f2e5] py-4 pl-5 pr-5 text-sm leading-relaxed text-[#5e746e]",
								children: answer
							})]
						}, question))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col items-center gap-3 rounded-2xl border border-dashed border-[#aac2b8] bg-[#f6f8f7] px-5 py-6 text-center sm:flex-row sm:justify-between sm:text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-cabinet text-sm font-bold text-[#102521]",
							children: "Still have a question?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-[11px] text-[#5e746e]",
							children: "Send it over and we will come back to you."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#contact",
							className: "inline-flex shrink-0 items-center gap-2 rounded-full bg-[#0b3d35] px-4 py-2.5 font-cabinet text-xs font-bold text-white transition hover:-translate-y-0.5 hover:bg-[#126152]",
							children: ["Contact us ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5" })]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "contact",
				"data-nav": "Contact",
				className: "bg-[#e9f2e5] py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-7xl gap-10 px-5 sm:px-8 lg:grid-cols-[.85fr_1.15fr] lg:items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionIntro, {
							eyebrow: "Contact",
							title: "Let’s get more people playing.",
							highlight: "playing."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md leading-relaxed text-[#5e746e]",
							children: "Questions about booking, venues, or becoming a CourtHub partner? Our team is ready to help."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 space-y-3",
							children: [
								{
									Icon: Mail,
									label: "Email us",
									value: "hello@courthub.ph",
									href: "mailto:hello@courthub.ph"
								},
								{
									Icon: Phone,
									label: "Call us",
									value: "+63 000 000 0000",
									href: null
								},
								{
									Icon: Clock3,
									label: "Office hours",
									value: "Mon – Fri, 9:00 AM – 6:00 PM",
									href: null
								}
							].map(({ Icon, label, value, href }) => {
								const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#eaf5d8] text-[#12806d] transition group-hover:bg-[#b8f05a] group-hover:text-[#102521]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-[10px] font-bold uppercase tracking-[.14em] text-[#5e746e]",
										children: label
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 block truncate font-cabinet text-sm font-bold text-[#102521]",
										children: value
									})]
								})] });
								const className = "group flex items-center gap-3 rounded-2xl border border-[#dce8e2] bg-white p-3.5 transition duration-300 hover:-translate-y-0.5 hover:border-[#b8f05a] hover:shadow-md";
								return href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href,
									className,
									children: body
								}, label) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className,
									children: body
								}, label);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-[.14em] text-[#5e746e]",
								children: "Follow along"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center gap-2",
								children: [[
									{
										name: "Facebook",
										Icon: Facebook
									},
									{
										name: "Instagram",
										Icon: Instagram
									},
									{
										name: "TikTok",
										Icon: Music2
									}
								].map(({ name, Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => noteSocialSoon(name),
									"aria-label": `${name} — coming soon`,
									className: "rounded-full border border-[#dce8e2] bg-white p-2.5 text-[#0b3d35] transition hover:-translate-y-0.5 hover:border-[#b8f05a] hover:text-[#12806d]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
								}, name)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `text-[11px] font-semibold text-[#12806d] transition-opacity duration-200 ${socialSoon ? "opacity-100" : "opacity-0"}`,
									children: [socialSoon, " coming soon"]
								})]
							})]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "overflow-hidden rounded-3xl border border-[#dce8e2] bg-white shadow-sm",
						onSubmit: (event) => {
							event.preventDefault();
							setContactNotice(true);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative overflow-hidden bg-[#09231f] px-5 py-5 text-white sm:px-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -right-10 -top-14 h-36 w-36 rounded-full bg-[#b8f05a]/20 blur-3xl" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "relative text-[10px] font-bold uppercase tracking-[.18em] text-[#b8f05a]",
									children: "Send a message"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "relative mt-1 font-cabinet text-xl font-bold tracking-tight",
									children: "Tell us what you need"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5 sm:p-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 sm:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingInput, {
										label: "Name",
										placeholder: "Your name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingInput, {
										label: "Email",
										placeholder: "you@example.com",
										type: "email"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingInput, {
									label: "Subject",
									placeholder: "How can we help?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-4 block text-sm font-bold",
									children: ["Message", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										className: "mt-2 min-h-32 w-full rounded-xl border border-[#d8e4df] bg-[#fbfcfb] px-3 py-2.5 outline-none transition focus:border-[#12806d] focus:ring-2 focus:ring-[#b8f05a]/50",
										placeholder: "Tell us a little more",
										required: true
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-5 flex flex-wrap items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										className: "inline-flex items-center gap-2 rounded-full bg-[#0b3d35] px-5 py-3 font-cabinet text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-[#126152]",
										children: ["Send message ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
									}), contactNotice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1.5 text-xs font-semibold text-[#12806d]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "h-3.5 w-3.5 shrink-0" }),
											"Not connected yet — email",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: "mailto:hello@courthub.ph",
												className: "underline",
												children: "hello@courthub.ph"
											})
										]
									})]
								})
							]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto max-w-7xl px-5 sm:px-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentRally, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative isolate overflow-hidden bg-[#09231f] px-5 py-20 text-center text-white sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: heroImages[2],
						alt: "",
						className: "absolute inset-0 -z-10 h-full w-full object-cover opacity-25",
						loading: "lazy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 -z-10 bg-[#09231f]/75" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/courthub-badge.png",
						alt: "",
						loading: "lazy",
						className: "pointer-events-none absolute right-6 top-1/2 -z-10 hidden h-64 w-64 -translate-y-1/2 opacity-25 md:block lg:right-16 lg:h-80 lg:w-80"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold uppercase tracking-[.2em] text-[#b8f05a]",
						children: "Ready when you are"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-5xl font-bold tracking-tight",
						children: "Ready to play?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-4 max-w-lg text-white/70",
						children: "Reserve your next court in minutes with CourtHub."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-7 flex justify-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: startBooking,
							className: "rounded-full bg-[#b8f05a] px-5 py-3 font-bold text-[#102521]",
							children: "Book now"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/explore",
							search: {},
							className: "rounded-full border border-white/30 px-5 py-3 font-bold hover:bg-white/10",
							children: "Browse venues"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "bg-[#061a17] px-5 py-8 text-white/65 sm:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl flex-col items-center gap-5 sm:flex-row sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/favicon.png",
							alt: "",
							width: 256,
							height: 256,
							className: "h-9 w-9 shrink-0 object-contain"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs leading-relaxed",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-white/80",
								children: [
									"© ",
									(/* @__PURE__ */ new Date()).getFullYear(),
									" CourtHub. All rights reserved."
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-0.5 block text-[11px] text-white/45",
								children: ["× Digitalization ", (/* @__PURE__ */ new Date()).getFullYear()]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-5 text-xs font-semibold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/privacy",
								className: "transition hover:text-[#b8f05a]",
								children: "Privacy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								className: "h-3 w-px bg-white/15"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/terms",
								className: "transition hover:text-[#b8f05a]",
								children: "Terms & Conditions"
							})
						]
					})]
				})
			}),
			highlightOpen && (() => {
				const category = highlightCategories.find((c) => c.key === highlightOpen.key);
				if (!category) return null;
				const idx = (highlightOpen.idx % category.images.length + category.images.length) % category.images.length;
				const step = (delta) => setHighlightOpen((open) => open && {
					...open,
					idx: open.idx + delta
				});
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "fixed inset-0 z-1400 flex flex-col items-center justify-center gap-4 bg-black/90 p-4 motion-safe:animate-[landing-overlay-in_.2s_ease-out_both]",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": `${category.label} highlights`,
					onClick: () => setHighlightOpen(null),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute left-4 top-4 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-[#b8f05a] px-3 py-1 font-cabinet text-[11px] font-bold uppercase tracking-[.1em] text-[#102521]",
								children: category.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-semibold text-white/60",
								children: [
									idx + 1,
									" / ",
									category.images.length
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: (event) => {
								event.stopPropagation();
								setHighlightOpen(null);
							},
							"aria-label": "Close highlights",
							className: "absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white transition hover:bg-white/20",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-6 w-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: (event) => {
								event.stopPropagation();
								step(-1);
							},
							"aria-label": "Previous photo",
							className: "absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20 sm:left-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-6 w-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: (event) => {
								event.stopPropagation();
								step(1);
							},
							"aria-label": "Next photo",
							className: "absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20 sm:right-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-6 w-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: category.images[idx],
							alt: `${category.label} highlight ${idx + 1}`,
							className: "max-h-[70vh] max-w-full rounded-2xl object-contain",
							onClick: (event) => event.stopPropagation()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-2",
							onClick: (event) => event.stopPropagation(),
							children: category.images.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setHighlightOpen({
									key: category.key,
									idx: i
								}),
								"aria-label": `Photo ${i + 1}`,
								className: `h-12 w-16 overflow-hidden rounded-lg ring-2 transition ${i === idx ? "ring-[#b8f05a]" : "ring-white/20 hover:ring-white/50"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src,
									alt: "",
									className: "h-full w-full object-cover"
								})
							}, src))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center gap-2",
							onClick: (event) => event.stopPropagation(),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] font-semibold uppercase tracking-[.14em] text-white/50",
									children: "View full highlights on"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-2",
									children: [
										{
											name: "Facebook",
											Icon: Facebook
										},
										{
											name: "X",
											Icon: Twitter
										},
										{
											name: "TikTok",
											Icon: Music2
										}
									].map(({ name, Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => noteSocialSoon(name),
										className: "inline-flex items-center gap-1.5 rounded-full border border-white/20 px-3 py-1.5 text-[11px] font-bold text-white/80 transition hover:border-[#b8f05a] hover:bg-white/10 hover:text-white",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-3.5 w-3.5" }),
											" ",
											name
										]
									}, name))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: `text-[11px] font-semibold text-[#b8f05a] transition-opacity duration-200 ${socialSoon ? "opacity-100" : "opacity-0"}`,
									children: [socialSoon, " highlights coming soon"]
								})
							]
						})
					]
				});
			})(),
			lightbox && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-1300 flex items-center justify-center bg-black/85 p-5",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": "Highlight preview",
				onClick: () => setLightbox(null),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "absolute right-5 top-5 rounded-full bg-white/15 p-2 text-white",
					"aria-label": "Close preview",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: lightbox,
					alt: "CourtHub community highlight",
					className: "max-h-[85vh] max-w-full rounded-2xl object-contain"
				})]
			})
		]
	});
}
function FeaturedVenueCard({ venue, index, lit, onOpen, onBook }) {
	const courts = venue.courts ?? [];
	const images = venue.images ?? [];
	const hasMultiple = images.length > 1;
	const [imgIdx, setImgIdx] = (0, import_react.useState)(0);
	const [imgHover, setImgHover] = (0, import_react.useState)(false);
	const [detailsHover, setDetailsHover] = (0, import_react.useState)(false);
	const [gallery, setGallery] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!imgHover || !hasMultiple) return;
		const id = window.setInterval(() => setImgIdx((i) => i + 1), 1400);
		return () => window.clearInterval(id);
	}, [imgHover, hasMultiple]);
	const lowest = (0, import_react.useMemo)(() => {
		const rates = courts.map((court) => {
			const hrs = effectiveHours({
				inherit_venue_hours: court.inherit_venue_hours,
				operating_hours: court.operating_hours
			}, venue.operating_hours);
			return minRate(Number(court.hourly_rate), normalizeRules(court.rate_rules), hrs);
		});
		return rates.length ? Math.min(...rates) : null;
	}, [courts, venue.operating_hours]);
	const hoursToday = (0, import_react.useMemo)(() => {
		const window_ = describeWindow(normalizeHours(venue.operating_hours)[HOUR_DAY_KEYS[zonedDayOfWeek(zonedDateISO())]]);
		if (window_ === "Closed") return {
			label: "Closed today",
			closed: true
		};
		if (window_ === "Open 24 hours") return {
			label: "Open 24 hours",
			closed: false
		};
		return {
			label: window_,
			closed: false
		};
	}, [venue.operating_hours]);
	const sports = (0, import_react.useMemo)(() => Array.from(new Set(courts.map((c) => c.sports?.name).filter(Boolean))), [courts]);
	const shownSports = sports.slice(0, 2);
	const extraSports = sports.slice(2);
	const idx = images.length ? (imgIdx % images.length + images.length) % images.length : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		onClick: onOpen,
		onKeyDown: (event) => {
			if (event.key === "Enter" || event.key === " ") {
				event.preventDefault();
				onOpen();
			}
		},
		role: "link",
		tabIndex: 0,
		style: { animationDelay: `${index * 110}ms` },
		className: `group flex cursor-pointer overflow-hidden rounded-2xl border border-[#dce8e2] bg-white shadow-sm transition duration-300 hover:-translate-y-1.5 hover:border-[#b8f05a] hover:shadow-xl hover:shadow-[#0b3d35]/12 focus:outline-none focus:ring-2 focus:ring-[#12806d] ${lit ? "motion-safe:animate-[sport-fade-in-up_.5s_cubic-bezier(0.2,0.8,0.2,1)_both]" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex w-1/2 min-w-0 flex-col p-4",
				onMouseEnter: () => setDetailsHover(true),
				onMouseLeave: () => setDetailsHover(false),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex w-fit items-center gap-1 rounded-full bg-[#eaf5d8] px-2 py-0.5 text-[10px] font-bold uppercase tracking-[.1em] text-[#4d7c0f]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-3 w-3 fill-current" }), " Featured venue"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-2 truncate font-cabinet text-lg font-bold tracking-tight text-[#102521] transition-colors duration-300 group-hover:text-[#12806d]",
						children: venue.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 flex items-start gap-1 text-[11px] leading-snug text-[#5e746e]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-px h-3 w-3 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "line-clamp-2",
							children: venue.address
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: `mt-2 inline-flex w-fit items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold ${hoursToday.closed ? "bg-[#f4e6e6] text-[#8a3d3d]" : "bg-[#eff5ed] text-[#12806d]"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "h-3 w-3" }),
							" ",
							hoursToday.label
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap items-center gap-1",
						children: [shownSports.map((sport) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full border border-[#dce8e2] bg-[#eaf5d8] px-2 py-0.5 font-cabinet text-[10px] font-semibold text-[#12806d]",
							children: sport
						}, sport)), extraSports.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							title: extraSports.join(", "),
							className: "rounded-full border border-[#dce8e2] bg-white px-2 py-0.5 font-cabinet text-[10px] font-semibold text-[#5e746e]",
							children: ["+", extraSports.length]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `h-8 transition-opacity duration-300 ${detailsHover ? "opacity-100" : "opacity-0"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-[10px] font-semibold text-[#12806d]",
								children: [
									courts.length,
									" ",
									courts.length === 1 ? "court" : "courts",
									" available"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-0.5 flex items-center gap-1 text-[10px] text-[#5e746e]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "h-3 w-3 shrink-0" }), " Tap here to view more venue details"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex items-end justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-[#5e746e]",
								children: lowest != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									"from ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
										className: "text-base font-bold text-[#0b3d35]",
										children: ["₱", lowest.toFixed(0)]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px]",
										children: " /hr"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: (event) => {
									event.stopPropagation();
									onBook();
								},
								className: "shrink-0 rounded-full bg-[#0b3d35] px-3 py-1.5 font-cabinet text-[11px] font-bold text-white transition hover:bg-[#b8f05a] hover:text-[#102521]",
								children: "Book now"
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative w-1/2 shrink-0 overflow-hidden bg-[#0b3d35]",
				onMouseEnter: () => setImgHover(true),
				onMouseLeave: () => {
					setImgHover(false);
					setImgIdx(0);
				},
				onClick: (event) => {
					event.stopPropagation();
					if (images.length > 0) setGallery(idx);
				},
				children: [
					images.length > 0 ? images.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src,
						alt: "",
						loading: "lazy",
						className: `absolute inset-0 h-full w-full object-cover transition-opacity duration-500 ${i === idx ? "opacity-100" : "opacity-0"}`
					}, src)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex h-full w-full items-center justify-center text-4xl",
						children: venue.map_emoji || "🏟️"
					}),
					hasMultiple && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute bottom-2 left-1/2 flex -translate-x-1/2 gap-1",
						children: images.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1 rounded-full transition-all duration-300 ${i === idx ? "w-3 bg-[#b8f05a]" : "w-1 bg-white/50"}` }, src))
					}),
					images.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pointer-events-none absolute inset-x-0 top-0 flex justify-end p-2 opacity-0 transition-opacity duration-300 group-hover:opacity-100",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-[#09231f]/80 px-2 py-0.5 text-[9px] font-bold uppercase tracking-[.1em] text-[#d9ff9b] backdrop-blur-sm",
							children: "Click to view photos"
						})
					})
				]
			}),
			gallery !== null && images.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-1400 flex items-center justify-center bg-black/90 p-4 motion-safe:animate-[landing-overlay-in_.2s_ease-out_both]",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": `${venue.name} photos`,
				onClick: (event) => {
					event.stopPropagation();
					setGallery(null);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute left-4 top-4 max-w-[70%] truncate text-sm font-semibold text-white/80",
						children: venue.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: (event) => {
							event.stopPropagation();
							setGallery(null);
						},
						"aria-label": "Close photos",
						className: "absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white transition hover:bg-white/20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-6 w-6" })
					}),
					hasMultiple && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: (event) => {
								event.stopPropagation();
								setGallery((g) => ((g ?? 0) - 1 + images.length) % images.length);
							},
							"aria-label": "Previous image",
							className: "absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20 sm:left-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-6 w-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: (event) => {
								event.stopPropagation();
								setGallery((g) => ((g ?? 0) + 1) % images.length);
							},
							"aria-label": "Next image",
							className: "absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20 sm:right-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-6 w-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full bg-white/10 px-3 py-1 text-sm font-medium text-white backdrop-blur",
							children: [
								gallery + 1,
								" / ",
								images.length
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: images[gallery],
						alt: venue.name,
						className: "max-h-full max-w-full object-contain",
						onClick: (event) => event.stopPropagation()
					})
				]
			})
		]
	});
}
function SectionIntro({ eyebrow, title, highlight, action }) {
	const cut = highlight ? title.indexOf(highlight) : -1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm font-bold uppercase tracking-[.2em] text-[#12806d] sm:text-base",
			children: eyebrow
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 max-w-2xl text-balance font-display text-4xl font-bold leading-[1.08] tracking-tight sm:text-5xl",
			children: cut >= 0 && highlight ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				title.slice(0, cut),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[#4d7c0f]",
					children: highlight
				}),
				title.slice(cut + highlight.length)
			] }) : title
		})] }), action]
	});
}
function LandingInput({ label, placeholder, type = "text" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mt-4 block text-sm font-bold",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			placeholder,
			className: "mt-2 w-full rounded-xl border border-[#d8e4df] bg-[#fbfcfb] px-3 py-2.5 outline-none transition focus:border-[#12806d] focus:ring-2 focus:ring-[#b8f05a]/50",
			required: true
		})]
	});
}
function VenueList({ venues, activeVenueId, onSelectVenue, activeVenue, listRef, priceFilter }) {
	const MAX_VISIBLE = 50;
	const visibleVenues = venues.slice(0, MAX_VISIBLE);
	const hiddenCount = Math.max(0, venues.length - MAX_VISIBLE);
	const [listScrolled, setListScrolled] = (0, import_react.useState)(false);
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const el = listRef.current;
		if (!el) return;
		const onScroll = () => setListScrolled(el.scrollTop > 40);
		onScroll();
		el.addEventListener("scroll", onScroll, { passive: true });
		return () => el.removeEventListener("scroll", onScroll);
	}, [listRef]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden border-b-2 border-[#b8f05a]/50 bg-linear-to-br from-[#0f4a40] to-[#09231f] transition-all duration-200 " + (listScrolled ? "max-h-0 py-0 opacity-0" : "max-h-16 px-4 py-2 opacity-100"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-w-0 truncate font-display text-[15px] font-extrabold leading-tight tracking-tight text-[#b8f05a]",
						children: activeVenue ? activeVenue.name : "Venues"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 rounded-full bg-[#b8f05a] px-2 py-0.5 text-[10px] font-extrabold tabular-nums text-[#102521] shadow-sm",
						children: activeVenue ? `${activeVenue.courtCount} ${activeVenue.courtCount === 1 ? "court" : "courts"}` : `${venues.length}`
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-0.5 text-[11px] font-medium leading-snug tracking-normal text-white/70",
					children: activeVenue ? "Courts at this venue" : hiddenCount > 0 ? `Showing ${visibleVenues.length} of ${venues.length} · refine to see more` : `${venues.length === 1 ? "venue" : "venues"} found on the map`
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: listRef,
				className: "nice-scroll min-h-0 flex-1 overflow-y-auto p-3",
				children: activeVenue ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onSelectVenue(null),
							className: "mb-1 flex items-center gap-1 text-xs font-semibold text-primary hover:underline",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-3.5 w-3.5" }), " Back to all venues"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-border bg-card p-4 shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-2 text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: activeVenue.address })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/venues/$venueId",
								params: { venueId: String(activeVenue.id) },
								search: {},
								className: "mt-3 inline-flex items-center rounded-full bg-primary px-3 py-1.5 text-xs font-bold text-primary-foreground hover:opacity-90 transition",
								children: "Open venue page →"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground",
							children: [
								"Courts (",
								activeVenue.courts.length,
								")"
							]
						}),
						activeVenue.courts.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtCard, {
							c,
							index: i,
							priceFilter,
							onOpenLightbox: (idx) => setLightbox({
								name: c.name,
								images: c.images ?? [],
								idx
							})
						}, c.id))
					]
				}) : venues.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground",
					children: "No venues match your search."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [visibleVenues.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenueCard, {
						v,
						active: v.id === activeVenueId,
						onSelect: () => onSelectVenue(v.id),
						onOpenLightbox: (idx) => setLightbox({
							name: v.name,
							images: v.images ?? [],
							idx
						})
					}, v.id)), hiddenCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-dashed border-border bg-card/60 p-3 text-center text-[11px] text-muted-foreground",
						children: [
							"+",
							hiddenCount,
							" more ",
							hiddenCount === 1 ? "venue" : "venues",
							" — use search or filters to narrow down."
						]
					})]
				})
			}),
			lightbox && lightbox.images.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-1400 flex items-center justify-center bg-black/90 p-4",
				onClick: () => setLightbox(null),
				role: "dialog",
				"aria-modal": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setLightbox(null),
						"aria-label": "Close",
						className: "absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white transition hover:bg-white/20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-6 w-6" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute left-4 top-4 max-w-[70%] truncate text-sm font-semibold text-white/80",
						children: lightbox.name
					}),
					lightbox.images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: (e) => {
								e.stopPropagation();
								setLightbox((s) => s && {
									...s,
									idx: (s.idx - 1 + s.images.length) % s.images.length
								});
							},
							"aria-label": "Previous image",
							className: "absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20 sm:left-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-6 w-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: (e) => {
								e.stopPropagation();
								setLightbox((s) => s && {
									...s,
									idx: (s.idx + 1) % s.images.length
								});
							},
							"aria-label": "Next image",
							className: "absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20 sm:right-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-6 w-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full bg-white/10 px-3 py-1 text-sm font-medium text-white backdrop-blur",
							children: [
								lightbox.idx + 1,
								" / ",
								lightbox.images.length
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: lightbox.images[lightbox.idx],
						alt: lightbox.name,
						className: "max-h-full max-w-full object-contain",
						onClick: (e) => e.stopPropagation()
					})
				]
			})
		]
	});
}
function VenueCard({ v, active, onSelect, onOpenLightbox }) {
	const pinned = v.latitude != null && v.longitude != null;
	const images = v.images ?? [];
	const hasImages = images.length > 0;
	const hasMultiple = images.length > 1;
	const [imgIdx, setImgIdx] = (0, import_react.useState)(0);
	const idx = (imgIdx % images.length + images.length) % images.length;
	const [imgHover, setImgHover] = (0, import_react.useState)(false);
	const [sportsPopoverOpen, setSportsPopoverOpen] = (0, import_react.useState)(false);
	const VISIBLE_SPORTS = 2;
	const extraSports = (v.sports ?? []).slice(VISIBLE_SPORTS);
	(0, import_react.useEffect)(() => {
		if (!imgHover || !hasMultiple) return;
		const id = setInterval(() => setImgIdx((i) => i + 1), 1400);
		return () => clearInterval(id);
	}, [imgHover, hasMultiple]);
	const hoursToday = (0, import_react.useMemo)(() => {
		const week = normalizeHours(v.operatingHours);
		const todayKey = HOUR_DAY_KEYS[zonedDayOfWeek(zonedDateISO())];
		const window = describeWindow(week[todayKey]);
		if (window === "Closed") return {
			label: "Closed today",
			closed: true
		};
		if (window === "Open 24 hours") return {
			label: "Open 24 hours",
			closed: false
		};
		return {
			label: `Open ${window}`,
			closed: false
		};
	}, [v.operatingHours]);
	const activate = () => pinned && onSelect();
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-vid": v.id,
		className: "group flex h-48 w-full flex-row overflow-hidden rounded-2xl text-left transition-all duration-200 " + (active ? "bg-primary/5 ring-2 ring-primary shadow-lg shadow-primary/10" : "bg-card ring-1 ring-border hover:ring-primary/60 hover:shadow-md") + (pinned ? "" : " opacity-50"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative h-full w-1/2 shrink-0 overflow-hidden bg-muted",
			onMouseEnter: () => setImgHover(true),
			onMouseLeave: () => {
				setImgHover(false);
				setImgIdx(0);
			},
			children: [
				hasImages ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: (e) => {
							e.stopPropagation();
							onOpenLightbox(idx);
						},
						"aria-label": "View full image",
						className: "block h-full w-full cursor-zoom-in",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: images[idx],
							alt: v.name,
							className: "h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-linear-to-t from-black/50 via-transparent to-transparent" }),
					hasMultiple && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: (e) => {
								e.stopPropagation();
								setImgIdx((i) => i - 1);
							},
							"aria-label": "Previous image",
							className: "absolute left-1.5 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-1 text-white opacity-0 transition group-hover:opacity-100 hover:bg-black/70",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-3.5 w-3.5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: (e) => {
								e.stopPropagation();
								setImgIdx((i) => i + 1);
							},
							"aria-label": "Next image",
							className: "absolute right-1.5 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-1 text-white opacity-0 transition group-hover:opacity-100 hover:bg-black/70",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute bottom-2 left-2 rounded-full bg-black/60 px-1.5 py-0.5 text-[9px] font-semibold text-white",
							children: [
								idx + 1,
								"/",
								images.length
							]
						})
					] })
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full w-full items-center justify-center bg-linear-to-br from-primary/10 to-muted text-3xl",
					children: v.mapEmoji ?? "🏟️"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute left-2 top-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 rounded-full bg-white/95 px-2.5 py-1 shadow-md ring-1 ring-black/5 dark:bg-neutral-900/95 dark:ring-white/10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 shrink-0 rounded-full " + (hoursToday.closed ? "bg-muted-foreground" : "bg-emerald-500") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "whitespace-nowrap text-[10px] font-bold " + (hoursToday.closed ? "text-muted-foreground" : "text-foreground"),
							children: hoursToday.label
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute bottom-2 right-2",
					children: v.courtCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 rounded-full bg-white/95 py-1 pl-1 pr-2.5 shadow-md ring-1 ring-black/5 dark:bg-neutral-900/95 dark:ring-white/10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[11px] font-extrabold text-primary-foreground",
							children: v.courtCount
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] font-bold text-foreground",
							children: v.courtCount === 1 ? "court" : "courts"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-full bg-black/60 px-2.5 py-1 text-[10px] font-semibold text-white/80 backdrop-blur-sm",
						children: "No courts yet"
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col gap-2 overflow-hidden bg-linear-to-br from-[#0f4a40] to-[#09231f] p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "truncate rounded-lg bg-[#b8f05a]/15 px-2.5 py-1.5 font-display text-[13px] font-bold leading-tight text-[#b8f05a] ring-1 ring-[#b8f05a]/25 transition-colors group-hover:text-[#d3ff87]",
					children: v.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-1.5 text-[11px] text-white/65",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-3 w-3 shrink-0 text-[#b8f05a]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "line-clamp-1",
						children: v.address
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-[22px] items-center gap-1 overflow-hidden",
					children: v.sports && v.sports.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [v.sports.slice(0, VISIBLE_SPORTS).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 whitespace-nowrap rounded-full bg-[#b8f05a]/15 px-2 py-0.5 text-[10px] font-semibold text-[#b8f05a] ring-1 ring-[#b8f05a]/25",
						children: s
					}, s)), extraSports.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
						open: sportsPopoverOpen,
						onOpenChange: setSportsPopoverOpen,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								role: "button",
								tabIndex: 0,
								onClick: (e) => {
									e.stopPropagation();
									if (typeof window !== "undefined" && window.matchMedia("(hover: hover) and (pointer: fine)").matches) e.preventDefault();
								},
								onMouseEnter: () => setSportsPopoverOpen(true),
								onMouseLeave: () => setSportsPopoverOpen(false),
								onKeyDown: (e) => {
									if (e.key === "Enter" || e.key === " ") {
										e.preventDefault();
										e.stopPropagation();
										setSportsPopoverOpen((o) => !o);
									}
								},
								className: "shrink-0 cursor-pointer whitespace-nowrap rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-medium text-white/70 transition hover:bg-white/20",
								children: ["+", extraSports.length]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
							align: "start",
							sideOffset: 6,
							className: "w-auto max-w-56 border-[#b8f05a]/25 bg-linear-to-br from-[#0f4a40] to-[#09231f] p-2",
							onClick: (e) => e.stopPropagation(),
							onMouseEnter: () => setSportsPopoverOpen(true),
							onMouseLeave: () => setSportsPopoverOpen(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1",
								children: extraSports.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "whitespace-nowrap rounded-full bg-[#b8f05a]/15 px-2 py-0.5 text-[10px] font-semibold text-[#b8f05a] ring-1 ring-[#b8f05a]/25",
									children: s
								}, s))
							})
						})]
					})] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto flex min-h-[26px] items-center justify-between gap-1.5 border-t border-white/10 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 shrink truncate whitespace-nowrap text-[11px] font-medium text-white/60",
						children: v.distanceKm != null ? `${v.distanceKm.toFixed(1)} km away` : !pinned ? "No location" : "Available now"
					}), v.minRate != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 whitespace-nowrap rounded-md bg-[#b8f05a]/15 px-2 py-0.5 text-[11px] font-bold text-[#b8f05a] ring-1 ring-[#b8f05a]/25",
						children: v.maxRate != null && v.maxRate > v.minRate ? `₱${v.minRate.toFixed(0)}–${v.maxRate.toFixed(0)}/hr` : `₱${v.minRate.toFixed(0)}/hr`
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 whitespace-nowrap text-[10px] text-white/40",
						children: "No courts"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: activate,
						disabled: !pinned,
						className: "flex-1 cursor-pointer rounded-lg bg-[#b8f05a] px-2 py-2 text-center text-[11px] font-extrabold uppercase tracking-wide text-[#102521] shadow-sm transition hover:bg-[#d3ff87] disabled:cursor-not-allowed disabled:opacity-40 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#b8f05a] focus-visible:ring-offset-1 focus-visible:ring-offset-[#09231f]",
						children: "Book Court"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => navigate({
							to: "/venues/$venueId",
							params: { venueId: String(v.id) },
							search: {}
						}),
						className: "flex-1 cursor-pointer rounded-lg bg-[#12806d] px-2 py-2 text-center text-[11px] font-extrabold uppercase tracking-wide text-white ring-1 ring-white/15 transition hover:bg-[#12806d]/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-1 focus-visible:ring-offset-[#09231f]",
						children: "View Venue"
					})]
				})
			]
		})]
	});
}
/** Court tile in the "Courts at this venue" panel — mirrors VenueCard's
*  split layout: photo on the left half, details and Book Now on the right. */
function CourtCard({ c, index, priceFilter, onOpenLightbox }) {
	const images = c.images ?? [];
	const hasImages = images.length > 0;
	const hasMultiple = images.length > 1;
	const lowRate = c.rateMin ?? c.hourly_rate;
	const highRate = c.rateMax ?? c.hourly_rate;
	const showsRange = highRate > lowRate;
	const [imgIdx, setImgIdx] = (0, import_react.useState)(0);
	const idx = (imgIdx % images.length + images.length) % images.length;
	const [imgHover, setImgHover] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!imgHover || !hasMultiple) return;
		const id = setInterval(() => setImgIdx((i) => i + 1), 1400);
		return () => clearInterval(id);
	}, [imgHover, hasMultiple]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "group flex h-40 w-full flex-row overflow-hidden rounded-2xl bg-card ring-1 ring-border transition-all duration-200 hover:ring-primary/60 hover:shadow-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative h-full w-1/2 shrink-0 overflow-hidden bg-muted",
			onMouseEnter: () => setImgHover(true),
			onMouseLeave: () => {
				setImgHover(false);
				setImgIdx(0);
			},
			children: [hasImages ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onOpenLightbox(idx),
					"aria-label": "View full image",
					className: "block h-full w-full cursor-zoom-in",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: images[idx],
						alt: c.name,
						className: "h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-linear-to-t from-black/50 via-transparent to-transparent" }),
				hasMultiple && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setImgIdx((i) => i - 1),
						"aria-label": "Previous image",
						className: "absolute left-1.5 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-1 text-white opacity-0 transition group-hover:opacity-100 hover:bg-black/70",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-3.5 w-3.5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setImgIdx((i) => i + 1),
						"aria-label": "Next image",
						className: "absolute right-1.5 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-1 text-white opacity-0 transition group-hover:opacity-100 hover:bg-black/70",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute bottom-2 left-2 rounded-full bg-black/60 px-1.5 py-0.5 text-[9px] font-semibold text-white",
						children: [
							idx + 1,
							"/",
							images.length
						]
					})
				] })
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-full w-full items-center justify-center bg-linear-to-br from-primary/10 to-muted text-3xl",
				children: c.mapEmoji ?? "🏟️"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute left-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-white/95 text-[11px] font-extrabold text-foreground shadow-md ring-1 ring-black/5 dark:bg-neutral-900/95 dark:ring-white/10",
				children: index + 1
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col gap-2 overflow-hidden bg-linear-to-br from-[#0f4a40] to-[#09231f] p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "truncate rounded-lg bg-[#b8f05a]/15 px-2.5 py-1.5 font-display text-[13px] font-bold leading-tight text-[#b8f05a] ring-1 ring-[#b8f05a]/25",
					children: c.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-[22px] items-center gap-1 overflow-hidden",
					children: c.sportName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 whitespace-nowrap rounded-full bg-[#b8f05a]/15 px-2 py-0.5 text-[10px] font-semibold text-[#b8f05a] ring-1 ring-[#b8f05a]/25",
						children: c.sportName
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto flex min-h-[26px] items-center justify-between gap-1.5 border-t border-white/10 pt-2",
					children: [showsRange ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex shrink-0 cursor-pointer items-center gap-1 whitespace-nowrap text-[11px] font-medium text-white/70 underline decoration-dotted underline-offset-2 transition hover:text-[#b8f05a] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#b8f05a]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "h-3 w-3 shrink-0" }), "Rate card"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
						align: "start",
						sideOffset: 6,
						className: "w-auto max-w-xs border-[#b8f05a]/25 bg-[#0f4a40] p-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RateCard, {
							baseRate: c.baseRate ?? c.hourly_rate,
							rules: c.rateRules ?? [],
							hours: c.openHours ?? null,
							variant: "dark",
							highlight: priceFilter
						})
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] font-medium text-white/60",
						children: "rate"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 whitespace-nowrap rounded-md bg-[#b8f05a]/15 px-2 py-0.5 text-[11px] font-bold text-[#b8f05a] ring-1 ring-[#b8f05a]/25",
						children: showsRange ? `₱${lowRate.toFixed(0)}–${highRate.toFixed(0)}/hr` : `₱${lowRate.toFixed(0)}/hr`
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/courts/$courtId",
					params: { courtId: String(c.id) },
					search: {},
					className: "w-full shrink-0 rounded-lg bg-[#b8f05a] px-3 py-2 text-center text-[11px] font-extrabold uppercase tracking-wide text-[#102521] shadow-sm transition hover:bg-[#d3ff87] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#b8f05a] focus-visible:ring-offset-1 focus-visible:ring-offset-[#09231f]",
					children: "Book Now →"
				})
			]
		})]
	});
}
//#endregion
export { Route as n, VenueExplorer as r, LandingPage as t };
