import { n as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/court-pricing-CFeeeUa8.js
var court_pricing_CFeeeUa8_exports = /* @__PURE__ */ __exportAll({
	A: () => isClosed,
	C: () => HOUR_DAY_KEYS,
	D: () => effectiveHours,
	E: () => describeWindow,
	F: () => openHoursForDay,
	I: () => parseWindow,
	M: () => makeWindow,
	N: () => normalizeHours,
	O: () => fmtHour,
	P: () => openHoursForDate,
	S: () => CLOSED,
	T: () => describeWeek,
	_: () => rateBands,
	a: () => court_pricing_exports,
	b: () => rateInBounds,
	c: () => fmtHour12,
	d: () => minRate,
	f: () => newRule,
	g: () => priceForHours,
	h: () => priceBreakdown,
	i: () => WEEKENDS,
	j: () => isOvernight,
	k: () => fullWeek,
	l: () => hasVariablePricing,
	m: () => peso,
	n: () => DAY_LABELS,
	o: () => defaultRuleTemplate,
	p: () => normalizeRules,
	r: () => WEEKDAYS,
	s: () => distinctRates,
	t: () => DAY_KEYS,
	u: () => maxRate,
	v: () => rateCardGroups,
	w: () => HOUR_DAY_LABELS,
	x: () => ALL_DAY,
	y: () => rateForHour
});
var HOUR_DAY_KEYS = [
	"sun",
	"mon",
	"tue",
	"wed",
	"thu",
	"fri",
	"sat"
];
var HOUR_DAY_LABELS = {
	sun: "Sunday",
	mon: "Monday",
	tue: "Tuesday",
	wed: "Wednesday",
	thu: "Thursday",
	fri: "Friday",
	sat: "Saturday"
};
var ALL_DAY = "00:00-24:00";
var CLOSED = "closed";
function fullWeek(window = ALL_DAY) {
	return Object.fromEntries(HOUR_DAY_KEYS.map((d) => [d, window]));
}
function normalizeHours(raw) {
	const out = fullWeek();
	if (!raw || typeof raw !== "object") return out;
	for (const d of HOUR_DAY_KEYS) {
		const v = raw[d];
		if (typeof v === "string" && v.trim()) out[d] = v.trim();
	}
	return out;
}
/** [startHour, endHour]; endHour <= startHour means it wraps past midnight. */
function parseWindow(raw) {
	if (!raw) return [0, 24];
	const t = raw.trim();
	if (t === "closed") return null;
	const m = /^(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})$/.exec(t);
	if (!m) return [0, 24];
	const s = Math.max(0, Math.min(24, parseInt(m[1], 10)));
	const e = Math.max(0, Math.min(24, parseInt(m[3], 10)));
	if (s === e) return [0, 24];
	return [s, e];
}
function makeWindow(start, end) {
	const p = (h) => `${String(h).padStart(2, "0")}:00`;
	return `${p(start)}-${p(end === 24 ? 24 : end)}`;
}
function isOvernight(raw) {
	const w = parseWindow(raw);
	return !!w && w[1] < w[0];
}
function isClosed(raw) {
	return parseWindow(raw) === null;
}
function dayKeyOf(dateISO) {
	return HOUR_DAY_KEYS[(/* @__PURE__ */ new Date(`${dateISO}T00:00:00`)).getDay()];
}
function prevDayKey(day) {
	return HOUR_DAY_KEYS[(HOUR_DAY_KEYS.indexOf(day) + 6) % 7];
}
/** The hours (0–23) a court is open on a given weekday, including yesterday's overnight tail. */
function openHoursForDay(hours, day) {
	const open = /* @__PURE__ */ new Set();
	const w = parseWindow(hours[day]);
	if (w) if (w[1] > w[0]) for (let h = w[0]; h < w[1]; h++) open.add(h);
	else for (let h = w[0]; h < 24; h++) open.add(h);
	const wp = parseWindow(hours[prevDayKey(day)]);
	if (wp && wp[1] < wp[0]) for (let h = 0; h < wp[1]; h++) open.add(h);
	return open;
}
/** The hours (0–23) a court is open on a given calendar date, in venue-local time. */
function openHoursForDate(hours, dateISO) {
	return openHoursForDay(hours, dayKeyOf(dateISO));
}
/** Effective schedule for a court: its own only when it opts out of the venue's. */
function effectiveHours(court, venueHours) {
	return normalizeHours(court.inherit_venue_hours !== false ? venueHours : court.operating_hours);
}
function fmtHour(h) {
	const hh = (h % 24 + 24) % 24;
	const period = hh < 12 ? "AM" : "PM";
	return `${hh % 12 === 0 ? 12 : hh % 12}:00 ${period}`;
}
/** "8:00 AM – 5:00 PM", "Open 24 hours", "Closed", "6:00 PM – 2:00 AM (next day)" */
function describeWindow(raw) {
	const w = parseWindow(raw);
	if (!w) return "Closed";
	if (w[0] === 0 && w[1] === 24) return "Open 24 hours";
	const label = `${fmtHour(w[0])} – ${fmtHour(w[1])}`;
	return w[1] < w[0] ? `${label} (next day)` : label;
}
/** Compact weekly summary, grouping consecutive days that share a window. */
function describeWeek(hours) {
	const order = [
		"mon",
		"tue",
		"wed",
		"thu",
		"fri",
		"sat",
		"sun"
	];
	const out = [];
	let runStart = 0;
	for (let i = 1; i <= order.length; i++) {
		if (i < order.length && hours[order[i]] === hours[order[runStart]]) continue;
		const a = order[runStart];
		const b = order[i - 1];
		const short = (d) => HOUR_DAY_LABELS[d].slice(0, 3);
		out.push({
			days: runStart === i - 1 ? short(a) : `${short(a)}–${short(b)}`,
			window: describeWindow(hours[a])
		});
		runStart = i;
	}
	return out;
}
var court_pricing_exports = /* @__PURE__ */ __exportAll$1({
	DAY_KEYS: () => DAY_KEYS,
	DAY_LABELS: () => DAY_LABELS,
	WEEKDAYS: () => WEEKDAYS,
	WEEKENDS: () => WEEKENDS,
	defaultRuleTemplate: () => defaultRuleTemplate,
	distinctRates: () => distinctRates,
	fmtHour12: () => fmtHour12,
	hasVariablePricing: () => hasVariablePricing,
	maxRate: () => maxRate,
	minRate: () => minRate,
	newRule: () => newRule,
	normalizeRules: () => normalizeRules,
	peso: () => peso,
	priceBreakdown: () => priceBreakdown,
	priceForHours: () => priceForHours,
	rateBands: () => rateBands,
	rateCardGroups: () => rateCardGroups,
	rateForDayHour: () => rateForDayHour,
	rateForHour: () => rateForHour,
	rateInBounds: () => rateInBounds
});
/** The hours of `day` a player can actually book, or `null` for "every hour" when
*  no schedule is supplied.
*
*  Every price below is derived from open hours only. A court open 6am–11pm whose
*  rules cover exactly those hours never charges its base rate, so quoting that
*  base — in a range, a rate card or the ₱/hr filter — advertises a price nobody
*  can book. */
function bookableHours(day, hours) {
	return hours ? openHoursForDay(hours, day) : null;
}
var DAY_KEYS = [
	"sun",
	"mon",
	"tue",
	"wed",
	"thu",
	"fri",
	"sat"
];
var DAY_LABELS = {
	sun: "Sun",
	mon: "Mon",
	tue: "Tue",
	wed: "Wed",
	thu: "Thu",
	fri: "Fri",
	sat: "Sat"
};
var WEEKDAYS = [
	"mon",
	"tue",
	"wed",
	"thu",
	"fri"
];
var WEEKENDS = ["sat", "sun"];
function normalizeRules(raw) {
	if (!Array.isArray(raw)) return [];
	const out = [];
	for (const r of raw) {
		if (!r || typeof r !== "object") continue;
		const o = r;
		const days = Array.isArray(o.days) ? o.days.filter((d) => DAY_KEYS.includes(d)) : [];
		const start = Number(o.start_hour);
		const end = Number(o.end_hour);
		const rate = Number(o.rate);
		if (days.length === 0 || !Number.isFinite(start) || !Number.isFinite(end) || !(rate > 0)) continue;
		if (!(start >= 0 && end <= 24 && start < end)) continue;
		out.push({
			id: typeof o.id === "string" ? o.id : `${days.join("")}-${start}-${end}`,
			label: typeof o.label === "string" ? o.label : void 0,
			days,
			start_hour: Math.floor(start),
			end_hour: Math.ceil(end),
			rate
		});
	}
	return out;
}
/** Rate for one hour slot on a given ISO date (yyyy-mm-dd) in local time. */
function rateForHour(baseRate, rules, dateISO, hour) {
	const day = DAY_KEYS[(/* @__PURE__ */ new Date(`${dateISO}T00:00:00`)).getDay()];
	return rateForDayHour(baseRate, rules, day, hour);
}
function rateForDayHour(baseRate, rules, day, hour) {
	let rate = Number(baseRate) || 0;
	for (const r of rules) if (r.days.includes(day) && hour >= r.start_hour && hour < r.end_hour) rate = r.rate;
	return rate;
}
/** Total for a set of hour indexes on a date. */
function priceForHours(baseRate, rules, dateISO, hours) {
	return hours.reduce((sum, h) => sum + rateForHour(baseRate, rules, dateISO, h), 0);
}
/** Lowest rate a player could pay across the whole week (for "from ₱X" labels). */
function minRate(baseRate, rules, hours) {
	let min = null;
	for (const d of DAY_KEYS) {
		const open = bookableHours(d, hours);
		for (let h = 0; h < 24; h++) {
			if (open && !open.has(h)) continue;
			const r = rateForDayHour(baseRate, rules, d, h);
			if (min == null || r < min) min = r;
		}
	}
	return min ?? (Number(baseRate) || 0);
}
function maxRate(baseRate, rules, hours) {
	let max = null;
	for (const d of DAY_KEYS) {
		const open = bookableHours(d, hours);
		for (let h = 0; h < 24; h++) {
			if (open && !open.has(h)) continue;
			const r = rateForDayHour(baseRate, rules, d, h);
			if (max == null || r > max) max = r;
		}
	}
	return max ?? (Number(baseRate) || 0);
}
function hasVariablePricing(baseRate, rules, hours) {
	return rules.length > 0 && minRate(baseRate, rules, hours) !== maxRate(baseRate, rules, hours);
}
/** Collapse a day's 24 hours into contiguous bands of equal price. */
function rateBands(baseRate, rules, day, hours) {
	const open = bookableHours(day, hours);
	const bands = [];
	let contiguous = false;
	for (let h = 0; h < 24; h++) {
		if (open && !open.has(h)) {
			contiguous = false;
			continue;
		}
		const r = rateForDayHour(baseRate, rules, day, h);
		const last = bands[bands.length - 1];
		if (contiguous && last && last.rate === r) last.end = h + 1;
		else bands.push({
			start: h,
			end: h + 1,
			rate: r
		});
		contiguous = true;
	}
	return bands;
}
/** Does a single hour's rate sit inside the filter? The one predicate behind both
*  the explore filter and the rate card's highlighting, so a lit band and an
*  included venue can never disagree. */
function rateInBounds(rate, bounds) {
	if (bounds.min != null && rate < bounds.min) return false;
	if (bounds.max != null && rate > bounds.max) return false;
	return true;
}
/** Every distinct ₱/hr this court charges across the week, ascending.
*
*  Filtering on these rather than on the [cheapest, dearest] span matters: a court
*  charging only ₱20 and ₱43 does *not* match "₱25–30", even though that span
*  overlaps its range. Comparing the real rates keeps the rate card honest — a
*  matched court always has at least one band to light up. */
function distinctRates(baseRate, rules, hours) {
	const seen = /* @__PURE__ */ new Set();
	for (const day of DAY_KEYS) for (const b of rateBands(baseRate, rules, day, hours)) seen.add(b.rate);
	if (!seen.size) seen.add(Number(baseRate) || 0);
	return [...seen].sort((a, b) => a - b);
}
/** The rate card as rows to print: consecutive days whose bands are identical are
*  folded into one row, so the usual weekday/weekend split renders as "Mon–Fri"
*  and "Sat–Sun" while a court that prices Wednesday differently still shows it
*  on its own line instead of being averaged away. */
function rateCardGroups(baseRate, rules, hours) {
	const week = [
		"mon",
		"tue",
		"wed",
		"thu",
		"fri",
		"sat",
		"sun"
	];
	const signature = (bands) => bands.map((b) => `${b.start}-${b.end}-${b.rate}`).join("|");
	const runs = [];
	for (const day of week) {
		const bands = rateBands(baseRate, rules, day, hours);
		const last = runs[runs.length - 1];
		if (last && signature(last.bands) === signature(bands)) last.days.push(day);
		else runs.push({
			days: [day],
			bands
		});
	}
	return runs.filter((r) => r.bands.length > 0).map(({ days, bands }) => ({
		label: days.length === 1 ? DAY_LABELS[days[0]] : `${DAY_LABELS[days[0]]}–${DAY_LABELS[days[days.length - 1]]}`,
		days,
		bands
	}));
}
/** Breakdown like [{ rate: 300, hours: 2 }, { rate: 450, hours: 3 }] sorted by rate. */
function priceBreakdown(baseRate, rules, dateISO, hours) {
	const map = /* @__PURE__ */ new Map();
	for (const h of hours) {
		const r = rateForHour(baseRate, rules, dateISO, h);
		map.set(r, (map.get(r) ?? 0) + 1);
	}
	return [...map.entries()].map(([rate, count]) => ({
		rate,
		hours: count
	})).sort((a, b) => a.rate - b.rate);
}
var peso = (n) => `₱${Number(n).toLocaleString("en-PH", {
	minimumFractionDigits: 0,
	maximumFractionDigits: 2
})}`;
function fmtHour12(h) {
	const hh = (h % 24 + 24) % 24;
	const period = hh < 12 ? "AM" : "PM";
	return `${hh % 12 === 0 ? 12 : hh % 12}:00 ${period}`;
}
/** Six sensible starter rows for the tenant "Quick setup" button. */
function defaultRuleTemplate(baseRate) {
	const b = Math.max(1, Math.round(Number(baseRate) || 300));
	const mk = (label, days, start, end, rate) => ({
		id: `${label}-${start}-${end}-${Math.random().toString(36).slice(2, 7)}`,
		label,
		days,
		start_hour: start,
		end_hour: end,
		rate
	});
	return [
		mk("Weekday morning", WEEKDAYS, 6, 12, b),
		mk("Weekday afternoon", WEEKDAYS, 12, 17, Math.round(b * 1.2)),
		mk("Weekday evening", WEEKDAYS, 17, 23, Math.round(b * 1.5)),
		mk("Weekend morning", WEEKENDS, 6, 12, Math.round(b * 1.3)),
		mk("Weekend afternoon", WEEKENDS, 12, 17, Math.round(b * 1.4)),
		mk("Weekend evening", WEEKENDS, 17, 23, Math.round(b * 1.7))
	];
}
function newRule(baseRate) {
	return {
		id: `rule-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
		label: "",
		days: [...WEEKDAYS],
		start_hour: 6,
		end_hour: 12,
		rate: Math.max(1, Math.round(Number(baseRate) || 300))
	};
}
//#endregion
export { peso as A, minRate as C, openHoursForDate as D, normalizeRules as E, rateForHour as F, rateInBounds as I, priceForHours as M, rateBands as N, openHoursForDay as O, rateCardGroups as P, maxRate as S, normalizeHours as T, fullWeek as _, HOUR_DAY_KEYS as a, isOvernight as b, WEEKENDS as c, describeWeek as d, describeWindow as f, fmtHour12 as g, fmtHour as h, DAY_LABELS as i, priceBreakdown as j, parseWindow as k, court_pricing_CFeeeUa8_exports as l, effectiveHours as m, CLOSED as n, HOUR_DAY_LABELS as o, distinctRates as p, DAY_KEYS as r, WEEKDAYS as s, ALL_DAY as t, defaultRuleTemplate as u, hasVariablePricing as v, newRule as w, makeWindow as x, isClosed as y };
