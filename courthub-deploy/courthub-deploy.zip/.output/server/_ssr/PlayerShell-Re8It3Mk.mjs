import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Dd0V2lPq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as PopoverTrigger, i as PopoverContent, r as Popover } from "./popover-Z5PgJyYY.mjs";
import { B as MapPin, H as LogOut, L as Menu, X as Heart, _t as BookOpen, dt as CheckCheck, pt as CalendarDays, t as X, vt as Bell } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PlayerShell-Re8It3Mk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Live notification feed for the signed-in user. */
function useNotifications(userId) {
	const qc = useQueryClient();
	const query = useQuery({
		queryKey: ["notifications", userId],
		enabled: !!userId,
		queryFn: async () => {
			const { data, error } = await supabase.from("notifications").select("id, type, title, body, link, booking_id, venue_id, conversation_id, read_at, created_at").order("created_at", { ascending: false }).limit(50);
			if (error) throw error;
			return data ?? [];
		}
	});
	(0, import_react.useEffect)(() => {
		if (!userId) return;
		const channel = supabase.channel(`notifications:${userId}:${Math.random().toString(36).slice(2)}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "notifications",
			filter: `user_id=eq.${userId}`
		}, () => qc.invalidateQueries({ queryKey: ["notifications", userId] })).subscribe();
		return () => {
			supabase.removeChannel(channel);
		};
	}, [userId, qc]);
	const items = query.data ?? [];
	const unread = items.filter((n) => !n.read_at).length;
	const markRead = async (ids) => {
		if (ids.length === 0) return;
		await supabase.from("notifications").update({ read_at: (/* @__PURE__ */ new Date()).toISOString() }).in("id", ids);
		qc.invalidateQueries({ queryKey: ["notifications", userId] });
	};
	const markAllRead = () => markRead(items.filter((n) => !n.read_at).map((n) => n.id));
	return {
		items,
		unread,
		loading: query.isLoading,
		markRead,
		markAllRead
	};
}
function timeAgo(iso) {
	const diff = Date.now() - new Date(iso).getTime();
	const m = Math.round(diff / 6e4);
	if (m < 1) return "just now";
	if (m < 60) return `${m}m ago`;
	const h = Math.round(m / 60);
	if (h < 24) return `${h}h ago`;
	const d = Math.round(h / 24);
	if (d < 7) return `${d}d ago`;
	return new Date(iso).toLocaleDateString("en-PH", {
		month: "short",
		day: "numeric"
	});
}
var NOTIFICATION_ICON = {
	booking_cancelled: "🚫",
	booking_confirmed: "✅",
	booking_reminder_day: "📅",
	booking_reminder_soon: "⏰",
	refund: "💸",
	message: "💬",
	hours_changed: "🕒"
};
function NotificationBell({ userId, onOpenBooking, align = "end" }) {
	const { items, unread, loading, markRead, markAllRead } = useNotifications(userId);
	const [open, setOpen] = (0, import_react.useState)(false);
	const navigate = useNavigate();
	if (!userId) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				"aria-label": unread > 0 ? `${unread} unread notifications` : "Notifications",
				className: "relative rounded-md border border-border p-2 text-foreground hover:bg-secondary",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "h-4 w-4" }), unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground",
					children: unread > 9 ? "9+" : unread
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverContent, {
			align,
			className: "z-[1300] w-[min(22rem,calc(100vw-2rem))] p-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-sm font-semibold",
					children: "Notifications"
				}), unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => markAllRead(),
					className: "inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-semibold text-primary hover:bg-primary/10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "h-3.5 w-3.5" }), " Mark all read"]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nice-scroll max-h-[60vh] overflow-y-auto",
				children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-6 text-center text-xs text-muted-foreground",
					children: "Loading…"
				}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-8 text-center text-xs text-muted-foreground",
					children: "Nothing yet. Booking changes, refunds and messages will show up here."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: items.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						if (!n.read_at) markRead([n.id]);
						if (n.booking_id && onOpenBooking) {
							onOpenBooking(n.booking_id, n.conversation_id);
							setOpen(false);
							return;
						}
						if (n.link) {
							setOpen(false);
							navigate({ to: n.link });
						}
					},
					className: "flex w-full gap-2.5 border-b border-border/70 px-3 py-2.5 text-left transition hover:bg-secondary/70 " + (n.read_at ? "" : "bg-primary/5"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 text-base leading-none",
							children: NOTIFICATION_ICON[n.type] ?? "🔔"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs font-semibold leading-snug",
									children: n.title
								}),
								n.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 block line-clamp-2 text-[11px] text-muted-foreground",
									children: n.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-[10px] uppercase tracking-wider text-muted-foreground",
									children: timeAgo(n.created_at)
								})
							]
						}),
						!n.read_at && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" })
					]
				}) }, n.id)) })
			})]
		})]
	});
}
var chLogo = { url: "/CHicon.png" };
/** No Home entry on purpose. Once a player is signed in their start page is
*  Explore; the landing page belongs to signed-out visitors, and `LandingPage`
*  bounces a signed-in player back to /explore. Signing out is the way back. */
var PLAYER_NAV = [
	{
		key: "explore",
		label: "Explore",
		icon: MapPin,
		to: "/explore",
		search: {}
	},
	{
		key: "favorites",
		label: "Favorites",
		icon: Heart,
		to: "/dashboard",
		search: { view: "favorites" }
	},
	{
		key: "bookings",
		label: "My Bookings",
		icon: BookOpen,
		to: "/dashboard",
		search: {}
	},
	{
		key: "calendar",
		label: "Calendar",
		icon: CalendarDays,
		to: "/dashboard",
		search: { view: "calendar" }
	}
];
function PlayerShell({ children, section, mobileOpen, setMobileOpen, collapsed, setCollapsed, userId, fullName, onSignOut }) {
	const current = PLAYER_NAV.find((n) => n.key === section);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh w-full",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "sticky top-0 hidden shrink-0 self-start border-r-2 border-[#b8f05a]/40 bg-linear-to-b from-[#0f4a40] to-[#09231f] text-white md:flex md:h-dvh md:flex-col transition-[width] duration-200 " + (collapsed ? "md:w-16" : "md:w-62.5"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerSidebarBody, {
					section,
					collapsed,
					setCollapsed,
					fullName,
					onSignOut
				})
			}),
			mobileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-1200 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Close menu",
					onClick: () => setMobileOpen(false),
					className: "absolute inset-0 bg-black/40"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "absolute inset-y-0 left-0 flex w-62.5 flex-col border-r-2 border-[#b8f05a]/40 bg-linear-to-b from-[#0f4a40] to-[#09231f] text-white shadow-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerSidebarBody, {
						section,
						collapsed: false,
						setCollapsed: () => {},
						onClose: () => setMobileOpen(false),
						fullName,
						onSignOut
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-full min-w-0 flex-1 flex-col overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-border bg-background px-4 py-2 md:hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setMobileOpen(true),
								className: "inline-flex items-center gap-2 rounded-md border border-border px-2.5 py-1.5 text-sm font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-4 w-4" }), " Menu"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-semibold",
								children: current?.label ?? "Workspace"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationBell, { userId })
						]
					}),
					section !== "explore" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden items-center justify-end border-b border-border bg-background px-6 py-2 md:flex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationBell, { userId })
					}),
					section === "explore" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full w-full flex-1 min-h-0",
						children
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "nice-scroll mx-auto flex w-full max-w-6xl min-h-0 flex-1 flex-col overflow-y-auto overflow-x-hidden px-4 py-6 sm:px-6 sm:py-8",
						children
					})
				]
			})
		]
	});
}
function PlayerSidebarBody({ section, collapsed, setCollapsed, onClose, fullName, onSignOut }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2 border-b border-white/10 px-3 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-w-0 items-center gap-2",
				children: collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: chLogo.url,
					alt: "CourtHub",
					className: "h-7 w-7 shrink-0 rounded-full object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "logo-glaze shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/courthub-wordmark.png",
						alt: "CourtHub",
						width: 983,
						height: 240,
						className: "h-7 w-auto object-contain"
					})
				})
			}), onClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onClose,
				"aria-label": "Close",
				className: "rounded-md p-1 text-white/70 transition-colors hover:bg-white/10 hover:text-[#b8f05a]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setCollapsed(!collapsed),
				"aria-label": collapsed ? "Expand sidebar" : "Collapse sidebar",
				className: "hidden rounded-md p-1 text-white/70 transition-colors hover:bg-white/10 hover:text-[#b8f05a] md:inline-flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-4 w-4" })
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "flex-1 overflow-y-auto p-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1",
				children: PLAYER_NAV.map(({ key, label, icon: Icon, to, search }) => {
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to,
						search,
						onClick: onClose,
						title: collapsed ? label : void 0,
						className: "flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors " + (section === key ? "bg-[#b8f05a] text-[#102521] shadow-sm" : "text-white/75 hover:bg-white/10 hover:text-[#b8f05a]"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 shrink-0" }), !collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: label
						})]
					}) }, key);
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-auto border-t border-white/10 p-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: onSignOut,
				title: collapsed ? "Sign out" : void 0,
				className: "flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm font-medium text-red-300 transition-colors hover:bg-red-500/15 hover:text-red-200",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4 shrink-0" }), !collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: "Sign out"
				})]
			})
		}),
		!collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-white/10 px-3 py-3.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "logo-glaze",
				style: { "--logo-glaze-src": "url(/role-player.png)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/role-player.png",
					alt: "",
					className: "h-8 w-auto object-contain"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 truncate font-display text-sm font-bold tracking-tight text-white",
				children: fullName || "Player"
			})]
		})
	] });
}
//#endregion
export { PlayerShell as n, NotificationBell as t };
