import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as MapInfoButton } from "./popover-Z5PgJyYY.mjs";
import { bt as Banknote } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ph-places-Ce4rPAEJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Movement below this is a click, not a drag. */
var DRAG_THRESHOLD_PX = 10;
/**
* Street View "pegman": drag the figure onto the map to open Google Street View
* at that spot.
*
* Google is only ever opened in a new tab through its documented URL scheme
* (`map_action=pano`), so this needs no Maps API key, no billing account, and
* embeds nothing — the same approach as the Directions links elsewhere in the
* app. Coverage is whatever Google has: dense along Philippine highways and
* cities, sparse on small barangay roads, and Google shows its own "no imagery
* here" screen when a spot has none.
*
* The drop is deliberately NOT gated on whether imagery exists. Checking that
* needs Google's Street View Metadata API (an API key, though the calls are
* free); the keyless alternative — treating "near an OSM road" as a proxy via
* Overpass — measured ~15s per viewport query and would still be wrong, since
* a mapped road does not imply Google drove it. So the copy sets expectations
* instead, and Google shows its own message when a spot has no panorama.
*/
function MapPegman({ pointToLatLng, containerRef, onDragStateChange, className }) {
	const [dragging, setDragging] = (0, import_react.useState)(false);
	const [ghost, setGhost] = (0, import_react.useState)(null);
	const [hint, setHint] = (0, import_react.useState)(false);
	/**
	* Drag state is held in a ref, not just React state, and the listeners below
	* are always mounted. Gating on state instead would drop the very first drag:
	* the pointer events can all arrive before React commits `dragging = true`,
	* leaving the handlers looking at a stale `false`.
	*/
	const draggingRef = (0, import_react.useRef)(false);
	/** Where the drag began, to tell a real drag from a stray click. */
	const startRef = (0, import_react.useRef)(null);
	const depsRef = (0, import_react.useRef)({
		pointToLatLng,
		containerRef,
		onDragStateChange
	});
	depsRef.current = {
		pointToLatLng,
		containerRef,
		onDragStateChange
	};
	/** Pointer type of the active drag; touch needs the ghost offset off-finger. */
	const touchRef = (0, import_react.useRef)(false);
	/**
	* True when the map is the thing actually visible at this point. A plain
	* rectangle test is not enough: on phones the venue sheet overlays the lower
	* part of the map, and dropping onto the sheet must not count as dropping on
	* the map. Hit-testing the topmost element handles any overlay. The drag
	* ghost is `pointer-events-none`, so it never shadows the result.
	*/
	const isOverMap = (x, y) => {
		const el = depsRef.current.containerRef.current;
		if (!el) return false;
		const top = document.elementFromPoint(x, y);
		return !!top && el.contains(top);
	};
	const endDrag = () => {
		if (draggingRef.current) depsRef.current.onDragStateChange?.(false);
		draggingRef.current = false;
		setDragging(false);
		setGhost(null);
	};
	(0, import_react.useEffect)(() => {
		const move = (e) => {
			if (!draggingRef.current) return;
			e.preventDefault();
			setGhost({
				x: e.clientX,
				y: e.clientY,
				overMap: isOverMap(e.clientX, e.clientY),
				touch: touchRef.current
			});
		};
		const up = (e) => {
			if (!draggingRef.current) return;
			const start = startRef.current;
			endDrag();
			if (start && Math.hypot(e.clientX - start.x, e.clientY - start.y) < DRAG_THRESHOLD_PX) return;
			if (!isOverMap(e.clientX, e.clientY)) return;
			const at = depsRef.current.pointToLatLng(e.clientX, e.clientY);
			if (!at) return;
			const url = `https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=${at.lat.toFixed(6)},${at.lng.toFixed(6)}`;
			window.open(url, "_blank", "noopener,noreferrer");
		};
		const cancel = (e) => {
			if (e.key === "Escape") endDrag();
		};
		window.addEventListener("pointermove", move, { passive: false });
		window.addEventListener("pointerup", up);
		window.addEventListener("pointercancel", endDrag);
		window.addEventListener("keydown", cancel);
		return () => {
			window.removeEventListener("pointermove", move);
			window.removeEventListener("pointerup", up);
			window.removeEventListener("pointercancel", endDrag);
			window.removeEventListener("keydown", cancel);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute z-500 " + (className ?? "right-3 top-16 md:bottom-24 md:top-auto"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Drag onto a street to open Street View",
			title: "Drag onto a road to see it at street level. Google has no imagery for every spot — roads and towns are covered best.",
			onPointerDown: (e) => {
				e.preventDefault();
				draggingRef.current = true;
				startRef.current = {
					x: e.clientX,
					y: e.clientY
				};
				touchRef.current = e.pointerType !== "mouse";
				onDragStateChange?.(true);
				setHint(false);
				setDragging(true);
				setGhost({
					x: e.clientX,
					y: e.clientY,
					overMap: isOverMap(e.clientX, e.clientY),
					touch: touchRef.current
				});
			},
			onMouseEnter: () => setHint(true),
			onMouseLeave: () => setHint(false),
			className: "relative flex h-11 w-11 touch-none select-none items-center justify-center rounded-full border-2 border-[#0f4a40] bg-white text-2xl shadow-lg ring-1 ring-[#b8f05a]/50 transition after:absolute after:-inset-2 after:content-[''] hover:scale-110 active:scale-95 dark:bg-neutral-900 " + (dragging ? "cursor-grabbing opacity-40" : "cursor-grab"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": true,
				children: "🧍"
			})
		}), hint && !dragging && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pointer-events-none absolute right-full top-1/2 mr-2 -translate-y-1/2 whitespace-nowrap rounded-md bg-[#09231f] px-2 py-1 text-[10px] font-semibold text-[#b8f05a] shadow-lg",
			children: "Drop me on a street"
		})]
	}), ghost && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none fixed z-1200 -translate-x-1/2 " + (ghost.touch ? "-translate-y-[150%]" : "-translate-y-1/2"),
		style: {
			left: ghost.x,
			top: ghost.y
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-12 w-12 items-center justify-center rounded-full text-3xl shadow-xl transition-colors " + (ghost.overMap ? "bg-[#b8f05a] ring-4 ring-[#b8f05a]/40" : "bg-white/80 grayscale"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": true,
				children: "🧍"
			})
		}), ghost.overMap && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 whitespace-nowrap rounded-md bg-[#09231f] px-2 py-1 text-center text-[10px] font-bold text-[#b8f05a] shadow-lg",
			children: ["Drop for Street View", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-[9px] font-medium text-white/60",
				children: "works best on roads"
			})]
		})]
	})] });
}
function courtOffset(lat, lng, i, total) {
	const R = 35e-5;
	const angle = i / total * Math.PI * 2 - Math.PI / 2;
	return {
		lat: lat + Math.sin(angle) * R,
		lng: lng + Math.cos(angle) * R / Math.cos(lat * Math.PI / 180)
	};
}
function buildDirUrl(lat, lng, from) {
	const base = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
	return from ? `${base}&origin=${from.lat},${from.lng}` : base;
}
function divIcon(L, html, size = 44, className = "") {
	return L.divIcon({
		className: `ch-marker ${className}`,
		html,
		iconSize: [size, size],
		iconAnchor: [size / 2, size / 2]
	});
}
function VenueMap({ venues, activeVenueId, onSelectVenue, onOpenVenue, onOpenCourt, nearby, radiusKm, radiusHasMatches, centerRef }) {
	const elRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const layerRef = (0, import_react.useRef)(null);
	const meRef = (0, import_react.useRef)(null);
	const circleRef = (0, import_react.useRef)(null);
	const streetLayerRef = (0, import_react.useRef)(null);
	const satelliteLayerRef = (0, import_react.useRef)(null);
	const readyRef = (0, import_react.useRef)(false);
	const [mapReady, setMapReady] = (0, import_react.useState)(false);
	const activeRef = (0, import_react.useRef)(null);
	const rezoomingRef = (0, import_react.useRef)(false);
	const userInteractedRef = (0, import_react.useRef)(false);
	const [view, setView] = (0, import_react.useState)("street");
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			const L = (await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).default ?? await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (!document.getElementById("leaflet-css")) {
				const link = document.createElement("link");
				link.id = "leaflet-css";
				link.rel = "stylesheet";
				link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
				document.head.appendChild(link);
			}
			if (!document.getElementById("ch-marker-css")) {
				const s = document.createElement("style");
				s.id = "ch-marker-css";
				s.textContent = `
          .ch-marker { background: transparent !important; border: 0 !important; }
          @keyframes ch-pulse-ring { 0% { transform: scale(0.6); opacity:.75;} 100% { transform: scale(1.8); opacity:0;} }
          @keyframes ch-arrow-bounce { 0%,100% { transform: translate(-50%, 0);} 50% { transform: translate(-50%, 6px);} }
          .ch-pin { position: relative; width: 52px; height: 52px; cursor: pointer; }
          .ch-pin::before { content:""; position:absolute; inset:4px; border-radius:9999px; background: #b8f05a; opacity:.55; animation: ch-pulse-ring 1.6s ease-out infinite; z-index:0; }
          .ch-pin .body { position:absolute; inset:0; border-radius:9999px; background: hsl(var(--card)); border:2px solid #12806d; box-shadow: 0 8px 22px rgba(0,0,0,.22), 0 0 0 4px rgba(18,128,109,.2); display:flex; align-items:center; justify-content:center; font-size:22px; z-index:1; }
          .ch-pin .body .emoji { display:inline-block; }
          .ch-pin .count { position:absolute; top:-4px; right:-4px; min-width:20px; height:20px; padding:0 5px; border-radius:9999px; background:#12806d; color:#fff; font-size:11px; font-weight:800; display:flex; align-items:center; justify-content:center; box-shadow: 0 2px 6px rgba(0,0,0,.25); z-index:2; }
          .ch-pin.active .body { background:#12806d; border-color:#b8f05a; }
          .ch-pin .tip { position:absolute; left:50%; bottom:-6px; width:10px; height:10px; background: hsl(var(--card)); border-right:2px solid #12806d; border-bottom:2px solid #12806d; transform: translateX(-50%) rotate(45deg); z-index:1; }
          .ch-pin.active .tip { background:#12806d; border-color:#b8f05a; }
          .ch-pin .arrow { position:absolute; left:50%; top:-26px; transform: translateX(-50%); width:0; height:0; border-left:9px solid transparent; border-right:9px solid transparent; border-top:14px solid #b8f05a; filter: drop-shadow(0 2px 3px rgba(0,0,0,.35)); animation: ch-arrow-bounce 1.1s ease-in-out infinite; z-index:3; }
          .ch-court { width: 40px; height: 40px; }
          .ch-court .body { background: hsl(var(--card)); color: hsl(var(--foreground)); border-color:#12806d; font-size:16px; }
          .ch-court .point-wrap { position:absolute; inset:0; pointer-events:none; z-index:3; }
          .ch-court .point-wrap .point { position:absolute; left:50%; top:-10px; width:0; height:0; margin-left:-6px; border-left:6px solid transparent; border-right:6px solid transparent; border-bottom:10px solid #12806d; filter: drop-shadow(0 1px 2px rgba(0,0,0,.4)); }
          .ch-me { width:18px; height:18px; border-radius:9999px; background:#12806d; border:3px solid #fff; box-shadow: 0 0 0 6px rgba(184,240,90,.5); }
          .ch-popup .leaflet-popup-content-wrapper { border-radius: 14px; padding: 2px; }
          .ch-popup .leaflet-popup-content { margin: 10px 12px; font-family: inherit; }
          .leaflet-tooltip.ch-tip-wrap { background: #ffffff; color: #0f172a; border: 1px solid rgba(0,0,0,.08); border-radius: 10px; box-shadow: 0 6px 18px rgba(0,0,0,.18); padding: 6px 10px; font-family: inherit; white-space: nowrap; max-width: none; pointer-events: auto; }
          .ch-tip-dir { display:inline-flex; align-items:center; gap:4px; font-size:11px; font-weight:700; color:#126152; text-decoration:none; padding:3px 8px; border-radius:9999px; background:rgba(184,240,90,.28); border:1px solid rgba(18,128,109,.35); }
          .ch-tip-dir:hover { background:rgba(184,240,90,.5); }
          .ch-dir-btn { display:inline-flex; align-items:center; gap:6px; margin-top:8px; font-size:12px; font-weight:700; color:#126152; text-decoration:none; padding:5px 10px; border-radius:9999px; background:rgba(184,240,90,.28); border:1px solid rgba(18,128,109,.35); }
          .ch-dir-btn:hover { background:rgba(184,240,90,.5); }
          .leaflet-tooltip.ch-tip-wrap::before { border-top-color: #ffffff; }
          .ch-tip { display: inline-flex; align-items: center; gap: 8px; }
          .ch-tip-sep { width: 1px; height: 12px; background: rgba(0,0,0,.12); flex: none; }
          .ch-tip-name { font-weight: 700; font-size: 12px; line-height: 1.2; color: #0f172a; }
          .ch-tip-addr { font-size: 11px; color: #64748b; line-height: 1.2; max-width: 220px; overflow: hidden; text-overflow: ellipsis; }
          .ch-tip-rate { font-size: 11px; font-weight: 700; color: #12806d; }
          .ch-tip-rate.ch-tip-muted { color: #64748b; font-weight: 600; }
          @keyframes ch-signal { 0% { transform: scale(0.05); opacity: .85; } 100% { transform: scale(1); opacity: 0; } }
          .ch-radius-base { transition: stroke .3s ease, fill .3s ease; }
          .ch-radius-ping { transform-box: fill-box; transform-origin: center; animation: ch-signal 2.6s ease-out infinite; }
          .ch-radius-ping-2 { animation-delay: 0.87s; }
          .ch-radius-ping-3 { animation-delay: 1.73s; }
        `;
				document.head.appendChild(s);
			}
			if (cancelled || !elRef.current) return;
			const map = L.map(elRef.current, {
				zoomControl: false,
				attributionControl: false
			}).setView([12.8797, 121.774], 6);
			L.control.zoom({ position: "bottomright" }).addTo(map);
			const street = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
				maxZoom: 19,
				attribution: ""
			});
			const satellite = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
				maxZoom: 19,
				attribution: ""
			});
			street.addTo(map);
			streetLayerRef.current = street;
			satelliteLayerRef.current = satellite;
			mapRef.current = map;
			layerRef.current = L.layerGroup().addTo(map);
			readyRef.current = true;
			setMapReady(true);
			setTimeout(() => map.invalidateSize(), 60);
			map.on("click", () => onSelectVenue(null));
			const publishCenter = () => {
				if (!centerRef) return;
				const c = map.getCenter();
				centerRef.current = {
					lat: c.lat,
					lng: c.lng
				};
			};
			publishCenter();
			map.on("moveend", publishCenter);
			map.on("zoomstart", (e) => {
				if (!rezoomingRef.current) userInteractedRef.current = true;
			});
			map.on("dragstart", () => {
				userInteractedRef.current = true;
			});
			map.on("zoomend", () => {
				const a = activeRef.current;
				if (!a || a.id == null) return;
				if (rezoomingRef.current) return;
				if (map.getZoom() < 17) onSelectVenue(null);
			});
		})();
		return () => {
			cancelled = true;
			if (mapRef.current) {
				mapRef.current.remove();
				mapRef.current = null;
				layerRef.current = null;
				meRef.current = null;
				readyRef.current = false;
			}
		};
	}, []);
	(0, import_react.useEffect)(() => {
		(async () => {
			if (!readyRef.current) return;
			const L = (await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).default ?? await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (meRef.current) {
				mapRef.current.removeLayer(meRef.current);
				meRef.current = null;
			}
			if (circleRef.current) {
				mapRef.current.removeLayer(circleRef.current);
				circleRef.current = null;
			}
			if (nearby) {
				meRef.current = L.marker([nearby.lat, nearby.lng], { icon: L.divIcon({
					className: "ch-marker",
					html: `<div class="ch-me"></div>`,
					iconSize: [18, 18],
					iconAnchor: [9, 9]
				}) }).addTo(mapRef.current);
				if (radiusKm && radiusKm > 0) {
					const color = radiusHasMatches ? "#12806d" : "#b8f05a";
					const group = L.layerGroup().addTo(mapRef.current);
					const base = L.circle([nearby.lat, nearby.lng], {
						radius: radiusKm * 1e3,
						weight: 2,
						color,
						fillColor: color,
						fillOpacity: radiusHasMatches ? .08 : .12,
						interactive: false,
						className: "ch-radius-base"
					}).addTo(group);
					[
						"ch-radius-ping",
						"ch-radius-ping ch-radius-ping-2",
						"ch-radius-ping ch-radius-ping-3"
					].forEach((cls) => {
						L.circle([nearby.lat, nearby.lng], {
							radius: radiusKm * 1e3,
							weight: 2,
							color,
							fill: false,
							interactive: false,
							className: cls
						}).addTo(group);
					});
					circleRef.current = group;
					if (activeVenueId == null) mapRef.current.fitBounds(base.getBounds(), { padding: [40, 40] });
				}
			}
		})();
	}, [
		mapReady,
		nearby,
		radiusKm,
		radiusHasMatches,
		activeVenueId
	]);
	(0, import_react.useEffect)(() => {
		(async () => {
			if (!readyRef.current) return;
			const L = (await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).default ?? await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			const layer = layerRef.current;
			layer.clearLayers();
			const pinned = venues.filter((v) => v.latitude != null && v.longitude != null);
			if (pinned.length === 0) return;
			const active = activeVenueId != null ? pinned.find((v) => v.id === activeVenueId) : null;
			if (active && active.latitude != null && active.longitude != null) {
				const vLat = active.latitude;
				const vLng = active.longitude;
				activeRef.current = {
					id: active.id,
					lat: vLat,
					lng: vLng
				};
				const venueEmoji = active.mapEmoji || "🎾";
				const centerIcon = divIcon(L, `<div class="ch-pin active"><div class="arrow"></div><div class="body"><span class="emoji">${venueEmoji}</span></div><div class="count">${active.courtCount}</div><div class="tip"></div></div>`);
				const centerMarker = L.marker([vLat, vLng], { icon: centerIcon }).addTo(layer);
				const dirUrl = buildDirUrl(vLat, vLng, nearby);
				centerMarker.bindPopup(`<div class="ch-popup-inner"><div style="font-weight:700;font-size:13px;">${active.name}</div><div style="font-size:11px;opacity:.7;">${active.address}</div><a class="ch-dir-btn" href="${dirUrl}" target="_blank" rel="noopener noreferrer">🧭 Get directions</a></div>`, {
					className: "ch-popup",
					closeButton: false,
					autoClose: false,
					closeOnClick: false
				});
				centerMarker.on("mouseover", () => centerMarker.openPopup());
				const courts = active.courts;
				courts.forEach((c, i) => {
					const total = Math.max(courts.length, 1);
					const angle = i / total * Math.PI * 2 - Math.PI / 2;
					const rotDeg = Math.atan2(-Math.cos(angle), -Math.sin(angle)) * 180 / Math.PI;
					const p = courtOffset(vLat, vLng, i, total);
					const html = `<div class="ch-pin ch-court"><div class="point-wrap" style="transform: rotate(${rotDeg}deg)"><div class="point"></div></div><div class="body"><span class="emoji">${c.mapEmoji || venueEmoji}</span></div><div class="count">${i + 1}</div></div>`;
					const m = L.marker([p.lat, p.lng], { icon: divIcon(L, html, 34, "ch-court") }).addTo(layer);
					m.bindPopup(`<div class="ch-popup-inner"><div style="font-weight:700;font-size:13px;">${c.name}</div><div style="font-size:11px;opacity:.7;">₱${Number(c.hourly_rate).toFixed(0)} / hour</div><div style="margin-top:6px;font-size:11px;color:hsl(var(--primary));font-weight:600;">Tap to book →</div></div>`, {
						className: "ch-popup",
						closeButton: false
					});
					m.on("mouseover", () => m.openPopup());
					m.on("click", (e) => {
						e.originalEvent?.stopPropagation?.();
						onOpenCourt(c.id);
					});
				});
				rezoomingRef.current = true;
				mapRef.current.flyTo([vLat, vLng], 18, { duration: .6 });
				setTimeout(() => {
					rezoomingRef.current = false;
					userInteractedRef.current = false;
				}, 700);
			} else {
				activeRef.current = null;
				pinned.forEach((v) => {
					const html = `<div class="ch-pin"><div class="body"><span class="emoji">${v.mapEmoji || "🎾"}</span></div><div class="count">${v.courtCount}</div><div class="tip"></div></div>`;
					const m = L.marker([v.latitude, v.longitude], { icon: divIcon(L, html) }).addTo(layer);
					const rateText = v.minRate == null ? "" : v.maxRate != null && v.maxRate > v.minRate ? `₱${v.minRate.toFixed(0)}–${v.maxRate.toFixed(0)}/hr` : `₱${v.minRate.toFixed(0)}/hr`;
					const rateLine = v.minRate != null ? `<div class="ch-tip-rate">${rateText} · ${v.courtCount} ${v.courtCount === 1 ? "court" : "courts"}</div>` : `<div class="ch-tip-rate ch-tip-muted">${v.courtCount} ${v.courtCount === 1 ? "court" : "courts"}</div>`;
					const tipHtml = `<div class="ch-tip"><span class="ch-tip-name">${v.name}</span><span class="ch-tip-sep"></span><span class="ch-tip-addr">${v.address}</span><span class="ch-tip-sep"></span>${rateLine}</div>`;
					m.bindTooltip(tipHtml, {
						direction: "top",
						offset: [0, -28],
						className: "ch-tip-wrap",
						opacity: 1,
						sticky: false
					});
					m.on("click", (e) => {
						e.originalEvent?.stopPropagation?.();
						userInteractedRef.current = false;
						onSelectVenue(v.id);
					});
				});
				if (!userInteractedRef.current) {
					const bounds = L.latLngBounds(pinned.map((v) => [v.latitude, v.longitude]));
					if (nearby) bounds.extend([nearby.lat, nearby.lng]);
					rezoomingRef.current = true;
					mapRef.current.fitBounds(bounds, {
						padding: [40, 40],
						maxZoom: 14
					});
					setTimeout(() => {
						rezoomingRef.current = false;
					}, 300);
				}
			}
		})();
	}, [
		mapReady,
		venues,
		activeVenueId,
		onSelectVenue,
		onOpenCourt,
		nearby
	]);
	(0, import_react.useEffect)(() => {}, [onOpenVenue]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: elRef,
			className: "absolute inset-0"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute left-3 top-3 z-[500] inline-flex overflow-hidden rounded-lg border border-border bg-background shadow",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					if (view === "street" || !mapRef.current) return;
					mapRef.current.removeLayer(satelliteLayerRef.current);
					streetLayerRef.current.addTo(mapRef.current);
					setView("street");
				},
				className: `px-3 py-1.5 text-xs font-medium ${view === "street" ? "bg-primary text-primary-foreground" : "hover:bg-secondary"}`,
				children: "🗺️ Street"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					if (view === "satellite" || !mapRef.current) return;
					mapRef.current.removeLayer(streetLayerRef.current);
					satelliteLayerRef.current.addTo(mapRef.current);
					setView("satellite");
				},
				className: `px-3 py-1.5 text-xs font-medium ${view === "satellite" ? "bg-primary text-primary-foreground" : "hover:bg-secondary"}`,
				children: "🛰️ Satellite"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPegman, {
			containerRef: elRef,
			onDragStateChange: (active) => {
				const map = mapRef.current;
				if (!map) return;
				if (active) {
					map.dragging?.disable();
					map.touchZoom?.disable();
				} else {
					map.dragging?.enable();
					map.touchZoom?.enable();
				}
			},
			pointToLatLng: (clientX, clientY) => {
				const map = mapRef.current;
				const el = elRef.current;
				if (!map || !el) return null;
				const r = el.getBoundingClientRect();
				const pt = map.containerPointToLatLng([clientX - r.left, clientY - r.top]);
				return {
					lat: pt.lat,
					lng: pt.lng
				};
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapInfoButton, { getCenter: () => {
			const c = mapRef.current?.getCenter?.();
			return c ? {
				lat: c.lat,
				lng: c.lng
			} : null;
		} })
	] });
}
/**
* The rally that closes the Contact section: two players trade a pickleball over a net,
* and the payment methods land beneath them.
*
* The rally itself is pure CSS — three looping animations that agree about the ball's
* position because they share one duration (see `.rally-court` in styles.css). React's only
* job is to notice when the pane comes into view: that starts the rally and deals the
* payment cards in. Leaving the viewport pauses it rather than unmounting it, so scrolling
* back finds the players mid-point rather than restarted.
*/
/** The two players, by name. Alliana is on the left, Ed on the right. */
var ALLIANA = "alliana";
var ED = "ed";
/** Rally-side chatter, in order. Ed opens, and the last line hands back to the first
*  cleanly, so the loop reads as a continuing match rather than a restart. */
var DIALOGUE = [
	{
		who: ED,
		text: "Hi, Alliana! How are you?"
	},
	{
		who: ALLIANA,
		text: "So far, so good! How about you?"
	},
	{
		who: ED,
		text: "Mutual feeling. I’m doing great. Ready for another game?"
	},
	{
		who: ALLIANA,
		text: "Definitely! But this time, don’t go easy on me. 😄"
	},
	{
		who: ED,
		text: "Are you sure? Last game you were complaining about my serves."
	},
	{
		who: ALLIANA,
		text: "Because your serves are impossible to return! 😂"
	},
	{
		who: ED,
		text: "That’s just part of the game."
	},
	{
		who: ALLIANA,
		text: "Okay, okay. Let’s see if you can beat me this time."
	},
	{
		who: ED,
		text: "Challenge accepted!"
	},
	{
		who: ALLIANA,
		text: "Wait… here comes the ball!"
	},
	{
		who: ED,
		text: "I got it!"
	},
	{
		who: ALLIANA,
		text: "Nice shot!"
	},
	{
		who: ED,
		text: "Thanks! Your turn."
	},
	{
		who: ALLIANA,
		text: "And… there! Did you see that?"
	},
	{
		who: ED,
		text: "Okay, that was actually a good one."
	},
	{
		who: ALLIANA,
		text: "Told you I’m getting better."
	},
	{
		who: ED,
		text: "I guess I need to step up my game."
	},
	{
		who: ALLIANA,
		text: "Exactly. Now, let’s finish this match!"
	},
	{
		who: ED,
		text: "Let’s do it! 🏓"
	}
];
/** Long enough to read the longest line without rushing it. */
var LINE_MS = 3200;
/** Live today through the PayMongo checkout — the same set the booking panel offers. */
var METHODS_LIVE = [
	{
		name: "GCash",
		tint: "#007CFF",
		initials: "G",
		logo: "/payments/gcash.svg"
	},
	{
		name: "Maya",
		tint: "#00B37E",
		initials: "M",
		logo: "/payments/maya.svg",
		markBg: "#102521"
	},
	{
		name: "GrabPay",
		tint: "#00B14F",
		initials: "GP",
		logo: "/payments/grabpay.svg"
	},
	{
		name: "QR Ph",
		tint: "#204884",
		initials: "QR",
		logo: "/payments/qrph.svg"
	}
];
/** Card payments exist in the checkout schema but are not offered to players yet. */
var METHODS_SOON = [{
	name: "Visa",
	tint: "#1A1F71",
	initials: "V",
	logo: "/payments/visa.svg"
}, {
	name: "Mastercard",
	tint: "#EB001B",
	initials: "MC",
	logo: "/payments/mastercard.svg"
}];
function PaymentRally() {
	const paneRef = (0, import_react.useRef)(null);
	const [inView, setInView] = (0, import_react.useState)(false);
	const [dealt, setDealt] = (0, import_react.useState)(false);
	const [line, setLine] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!inView) return;
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const id = window.setInterval(() => setLine((prev) => (prev + 1) % DIALOGUE.length), LINE_MS);
		return () => window.clearInterval(id);
	}, [inView]);
	(0, import_react.useEffect)(() => {
		const el = paneRef.current;
		if (!el) return;
		const observer = new IntersectionObserver(([entry]) => {
			setInView(entry.isIntersecting);
			if (entry.isIntersecting) setDealt(true);
		}, { threshold: .25 });
		observer.observe(el);
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: paneRef,
		className: "mt-14 overflow-hidden rounded-3xl border border-[#dce8e2] bg-white",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-4 border-b border-[#dce8e2] bg-[#f6f8f7] px-5 py-4 sm:px-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] font-bold uppercase tracking-[.18em] text-[#5e746e]",
					children: "Checkout"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-0.5 font-cabinet text-lg font-bold tracking-tight text-[#102521]",
					children: "Keep the rally going. We’ll handle the rest."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden max-w-[15rem] text-right text-[11px] leading-relaxed text-[#5e746e] sm:block",
					children: "Every booking is settled through our secure checkout."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chatter, { line }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rally-court relative h-44 overflow-hidden bg-gradient-to-b from-[#f6f8f7] to-[#eaf5d8] sm:h-56",
				"data-playing": inView,
				role: "img",
				"aria-label": "Alliana and Ed rallying a pickleball across a net",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-x-0 bottom-8 h-px bg-[#c3d6cd]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-x-0 bottom-0 h-8 bg-[#dfeed2]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Net, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Player, {
						variant: "girl",
						className: "absolute bottom-6 left-[2%] h-28 w-auto sm:h-36"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Player, {
						variant: "boy",
						className: "absolute bottom-6 right-[2%] h-28 w-auto -scale-x-100 sm:h-36"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 py-7 sm:px-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-bold uppercase tracking-[.18em] text-[#5e746e]",
							children: "Pay with"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-[#5e746e]",
							children: "Secured by our payment provider."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6",
						children: [METHODS_LIVE.map((method, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MethodCard, {
							...method,
							shown: dealt,
							index
						}, method.name)), METHODS_SOON.map((method, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MethodCard, {
							...method,
							soon: true,
							shown: dealt,
							index: METHODS_LIVE.length + index
						}, method.name))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 border-t border-[#eef3f0] pt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-bold uppercase tracking-[.18em] text-[#5e746e]",
							children: "Or pay on arrival"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-col gap-3 sm:flex-row sm:items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pay-card flex items-center gap-2.5 rounded-xl border border-[#dce8e2] bg-white px-3 py-2.5 transition-all duration-300 hover:-translate-y-0.5 hover:border-[#b8f05a] hover:shadow-md sm:w-56",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-7 w-10 shrink-0 place-items-center rounded-md",
									style: { backgroundColor: "#0b3d351a" },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, {
										className: "h-4 w-4 text-[#0b3d35]",
										"aria-hidden": true
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-cabinet text-xs font-bold text-[#102521]",
										children: "Cash at the venue"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-[9px] font-semibold text-[#5e746e]",
										children: "Settle when you arrive"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] leading-relaxed text-[#5e746e] sm:flex-1",
								children: "Prefer to pay in person? Many venues let you settle in cash on the day. Each venue sets its own rule, and its booking page says which it takes before you confirm."
							})]
						})]
					})
				]
			})
		]
	});
}
function Chatter({ line }) {
	const speaker = DIALOGUE[line].who;
	const lastFrom = (who) => {
		for (let i = line; i >= 0; i -= 1) if (DIALOGUE[i].who === who) return i;
		return -1;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"aria-hidden": true,
		className: "flex min-h-[6.5rem] items-end justify-between gap-3 bg-[#f6f8f7] px-5 pb-3 pt-5 sm:gap-6 sm:px-7",
		children: [ALLIANA, ED].map((who) => {
			const index = lastFrom(who);
			const isAlliana = who === ALLIANA;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `min-w-0 flex-1 ${isAlliana ? "" : "flex justify-end"}`,
				children: index >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `bubble-pop relative max-w-[17rem] rounded-2xl border px-3 py-2 transition-opacity duration-300 ${speaker === who ? "border-[#dce8e2] bg-white opacity-100 shadow-sm" : "border-[#e3ece7] bg-[#fbfdfc] opacity-55"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `text-[9px] font-bold uppercase tracking-[.14em] ${isAlliana ? "text-[#12806d]" : "text-[#2f6d8f]"}`,
							children: isAlliana ? "Alliana" : "Ed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-xs leading-relaxed text-[#41564f]",
							children: DIALOGUE[index].text
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute -bottom-1 h-2.5 w-2.5 rotate-45 border-b border-r ${speaker === who ? "border-[#dce8e2] bg-white" : "border-[#e3ece7] bg-[#fbfdfc]"} ${isAlliana ? "left-5" : "right-5"}` })
					]
				}, index)
			}, who);
		})
	});
}
function Net() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute bottom-8 left-1/2 h-20 w-24 -translate-x-1/2 sm:h-24 sm:w-32",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-2 bottom-0 top-2 bg-[repeating-linear-gradient(90deg,#7d9a90_0_1px,transparent_1px_7px),repeating-linear-gradient(0deg,#7d9a90_0_1px,transparent_1px_7px)] opacity-55" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-1 top-0 h-2 rounded-sm bg-white shadow-[0_1px_2px_rgba(16,37,33,0.2)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 left-0 top-0 w-1.5 rounded-full bg-[#0b3d35]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-0 right-0 top-0 w-1.5 rounded-full bg-[#0b3d35]" })
		]
	});
}
function Ball() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rally-ball absolute h-6 w-6 sm:h-7 sm:w-7",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "rally-ball-arc absolute inset-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rally-ball-spin absolute inset-0 grid place-items-center rounded-full bg-[#d9f24f] shadow-[0_2px_10px_rgba(16,37,33,0.25)] ring-1 ring-[#0b3d35]/15",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid grid-cols-3 gap-[3px]",
					children: Array.from({ length: 9 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-[3px] w-[3px] rounded-full bg-[#0b3d35]/35" }, i))
				})
			})
		})
	});
}
function MethodCard({ name, tint, initials, logo, markBg, soon, shown, index }) {
	const [logoBroken, setLogoBroken] = (0, import_react.useState)(false);
	const showLogo = Boolean(logo) && !logoBroken;
	const delay = index * 80;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-dealt": shown,
		style: {
			"--deal-delay": `${delay}ms`,
			transitionDelay: shown ? `${delay}ms` : "0ms"
		},
		className: `pay-card group flex items-center gap-2 rounded-xl border px-2.5 py-2 transition-all duration-500 ease-out motion-reduce:transition-none ${soon ? "border-dashed border-[#c3d6cd] bg-[#f6f8f7]" : "border-[#dce8e2] bg-white hover:-translate-y-0.5 hover:border-[#b8f05a] hover:shadow-md"} ${shown ? "translate-y-0 scale-100 opacity-100" : "translate-y-2.5 scale-[.96] opacity-0"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `pay-mark grid h-7 w-16 shrink-0 place-items-center overflow-hidden rounded-md px-1 transition-transform duration-300 motion-reduce:transition-none ${soon ? "" : "group-hover:scale-110"}`,
			style: showLogo ? markBg ? { backgroundColor: markBg } : void 0 : { backgroundColor: `${soon ? "#9db3ac" : tint}1a` },
			children: showLogo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: logo,
				alt: `${name} logo`,
				loading: "lazy",
				onError: () => setLogoBroken(true),
				className: `h-full w-full object-contain ${soon ? "opacity-60" : ""}`
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[9px] font-bold",
				style: { color: soon ? "#5e746e" : tint },
				children: initials
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `block truncate font-cabinet text-xs font-bold ${soon ? "text-[#5e746e]" : "text-[#102521]"}`,
				children: name
			}), soon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-[9px] font-semibold text-[#8aa39a]",
				children: "Coming soon"
			})]
		})]
	});
}
/** Flat illustration, drawn rather than photographed so it recolours with the brand and
*  costs no image request. Limbs are round-capped strokes; only the kit is filled.
*  The two variants share every coordinate — they differ in hair, kit and palette, which
*  is what keeps their paddles meeting the ball at the same height. */
function Player({ variant, className }) {
	const girl = variant === "girl";
	const skin = girl ? "#f0c6a0" : "#d9a172";
	const hair = girl ? "#3a2a1e" : "#241a12";
	const kit = girl ? "#b8f05a" : "#12806d";
	const kitShade = girl ? "#a5e243" : "#0f6b5c";
	const bottoms = girl ? "#0b3d35" : "#123f57";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 -16 132 172",
		className,
		"aria-hidden": true,
		focusable: "false",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "52",
				cy: "150",
				rx: "30",
				ry: "4.5",
				fill: "#0b3d35",
				opacity: "0.12"
			}),
			girl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M36 24c-9 2-14 10-13 20 1 9 5 14 9 19",
				stroke: hair,
				strokeWidth: "9",
				strokeLinecap: "round",
				fill: "none"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M44 88 32 112l-7 22",
				stroke: skin,
				strokeWidth: "8",
				strokeLinecap: "round",
				strokeLinejoin: "round",
				fill: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M40 54 29 68l3 14",
				stroke: skin,
				strokeWidth: "7",
				strokeLinecap: "round",
				strokeLinejoin: "round",
				fill: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M56 88l9 24 3 22",
				stroke: skin,
				strokeWidth: "8.5",
				strokeLinecap: "round",
				strokeLinejoin: "round",
				fill: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M20 136h14a3 3 0 0 1 0 6H19a3 3 0 0 1 1-6Z",
				fill: "#0b3d35"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M62 138h14a3 3 0 0 1 0 6H61a3 3 0 0 1 1-6Z",
				fill: "#0b3d35"
			}),
			girl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M35 74h32l6 20H30l5-20Z",
				fill: bottoms
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M35 74h32v18H35V74Z",
				fill: bottoms
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M50 84h2v8h-2v-8Z",
				fill: "#0b3d35",
				opacity: "0.35"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M38 42h26l6 34H32l6-34Z",
				fill: kit
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M38 42h26l2 10H36l2-10Z",
				fill: kitShade
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "52",
				cy: "28",
				r: "14",
				fill: skin
			}),
			girl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M38 26c1-9 7-14 14-14s13 5 14 14c-4-5-9-7-14-7s-10 2-14 7Z",
				fill: hair
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M38 25c0-9 6-14 14-14s14 5 14 14c-2-3-5-5-8-5-6 0-8 3-14 3-3 0-5 1-6 2Z",
				fill: hair
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "59",
				cy: "29",
				r: "1.8",
				fill: "#2b2018"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M56 35c2 1.5 4.5 1.5 6.5 0",
				stroke: "#2b2018",
				strokeWidth: "1.6",
				strokeLinecap: "round",
				fill: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				className: `rally-swing ${girl ? "" : "rally-swing-far"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M64 52l22 6 14-4",
						stroke: skin,
						strokeWidth: "7",
						strokeLinecap: "round",
						strokeLinejoin: "round",
						fill: "none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "98",
						y: "50",
						width: "16",
						height: "7",
						rx: "3.5",
						fill: "#0b3d35"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "112",
						y: "36",
						width: "17",
						height: "35",
						rx: "8",
						fill: girl ? "#12806d" : "#b8f05a"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "115",
						y: "39",
						width: "11",
						height: "29",
						rx: "5.5",
						fill: girl ? "#0f6b5c" : "#a5e243"
					})
				]
			})
		]
	});
}
/**
* Philippine place lookup on top of OpenStreetMap Nominatim.
*
* Nominatim is a free, shared service. Its usage policy is respected here by:
*  - serialising requests with at least `MIN_REQUEST_INTERVAL_MS` between them,
*  - caching responses so repeated/edited queries do not re-hit the API,
*  - keeping `limit` modest and sending `countrycodes=ph`,
*  - identifying the app via the browser's automatic Referer header (browsers
*    forbid setting User-Agent from fetch; callers on Node should set one).
*
* What this module does NOT do: guarantee that every Philippine place exists.
* Coverage is whatever OpenStreetMap contains. This code improves *recall and
* ranking over that data*; it cannot invent places OSM has never mapped.
*/
var ENDPOINT = "https://nominatim.openstreetmap.org/search";
/**
* Photon is an OSM-backed *autocomplete* geocoder. Nominatim will not complete
* partial business names — "SM Seaside" returns the road inside the mall, never
* the mall — because it geocodes complete addresses rather than suggesting
* as-you-type. Photon indexes the same OSM data for prefix search, so it is
* used strictly as a fallback when Nominatim comes back empty or approximate.
*/
var PHOTON_ENDPOINT = "https://photon.komoot.io/api/";
/** Philippines bounding box, to keep Photon's unrestricted index in-country. */
var PH_BBOX = "116.9,4.6,126.6,21.1";
var MIN_REQUEST_INTERVAL_MS = 1100;
var CACHE_TTL_MS = 600 * 1e3;
var CACHE_MAX = 120;
/** Whole-string aliases, keyed by punctuation-stripped lowercase input. */
var FULL_ALIASES = {
	"region i": "Ilocos Region",
	"region 1": "Ilocos Region",
	"region ii": "Cagayan Valley",
	"region 2": "Cagayan Valley",
	"region iii": "Central Luzon",
	"region 3": "Central Luzon",
	"region iv a": "Calabarzon",
	"region iva": "Calabarzon",
	"region 4a": "Calabarzon",
	"region iv b": "Mimaropa",
	"region ivb": "Mimaropa",
	"region 4b": "Mimaropa",
	"region iv": "Calabarzon",
	"region 4": "Calabarzon",
	"region v": "Bicol Region",
	"region 5": "Bicol Region",
	"region vi": "Western Visayas",
	"region 6": "Western Visayas",
	"region vii": "Central Visayas",
	"region 7": "Central Visayas",
	"region viii": "Eastern Visayas",
	"region 8": "Eastern Visayas",
	"region ix": "Zamboanga Peninsula",
	"region 9": "Zamboanga Peninsula",
	"region x": "Northern Mindanao",
	"region 10": "Northern Mindanao",
	"region xi": "Davao Region",
	"region 11": "Davao Region",
	"region xii": "Soccsksargen",
	"region 12": "Soccsksargen",
	"region xiii": "Caraga",
	"region 13": "Caraga",
	ncr: "Metro Manila",
	"national capital region": "Metro Manila",
	car: "Cordillera Administrative Region",
	barmm: "Bangsamoro Autonomous Region in Muslim Mindanao",
	armm: "Bangsamoro Autonomous Region in Muslim Mindanao",
	qc: "Quezon City",
	gensan: "General Santos City",
	"gen santos": "General Santos City",
	"gen santos city": "General Santos City",
	cdo: "Cagayan de Oro",
	bgc: "Bonifacio Global City",
	"the fort": "Bonifacio Global City",
	bacoor: "Bacoor",
	samal: "Island Garden City of Samal",
	igacos: "Island Garden City of Samal"
};
/**
* Token-level rewrites applied after full-alias matching. "barangay"/"brgy"
* maps to empty because OSM stores the bare name ("Lahug", not "Barangay
* Lahug"), so keeping the word actively hurts matching.
*/
var TOKEN_ALIASES = {
	barangay: "",
	brgy: "",
	bgy: "",
	brgys: "",
	sta: "santa",
	sto: "santo",
	mt: "mount",
	natl: "national",
	intl: "international",
	univ: "university",
	hosp: "hospital",
	paranaque: "parañaque",
	"las pinas": "las piñas"
};
/**
* Fold a name for comparison: drop diacritics, punctuation and dash variants so
* "Osmena" matches "Osmeña", "Cebu IT Park" matches "Cebu I.T. Park", and
* "Mactan-Cebu" matches "Mactan–Cebu" (en dash).
*/
function fold(s) {
	return s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[.'’`]/g, "").replace(/[–—-]/g, " ").replace(/\s+/g, " ").trim();
}
/** Strip punctuation/diacritic noise for alias matching only. */
function aliasKey(s) {
	return s.toLowerCase().replace(/[.,()]/g, " ").replace(/[-–—/]/g, " ").replace(/\s+/g, " ").trim();
}
/**
* Canonicalise a user query: expand well-known Philippine shorthands, fix
* punctuation/casing noise, and rewrite "City of X" to "X City".
*/
function normalizePhQuery(raw) {
	const original = raw.trim().replace(/\s+/g, " ");
	if (!original) return {
		query: "",
		changed: false
	};
	const key = aliasKey(original);
	if (FULL_ALIASES[key]) {
		const mapped = FULL_ALIASES[key];
		return {
			query: mapped,
			changed: aliasKey(mapped) !== key
		};
	}
	const query = original.split(",").map((seg) => {
		const segKey = aliasKey(seg);
		if (FULL_ALIASES[segKey]) return FULL_ALIASES[segKey];
		const cityOf = segKey.match(/^city of (.+)$/);
		if (cityOf) return `${titleCase(cityOf[1])} City`;
		const muniOf = segKey.match(/^(?:municipality|province) of (.+)$/);
		if (muniOf) return titleCase(muniOf[1]);
		const tokens = segKey.split(" ").filter(Boolean);
		const rewritten = tokens.map((t) => TOKEN_ALIASES[t] ?? t).filter(Boolean);
		if (!rewritten.length) return "";
		return rewritten.some((t, i) => t !== tokens[i]) ? titleCase(rewritten.join(" ")) : seg.trim();
	}).map((s) => s.trim()).filter(Boolean).join(", ");
	return {
		query,
		changed: aliasKey(query) !== key
	};
}
function titleCase(s) {
	return s.replace(/\b[\p{L}]/gu, (c) => c.toUpperCase());
}
var KIND_BY_ADDRESSTYPE = {
	region: "Region",
	state: "Province",
	province: "Province",
	county: "Province",
	city: "City",
	town: "Town",
	municipality: "Municipality",
	village: "Village",
	hamlet: "Village",
	suburb: "Barangay",
	quarter: "Barangay",
	neighbourhood: "Barangay",
	island: "Island",
	road: "Road",
	highway: "Road",
	aeroway: "Airport",
	railway: "Station",
	amenity: "Landmark",
	shop: "Shop",
	commercial: "Landmark",
	building: "Building",
	tourism: "Landmark",
	leisure: "Landmark",
	office: "Office",
	healthcare: "Healthcare",
	industrial: "Industrial",
	residential: "Subdivision",
	landuse: "Area",
	place: "Place",
	man_made: "Landmark",
	natural: "Natural",
	waterway: "Waterway",
	harbour: "Port",
	port: "Port"
};
/**
* OSM's `type` value is more specific than `addresstype`, so it gives a better
* label for the POI categories people actually search for.
*/
var KIND_BY_OSM_VALUE = {
	school: "School",
	college: "School",
	university: "University",
	kindergarten: "School",
	hospital: "Hospital",
	clinic: "Clinic",
	doctors: "Clinic",
	pharmacy: "Pharmacy",
	townhall: "Government",
	government: "Government",
	public_building: "Government",
	courthouse: "Government",
	police: "Government",
	fire_station: "Government",
	post_office: "Government",
	aerodrome: "Airport",
	terminal: "Terminal",
	ferry_terminal: "Port",
	harbour: "Port",
	port: "Port",
	marina: "Port",
	bus_station: "Terminal",
	mall: "Mall",
	marketplace: "Market",
	supermarket: "Supermarket",
	stadium: "Stadium",
	sports_centre: "Sports Centre",
	pitch: "Sports Venue",
	park: "Park",
	church: "Church",
	place_of_worship: "Church",
	hotel: "Hotel",
	resort: "Resort",
	bank: "Bank",
	residential: "Subdivision",
	neighbourhood: "Subdivision",
	industrial: "Industrial"
};
var AREA_TYPES = /* @__PURE__ */ new Set([
	"region",
	"state",
	"province",
	"county",
	"city",
	"town",
	"municipality",
	"village",
	"hamlet",
	"suburb",
	"quarter",
	"neighbourhood"
]);
var ROAD_TYPES = /* @__PURE__ */ new Set(["road", "highway"]);
var STREET_HINT = /\b(street|st|road|rd|avenue|ave|highway|hwy|blvd|boulevard|drive|dr|lane|ln|corner|cor|extension|ext)\b/i;
/** Does the query read like the user is after a street/address? */
function looksLikeStreetQuery(q) {
	return STREET_HINT.test(q) || /\d+\s/.test(q.trim());
}
/** Great-circle distance in km, for proximity-biased ranking. */
function haversineKm(a, b) {
	const toRad = (v) => v * Math.PI / 180;
	const R = 6371;
	const dLat = toRad(b.lat - a.lat);
	const dLng = toRad(b.lng - a.lng);
	const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
	return 2 * R * Math.asin(Math.sqrt(h));
}
function buildContext(label, a) {
	const barangay = a.suburb || a.quarter || a.neighbourhood || void 0;
	const city = a.city || a.town || a.municipality || a.village || void 0;
	const province = a.state || a.province || void 0;
	const region = a.region || void 0;
	const postcode = a.postcode || void 0;
	const seen = /* @__PURE__ */ new Set([label.toLowerCase()]);
	return {
		context: [
			barangay,
			city,
			province,
			region
		].filter((v) => !!v).filter((v) => {
			const k = v.toLowerCase();
			if (seen.has(k)) return false;
			seen.add(k);
			return true;
		}).join(" · "),
		parts: {
			region,
			province,
			city,
			barangay,
			postcode
		}
	};
}
function toPlace(r, query, viaFallback, near) {
	const addressType = (r.addresstype || r.type || "").toLowerCase();
	const label = (r.name || r.display_name.split(",")[0] || "").trim() || r.display_name;
	const a = r.address ?? {};
	const { context, parts } = buildContext(label, a);
	const nameFolded = fold(label);
	const queryFolded = fold(query);
	const firstSegment = fold(query.split(",")[0] ?? query);
	const nameScore = (q) => {
		if (!q) return 0;
		if (nameFolded === q) return -100;
		if (nameFolded.startsWith(q)) return -50;
		if (nameFolded.includes(q)) return -20;
		const qTokens = q.split(" ").filter((t) => t.length > 2);
		const hit = qTokens.filter((t) => nameFolded.includes(t)).length;
		return qTokens.length ? -Math.round(hit / qTokens.length * 25) : 0;
	};
	const nameMatch = Math.min(nameScore(queryFolded), nameScore(firstSegment));
	let score = nameMatch;
	const contextTokens = query.split(",").slice(1).map((s) => fold(s)).filter(Boolean);
	if (contextTokens.length) {
		const haystack = fold([
			a.city,
			a.town,
			a.municipality,
			a.state,
			a.region
		].filter(Boolean).join(" "));
		const matched = contextTokens.filter((t) => haystack.includes(t)).length;
		score -= Math.round(matched / contextTokens.length * 35);
	}
	if (AREA_TYPES.has(addressType)) score -= 30;
	if (addressType === "island") score -= 10;
	if (ROAD_TYPES.has(addressType) && !looksLikeStreetQuery(query)) score += 60;
	if (near) {
		const d = haversineKm(near, {
			lat: Number(r.lat),
			lng: Number(r.lon)
		});
		score -= Math.round(70 * Math.exp(-d / 60));
	}
	score -= Math.round((r.importance ?? 0) * 20);
	return {
		id: String(r.place_id),
		label,
		context,
		kind: AREA_TYPES.has(addressType) ? KIND_BY_ADDRESSTYPE[addressType] ?? "Place" : KIND_BY_OSM_VALUE[(r.type ?? "").toLowerCase()] ?? KIND_BY_ADDRESSTYPE[addressType] ?? (addressType ? "Landmark" : "Place"),
		lat: Number(r.lat),
		lng: Number(r.lon),
		displayName: r.display_name,
		...parts,
		osmType: r.osm_type,
		osmId: r.osm_id,
		osmCategory: r.category ?? r.class,
		osmValue: r.type,
		approximate: ROAD_TYPES.has(addressType) && !looksLikeStreetQuery(query),
		nameScore: nameMatch,
		viaFallback,
		score,
		display: label,
		displaySuffix: ""
	};
}
/**
* Words that carry no distinguishing information when comparing a context part
* against a place name, so "Cebu City" counts as already present in
* "Ayala Center Cebu".
*/
var GENERIC_PLACE_WORDS = /* @__PURE__ */ new Set([
	"city",
	"municipality",
	"province",
	"town",
	"of",
	"the",
	"poblacion"
]);
function distinctiveTokens(s) {
	return fold(s).split(" ").filter((t) => t && !GENERIC_PLACE_WORDS.has(t));
}
/**
* True when every distinguishing word of `part` already appears in the text we
* are about to show, so repeating it adds nothing.
*/
function isRedundant(part, against) {
	const tokens = distinctiveTokens(part);
	if (!tokens.length) return true;
	const shown = new Set(against.map((a) => fold(a)).join(" ").split(" ").filter(Boolean));
	return tokens.every((t) => shown.has(t));
}
/** The default, shortest useful context: city then province, skipping repeats. */
function baseParts(p) {
	const parts = [];
	if (p.city && !isRedundant(p.city, [p.label])) parts.push(p.city);
	if (p.province && !isRedundant(p.province, [p.label, ...parts])) parts.push(p.province);
	return parts;
}
function compose(label, parts, kind) {
	const head = parts.length ? `${label}, ${parts.join(", ")}` : label;
	return kind ? `${head} (${kind})` : head;
}
/**
* Assign each suggestion the shortest label that stays unambiguous *within this
* result list*. Everything starts at city/province level with no region; only a
* colliding group escalates, and only as far as it must — barangay, then
* region, then the place type. This is why "Central Visayas" never appears for
* a normal search but "Cebu (Island)" can still be told apart from "Cebu".
*/
function assignDisplayNames(places) {
	const groups = /* @__PURE__ */ new Map();
	for (const p of places) {
		const key = compose(p.label, baseParts(p));
		const g = groups.get(key);
		if (g) g.push(p);
		else groups.set(key, [p]);
	}
	const withDisplay = /* @__PURE__ */ new Map();
	for (const group of groups.values()) {
		if (group.length === 1) {
			withDisplay.set(group[0], compose(group[0].label, baseParts(group[0])));
			continue;
		}
		const variants = [
			(p) => compose(p.label, baseParts(p)),
			(p) => compose(p.label, p.barangay && !isRedundant(p.barangay, [p.label]) ? [p.barangay, ...baseParts(p)] : baseParts(p)),
			(p) => compose(p.label, p.region && !isRedundant(p.region, [p.label]) ? [...baseParts(p), p.region] : baseParts(p)),
			(p, i) => compose(p.label, baseParts(p), i === 0 ? void 0 : p.kind),
			(p, i) => compose(p.label, p.region ? [...baseParts(p), p.region] : baseParts(p), i === 0 ? void 0 : p.kind)
		];
		const chosen = variants.find((v) => new Set(group.map(v)).size === group.length) ?? variants[variants.length - 1];
		group.forEach((p, i) => withDisplay.set(p, chosen(p, i)));
	}
	return places.map((p) => {
		const display = withDisplay.get(p) ?? p.label;
		return {
			...p,
			display,
			displaySuffix: display.startsWith(p.label) ? display.slice(p.label.length) : display
		};
	});
}
/**
* Collapse hits that are the same destination: same name within the same
* city/province. Deliberately keyed on administrative area rather than
* coordinates so that the five different "San Jose" municipalities survive
* while a mall's dozen mapped nodes collapse to one.
*
* `kind` is deliberately NOT part of the key: OSM often carries one barangay as
* both `village` and `suburb`, which would otherwise render as two identical
* rows. Genuinely different places (Cebu the province vs Cebu City vs Cebu the
* island) already differ in their administrative fields.
*/
function dedupe(places) {
	const seen = /* @__PURE__ */ new Set();
	return places.filter((p) => {
		const key = [
			p.label.toLowerCase(),
			(p.city ?? "").toLowerCase(),
			(p.province ?? "").toLowerCase(),
			(p.region ?? "").toLowerCase()
		].join("|");
		if (seen.has(key)) return false;
		seen.add(key);
		return true;
	});
}
var cache = /* @__PURE__ */ new Map();
var gate = Promise.resolve();
var lastRequestAt = 0;
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/** Serialise every outbound call and space them per Nominatim's policy. */
function schedule(fn) {
	const run = gate.then(async () => {
		const wait = MIN_REQUEST_INTERVAL_MS - (Date.now() - lastRequestAt);
		if (wait > 0) await sleep(wait);
		lastRequestAt = Date.now();
		return fn();
	});
	gate = run.catch(() => void 0);
	return run;
}
async function fetchRows(query, signal) {
	const key = query.toLowerCase();
	const hit = cache.get(key);
	if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.rows;
	const params = new URLSearchParams({
		format: "jsonv2",
		q: query,
		limit: "30",
		addressdetails: "1",
		countrycodes: "ph",
		"accept-language": "en"
	});
	const rows = await schedule(async () => {
		const res = await fetch(`${ENDPOINT}?${params}`, {
			signal,
			headers: { Accept: "application/json" }
		});
		return res.ok ? await res.json() : [];
	});
	if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value);
	cache.set(key, {
		at: Date.now(),
		rows
	});
	return rows;
}
/** Build progressively looser variants of a query for fallback attempts. */
function relaxations(query) {
	const out = [];
	const segs = query.split(",").map((s) => s.trim()).filter(Boolean);
	if (segs.length > 1) out.push(segs.slice(0, -1).join(", "));
	if (segs.length > 2) out.push(segs[0]);
	const stripped = query.replace(/\b(city|municipality|province|barangay)\b/gi, "").trim();
	if (stripped && stripped.toLowerCase() !== query.toLowerCase()) out.push(stripped);
	return [...new Set(out)].filter((s) => s.length >= 3);
}
/**
* Photon's `type` describes the feature's administrative level; translate it to
* the Nominatim `addresstype` vocabulary so scoring, kind resolution and
* display all keep working off a single representation.
*/
var PHOTON_TYPE_TO_ADDRESSTYPE = {
	country: "country",
	state: "region",
	county: "state",
	city: "city",
	district: "suburb",
	locality: "village",
	street: "road",
	house: "building"
};
/**
* Photon's `type` is a coarse bucket and lies about POIs — it calls a shopping
* mall a "locality", which would wrongly earn it the administrative-area
* ranking bonus. Trust `type` only for genuine place/boundary features and
* otherwise classify from the OSM tags, matching Nominatim's `addresstype`.
*/
function photonAddressType(p) {
	const key = (p.osm_key ?? "").toLowerCase();
	const value = (p.osm_value ?? "").toLowerCase();
	const type = (p.type ?? "").toLowerCase();
	if (key === "highway") return "road";
	if (key === "place" || key === "boundary") return PHOTON_TYPE_TO_ADDRESSTYPE[type] ?? value;
	return value || PHOTON_TYPE_TO_ADDRESSTYPE[type] || "";
}
/**
* Reshape a Photon feature into the Nominatim row shape. Everything downstream
* — scoring, proximity, dedupe, display — then treats both sources identically.
*/
function photonToRow(f) {
	const p = f.properties ?? {};
	const coords = f.geometry?.coordinates;
	if (!coords || !p.name) return null;
	const addressType = photonAddressType(p);
	return {
		place_id: Number(p.osm_id ?? 0),
		osm_type: p.osm_type === "N" ? "node" : p.osm_type === "W" ? "way" : "relation",
		osm_id: p.osm_id,
		display_name: [
			p.name,
			p.district,
			p.city,
			p.county,
			p.state,
			"Philippines"
		].filter(Boolean).join(", "),
		name: p.name,
		addresstype: addressType,
		category: p.osm_key,
		type: p.osm_value,
		importance: 0,
		address: {
			...p.district ? { suburb: p.district } : {},
			...p.city ? { city: p.city } : {},
			...p.county ? { state: p.county } : {},
			...p.state ? { region: p.state } : {},
			...p.postcode ? { postcode: p.postcode } : {}
		},
		lat: String(coords[1]),
		lon: String(coords[0])
	};
}
/**
* Query Photon for autocomplete-style matches. Shares the global rate-limit
* gate and cache with Nominatim, and never throws — a failure here just means
* the Nominatim result stands.
*/
async function fetchPhotonRows(query, signal, near) {
	const key = `photon:${query.toLowerCase()}|${near ? `${near.lat.toFixed(2)},${near.lng.toFixed(2)}` : ""}`;
	const hit = cache.get(key);
	if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.rows;
	const params = new URLSearchParams({
		q: query,
		limit: "15",
		lang: "en",
		bbox: PH_BBOX
	});
	if (near) {
		params.set("lat", String(near.lat));
		params.set("lon", String(near.lng));
	}
	let rows = [];
	try {
		rows = await schedule(async () => {
			const res = await fetch(`${PHOTON_ENDPOINT}?${params}`, {
				signal,
				headers: { Accept: "application/json" }
			});
			if (!res.ok) return [];
			return ((await res.json()).features ?? []).filter((f) => (f.properties?.countrycode ?? "PH").toUpperCase() === "PH").map(photonToRow).filter((r) => r !== null);
		});
	} catch {
		return [];
	}
	if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value);
	cache.set(key, {
		at: Date.now(),
		rows
	});
	return rows;
}
/**
* When the query names a place precisely, businesses that merely sit *inside*
* that place should not crowd the list. Searching "Ayala Center Cebu" surfaces
* KFC and McDonald's because they are metres from the map centre — their score
* is almost entirely the proximity bonus, with the name contributing nothing.
*
* So: only when an exact/prefix match exists (the "anchor") do we push down
* hits whose *name* barely matched. This is query-aware, not a business filter:
* searching "KFC Cebu" produces no anchor (no result is named "KFC Cebu"), so
* every KFC keeps its ranking. Demoted entries are pushed below, never removed.
*/
var ANCHOR_NAME_SCORE = -50;
var WEAK_NAME_SCORE = -25;
var INSIDE_PENALTY = 80;
function demoteWeakNameMatches(places) {
	if (!places.some((p) => p.nameScore <= ANCHOR_NAME_SCORE)) return places;
	return places.map((p) => p.nameScore > WEAK_NAME_SCORE ? {
		...p,
		score: p.score + INSIDE_PENALTY
	} : p).sort((a, b) => a.score - b.score);
}
/** True when a ranked list contains something we would call a real match. */
function hasStrongMatch(places) {
	const top = places[0];
	return !!top && !top.approximate && top.score <= -40;
}
async function searchPhPlaces(rawQuery, opts = {}) {
	const { signal, limit = 10, near } = opts;
	const { query, changed } = normalizePhQuery(rawQuery);
	if (query.length < 3) return {
		results: [],
		usedQuery: query,
		fallbackUsed: false
	};
	const rank = (rows, q, viaFallback) => dedupe(rows.map((r) => toPlace(r, q, viaFallback, near)).sort((a, b) => a.score - b.score));
	const primary = rank(await fetchRows(query, signal), query, false);
	let results = primary;
	let fallbackUsed = false;
	let note;
	if (!hasStrongMatch(primary) || primary[0]?.approximate) {
		const alt = rank(await fetchPhotonRows(query, signal, near), query, true);
		const best = alt[0];
		if (!!best && (!primary.length || primary[0].approximate && !best.approximate || best.score < primary[0].score)) {
			results = dedupe([...alt, ...primary]).sort((a, b) => a.score - b.score);
			fallbackUsed = true;
			note = void 0;
		}
	}
	if (!fallbackUsed && !hasStrongMatch(primary)) for (const relaxed of relaxations(query)) {
		if (signal?.aborted) break;
		const alt = rank(await fetchRows(relaxed, signal), relaxed, true);
		if (!alt.length) continue;
		if (!primary.length || (alt[0]?.score ?? 0) < (primary[0]?.score ?? 0)) {
			results = dedupe([...alt, ...primary]).sort((a, b) => a.score - b.score);
			fallbackUsed = true;
			note = `No exact match for "${query}" — showing results for "${relaxed}".`;
			break;
		}
	}
	if (!fallbackUsed && results[0]?.approximate) note = "No landmark or place matched exactly; the closest road/area match is shown and marked approximate.";
	if (!results.length) note = `No Philippine location in OpenStreetMap matched "${query}".`;
	return {
		results: assignDisplayNames(demoteWeakNameMatches(results).slice(0, limit)),
		usedQuery: query,
		normalizedFrom: changed ? rawQuery.trim() : void 0,
		fallbackUsed,
		note
	};
}
//#endregion
export { VenueMap as n, searchPhPlaces as r, PaymentRally as t };
