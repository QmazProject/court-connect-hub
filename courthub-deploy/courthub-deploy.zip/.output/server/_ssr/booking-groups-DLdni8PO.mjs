import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { k as isRedirect, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/booking-groups-DLdni8PO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
function groupBookingSessions(rows) {
	const buckets = /* @__PURE__ */ new Map();
	for (const r of rows) {
		const k = [
			r.court_id,
			r.user_id ?? "",
			r.status,
			r.payment_status ?? ""
		].join("|");
		const arr = buckets.get(k);
		if (arr) arr.push(r);
		else buckets.set(k, [r]);
	}
	const sessions = [];
	for (const [k, arr] of buckets) {
		arr.sort((a, b) => a.start_time.localeCompare(b.start_time));
		let run = [];
		const flush = () => {
			if (run.length === 0) return;
			const first = run[0];
			const last = run[run.length - 1];
			sessions.push({
				key: `${k}|${first.id}`,
				ids: run.map((r) => r.id),
				items: run,
				first,
				start_time: first.start_time,
				end_time: last.end_time,
				hours: Math.max(1, Math.round((new Date(last.end_time).getTime() - new Date(first.start_time).getTime()) / 36e5))
			});
			run = [];
		};
		for (const r of arr) {
			if (run.length === 0) {
				run = [r];
				continue;
			}
			const prevEnd = new Date(run[run.length - 1].end_time).getTime();
			if (new Date(r.start_time).getTime() === prevEnd) run.push(r);
			else {
				flush();
				run = [r];
			}
		}
		flush();
	}
	return sessions.sort((a, b) => a.start_time.localeCompare(b.start_time));
}
var TIME_OPTS = {
	hour: "numeric",
	minute: "2-digit"
};
var formatTime = (iso) => new Date(iso).toLocaleTimeString("en-PH", TIME_OPTS);
var formatDateLabel = (iso) => new Date(iso).toLocaleDateString("en-PH", {
	weekday: "short",
	month: "short",
	day: "numeric",
	year: "numeric"
});
/** e.g. "5:00 PM – 10:00 PM" */
var formatTimeRange = (startIso, endIso) => `${formatTime(startIso)} – ${formatTime(endIso)}`;
/** e.g. "5:00 PM – 10:00 PM · 5 hrs" */
function formatSessionLabel(startIso, endIso) {
	const hrs = Math.max(1, Math.round((new Date(endIso).getTime() - new Date(startIso).getTime()) / 36e5));
	return `${formatTimeRange(startIso, endIso)} · ${hrs} hr${hrs > 1 ? "s" : ""}`;
}
//#endregion
export { useServerFn as a, groupBookingSessions as i, formatSessionLabel as n, formatTimeRange as r, formatDateLabel as t };
