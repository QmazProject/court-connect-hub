import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Dd0V2lPq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { M as redirect, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, l as useRouterState, m as createFileRoute, p as lazyRouteComponent, s as Scripts, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Route$7 } from "./courts._courtId-Df7lJkRe.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as Route$8 } from "./dashboard-DJjALW39.mjs";
import { n as Route$9 } from "./routes-Dvn3UgEW.mjs";
import { t as Route$10 } from "./explore-Dg0b7smx.mjs";
import { t as Route$11 } from "./explore_.guest-Cc28KCDw.mjs";
import { t as Route$12 } from "./landing-DEsAxbvm.mjs";
import { t as Route$13 } from "./venues._venueId-B8m7HfCs.mjs";
import { createHmac, timingSafeEqual } from "crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Bvw8h4OG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DUH0z3Fd.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	window.__lovableReportRuntimeError?.({
		message,
		stack: error instanceof Error ? error.stack : void 0,
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted-foreground",
					children: "This court doesn't exist."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/landing",
					className: "mt-6 inline-flex rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground",
					children: "Back to CourtHub"
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "root" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold",
					children: "Something went wrong"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: error.message
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						router.invalidate();
						reset();
					},
					className: "mt-6 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground",
					children: "Try again"
				})
			]
		})
	});
}
var Route$6 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "CourtHub — Book & manage sports courts" },
			{
				name: "description",
				content: "CourtHub connects players with courts and gives venue tenants tools to list and manage their courts, rates and hours."
			},
			{
				property: "og:title",
				content: "CourtHub"
			},
			{
				property: "og:description",
				content: "Book & manage sports courts."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon-16.png",
				type: "image/png",
				sizes: "16x16"
			},
			{
				rel: "icon",
				href: "/favicon-32.png",
				type: "image/png",
				sizes: "32x32"
			},
			{
				rel: "icon",
				href: "/favicon.png",
				type: "image/png",
				sizes: "256x256"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: ""
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$6.useRouteContext();
	const router = useRouter();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const isVenuePage = pathname.startsWith("/venues/");
	const isCourtPage = pathname.startsWith("/courts/");
	const showFloatingNav = isVenuePage || isCourtPage;
	const handleBack = () => {
		if (window.history.length > 2) router.history.back();
		else router.navigate({ to: isVenuePage || isCourtPage ? "/explore" : "/landing" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-dvh flex-col",
			children: [showFloatingNav && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed left-4 top-4 z-1100 flex items-center gap-2",
				children: (isVenuePage || isCourtPage) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: handleBack,
					className: "inline-flex items-center rounded-full border border-border bg-background/90 px-4 py-2 text-sm font-semibold text-foreground shadow-sm backdrop-blur transition hover:bg-secondary",
					children: "← Back"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex min-h-0 flex-1 flex-col overflow-y-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			})]
		})
	});
}
var $$splitComponentImporter$4 = () => import("./route-Di7iQBCH.mjs");
var Route$5 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		const { data, error } = await supabase.auth.getUser();
		if (error || !data.user) throw redirect({
			to: "/landing",
			search: { signin: true }
		});
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./privacy-7DZ7KQXV.mjs");
var Route$4 = createFileRoute("/privacy")({
	component: lazyRouteComponent($$splitComponentImporter$3, "component"),
	head: () => ({ meta: [
		{ title: "Privacy Policy — CourtHub" },
		{
			name: "description",
			content: "How CourtHub collects, uses, shares and protects your personal data, and the rights you have over it under the Data Privacy Act of 2012."
		},
		{
			property: "og:title",
			content: "Privacy Policy — CourtHub"
		},
		{
			property: "og:type",
			content: "website"
		}
	] })
});
var $$splitComponentImporter$2 = () => import("./reset-password-VVBjGlAf.mjs");
var Route$3 = createFileRoute("/reset-password")({
	component: lazyRouteComponent($$splitComponentImporter$2, "component"),
	head: () => ({ meta: [{ title: "Reset your password — CourtHub" }, {
		name: "robots",
		content: "noindex"
	}] })
});
var $$splitComponentImporter$1 = () => import("./terms-BnRNn9uj.mjs");
var Route$2 = createFileRoute("/terms")({
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	head: () => ({ meta: [
		{ title: "Terms & Conditions — CourtHub" },
		{
			name: "description",
			content: "The terms that govern your use of CourtHub, including account rules, bookings and payments, intellectual property and the restrictions on reverse engineering the platform."
		},
		{
			property: "og:title",
			content: "Terms & Conditions — CourtHub"
		},
		{
			property: "og:type",
			content: "website"
		}
	] })
});
var $$splitComponentImporter = () => import("./payment.return-Cf1kFua5.mjs");
var Route$1 = createFileRoute("/payment/return")({
	validateSearch: (s) => ({
		ref: typeof s.ref === "string" ? s.ref : void 0,
		status: typeof s.status === "string" ? s.status : void 0
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: () => ({ meta: [{ title: "Payment status · CourtHub" }, {
		name: "description",
		content: "Confirming your CourtHub payment."
	}] })
});
var Route = createFileRoute("/api/public/paymongo/webhook")({ server: { handlers: { POST: async ({ request }) => {
	const raw = await request.text();
	const sigHeader = request.headers.get("paymongo-signature") ?? "";
	const secret = process.env.PAYMONGO_WEBHOOK_SECRET;
	if (!secret) {
		console.error("[paymongo webhook] PAYMONGO_WEBHOOK_SECRET is not configured");
		return new Response("Webhook secret not configured", { status: 500 });
	}
	const parts = Object.fromEntries(sigHeader.split(",").map((p) => {
		const [k, v] = p.split("=");
		return [k?.trim(), (v ?? "").trim()];
	}));
	const t = parts["t"];
	const testSig = parts["te"];
	const liveSig = parts["li"];
	if (!t || !testSig && !liveSig) return new Response("Invalid signature header", { status: 401 });
	const expected = createHmac("sha256", secret).update(`${t}.${raw}`).digest("hex");
	const candidate = testSig || liveSig || "";
	let valid = false;
	try {
		const a = Buffer.from(candidate);
		const b = Buffer.from(expected);
		valid = a.length === b.length && timingSafeEqual(a, b);
	} catch {
		valid = false;
	}
	if (!valid) return new Response("Invalid signature", { status: 401 });
	let payload;
	try {
		payload = JSON.parse(raw);
	} catch {
		return new Response("Invalid JSON", { status: 400 });
	}
	const eventType = payload.data?.attributes?.type ?? "";
	const sessionId = payload.data?.attributes?.data?.id;
	const sessionAttrs = payload.data?.attributes?.data?.attributes;
	if (!sessionId) return new Response("ok");
	const { supabaseAdmin } = await import("./client.server-Bw6iWMJ-.mjs");
	if (eventType === "checkout_session.payment.paid") {
		const payment = sessionAttrs?.payments?.[0];
		const paymentId = payment?.id;
		const method = payment?.attributes.source?.type ?? "unknown";
		const { data: finalization, error: finalizationErr } = await supabaseAdmin.rpc("finalize_paid_checkout", {
			_session_id: sessionId,
			_payment_id: paymentId ?? "unknown",
			_method: method
		});
		if (finalizationErr) {
			console.error("[paymongo webhook] checkout finalization failed", finalizationErr);
			return new Response("DB error", { status: 500 });
		}
		const result = Array.isArray(finalization) ? finalization[0] : finalization;
		if (result?.refund_required) {
			const bookingIds = result.booking_ids ?? [];
			try {
				const { data: transactions, error: txErr } = await supabaseAdmin.from("transactions").select("id, amount, raw").eq("provider_ref", sessionId).eq("status", "paid");
				if (txErr) throw txErr;
				const totalCentavos = Math.round((transactions ?? []).reduce((sum, tx) => sum + Number(tx.amount), 0) * 100);
				if (!paymentId || totalCentavos <= 0) throw new Error("Payment reference or refund amount is missing");
				const { refundPayment } = await import("./paymongo.server-iZzYBd36.mjs");
				await refundPayment({
					paymentId,
					amountCentavos: totalCentavos,
					reason: "requested_by_customer"
				});
				await supabaseAdmin.from("transactions").update({
					status: "refunded",
					refunded_at: (/* @__PURE__ */ new Date()).toISOString()
				}).eq("provider_ref", sessionId);
				await supabaseAdmin.from("bookings").update({
					payment_status: "refunded",
					refund_status: "refunded"
				}).in("id", bookingIds);
			} catch (refundErr) {
				console.error("[paymongo webhook] automatic refund failed", refundErr);
			}
		}
	} else if (eventType === "checkout_session.payment.failed" || eventType === "payment.failed") {
		const { data: failedTransactions, error: failedTxErr } = await supabaseAdmin.from("transactions").select("booking_id").eq("provider_ref", sessionId);
		if (failedTxErr) {
			console.error("[paymongo webhook] failed-payment lookup failed", failedTxErr);
			return new Response("DB error", { status: 500 });
		}
		await supabaseAdmin.from("transactions").update({ status: "failed" }).eq("provider_ref", sessionId);
		const bookingIds = Array.from(new Set((failedTransactions ?? []).map((tx) => tx.booking_id)));
		if (bookingIds.length > 0) await supabaseAdmin.from("bookings").update({ payment_status: "failed" }).in("id", bookingIds).eq("status", "pending");
	}
	return new Response("ok");
} } } });
var IndexRoute = Route$9.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$6
});
var AuthenticatedRouteRoute = Route$5.update({
	id: "/_authenticated",
	getParentRoute: () => Route$6
});
var ExploreRoute = Route$10.update({
	id: "/explore",
	path: "/explore",
	getParentRoute: () => Route$6
});
var LandingRoute = Route$12.update({
	id: "/landing",
	path: "/landing",
	getParentRoute: () => Route$6
});
var PrivacyRoute = Route$4.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$6
});
var ResetPasswordRoute = Route$3.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$6
});
var TermsRoute = Route$2.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$6
});
var AuthenticatedDashboardRoute = Route$8.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AuthenticatedRouteRoute
});
var CourtsCourtIdRoute = Route$7.update({
	id: "/courts/$courtId",
	path: "/courts/$courtId",
	getParentRoute: () => Route$6
});
var ExploreGuestRoute = Route$11.update({
	id: "/explore_/guest",
	path: "/explore/guest",
	getParentRoute: () => Route$6
});
var PaymentReturnRoute = Route$1.update({
	id: "/payment/return",
	path: "/payment/return",
	getParentRoute: () => Route$6
});
var VenuesVenueIdRoute = Route$13.update({
	id: "/venues/$venueId",
	path: "/venues/$venueId",
	getParentRoute: () => Route$6
});
var ApiPublicPaymongoWebhookRoute = Route.update({
	id: "/api/public/paymongo/webhook",
	path: "/api/public/paymongo/webhook",
	getParentRoute: () => Route$6
});
var AuthenticatedRouteRouteChildren = { AuthenticatedDashboardRoute };
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	ExploreRoute,
	LandingRoute,
	PrivacyRoute,
	ResetPasswordRoute,
	TermsRoute,
	CourtsCourtIdRoute,
	ExploreGuestRoute,
	PaymentReturnRoute,
	VenuesVenueIdRoute,
	ApiPublicPaymongoWebhookRoute
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
