import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as objectType, s as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/explore_.guest-Cc28KCDw.js
var $$splitComponentImporter = () => import("./explore_.guest-BD-cCZqE.mjs");
var guestSearchSchema = objectType({ sport: stringType().optional() });
/** Guest mode: the signed-out face of /explore — same map, same list, same filters, with a
*  Guest mode badge and no booking. Deliberately a separate URL rather than a state of /explore.
*
*  Known trade-off: auth state now lives in the URL as well as in the session, so signing in
*  while sitting here leaves the badge showing on a page that is no longer a guest view until
*  the visitor navigates. A `beforeLoad` redirect for authenticated users would close that,
*  and is the obvious thing to add if it starts to bite.
*/
var Route = createFileRoute("/explore_/guest")({
	validateSearch: guestSearchSchema,
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: () => ({ meta: [{ title: "Explore venues | CourtHub" }, {
		name: "description",
		content: "Browse sports courts across the Philippines. Sign in to book."
	}] })
});
//#endregion
export { Route as t };
