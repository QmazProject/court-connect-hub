import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as LandingPage } from "./routes-Dvn3UgEW.mjs";
import { t as Route } from "./landing-DEsAxbvm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/landing-B9tFllL-.js
var import_jsx_runtime = require_jsx_runtime();
function LandingRoute() {
	const { signin, signup } = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingPage, {
		signin,
		signup
	});
}
//#endregion
export { LandingRoute as component };
