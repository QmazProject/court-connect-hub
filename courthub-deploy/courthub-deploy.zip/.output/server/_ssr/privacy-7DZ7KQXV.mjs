import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as PRIVACY, n as LegalPage } from "./LegalDocument-B84apQRn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-7DZ7KQXV.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalPage, {
		doc: PRIVACY,
		counterpart: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/terms",
			className: "text-sm font-bold text-[#12806d] transition hover:underline",
			children: "Read the Terms & Conditions"
		})
	});
}
//#endregion
export { PrivacyRoute as component };
