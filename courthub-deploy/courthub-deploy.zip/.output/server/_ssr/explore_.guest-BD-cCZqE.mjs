import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as VenueExplorer } from "./routes-Dvn3UgEW.mjs";
import { t as Route } from "./explore_.guest-Cc28KCDw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/explore_.guest-BD-cCZqE.js
var import_jsx_runtime = require_jsx_runtime();
/** Guest mode: the signed-out face of /explore — same map, same list, same filters, with a
*  Guest mode badge and no booking. Deliberately a separate URL rather than a state of /explore.
*
*  Known trade-off: auth state now lives in the URL as well as in the session, so signing in
*  while sitting here leaves the badge showing on a page that is no longer a guest view until
*  the visitor navigates. A `beforeLoad` redirect for authenticated users would close that,
*  and is the obvious thing to add if it starts to bite.
*/
function ExploreGuestRoute() {
	const { sport } = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenueExplorer, {
		sport,
		guestMode: true
	});
}
//#endregion
export { ExploreGuestRoute as component };
