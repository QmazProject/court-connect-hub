import { i as __toESM } from "../_runtime.mjs";
import { A as peso$1, C as minRate, D as openHoursForDate, E as normalizeRules, N as rateBands, O as openHoursForDay, T as normalizeHours, _ as fullWeek, a as HOUR_DAY_KEYS, b as isOvernight, c as WEEKENDS, f as describeWindow, g as fmtHour12, h as fmtHour$1, i as DAY_LABELS, k as parseWindow, m as effectiveHours, n as CLOSED, o as HOUR_DAY_LABELS, r as DAY_KEYS, s as WEEKDAYS, t as ALL_DAY, u as defaultRuleTemplate, v as hasVariablePricing, w as newRule, x as makeWindow, y as isClosed } from "./court-pricing-CFeeeUa8.mjs";
import { t as supabase } from "./client-Dd0V2lPq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime, a as Overlay2, c as Title2, i as Description2, n as Cancel, o as Portal2, r as Content2, s as Root2, t as Action } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { c as createServerFn } from "./createServerFn-BFFE07zL.mjs";
import { a as useServerFn, i as groupBookingSessions, n as formatSessionLabel, r as formatTimeRange, t as formatDateLabel } from "./booking-groups-DLdni8PO.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-BwdutfJC.mjs";
import { n as Root2$1, r as Trigger, t as Content2$1 } from "../_libs/@radix-ui/react-hover-card+[...].mjs";
import { n as MapPicker, o as cn, t as MapInfoButton } from "./popover-Z5PgJyYY.mjs";
import { B as MapPin, D as Search, E as Send, F as Navigation, G as Layers, K as LandPlot, L as Menu, O as Save, P as Pencil, T as Settings, W as LayoutDashboard, X as Heart, Y as History, _ as Timer, _t as BookOpen, ct as ChevronLeft, f as Trophy, ft as CalendarPlus, g as Trash2, gt as Bookmark, h as TrendingDown, i as Wallet, j as Receipt, k as RotateCcw, lt as ChevronDown, m as TrendingUp, o as Users, ot as ChevronUp, p as TriangleAlert, pt as CalendarDays, st as ChevronRight, t as X, u as UserCog, v as TicketPercent, w as ShieldAlert, y as TableProperties } from "../_libs/lucide-react.mjs";
import { n as PlayerShell, t as NotificationBell } from "./PlayerShell-Re8It3Mk.mjs";
import { a as numberType, i as enumType, o as objectType, s as stringType, t as arrayType } from "../_libs/zod.mjs";
import { n as createSsrRpc, r as retryBookingPayment, t as cancelPendingBookings } from "./paymongo.functions-BVintJM4.mjs";
import { t as Route } from "./dashboard-DJjALW39.mjs";
import { i as useFavoriteCourts, n as FavoriteButton, r as buttonVariants } from "./FavoriteButton-WKzUJGL1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-DuG25dPy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var sameSet = (a, b) => a.length === b.length && b.every((d) => a.includes(d));
function DayPreset({ rule, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		value: sameSet(rule.days, WEEKDAYS) ? "weekdays" : sameSet(rule.days, WEEKENDS) ? "weekends" : "custom",
		onChange: (e) => {
			const v = e.target.value;
			if (v === "weekdays") onChange([...WEEKDAYS]);
			else if (v === "weekends") onChange([...WEEKENDS]);
		},
		className: "w-full rounded-lg border border-input bg-background px-2 py-1.5 text-xs",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: "weekdays",
				children: "Weekdays (Mon–Fri)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: "weekends",
				children: "Weekends (Sat–Sun)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: "custom",
				children: "Custom days"
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-1.5 flex flex-wrap gap-1",
		children: DAY_KEYS.map((d) => {
			const on = rule.days.includes(d);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onChange(on ? rule.days.filter((x) => x !== d) : [...rule.days, d]),
				className: "rounded-full border px-2 py-0.5 text-[10px] font-semibold transition " + (on ? "border-primary bg-primary/15 text-primary" : "border-border text-muted-foreground hover:border-primary/50"),
				children: DAY_LABELS[d]
			}, d);
		})
	})] });
}
function HourSelect$1({ value, onChange, max = 24 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		value,
		onChange: (e) => onChange(Number(e.target.value)),
		className: "w-full rounded-lg border border-input bg-background px-2 py-1.5 text-xs",
		children: Array.from({ length: max + 1 }, (_, h) => h).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: h,
			children: h === 24 ? "12:00 AM (next day)" : fmtHour12(h)
		}, h))
	});
}
function PreviewStrip({ baseRate, rules, day, title }) {
	const bands = (0, import_react.useMemo)(() => rateBands(baseRate, rules, day), [
		baseRate,
		rules,
		day
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-1 flex flex-wrap gap-1",
		children: bands.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "rounded-md border px-2 py-0.5 text-[10px] font-medium " + (b.rate === Number(baseRate) ? "border-border bg-muted text-muted-foreground" : "border-primary/40 bg-primary/10 text-foreground"),
			children: [
				fmtHour12(b.start),
				"–",
				fmtHour12(b.end % 24),
				" · ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: peso$1(b.rate) })
			]
		}, `${b.start}-${b.end}`))
	})] });
}
function RateRulesEditor({ baseRate, rules, onChange }) {
	const enabled = rules.length > 0;
	const update = (id, patch) => onChange(rules.map((r) => r.id === id ? {
		...r,
		...patch
	} : r));
	const invalid = rules.filter((r) => r.days.length === 0 || r.start_hour >= r.end_hour || !(r.rate > 0));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 rounded-xl border border-primary/30 bg-primary/5 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-semibold uppercase tracking-wider text-primary",
				children: "Time-based pricing"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[11px] text-muted-foreground",
				children: "Charge different rates for morning, afternoon and evening, and for weekends. Any hour without a rule uses the hourly rate above."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-xs font-medium",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: enabled,
					onChange: (e) => onChange(e.target.checked ? defaultRuleTemplate(baseRate) : [])
				}), "Use time-based pricing"]
			})]
		}), enabled && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 space-y-2",
				children: rules.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-background p-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-[1.4fr_1fr_1fr_0.9fr_auto] sm:items-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: r.label ?? "",
								onChange: (e) => update(r.id, { label: e.target.value }),
								placeholder: "Label (e.g. Weekday evening)",
								className: "w-full rounded-lg border border-input bg-background px-2 py-1.5 text-xs"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayPreset, {
									rule: r,
									onChange: (days) => update(r.id, { days })
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-medium text-muted-foreground",
									children: "From"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HourSelect$1, {
									value: r.start_hour,
									onChange: (v) => update(r.id, { start_hour: v }),
									max: 23
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-medium text-muted-foreground",
									children: "Until"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HourSelect$1, {
									value: r.end_hour,
									onChange: (v) => update(r.id, { end_hour: v })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-medium text-muted-foreground",
									children: "Rate / hr (₱)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 1,
									value: r.rate,
									onChange: (e) => update(r.id, { rate: Number(e.target.value) }),
									className: "w-full rounded-lg border border-input bg-background px-2 py-1.5 text-xs"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onChange(rules.filter((x) => x.id !== r.id)),
								className: "self-end rounded-lg border border-border px-2 py-1.5 text-xs text-muted-foreground hover:border-destructive hover:text-destructive",
								"aria-label": "Remove rule",
								children: "Remove"
							})
						]
					}), (r.days.length === 0 || r.start_hour >= r.end_hour || !(r.rate > 0)) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-[11px] text-destructive",
						children: "Pick at least one day, an end time after the start time, and a rate above ₱0."
					})]
				}, r.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange([...rules, newRule(baseRate)]),
					className: "rounded-lg border border-border bg-background px-3 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary",
					children: "+ Add rule"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange(defaultRuleTemplate(baseRate)),
					className: "rounded-lg border border-border bg-background px-3 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary",
					children: "Quick setup (AM / PM / evening)"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-2 rounded-lg border border-border bg-background p-2.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] font-semibold",
						children: "Player-facing preview"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewStrip, {
						baseRate,
						rules,
						day: "wed",
						title: "Typical weekday"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewStrip, {
						baseRate,
						rules,
						day: "sat",
						title: "Typical weekend"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] text-muted-foreground",
						children: "If two rules overlap, the one lower in the list wins. Grey bands use your default hourly rate."
					})
				]
			}),
			invalid.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-[11px] text-amber-900 dark:text-amber-200",
				children: [
					"⚠ ",
					invalid.length,
					" rule",
					invalid.length > 1 ? "s are" : " is",
					" incomplete and will be ignored when saving."
				]
			})
		] })]
	});
}
var HOUR_OPTIONS = Array.from({ length: 25 }, (_, h) => h);
function HourSelect({ value, onChange, allowMidnightEnd }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		value,
		onChange: (e) => onChange(Number(e.target.value)),
		className: "rounded-lg border border-input bg-background px-2 py-1.5 text-xs",
		children: HOUR_OPTIONS.filter((h) => allowMidnightEnd ? true : h < 24).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: h,
			children: h === 24 ? "12:00 AM (midnight)" : fmtHour$1(h)
		}, h))
	});
}
function DayRow({ day, value, onChange }) {
	const closed = isClosed(value);
	const w = parseWindow(value) ?? [8, 17];
	const open24 = !closed && w[0] === 0 && w[1] === 24;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-2 border-b border-border py-2 last:border-b-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-20 shrink-0 text-xs font-semibold",
				children: HOUR_DAY_LABELS[day]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				value: closed ? "closed" : open24 ? "24h" : "custom",
				onChange: (e) => {
					const v = e.target.value;
					if (v === "closed") onChange(CLOSED);
					else if (v === "24h") onChange(ALL_DAY);
					else onChange(makeWindow(8, 17));
				},
				className: "rounded-lg border border-input bg-background px-2 py-1.5 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "24h",
						children: "Open 24 hours"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "custom",
						children: "Set hours"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "closed",
						children: "Closed"
					})
				]
			}),
			!closed && !open24 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HourSelect, {
					value: w[0],
					onChange: (v) => onChange(makeWindow(v, w[1]))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "to"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HourSelect, {
					value: w[1],
					onChange: (v) => onChange(makeWindow(w[0], v)),
					allowMidnightEnd: true
				}),
				isOvernight(value) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full border border-primary/40 bg-primary/10 px-2 py-0.5 text-[10px] font-semibold text-primary",
					children: "Overnight → next day"
				})
			] }),
			(closed || open24) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[11px] text-muted-foreground",
				children: describeWindow(value)
			})
		]
	});
}
function OperatingHoursEditor({ hours, onChange, title = "Operating hours", hint }) {
	const set = (day, v) => onChange({
		...hours,
		[day]: v
	});
	const applyToAll = () => {
		const mon = hours.mon ?? "00:00-24:00";
		onChange(Object.fromEntries(HOUR_DAY_KEYS.map((d) => [d, mon])));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-semibold uppercase tracking-wider text-primary",
				children: title
			}), hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[11px] text-muted-foreground",
				children: hint
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange(Object.fromEntries(HOUR_DAY_KEYS.map((d) => [d, ALL_DAY]))),
					className: "rounded-lg border border-border bg-background px-2.5 py-1.5 text-[11px] font-semibold hover:border-primary hover:text-primary",
					children: "Open 24/7"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: applyToAll,
					className: "rounded-lg border border-border bg-background px-2.5 py-1.5 text-[11px] font-semibold hover:border-primary hover:text-primary",
					children: "Copy Monday to all days"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2",
			children: [
				"mon",
				"tue",
				"wed",
				"thu",
				"fri",
				"sat",
				"sun"
			].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayRow, {
				day: d,
				value: hours[d] ?? "00:00-24:00",
				onChange: (v) => set(d, v)
			}, d))
		})]
	});
}
function CourtHoursEditor({ inherit, onInheritChange, hours, onHoursChange, venueHours }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 rounded-xl border border-primary/30 bg-primary/5 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-start gap-2 text-xs font-medium",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				className: "mt-0.5",
				checked: inherit,
				onChange: (e) => onInheritChange(e.target.checked)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Follow the venue's operating hours", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block text-[11px] font-normal text-muted-foreground",
				children: "Recommended. Change the venue hours once and every court that follows them updates automatically."
			})] })]
		}), inherit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 grid gap-1 rounded-lg border border-border bg-background p-2.5 sm:grid-cols-2",
			children: [
				"mon",
				"tue",
				"wed",
				"thu",
				"fri",
				"sat",
				"sun"
			].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2 text-[11px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium text-muted-foreground",
					children: HOUR_DAY_LABELS[d].slice(0, 3)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: describeWindow(venueHours[d])
				})]
			}, d))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OperatingHoursEditor, {
				hours,
				onChange: onHoursChange,
				title: "Court-specific hours",
				hint: "This court ignores the venue schedule and uses the hours below."
			})
		})]
	});
}
var BUCKET = "venue-images";
var SIGNED_EXPIRY = 3600 * 24 * 365 * 10;
function ImageUploader({ label = "Photos", pathPrefix, images, onChange, max = 8 }) {
	const fileRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	const handleFiles = async (files) => {
		if (!files || files.length === 0) return;
		setErr(null);
		setBusy(true);
		try {
			const remaining = Math.max(0, max - images.length);
			const list = Array.from(files).slice(0, remaining);
			const uploaded = [];
			for (const file of list) {
				if (!file.type.startsWith("image/")) throw new Error(`"${file.name}" is not an image.`);
				if (file.size > 5 * 1024 * 1024) throw new Error(`"${file.name}" is larger than 5 MB.`);
				const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
				const path = `${pathPrefix}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
				const { error: upErr } = await supabase.storage.from(BUCKET).upload(path, file, {
					cacheControl: "3600",
					upsert: false,
					contentType: file.type
				});
				if (upErr) throw upErr;
				const { data: signed, error: sErr } = await supabase.storage.from(BUCKET).createSignedUrl(path, SIGNED_EXPIRY);
				if (sErr) throw sErr;
				uploaded.push(signed.signedUrl);
			}
			onChange([...images, ...uploaded]);
		} catch (e) {
			setErr(e instanceof Error ? e.message : "Upload failed");
		} finally {
			setBusy(false);
			if (fileRef.current) fileRef.current.value = "";
		}
	};
	const remove = (idx) => {
		onChange(images.filter((_, i) => i !== idx));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-1 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-[11px] text-muted-foreground",
				children: [
					images.length,
					"/",
					max
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [images.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-20 w-28 overflow-hidden rounded-md border border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src,
					alt: `Upload ${i + 1}`,
					className: "h-full w-full object-cover",
					loading: "lazy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => remove(i),
					className: "absolute right-1 top-1 rounded-full bg-background/90 px-1.5 py-0.5 text-[10px] font-semibold text-destructive shadow hover:bg-background",
					"aria-label": "Remove image",
					children: "✕"
				})]
			}, i)), images.length < max && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: busy,
				onClick: () => fileRef.current?.click(),
				className: "grid h-20 w-28 place-items-center rounded-md border-2 border-dashed border-border text-xs text-muted-foreground hover:border-primary hover:text-primary disabled:opacity-60",
				children: busy ? "Uploading…" : "+ Upload"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			ref: fileRef,
			type: "file",
			accept: "image/*",
			multiple: true,
			className: "hidden",
			onChange: (e) => handleFiles(e.target.files)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-[11px] text-muted-foreground",
			children: "JPG/PNG/WebP up to 5 MB each."
		}),
		err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 rounded-md bg-destructive/10 px-2 py-1 text-xs text-destructive",
			children: err
		})
	] });
}
var PRESETS = [
	"🎾",
	"🥎",
	"🏓",
	"🏸",
	"🏀",
	"🏐",
	"⚽",
	"🏈",
	"🏑",
	"🏒",
	"🥅",
	"⛳",
	"🎱",
	"🏊",
	"🥊",
	"🤸",
	"🏟️",
	"📍",
	"⭐",
	"🔥",
	"💪",
	"🏆"
];
function firstEmoji(s) {
	const trimmed = s.trim();
	if (!trimmed) return "";
	try {
		const first = new Intl.Segmenter(void 0, { granularity: "grapheme" }).segment(trimmed)[Symbol.iterator]().next();
		return first.done ? trimmed.slice(0, 2) : first.value.segment;
	} catch {
		return Array.from(trimmed)[0] ?? "";
	}
}
function EmojiPicker({ label = "Map emoji", value, fallback = "🎾", onChange, hint }) {
	const [custom, setCustom] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted-foreground",
					children: label
				}), value && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange(null),
					className: "text-[11px] font-medium text-muted-foreground hover:text-primary",
					children: "Reset to default"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1.5 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-label": "Current emoji preview",
					className: "grid h-11 w-11 shrink-0 place-items-center rounded-full border-2 border-primary bg-primary/10 text-2xl",
					children: value || fallback
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: PRESETS.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onChange(e),
						className: "grid h-8 w-8 place-items-center rounded-md border text-lg transition " + (value === e ? "border-primary bg-primary/10" : "border-border bg-background hover:border-primary"),
						children: e
					}, e))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						value: custom,
						onChange: (e) => setCustom(e.target.value),
						placeholder: "Or paste any emoji…",
						maxLength: 8,
						className: "w-32 rounded-md border border-input bg-background px-2 py-1 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							const pick = firstEmoji(custom);
							if (pick) {
								onChange(pick);
								setCustom("");
							}
						},
						className: "rounded-md border border-border px-2 py-1 text-xs font-medium hover:border-primary hover:text-primary",
						children: "Use"
					}),
					hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-muted-foreground",
						children: hint
					})
				]
			})
		]
	});
}
var HoverCard = Root2$1;
var HoverCardTrigger = Trigger;
var HoverCardContent = import_react.forwardRef(({ className, align = "center", sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2$1, {
	ref,
	align,
	sideOffset,
	className: cn("z-50 w-64 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-hover-card-content-transform-origin)", className),
	...props
}));
HoverCardContent.displayName = Content2$1.displayName;
/**
* Shown before narrowing operating hours. Existing bookings are always
* grandfathered — new hours only ever gate NEW bookings.
*/
function HoursConflictDialog({ conflicts, onKeep, onCancelThem, onDismiss, busy }) {
	const total = conflicts.reduce((n, c) => n + c.bookingIds.length, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[1400] grid place-items-center bg-black/50 px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex max-h-[85dvh] w-full max-w-lg flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3 border-b border-border p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-5 w-5 shrink-0 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "font-display text-lg font-semibold",
							children: [
								conflicts.length,
								" upcoming booking",
								conflicts.length === 1 ? "" : "s",
								" fall outside the new hours"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: [
								total,
								" reserved hour",
								total === 1 ? "" : "s",
								" in total. Existing bookings are honoured by default — the new schedule only applies to bookings made from now on."
							]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onDismiss,
						disabled: busy,
						className: "rounded-md p-1 hover:bg-secondary",
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "nice-scroll flex-1 divide-y divide-border overflow-y-auto px-5",
					children: conflicts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center justify-between gap-2 py-2.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: formatDateLabel(c.startTime)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-muted-foreground",
								children: [
									formatSessionLabel(c.startTime, c.endTime),
									" · ",
									c.courtName,
									" · ",
									c.playerName
								]
							})]
						}), c.paid && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-primary",
							children: "Paid"
						})]
					}, c.bookingIds.join(",")))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-end gap-2 border-t border-border p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: onDismiss,
							disabled: busy,
							className: "rounded-lg border border-border px-4 py-2 text-sm font-semibold",
							children: "Back to editing"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: onCancelThem,
							disabled: busy,
							className: "rounded-lg border border-destructive/40 px-4 py-2 text-sm font-semibold text-destructive hover:bg-destructive/10 disabled:opacity-50",
							children: "Cancel & refund them"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: onKeep,
							disabled: busy,
							className: "rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-50",
							children: busy ? "Saving…" : "Keep them (recommended)"
						})
					]
				})
			]
		})
	});
}
var localDateISO = (iso) => {
	const d = new Date(iso);
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
/**
* Upcoming confirmed bookings that would sit outside a proposed schedule.
* `scope` is either the venue's new hours (affects every inheriting court)
* or a single court's new hours.
*/
async function findHoursConflicts(opts) {
	const nowIso = (/* @__PURE__ */ new Date()).toISOString();
	let q = supabase.from("bookings").select("id, court_id, user_id, start_time, end_time, status, payment_status, courts!inner(name, venue_id, inherit_venue_hours, operating_hours)").eq("status", "confirmed").gte("start_time", nowIso).eq("courts.venue_id", opts.venueId).order("start_time", { ascending: true }).limit(500);
	if (opts.courtId) q = q.eq("court_id", opts.courtId);
	const { data, error } = await q;
	if (error) throw error;
	const rows = data ?? [];
	if (rows.length === 0) return [];
	const outside = rows.filter((r) => {
		const court = r.courts;
		if (!court) return false;
		let hours;
		if (opts.courtId) hours = opts.courtInherits && opts.newVenueHours ? opts.newVenueHours : opts.newCourtHours;
		else if (court.inherit_venue_hours !== false && opts.newVenueHours) hours = opts.newVenueHours;
		else hours = effectiveHours({
			inherit_venue_hours: court.inherit_venue_hours,
			operating_hours: court.operating_hours
		}, opts.newVenueHours ?? {});
		return !openHoursForDate(hours, localDateISO(r.start_time)).has(new Date(r.start_time).getHours());
	});
	if (outside.length === 0) return [];
	const uids = Array.from(new Set(outside.map((r) => r.user_id).filter(Boolean)));
	const { data: profiles } = uids.length ? await supabase.from("profiles").select("id, full_name").in("id", uids) : { data: [] };
	const nameMap = new Map((profiles ?? []).map((p) => [p.id, p.full_name || "Player"]));
	return groupBookingSessions(outside).map((s) => ({
		bookingIds: s.ids,
		startTime: s.start_time,
		endTime: s.end_time,
		courtName: s.first.courts?.name ?? `Court #${s.first.court_id}`,
		playerName: nameMap.get(s.first.user_id ?? "") ?? "Player",
		paid: s.items.some((i) => i.payment_status === "paid")
	}));
}
var CancelInput = objectType({
	bookingIds: arrayType(numberType().int().positive()).min(1).max(100),
	reason: stringType().trim().max(500).optional(),
	refundMode: enumType([
		"auto",
		"manual",
		"none"
	])
});
/**
* Venue-staff cancellation. The RPC enforces that the caller is staff of the
* venue, flips the bookings to cancelled (never deletes them) and notifies the
* player. Automatic refunds are then pushed back to the original PayMongo
* payment — we never ask a player for a GCash or card number.
*/
var cancelBookingsWithRefund = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => CancelInput.parse(data)).handler(createSsrRpc("e6d797fc46af27ae0c4dcdb2f89d05cd9cd84f62316651b2a5967f2632668ebb"));
var ruleKey = (a, b) => `${a}>${b}`;
/** Every ordered pair among the given courts, both directions enabled. */
function allPairsEnabled(courtIds) {
	const s = /* @__PURE__ */ new Set();
	for (const a of courtIds) for (const b of courtIds) if (a !== b) s.add(ruleKey(a, b));
	return s;
}
function CourtBlockRulesEditor({ courts, rules, onChange }) {
	const toggle = (a, b) => {
		const next = new Set(rules);
		const k = ruleKey(a, b);
		if (next.has(k)) next.delete(k);
		else next.add(k);
		onChange(next);
	};
	if (courts.length < 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-xl border border-dashed border-border p-3 text-xs text-muted-foreground",
		children: "Select at least two courts above to configure which ones block each other."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-primary/30 bg-primary/5 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-semibold uppercase tracking-wider text-primary",
				children: "Configured rules"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-[11px] text-muted-foreground",
				children: [
					"Tap a court on the right to switch its rule on or off. ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-foreground",
						children: "Left → Right"
					}),
					" means: when the left court is booked for an hour, the right court is blocked for that hour."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 space-y-2",
				children: courts.map((src) => {
					const others = courts.filter((c) => c.id !== src.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-lg border border-border bg-background p-2.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-start gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-[7.5rem] shrink-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-sm font-semibold",
										children: [src.emoji ? `${src.emoji} ` : "", src.name]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] uppercase tracking-wider text-muted-foreground",
										children: src.sport ?? "—"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "→"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-1 flex-wrap gap-1.5",
									children: others.map((dst) => {
										const on = rules.has(ruleKey(src.id, dst.id));
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => toggle(src.id, dst.id),
											"aria-pressed": on,
											className: "rounded-full border px-2.5 py-1 text-[11px] font-semibold transition " + (on ? "border-primary bg-primary/15 text-primary" : "border-border text-muted-foreground hover:border-primary/50"),
											children: [
												on ? "✓ " : "",
												dst.emoji ? `${dst.emoji} ` : "",
												dst.name,
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "ml-1 font-normal opacity-70",
													children: dst.sport ?? ""
												})
											]
										}, dst.id);
									})
								})
							]
						})
					}, src.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange(allPairsEnabled(courts.map((c) => c.id))),
					className: "rounded-lg border border-border bg-background px-3 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary",
					children: "Enable all (block each other)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange(/* @__PURE__ */ new Set()),
					className: "rounded-lg border border-border bg-background px-3 py-1.5 text-xs font-semibold hover:border-destructive hover:text-destructive",
					children: "Clear all"
				})]
			})
		]
	});
}
var AlertDialog = Root2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	className: cn("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
var AlertDialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
AlertDialogHeader.displayName = "AlertDialogHeader";
var AlertDialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
AlertDialogFooter.displayName = "AlertDialogFooter";
var AlertDialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("text-lg font-semibold", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), "mt-2 sm:mt-0", className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
var MAX_LEN = 2e3;
/**
* Private thread attached to a single booking (player <-> venue staff).
* Payment details must never be exchanged here — refunds are processed
* back to the original payment method by the venue.
*/
function BookingChat({ bookingId, venueId, playerId, meId, title, subtitle, onClose }) {
	const qc = useQueryClient();
	const [text, setText] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)(null);
	const [sending, setSending] = (0, import_react.useState)(false);
	const bottomRef = (0, import_react.useRef)(null);
	const convQ = useQuery({
		queryKey: ["conversation", bookingId],
		queryFn: async () => {
			const { data: existing, error } = await supabase.from("conversations").select("id, booking_id, venue_id, player_id").eq("booking_id", bookingId).maybeSingle();
			if (error) throw error;
			if (existing) return existing;
			const { data: created, error: insErr } = await supabase.from("conversations").insert({
				booking_id: bookingId,
				venue_id: venueId,
				player_id: playerId
			}).select("id, booking_id, venue_id, player_id").single();
			if (insErr) throw insErr;
			return created;
		}
	});
	const conversationId = convQ.data?.id;
	const msgsQ = useQuery({
		queryKey: ["messages", conversationId],
		enabled: !!conversationId,
		queryFn: async () => {
			const { data, error } = await supabase.from("messages").select("id, conversation_id, sender_id, body, created_at").eq("conversation_id", conversationId).order("created_at", { ascending: true }).limit(300);
			if (error) throw error;
			return data ?? [];
		}
	});
	const namesQ = useQuery({
		queryKey: [
			"chat-names",
			conversationId,
			(msgsQ.data ?? []).length
		],
		enabled: !!msgsQ.data && msgsQ.data.length > 0,
		queryFn: async () => {
			const ids = Array.from(new Set((msgsQ.data ?? []).map((m) => m.sender_id)));
			const { data } = await supabase.from("profiles").select("id, full_name").in("id", ids);
			return new Map((data ?? []).map((p) => [p.id, p.full_name || "Member"]));
		}
	});
	(0, import_react.useEffect)(() => {
		if (!conversationId) return;
		const channel = supabase.channel(`messages:${conversationId}:${Math.random().toString(36).slice(2)}`).on("postgres_changes", {
			event: "INSERT",
			schema: "public",
			table: "messages",
			filter: `conversation_id=eq.${conversationId}`
		}, () => qc.invalidateQueries({ queryKey: ["messages", conversationId] })).subscribe();
		return () => {
			supabase.removeChannel(channel);
		};
	}, [conversationId, qc]);
	(0, import_react.useEffect)(() => {
		bottomRef.current?.scrollIntoView({ behavior: "smooth" });
	}, [msgsQ.data?.length]);
	const send = async () => {
		const body = text.trim();
		if (!body || !conversationId) return;
		if (body.length > MAX_LEN) {
			setErr(`Messages are limited to ${MAX_LEN} characters.`);
			return;
		}
		setSending(true);
		setErr(null);
		const { error } = await supabase.from("messages").insert({
			conversation_id: conversationId,
			sender_id: meId,
			body
		});
		setSending(false);
		if (error) {
			setErr(error.message);
			return;
		}
		setText("");
		qc.invalidateQueries({ queryKey: ["messages", conversationId] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[1400] grid place-items-end bg-black/50 sm:place-items-center sm:p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-[85dvh] w-full flex-col overflow-hidden rounded-t-2xl border border-border bg-card shadow-2xl sm:h-[600px] sm:max-w-lg sm:rounded-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3 border-b border-border px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "truncate font-display text-sm font-semibold",
							children: title
						}), subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-[11px] text-muted-foreground",
							children: subtitle
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						"aria-label": "Close chat",
						className: "rounded-md p-1 hover:bg-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2 border-b border-amber-500/30 bg-amber-500/10 px-4 py-2 text-[11px] text-amber-800 dark:text-amber-300",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "mt-0.5 h-3.5 w-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Never share GCash numbers, card details or passwords here. Refunds are returned to your original payment method." })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nice-scroll flex-1 space-y-3 overflow-y-auto px-4 py-3",
					children: [convQ.isLoading || msgsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-muted-foreground",
						children: "Loading conversation…"
					}) : convQ.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-destructive",
						children: convQ.error.message
					}) : (msgsQ.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-8 text-center text-xs text-muted-foreground",
						children: "No messages yet. Say hello — this thread is only about this booking."
					}) : (msgsQ.data ?? []).map((m) => {
						const mine = m.sender_id === meId;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col " + (mine ? "items-end" : "items-start"),
							children: [
								!mine && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-0.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
									children: namesQ.data?.get(m.sender_id) ?? "Member"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "max-w-[80%] whitespace-pre-wrap break-words rounded-2xl px-3 py-2 text-sm " + (mine ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"),
									children: m.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 text-[10px] text-muted-foreground",
									children: new Date(m.created_at).toLocaleString("en-PH", {
										dateStyle: "short",
										timeStyle: "short"
									})
								})
							]
						}, m.id);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: bottomRef })]
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-4 pb-1 text-[11px] text-destructive",
					children: err
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end gap-2 border-t border-border p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: text,
						onChange: (e) => setText(e.target.value.slice(0, MAX_LEN)),
						onKeyDown: (e) => {
							if (e.key === "Enter" && !e.shiftKey) {
								e.preventDefault();
								send();
							}
						},
						rows: 2,
						placeholder: "Write a message…",
						className: "min-h-[44px] flex-1 resize-none rounded-xl border border-input bg-background px-3 py-2 text-sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: send,
						disabled: sending || !text.trim() || !conversationId,
						className: "grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground disabled:opacity-50",
						"aria-label": "Send message",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4" })
					})]
				})
			]
		})
	});
}
/**
* Venue-staff cancellation. Bookings are never deleted — they move to
* "cancelled" so receipts, reporting and the player's history stay intact.
*/
function CancelRefundDialog({ target, onClose, onDone }) {
	const cancelFn = useServerFn(cancelBookingsWithRefund);
	const [reason, setReason] = (0, import_react.useState)("");
	const [mode, setMode] = (0, import_react.useState)("auto");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	const submit = async () => {
		setBusy(true);
		setErr(null);
		try {
			const res = await cancelFn({ data: {
				bookingIds: target.bookingIds,
				reason: reason.trim() || void 0,
				refundMode: target.hasPaid ? mode : "none"
			} });
			setResult(res);
			onDone();
		} catch (e) {
			setErr(e.message);
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[1400] grid place-items-center bg-black/50 px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-5 w-5 shrink-0 text-destructive" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-lg font-semibold",
						children: "Cancel booking"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-xs text-muted-foreground",
						children: target.label
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					disabled: busy,
					className: "rounded-md p-1 hover:bg-secondary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
				})]
			}), result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-secondary/60 p-3",
						children: [
							result.cancelled,
							" slot",
							result.cancelled === 1 ? "" : "s",
							" cancelled",
							result.refunded > 0 ? ` · ${result.refunded} refund${result.refunded === 1 ? "" : "s"} sent` : "",
							". The player has been notified."
						]
					}),
					result.failures.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1 rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-[11px] text-amber-800 dark:text-amber-300",
						children: result.failures.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: f }, f))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						className: "mt-2 w-full rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground",
						children: "Done"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-4 block text-xs font-semibold uppercase tracking-wider text-muted-foreground",
					children: "Reason for the player"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: reason,
					onChange: (e) => setReason(e.target.value.slice(0, 500)),
					rows: 3,
					placeholder: "e.g. Court maintenance on this date — sorry for the trouble.",
					className: "mt-1.5 w-full resize-none rounded-xl border border-input bg-background px-3 py-2 text-sm"
				}),
				target.hasPaid ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
						children: "Refund"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex cursor-pointer items-start gap-2 rounded-xl border border-border p-3 text-sm has-[:checked]:border-primary has-[:checked]:bg-primary/5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								className: "mt-0.5",
								checked: mode === "auto",
								onChange: () => setMode("auto")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Refund automatically via PayMongo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 block text-[11px] font-normal text-muted-foreground",
								children: "Money goes back to the exact source the player paid from. Recommended."
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex cursor-pointer items-start gap-2 rounded-xl border border-border p-3 text-sm has-[:checked]:border-primary has-[:checked]:bg-primary/5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								className: "mt-0.5",
								checked: mode === "manual",
								onChange: () => setMode("manual")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Settle the refund myself", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 block text-[11px] font-normal text-muted-foreground",
								children: "Marked as “refund pending” until you mark it settled. Arrange it in the booking chat — never ask for card or e-wallet numbers."
							})] })]
						})]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-xl bg-secondary/60 p-3 text-xs text-muted-foreground",
					children: "Nothing was paid for this booking, so there is no refund to process."
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-destructive",
					children: err
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						disabled: busy,
						className: "rounded-lg border border-border px-4 py-2 text-sm font-semibold",
						children: "Keep booking"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: submit,
						disabled: busy,
						className: "rounded-lg bg-destructive px-4 py-2 text-sm font-semibold text-destructive-foreground hover:opacity-90 disabled:opacity-50",
						children: busy ? "Cancelling…" : target.hasPaid ? "Cancel & refund" : "Cancel booking"
					})]
				})
			] })]
		})
	});
}
var SPORT_COLORS = {
	tennis: {
		bg: "bg-emerald-100",
		dot: "bg-emerald-500",
		text: "text-emerald-900",
		border: "border-emerald-200"
	},
	basketball: {
		bg: "bg-amber-100",
		dot: "bg-amber-500",
		text: "text-amber-900",
		border: "border-amber-200"
	},
	badminton: {
		bg: "bg-sky-100",
		dot: "bg-sky-500",
		text: "text-sky-900",
		border: "border-sky-200"
	},
	volleyball: {
		bg: "bg-violet-100",
		dot: "bg-violet-500",
		text: "text-violet-900",
		border: "border-violet-200"
	},
	pickleball: {
		bg: "bg-pink-100",
		dot: "bg-pink-500",
		text: "text-pink-900",
		border: "border-pink-200"
	},
	football: {
		bg: "bg-lime-100",
		dot: "bg-lime-500",
		text: "text-lime-900",
		border: "border-lime-200"
	},
	squash: {
		bg: "bg-rose-100",
		dot: "bg-rose-500",
		text: "text-rose-900",
		border: "border-rose-200"
	},
	default: {
		bg: "bg-slate-100",
		dot: "bg-slate-500",
		text: "text-slate-900",
		border: "border-slate-200"
	}
};
/** Colour for a sport slug. Unknown sports fall back to slate rather than to no
*  colour at all — an uncoloured block reads as a different kind of thing. */
function sportStyle(slug) {
	if (!slug) return SPORT_COLORS.default;
	return SPORT_COLORS[slug.toLowerCase()] ?? SPORT_COLORS.default;
}
/**
* Derived statistics for the player workspace.
*
* Everything here is pure: rows in, numbers out. The dashboard renders it, but the
* rules live here so there is exactly one answer to "what did this booking cost"
* and "who cancelled it" — the same answer the tenant side already gives.
*
* Three money values are deliberately kept apart, because conflating them is how a
* dashboard ends up lying to someone about a refund:
*
*   price    — what the booking costs:  unit_price - discount_amount
*   paid     — what actually reached the venue: transactions with status 'paid'
*   refunded — what came back:                  transactions with status 'refunded'
*
* A refunded transaction is flipped from 'paid' to 'refunded' by the refund path, so
* `paid` is already net of refunds and must not be reduced again.
*/
var PERIODS = [
	{
		key: "month",
		label: "This month"
	},
	{
		key: "last_month",
		label: "Last month"
	},
	{
		key: "3months",
		label: "Last 3 months"
	},
	{
		key: "year",
		label: "This year"
	},
	{
		key: "all",
		label: "All time"
	}
];
/** What one hourly row costs. Mirrors the tenant bookings table exactly:
*  `unit_price - discount_amount`, falling back to the court's current rate only
*  when the row predates unit_price (the same fallback the checkout uses). */
function rowPrice(row) {
	const unit = row.unit_price ?? row.courts?.hourly_rate ?? 0;
	return Math.max(0, Number(unit) - Number(row.discount_amount ?? 0));
}
function sessionPrice(session) {
	return session.items.reduce((sum, r) => sum + rowPrice(r), 0);
}
function indexTransactions(txs) {
	const map = /* @__PURE__ */ new Map();
	for (const t of txs) {
		const list = map.get(t.booking_id);
		if (list) list.push(t);
		else map.set(t.booking_id, [t]);
	}
	return map;
}
var sumTx = (list, status) => (list ?? []).reduce((sum, t) => t.status === status ? sum + Number(t.amount || 0) : sum, 0);
/** Money that actually reached the venue for this session. */
function sessionPaid(session, idx) {
	return session.ids.reduce((sum, id) => sum + sumTx(idx.get(id), "paid"), 0);
}
/** Money returned to the player for this session. */
function sessionRefunded(session, idx) {
	return session.ids.reduce((sum, id) => sum + sumTx(idx.get(id), "refunded"), 0);
}
/** Still owed. Never negative: a partial refund or a rounded transaction can land
*  fractionally above the price, and showing "-₱0.50 due" would be worse than
*  showing nothing owed. */
function sessionBalance(session, idx) {
	return Math.max(0, sessionPrice(session) - sessionPaid(session, idx));
}
/** The payment method the player actually used, if any transaction records one. */
function sessionMethod(session, idx) {
	for (const id of session.ids) {
		const hit = (idx.get(id) ?? []).find((t) => t.method && (t.status === "paid" || t.status === "refunded"));
		if (hit?.method) return hit.method;
	}
	return null;
}
/** Attribute a cancellation.
*
*  `staff_cancel_bookings` stamps `cancelled_by` with the staff member's uid, and the
*  player's own cancel stamps their own. Rows cancelled by the expiry jobs leave it
*  NULL and explain themselves in `cancel_reason` — those are the ones that must not
*  be blamed on anybody. The reason-text check also rescues player cancellations made
*  before `cancelled_by` was written on that path. */
function classifyCancellation(row, userId) {
	if (row.status === "expired") return "expired";
	if (row.cancelled_by) return row.cancelled_by === userId ? "player" : "venue";
	const reason = (row.cancel_reason ?? "").toLowerCase();
	if (reason.includes("cancelled by player")) return "player";
	if (reason.includes("expired")) return "expired";
	return "expired";
}
function sessionState(session, nowMs) {
	const r = session.first;
	if (r.status === "expired") return "expired";
	if (r.status === "cancelled") return "cancelled";
	return new Date(session.end_time).getTime() < nowMs ? "completed" : "upcoming";
}
/** Inclusive start of a period, or null for "all time". Uses local calendar
*  boundaries so "this month" means what the player's calendar says. */
function periodStart(period, now) {
	const d = new Date(now);
	d.setHours(0, 0, 0, 0);
	switch (period) {
		case "month":
			d.setDate(1);
			return d;
		case "last_month":
			d.setDate(1);
			d.setMonth(d.getMonth() - 1);
			return d;
		case "3months":
			d.setDate(1);
			d.setMonth(d.getMonth() - 2);
			return d;
		case "year":
			d.setMonth(0, 1);
			return d;
		case "all": return null;
	}
}
/** Exclusive end. Only "last month" ends before now. */
function periodEnd(period, now) {
	if (period !== "last_month") return null;
	const d = new Date(now);
	d.setHours(0, 0, 0, 0);
	d.setDate(1);
	return d;
}
function inWindow(iso, start, end) {
	const t = new Date(iso).getTime();
	if (start && t < start.getTime()) return false;
	if (end && t >= end.getTime()) return false;
	return true;
}
/** Local calendar day, YYYY-MM-DD. en-CA because it sorts and compares as a string;
*  the raw ISO would bucket by UTC and push a 9pm Manila booking to the next day. */
var dayKey = (iso) => (typeof iso === "string" ? new Date(iso) : iso).toLocaleDateString("en-CA");
var monthKey = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
var BANDS = [
	{
		label: "Morning",
		range: "5 AM – 11 AM",
		from: 5,
		to: 11
	},
	{
		label: "Midday",
		range: "11 AM – 3 PM",
		from: 11,
		to: 15
	},
	{
		label: "Evening",
		range: "3 PM – 8 PM",
		from: 15,
		to: 20
	},
	{
		label: "Late",
		range: "8 PM – 5 AM",
		from: 20,
		to: 29
	}
];
function bandFor(hour) {
	const h = hour < 5 ? hour + 24 : hour;
	return BANDS.find((b) => h >= b.from && h < b.to) ?? BANDS[3];
}
function byPopularity(a, b) {
	return b.bookings - a.bookings || b.hours - a.hours || b.amount - a.amount || a.label.localeCompare(b.label);
}
function bump(map, key, label, sublabel, amount, hours) {
	const cur = map.get(key) ?? {
		key,
		label,
		sublabel,
		amount: 0,
		bookings: 0,
		hours: 0
	};
	cur.amount += amount;
	cur.bookings += 1;
	cur.hours += hours;
	map.set(key, cur);
}
function buildPlayerStats({ rows, transactions, userId, now = /* @__PURE__ */ new Date(), period = "all" }) {
	const nowMs = now.getTime();
	const idx = indexTransactions(transactions);
	const all = groupBookingSessions(rows).sort((a, b) => b.start_time.localeCompare(a.start_time));
	const start = periodStart(period, now);
	const end = periodEnd(period, now);
	const inPeriod = (s) => inWindow(s.start_time, start, end);
	const upcoming = [];
	const completed = [];
	const cancelled = [];
	let cancelledByPlayer = 0;
	let cancelledByVenue = 0;
	let expired = 0;
	for (const s of all) {
		const state = sessionState(s, nowMs);
		if (state === "upcoming") {
			upcoming.push(s);
			continue;
		}
		if (!inPeriod(s)) continue;
		if (state === "completed") {
			completed.push(s);
			continue;
		}
		cancelled.push(s);
		const who = classifyCancellation(s.first, userId);
		if (who === "player") cancelledByPlayer += 1;
		else if (who === "venue") cancelledByVenue += 1;
		else expired += 1;
	}
	upcoming.sort((a, b) => a.start_time.localeCompare(b.start_time));
	const hoursPlayed = completed.reduce((sum, s) => sum + s.hours, 0);
	const sessionsPlayed = completed.length;
	const byVenue = /* @__PURE__ */ new Map();
	const byCourt = /* @__PURE__ */ new Map();
	const bySport = /* @__PURE__ */ new Map();
	let total = 0;
	let refunded = 0;
	let pendingRefund = 0;
	let outstanding = 0;
	const spendSessions = all.filter((s) => sessionState(s, nowMs) !== "upcoming" && inPeriod(s));
	for (const s of spendSessions) {
		const paid = sessionPaid(s, idx);
		const back = sessionRefunded(s, idx);
		total += paid;
		refunded += back;
		if (s.first.refund_status === "pending") pendingRefund += paid;
		const c = s.first.courts;
		if (paid > 0) {
			const venueName = c?.venues?.name ?? "Unknown venue";
			bump(byVenue, String(c?.venues?.id ?? venueName), venueName, c?.venues?.address ?? void 0, paid, s.hours);
			bump(byCourt, String(s.first.court_id), c?.name ?? `Court #${s.first.court_id}`, venueName, paid, s.hours);
			const sport = c?.sports?.name;
			if (sport) bump(bySport, sport, sport, void 0, paid, s.hours);
		}
	}
	for (const s of upcoming) outstanding += sessionBalance(s, idx);
	const spendByMonth = /* @__PURE__ */ new Map();
	for (const t of transactions) {
		if (t.status !== "paid") continue;
		const d = new Date(t.paid_at ?? t.created_at);
		spendByMonth.set(monthKey(d), (spendByMonth.get(monthKey(d)) ?? 0) + Number(t.amount || 0));
	}
	const anchor = new Date(now);
	anchor.setDate(1);
	const months = Array.from({ length: 6 }, (_, i) => {
		const d = new Date(anchor);
		d.setMonth(d.getMonth() - (5 - i));
		return {
			key: monthKey(d),
			label: d.toLocaleDateString("en-PH", { month: "short" }),
			amount: spendByMonth.get(monthKey(d)) ?? 0
		};
	});
	let thisPeriod = 0;
	let prevPeriod = 0;
	if (start) {
		const span = (end ?? now).getTime() - start.getTime();
		const prevStart = new Date(start.getTime() - span);
		for (const t of transactions) {
			if (t.status !== "paid") continue;
			const when = t.paid_at ?? t.created_at;
			if (inWindow(when, start, end)) thisPeriod += Number(t.amount || 0);
			else if (inWindow(when, prevStart, start)) prevPeriod += Number(t.amount || 0);
		}
	} else thisPeriod = total;
	const delta = start && prevPeriod > 0 ? (thisPeriod - prevPeriod) / prevPeriod * 100 : null;
	const bandCount = /* @__PURE__ */ new Map();
	const byWeekday = Array.from({ length: 7 }, () => 0);
	for (const s of completed) {
		const d = new Date(s.start_time);
		byWeekday[d.getDay()] += 1;
		const band = bandFor(d.getHours());
		bandCount.set(band.label, (bandCount.get(band.label) ?? 0) + 1);
	}
	const topBandEntry = Array.from(bandCount).sort((a, b) => b[1] - a[1])[0];
	const usualTime = topBandEntry ? {
		label: topBandEntry[0],
		range: BANDS.find((b) => b.label === topBandEntry[0]).range,
		count: topBandEntry[1]
	} : null;
	const sportSessions = /* @__PURE__ */ new Map();
	for (const s of completed) {
		const name = s.first.courts?.sports?.name;
		if (!name) continue;
		bump(sportSessions, name, name, void 0, sessionPaid(s, idx), s.hours);
	}
	const sportTotal = Array.from(sportSessions.values()).reduce((sum, x) => sum + x.bookings, 0);
	const sports = Array.from(sportSessions.values()).map((x) => ({
		...x,
		share: sportTotal ? x.bookings / sportTotal * 100 : 0
	})).sort(byPopularity);
	const rank = (m) => Array.from(m.values()).sort(byPopularity);
	const venuesRanked = rank(byVenue);
	const courtsRanked = rank(byCourt);
	const venueVisits = /* @__PURE__ */ new Map();
	const courtVisits = /* @__PURE__ */ new Map();
	for (const s of completed) {
		const c = s.first.courts;
		const venueName = c?.venues?.name ?? "Unknown venue";
		bump(venueVisits, String(c?.venues?.id ?? venueName), venueName, c?.venues?.address ?? void 0, sessionPaid(s, idx), s.hours);
		bump(courtVisits, String(s.first.court_id), c?.name ?? `Court #${s.first.court_id}`, venueName, sessionPaid(s, idx), s.hours);
	}
	return {
		sessions: all,
		upcoming,
		completed,
		cancelled,
		next: upcoming[0] ?? null,
		counts: {
			upcoming: upcoming.length,
			completed: completed.length,
			cancelled: cancelled.length,
			cancelledByPlayer,
			cancelledByVenue,
			expired
		},
		hoursPlayed,
		sessionsPlayed,
		avgSessionHours: sessionsPlayed ? hoursPlayed / sessionsPlayed : 0,
		avgPerBooking: sessionsPlayed ? total / sessionsPlayed : 0,
		spend: {
			total,
			refunded,
			pendingRefund,
			outstanding,
			byVenue: venuesRanked.sort((a, b) => b.amount - a.amount),
			byCourt: courtsRanked.sort((a, b) => b.amount - a.amount),
			bySport: Array.from(bySport.values()).sort((a, b) => b.amount - a.amount),
			months,
			thisPeriod,
			prevPeriod,
			delta,
			deltaAmount: thisPeriod - prevPeriod
		},
		sports,
		topSport: sports[0] ?? null,
		topVenue: rank(venueVisits)[0] ?? null,
		topCourt: rank(courtVisits)[0] ?? null,
		usualTime,
		byWeekday,
		hasAnyBooking: all.length > 0,
		hasHistory: sessionsPlayed > 0
	};
}
var peso = (n) => `₱${n.toLocaleString("en-PH", {
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
})}`;
/** Tiles have room for four digits. ₱18,450.00 wraps a 320px tile; ₱18.4k does not. */
var pesoShort = (n) => n >= 1e6 ? `₱${(n / 1e6).toFixed(1)}M` : n >= 1e4 ? `₱${(n / 1e3).toFixed(1)}k` : `₱${Math.round(n).toLocaleString("en-PH")}`;
/** "1h 55m" — the spec's average-session format. */
function humanHours(hours) {
	if (!hours) return "0h";
	const h = Math.floor(hours);
	const m = Math.round((hours - h) * 60);
	if (!h) return `${m}m`;
	return m ? `${h}h ${m}m` : `${h}h`;
}
/** "Today at 6:00 PM" / "Tomorrow" / "In 3 days" — calendar-day based, so a booking
*  at 1 AM tomorrow reads "Tomorrow" rather than "in 4 hours". */
function countdownLabel(startIso, now = /* @__PURE__ */ new Date()) {
	const start = new Date(startIso);
	const diffMs = start.getTime() - now.getTime();
	const time = start.toLocaleTimeString("en-PH", {
		hour: "numeric",
		minute: "2-digit"
	});
	if (diffMs <= 0) return "Happening now";
	const startOfToday = new Date(now);
	startOfToday.setHours(0, 0, 0, 0);
	const days = Math.round((new Date(start).setHours(0, 0, 0, 0) - startOfToday.getTime()) / 864e5);
	if (days === 0) {
		const mins = Math.round(diffMs / 6e4);
		if (mins < 60) return `Starting in ${mins} min`;
		return `Today at ${time}`;
	}
	if (days === 1) return `Tomorrow at ${time}`;
	if (days < 7) return `In ${days} days`;
	if (days < 14) return "Next week";
	return start.toLocaleDateString("en-PH", {
		month: "short",
		day: "numeric"
	});
}
/** Google Maps link for the venue — coordinates when we have them, address otherwise. */
function directionsUrl(court) {
	const v = court?.venues;
	if (!v) return null;
	if (v.latitude != null && v.longitude != null) return `https://www.google.com/maps/dir/?api=1&destination=${v.latitude},${v.longitude}`;
	if (v.address) return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(v.address)}`;
	return null;
}
/** A downloadable .ics for one session. Built inline rather than fetched so it works
*  offline and needs no endpoint. */
function icsForSession(session) {
	const c = session.first.courts;
	const stamp = (iso) => new Date(iso).toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
	const title = `${c?.sports?.name ?? "Court booking"} · ${c?.venues?.name ?? "Venue"}`;
	const location = c?.venues?.address ?? c?.venues?.name ?? "";
	const escape = (s) => s.replace(/([,;\\])/g, "\\$1").replace(/\n/g, "\\n");
	return [
		"BEGIN:VCALENDAR",
		"VERSION:2.0",
		"PRODID:-//CourtHub//Player Booking//EN",
		"BEGIN:VEVENT",
		`UID:booking-${session.first.id}@courthub`,
		`DTSTAMP:${stamp((/* @__PURE__ */ new Date()).toISOString())}`,
		`DTSTART:${stamp(session.start_time)}`,
		`DTEND:${stamp(session.end_time)}`,
		`SUMMARY:${escape(title)}`,
		`DESCRIPTION:${escape(`${c?.name ?? "Court"} · ${session.hours} hour${session.hours > 1 ? "s" : ""}`)}`,
		`LOCATION:${escape(location)}`,
		"END:VEVENT",
		"END:VCALENDAR"
	].join("\r\n");
}
/**
* The player's workspace: next game, schedule, spending, sports and history.
*
* Lifted out of routes/_authenticated/dashboard.tsx, which is already ~6,900 lines and
* costs minutes to transform on a /mnt/c checkout. Every number rendered here comes from
* `@/lib/player-stats`, which is the single source of truth for what a booking cost, what
* was actually paid, and who cancelled it — this file only decides how to show it.
*
* Section order follows what a player opens the page to find out: when am I playing,
* where, what do I owe — then how active have I been, then what did I spend.
*/
var BOOKING_SELECT = "id, court_id, start_time, end_time, status, payment_status, refund_status, cancelled_at, cancelled_by, cancel_reason, unit_price, discount_amount, created_at, courts(name, hourly_rate, map_emoji, images, sports(name), venues(id, name, address, latitude, longitude, is_active))";
var TX_SELECT = "id, booking_id, amount, status, method, paid_at, refunded_at, created_at, provider_ref";
var fmtDate = (iso) => new Date(iso).toLocaleDateString("en-PH", {
	weekday: "short",
	month: "short",
	day: "numeric",
	year: "numeric"
});
var fmtDateShort = (iso) => new Date(iso).toLocaleDateString("en-PH", {
	weekday: "short",
	month: "short",
	day: "numeric"
});
/** Payment state as the player experiences it, not as the column spells it.
*  `refund_status` outranks `payment_status`: once a refund is moving, that is the
*  thing the player is waiting on. */
function PaymentBadge({ paymentStatus, refundStatus }) {
	let label = paymentStatus.replace("_", " ");
	let tone = "bg-secondary text-muted-foreground";
	if (refundStatus === "pending") {
		label = "Refund pending";
		tone = "bg-sky-500/15 text-sky-700 dark:text-sky-300";
	} else if (refundStatus === "refunded" || paymentStatus === "refunded") {
		label = "Refunded";
		tone = "bg-sky-500/15 text-sky-700 dark:text-sky-300";
	} else if (paymentStatus === "paid") {
		label = "Paid";
		tone = "bg-primary/15 text-primary";
	} else if (paymentStatus === "pending" || paymentStatus === "unpaid") {
		label = "Payment pending";
		tone = "bg-amber-500/15 text-amber-700 dark:text-amber-300";
	} else if (paymentStatus === "failed") {
		label = "Payment failed";
		tone = "bg-destructive/10 text-destructive";
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-0.5 text-[11px] font-semibold ${tone}`,
		children: label
	});
}
function StatusBadge({ session, userId }) {
	const r = session.first;
	const state = sessionState(session, Date.now());
	if (state === "cancelled" || state === "expired") {
		const who = classifyCancellation(r, userId);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `rounded-full px-2 py-0.5 text-[11px] font-semibold ${who === "venue" ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" : who === "player" ? "bg-muted text-muted-foreground" : "bg-muted text-muted-foreground"}`,
			children: who === "player" ? "Cancelled by you" : who === "venue" ? "Cancelled by venue" : "Expired"
		});
	}
	if (state === "completed") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-full bg-emerald-500/15 px-2 py-0.5 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300",
		children: "Completed"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-0.5 text-[11px] font-semibold ${r.status === "confirmed" ? "bg-primary/10 text-primary" : "bg-amber-500/15 text-amber-700 dark:text-amber-300"}`,
		children: r.status === "confirmed" ? "Confirmed" : "Awaiting payment"
	});
}
function StatTile({ icon: Icon, label, value, hint, tone = "neutral" }) {
	const rail = tone === "warning" ? "bg-amber-500" : tone === "primary" ? "bg-primary" : "bg-border";
	const chip = tone === "warning" ? "bg-amber-500/15 text-amber-600 dark:text-amber-400" : tone === "primary" ? "bg-primary/12 text-primary" : "bg-secondary text-muted-foreground";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative overflow-hidden rounded-2xl border border-border bg-card p-4 shadow-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": true,
				className: `absolute inset-y-0 left-0 w-1 ${rail}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `grid h-7 w-7 shrink-0 place-items-center rounded-lg ${chip}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-3.5 w-3.5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-cabinet text-2xl font-bold leading-none tracking-tight tabular-nums sm:text-3xl",
				children: value
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 truncate text-[11px] text-muted-foreground",
				children: hint
			})
		]
	});
}
function SectionHead({ title, sub, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-lg font-bold tracking-tight",
			children: title
		}), sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-0.5 text-xs text-muted-foreground",
			children: sub
		})] }), action]
	});
}
/** Horizontal ranked bars. One hue, length carries the value — no legend needed. */
function RankedBars({ rows, total, unit }) {
	if (rows.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-3 text-xs text-muted-foreground",
		children: "Nothing to show yet."
	});
	const peak = Math.max(1, ...rows.map((r) => r.amount));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-3 space-y-3",
		children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-3 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 truncate font-semibold",
					children: r.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 font-display font-bold tabular-nums",
					children: unit === "money" ? peso(r.amount) : r.amount
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1.5 min-w-0 flex-1 overflow-hidden rounded-full bg-secondary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-primary",
						style: { width: `${r.amount / peak * 100}%` }
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "shrink-0 text-[10px] tabular-nums text-muted-foreground",
					children: [
						r.bookings,
						" ",
						r.bookings === 1 ? "booking" : "bookings",
						total > 0 && ` · ${Math.round(r.amount / total * 100)}%`
					]
				})]
			}),
			r.sublabel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 truncate text-[10px] text-muted-foreground",
				children: r.sublabel
			})
		] }, r.key))
	});
}
function BookingCard({ session, idx, userId, highlight, focused, onPay, onCancel, onMessage, actions = true }) {
	const r = session.first;
	const c = r.courts;
	const state = sessionState(session, Date.now());
	const price = sessionPrice(session);
	const paid = sessionPaid(session, idx);
	const refunded = sessionRefunded(session, idx);
	const balance = sessionBalance(session, idx);
	const method = sessionMethod(session, idx);
	const venueInactive = c?.venues?.is_active === false;
	const thumb = c?.images?.[0];
	const canPay = state === "upcoming" && r.status === "pending" && balance > 0;
	const canCancel = state === "upcoming";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		id: `booking-${session.first.id}`,
		className: `overflow-hidden rounded-2xl border bg-card shadow-sm transition hover:shadow-md ${focused ? "border-primary ring-2 ring-primary/40" : highlight ? "border-primary/50 ring-1 ring-primary/20" : "border-border"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-start gap-3",
					children: [thumb ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: thumb,
						alt: "",
						loading: "lazy",
						className: "h-14 w-14 shrink-0 rounded-xl object-cover ring-1 ring-border"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-14 w-14 shrink-0 place-items-center rounded-xl bg-primary/10 text-2xl",
						children: c?.map_emoji ?? "🎾"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate font-display text-base font-bold leading-tight",
								children: c?.venues?.name ?? "Venue"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-0.5 truncate text-xs text-muted-foreground",
								children: [
									c?.name,
									c?.sports?.name ? ` · ${c.sports.name}` : "",
									" · ",
									session.hours,
									" hr",
									session.hours > 1 ? "s" : ""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1.5 text-sm font-semibold tabular-nums",
								children: fmtDate(session.start_time)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs tabular-nums text-muted-foreground",
								children: [formatTimeRange(session.start_time, session.end_time), session.ids.length > 1 ? ` · ${session.ids.length} slots` : ""]
							}),
							c?.venues?.address && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 flex items-center gap-1 truncate text-[11px] text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-3 w-3 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate",
									children: c.venues.address
								})]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-end gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-cabinet text-xl font-bold tabular-nums",
							children: peso(price)
						}),
						paid > 0 && paid < price && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] tabular-nums text-muted-foreground",
							children: [
								peso(paid),
								" paid · ",
								peso(balance),
								" due"
							]
						}),
						refunded > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] font-semibold tabular-nums text-sky-700 dark:text-sky-300",
							children: [peso(refunded), " refunded"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-0.5 flex flex-wrap justify-end gap-1.5",
							children: [
								venueInactive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-destructive/15 px-2 py-0.5 text-[11px] font-semibold text-destructive ring-1 ring-destructive/30",
									children: "Venue inactive"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
									session,
									userId
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentBadge, {
									paymentStatus: r.payment_status,
									refundStatus: r.refund_status
								})
							]
						}),
						method && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[10px] uppercase tracking-wider text-muted-foreground",
							children: ["via ", method.replace("_", " ")]
						})
					]
				})]
			}),
			r.cancel_reason && state !== "upcoming" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-4 mb-3 rounded-lg bg-secondary/60 px-3 py-2 text-[11px] text-muted-foreground",
				children: r.cancel_reason
			}),
			actions && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap justify-end gap-2 border-t border-border bg-secondary/30 px-4 py-3",
				children: [
					c?.venues?.id && onMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => onMessage(session),
						className: "rounded-lg border border-border bg-background px-3 py-1.5 text-xs font-semibold transition hover:border-primary hover:text-primary",
						children: "Message venue"
					}),
					state !== "upcoming" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/courts/$courtId",
						params: { courtId: String(r.court_id) },
						className: "inline-flex items-center gap-1 rounded-lg border border-border bg-background px-3 py-1.5 text-xs font-semibold transition hover:border-primary hover:text-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-3 w-3" }), " Book again"]
					}),
					canPay && onPay && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => onPay(session),
						disabled: venueInactive,
						title: venueInactive ? "Venue is inactive — payment disabled" : void 0,
						className: "rounded-lg bg-primary px-3 py-1.5 text-xs font-bold text-primary-foreground transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50",
						children: ["Pay ", peso(balance)]
					}),
					canCancel && onCancel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => onCancel(session),
						className: "rounded-lg border border-destructive/40 px-3 py-1.5 text-xs font-semibold text-destructive transition hover:bg-destructive/10",
						children: "Cancel"
					})
				]
			})
		]
	});
}
function NextGame({ session, idx, onPay, onCancel }) {
	const r = session.first;
	const c = r.courts;
	const balance = sessionBalance(session, idx);
	const paid = sessionPaid(session, idx);
	const directions = directionsUrl(c);
	const [, setTick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => setTick((n) => n + 1), 6e4);
		return () => clearInterval(id);
	}, []);
	const addToCalendar = () => {
		const blob = new Blob([icsForSession(session)], { type: "text/calendar;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `booking-${r.id}.ics`;
		a.click();
		URL.revokeObjectURL(url);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden rounded-3xl border-2 border-[#b8f05a]/30 bg-linear-to-br from-[#0f4a40] via-[#0c3a33] to-[#09231f] text-white shadow-lg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"aria-hidden": true,
			className: "pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full opacity-[0.08]",
			style: { background: "radial-gradient(circle, #b8f05a 0%, transparent 65%)" }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative p-5 sm:p-7",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-bold uppercase tracking-[0.18em] text-[#b8f05a]",
								children: "Next game"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-cabinet text-3xl font-bold leading-tight tracking-tight sm:text-4xl",
								children: countdownLabel(session.start_time)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1.5 text-sm text-white/70 tabular-nums",
								children: [
									fmtDate(session.start_time),
									" ·",
									" ",
									formatTimeRange(session.start_time, session.end_time),
									" · ",
									session.hours,
									" hr",
									session.hours > 1 ? "s" : ""
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
							session,
							userId: r.cancelled_by ?? ""
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentBadge, {
							paymentStatus: r.payment_status,
							refundStatus: r.refund_status
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-wrap items-start gap-4 border-t border-white/10 pt-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/10 text-2xl",
							children: c?.map_emoji ?? "🎾"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg font-bold leading-tight",
									children: c?.venues?.name ?? "Venue"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-0.5 text-sm text-white/70",
									children: [c?.name, c?.sports?.name ? ` · ${c.sports.name}` : ""]
								}),
								c?.venues?.address && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 flex items-start gap-1 text-xs text-white/55",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-3 w-3 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.venues.address })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-cabinet text-2xl font-bold tabular-nums",
								children: peso(sessionPrice(session))
							}), balance > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs font-semibold text-amber-300 tabular-nums",
								children: [peso(balance), " due"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-white/55 tabular-nums",
								children: [peso(paid), " paid"]
							})]
						})
					]
				}),
				balance > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 rounded-xl bg-amber-400/15 px-3 py-2 text-xs font-semibold text-amber-200",
					children: "Your slot is only reserved once payment clears."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-wrap gap-2",
					children: [
						balance > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => onPay(session),
							disabled: c?.venues?.is_active === false,
							className: "rounded-full bg-[#b8f05a] px-4 py-2 text-sm font-bold text-[#102521] transition hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-50",
							children: ["Pay ", peso(balance)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/venues/$venueId",
							params: { venueId: String(c?.venues?.id ?? "") },
							className: "rounded-full border border-white/25 px-4 py-2 text-sm font-semibold text-white/85 transition hover:border-[#b8f05a]/60 hover:text-white",
							children: "View venue"
						}),
						directions && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: directions,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "inline-flex items-center gap-1.5 rounded-full border border-white/25 px-4 py-2 text-sm font-semibold text-white/85 transition hover:border-[#b8f05a]/60 hover:text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "h-3.5 w-3.5" }), " Directions"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: addToCalendar,
							className: "inline-flex items-center gap-1.5 rounded-full border border-white/25 px-4 py-2 text-sm font-semibold text-white/85 transition hover:border-[#b8f05a]/60 hover:text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarPlus, { className: "h-3.5 w-3.5" }), " Add to calendar"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => onCancel(session),
							className: "rounded-full border border-red-400/40 px-4 py-2 text-sm font-semibold text-red-300 transition hover:bg-red-500/15",
							children: "Cancel"
						})
					]
				})
			]
		})]
	});
}
function UpcomingSection({ sessions, idx, userId, focusBookingId, onPay, onCancel, onMessage }) {
	const [when, setWhen] = (0, import_react.useState)("all");
	const [sport, setSport] = (0, import_react.useState)("all");
	const [venue, setVenue] = (0, import_react.useState)("all");
	const sports = (0, import_react.useMemo)(() => Array.from(new Set(sessions.map((s) => s.first.courts?.sports?.name).filter(Boolean))).sort(), [sessions]);
	const venues = (0, import_react.useMemo)(() => Array.from(new Set(sessions.map((s) => s.first.courts?.venues?.name).filter(Boolean))).sort(), [sessions]);
	const shown = (0, import_react.useMemo)(() => {
		const now = /* @__PURE__ */ new Date();
		const today = dayKey(now);
		const endOfWeek = new Date(now);
		endOfWeek.setDate(endOfWeek.getDate() + (7 - endOfWeek.getDay()));
		const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
		return sessions.filter((s) => {
			const start = new Date(s.start_time);
			if (when === "today" && dayKey(start) !== today) return false;
			if (when === "week" && start > endOfWeek) return false;
			if (when === "month" && start > endOfMonth) return false;
			if (sport !== "all" && s.first.courts?.sports?.name !== sport) return false;
			if (venue !== "all" && s.first.courts?.venues?.name !== venue) return false;
			return true;
		});
	}, [
		sessions,
		when,
		sport,
		venue
	]);
	const chip = (active) => `rounded-full px-3 py-1.5 text-xs font-bold transition ${active ? "bg-primary text-primary-foreground" : "border border-border bg-card text-muted-foreground hover:border-primary/50 hover:text-foreground"}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				title: "Upcoming",
				sub: `${sessions.length} booking${sessions.length === 1 ? "" : "s"} ahead`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/dashboard",
					search: { view: "calendar" },
					className: "inline-flex items-center gap-1 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-bold transition hover:border-primary hover:text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "h-3.5 w-3.5" }), " Calendar view"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nice-scroll mt-3 flex gap-2 overflow-x-auto pb-1",
				children: [
					[
						["all", "All"],
						["today", "Today"],
						["week", "This week"],
						["month", "This month"]
					].map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setWhen(k),
						className: `shrink-0 ${chip(when === k)}`,
						children: l
					}, k)),
					sports.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: sport,
						onChange: (e) => setSport(e.target.value),
						"aria-label": "Filter by sport",
						className: "shrink-0 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-bold outline-none transition focus:border-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All sports"
						}), sports.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))]
					}),
					venues.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: venue,
						onChange: (e) => setVenue(e.target.value),
						"aria-label": "Filter by venue",
						className: "shrink-0 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-bold outline-none transition focus:border-primary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All venues"
						}), venues.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: v,
							children: v
						}, v))]
					})
				]
			}),
			shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-2xl border border-dashed border-border p-8 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm font-bold",
					children: "Nothing in this range"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: "Try a wider filter, or book a court."
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid gap-3",
				children: shown.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingCard, {
					session: s,
					idx,
					userId,
					highlight: i === 0 && when === "all" && sport === "all" && venue === "all",
					focused: !!focusBookingId && s.ids.includes(focusBookingId),
					onPay,
					onCancel,
					onMessage
				}, s.key))
			})
		]
	});
}
function SpendingSection({ stats, periodLabel }) {
	const { spend } = stats;
	const peak = Math.max(1, ...spend.months.map((m) => m.amount));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			title: "Your spending",
			sub: `Court bookings · ${periodLabel.toLowerCase()}`
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 grid gap-3 lg:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-5 lg:col-span-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground",
								children: "Total spent"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-4 w-4" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-cabinet text-3xl font-bold tabular-nums",
							children: peso(spend.thisPeriod)
						}),
						spend.delta !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1.5 flex flex-wrap items-center gap-1.5 text-[11px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `inline-flex items-center gap-0.5 rounded-full px-1.5 py-0.5 font-bold tabular-nums ${spend.deltaAmount > 0 ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" : "bg-primary/15 text-primary"}`,
								children: [
									spend.deltaAmount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-3 w-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "h-3 w-3" }),
									Math.abs(Math.round(spend.delta)),
									"%"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: [
									spend.deltaAmount > 0 ? "more" : "less",
									" than the period before (",
									peso(Math.abs(spend.deltaAmount)),
									")"
								]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 text-[11px] text-muted-foreground",
							children: "No earlier period to compare against."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex h-20 items-end gap-1.5 border-t border-border pt-4",
							children: spend.months.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group flex flex-1 flex-col items-center gap-1.5",
								title: `${m.label}: ${peso(m.amount)}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex w-full flex-1 items-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `w-full rounded-t-md transition-all ${i === 5 ? "bg-primary" : "bg-primary/35 group-hover:bg-primary/60"}`,
										style: { height: `${Math.max(m.amount > 0 ? 8 : 3, m.amount / peak * 100)}%` }
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `text-[9px] font-semibold uppercase ${i === 5 ? "text-foreground" : "text-muted-foreground"}`,
									children: m.label
								})]
							}, m.key))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 text-[10px] text-muted-foreground",
							children: "Last 6 months, regardless of the filter above."
						}),
						(spend.refunded > 0 || spend.pendingRefund > 0 || spend.outstanding > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 space-y-1.5 border-t border-border pt-3 text-[11px]",
							children: [
								spend.outstanding > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted-foreground",
										children: "Still to pay"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-bold tabular-nums text-amber-700 dark:text-amber-300",
										children: peso(spend.outstanding)
									})]
								}),
								spend.refunded > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted-foreground",
										children: "Refunded to you"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-bold tabular-nums text-sky-700 dark:text-sky-300",
										children: peso(spend.refunded)
									})]
								}),
								spend.pendingRefund > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted-foreground",
										children: "Refund pending"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-bold tabular-nums text-sky-700 dark:text-sky-300",
										children: peso(spend.pendingRefund)
									})]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-sm font-bold",
								children: "Where it goes"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-[11px] text-muted-foreground",
							children: "By venue"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankedBars, {
							rows: spend.byVenue.slice(0, 5),
							total: spend.total,
							unit: "money"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-sm font-bold",
								children: "By sport"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "h-4 w-4" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-[11px] text-muted-foreground",
							children: "What you spend it playing"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankedBars, {
							rows: spend.bySport.slice(0, 5),
							total: spend.total,
							unit: "money"
						}),
						spend.byCourt.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 border-t border-border pt-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold uppercase tracking-wider text-muted-foreground",
									children: "Top court"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 truncate font-display text-sm font-bold",
									children: spend.byCourt[0].label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-[11px] tabular-nums text-muted-foreground",
									children: [
										spend.byCourt[0].sublabel,
										" · ",
										peso(spend.byCourt[0].amount)
									]
								})
							]
						})
					]
				})
			]
		})]
	});
}
function SportsSection({ stats }) {
	const { sports, topSport, topVenue, topCourt, usualTime, avgSessionHours, avgPerBooking } = stats;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			title: "Your sports",
			sub: "Worked out from the games you actually played"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 grid gap-3 lg:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground",
						children: "Your #1 sport"
					}), topSport ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-cabinet text-2xl font-bold leading-none",
							children: topSport.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1.5 text-xs text-muted-foreground tabular-nums",
							children: [
								Math.round(topSport.share),
								"% of your games · ",
								topSport.bookings,
								" session",
								topSport.bookings > 1 ? "s" : "",
								" · ",
								topSport.hours,
								" hr",
								topSport.hours > 1 ? "s" : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-2.5 border-t border-border pt-3",
							children: sports.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate font-semibold",
									children: s.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "shrink-0 tabular-nums text-muted-foreground",
									children: [
										s.bookings,
										" · ",
										s.hours,
										" hr",
										s.hours > 1 ? "s" : ""
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 h-1.5 overflow-hidden rounded-full bg-secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-primary",
									style: { width: `${s.share}%` }
								})
							})] }, s.key))
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted-foreground",
						children: "Play a game and your sports will show up here."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground",
						children: "Your home court"
					}), topVenue ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 truncate font-cabinet text-xl font-bold leading-tight",
							children: topVenue.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs tabular-nums text-muted-foreground",
							children: [
								topVenue.bookings,
								" booking",
								topVenue.bookings > 1 ? "s" : "",
								" · ",
								topVenue.hours,
								" hr",
								topVenue.hours > 1 ? "s" : "",
								" · ",
								peso(topVenue.amount),
								" spent"
							]
						}),
						topCourt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 border-t border-border pt-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold uppercase tracking-wider text-muted-foreground",
									children: "Most-used court"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 truncate font-display text-sm font-bold",
									children: topCourt.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-[11px] tabular-nums text-muted-foreground",
									children: [
										topCourt.sublabel,
										" · ",
										topCourt.bookings,
										" booking",
										topCourt.bookings > 1 ? "s" : ""
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/courts/$courtId",
									params: { courtId: topCourt.key },
									className: "mt-3 inline-flex items-center gap-1 rounded-full bg-primary px-3.5 py-1.5 text-xs font-bold text-primary-foreground transition hover:opacity-90",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-3 w-3" }), " Book again"]
								})
							]
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted-foreground",
						children: "Once you have played somewhere, it will show here."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground",
							children: "Your habits"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 space-y-2.5 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted-foreground",
										children: "Usual playing time"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-display font-bold",
										children: usualTime ? usualTime.label : "—"
									})]
								}),
								usualTime && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted-foreground",
										children: "Typically"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-display font-bold tabular-nums",
										children: usualTime.range
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted-foreground",
										children: "Average session"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-display font-bold tabular-nums",
										children: humanHours(avgSessionHours)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted-foreground",
										children: "Average booking"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "font-display font-bold tabular-nums",
										children: peso(avgPerBooking)
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 border-t border-border pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-wider text-muted-foreground",
								children: "Days you play"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex h-14 items-end gap-1",
								children: [
									"S",
									"M",
									"T",
									"W",
									"T",
									"F",
									"S"
								].map((d, i) => {
									const peak = Math.max(1, ...stats.byWeekday);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "group flex flex-1 flex-col items-center gap-1",
										title: `${stats.byWeekday[i]} game${stats.byWeekday[i] === 1 ? "" : "s"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex w-full flex-1 items-end",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: `w-full rounded-t-md transition-all ${stats.byWeekday[i] === peak && peak > 0 ? "bg-primary" : "bg-primary/30 group-hover:bg-primary/50"}`,
												style: { height: `${Math.max(stats.byWeekday[i] > 0 ? 12 : 5, stats.byWeekday[i] / peak * 100)}%` }
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[9px] font-bold text-muted-foreground",
											children: d
										})]
									}, i);
								})
							})]
						})
					]
				})
			]
		})]
	});
}
function CancellationSummary({ stats, periodLabel }) {
	const { counts, spend } = stats;
	if (counts.cancelled === 0) return null;
	const rate = counts.completed + counts.cancelled > 0 ? counts.cancelled / (counts.completed + counts.cancelled) * 100 : 0;
	const ownRate = counts.completed + counts.cancelledByPlayer > 0 ? counts.cancelledByPlayer / (counts.completed + counts.cancelledByPlayer) * 100 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				title: "Cancellations",
				sub: periodLabel.toLowerCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground",
								children: "Cancelled"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-cabinet text-3xl font-bold tabular-nums",
								children: counts.cancelled
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-[11px] tabular-nums text-muted-foreground",
								children: [Math.round(rate), "% of your bookings"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground",
								children: "By you"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-cabinet text-3xl font-bold tabular-nums",
								children: counts.cancelledByPlayer
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-[11px] tabular-nums text-muted-foreground",
								children: [Math.round(ownRate), "% own cancellation rate"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground",
								children: "By the venue"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-cabinet text-3xl font-bold tabular-nums",
								children: counts.cancelledByVenue
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[11px] text-muted-foreground",
								children: "Not counted against you"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-[0.12em] text-muted-foreground",
								children: "Refunds"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-cabinet text-3xl font-bold tabular-nums",
								children: pesoShort(spend.refunded)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[11px] tabular-nums text-muted-foreground",
								children: spend.pendingRefund > 0 ? `${peso(spend.pendingRefund)} still pending` : "All settled"
							})
						]
					})
				]
			}),
			counts.expired > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-[11px] text-muted-foreground",
				children: [
					counts.expired,
					" unpaid hold",
					counts.expired > 1 ? "s" : "",
					" expired before payment — these are not cancellations."
				]
			})
		]
	});
}
function Insights({ stats, periodLabel }) {
	const lines = [];
	const { topSport, topVenue, usualTime, spend, sessionsPlayed, hoursPlayed } = stats;
	if (topSport && topSport.bookings > 1) lines.push(`You played ${topSport.label} ${topSport.bookings} times ${periodLabel.toLowerCase()} — ${Math.round(topSport.share)}% of your games.`);
	if (topVenue && topVenue.bookings > 1) lines.push(`${topVenue.label} is your most visited venue, with ${topVenue.bookings} bookings.`);
	if (spend.delta !== null && Math.abs(spend.deltaAmount) >= 1) lines.push(spend.deltaAmount < 0 ? `You spent ${peso(Math.abs(spend.deltaAmount))} less than the period before.` : `You spent ${peso(spend.deltaAmount)} more than the period before.`);
	if (usualTime && usualTime.count > 1) lines.push(`Your usual playing time is ${usualTime.range.toLowerCase()}.`);
	if (hoursPlayed > 0) lines.push(`You have played ${humanHours(hoursPlayed)} across ${sessionsPlayed} session${sessionsPlayed > 1 ? "s" : ""}.`);
	if (spend.outstanding > 0) lines.push(`You have ${peso(spend.outstanding)} still to pay on upcoming bookings.`);
	if (lines.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			title: "Insights",
			sub: "Worked out from your bookings — nothing estimated"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 grid gap-2 sm:grid-cols-2",
			children: lines.slice(0, 6).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-start gap-2.5 rounded-xl border border-border bg-card p-3 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: l })]
			}, l))
		})]
	});
}
function HistorySection({ stats, idx, userId, focusBookingId, onMessage }) {
	const [tab, setTab] = (0, import_react.useState)("all");
	const [q, setQ] = (0, import_react.useState)("");
	const [limit, setLimit] = (0, import_react.useState)(6);
	const rows = (0, import_react.useMemo)(() => {
		const sorted = (tab === "completed" ? stats.completed : tab === "cancelled" ? stats.cancelled : [...stats.completed, ...stats.cancelled]).slice().sort((a, b) => b.start_time.localeCompare(a.start_time));
		const needle = q.trim().toLowerCase();
		if (!needle) return sorted;
		return sorted.filter((s) => {
			const c = s.first.courts;
			return [
				c?.venues?.name,
				c?.name,
				c?.sports?.name,
				c?.venues?.address,
				fmtDate(s.start_time)
			].filter(Boolean).some((v) => v.toLowerCase().includes(needle));
		});
	}, [
		tab,
		stats.completed,
		stats.cancelled,
		q
	]);
	if (!stats.hasAnyBooking) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				title: "Booking history",
				sub: "Everything that already happened"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 rounded-full border border-border bg-card p-1",
					children: [
						["all", "All"],
						["completed", "Completed"],
						["cancelled", "Cancelled"]
					].map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							setTab(k);
							setLimit(6);
						},
						className: `rounded-full px-3 py-1 text-xs font-bold transition ${tab === k ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`,
						children: [l, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 tabular-nums opacity-70",
							children: k === "all" ? stats.completed.length + stats.cancelled.length : k === "completed" ? stats.completed.length : stats.cancelled.length
						})]
					}, k))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative min-w-0 flex-1 sm:max-w-64",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: q,
							onChange: (e) => setQ(e.target.value),
							placeholder: "Search venue, court, sport or date",
							"aria-label": "Search booking history",
							className: "w-full rounded-full border border-border bg-background py-1.5 pl-8 pr-8 text-xs outline-none transition focus:border-primary"
						}),
						q && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setQ(""),
							"aria-label": "Clear search",
							className: "absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5" })
						})
					]
				})]
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-2xl border border-dashed border-border p-8 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm font-bold",
					children: q ? "No match" : "Nothing here yet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: q ? `Nothing in your history matches "${q}".` : "Your completed and cancelled games will appear here."
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid gap-3",
				children: rows.slice(0, limit).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingCard, {
					session: s,
					idx,
					userId,
					onMessage
				}, s.key))
			}), rows.length > limit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => setLimit((n) => n + 10),
				className: "mt-3 w-full rounded-xl border border-border bg-card py-2.5 text-xs font-bold transition hover:border-primary hover:text-primary",
				children: [
					"Show ",
					Math.min(10, rows.length - limit),
					" more · ",
					rows.length - limit,
					" remaining"
				]
			})] })
		]
	});
}
var CAL_MODES = [
	{
		key: "month",
		label: "Month"
	},
	{
		key: "week",
		label: "Week"
	},
	{
		key: "day",
		label: "Day"
	}
];
var WEEKDAY_HEADS = [
	"Sun",
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat"
];
var midnight = (d) => {
	const x = new Date(d);
	x.setHours(0, 0, 0, 0);
	return x;
};
var addDays = (d, n) => {
	const x = new Date(d);
	x.setDate(x.getDate() + n);
	return x;
};
var startOfWeek = (d) => addDays(midnight(d), -midnight(d).getDay());
var startOfMonth = (d) => new Date(d.getFullYear(), d.getMonth(), 1);
/** Hours from that day's midnight. Doing the arithmetic in milliseconds rather than
*  reading `getHours()` is what makes a session ending at midnight land on 24 instead
*  of wrapping to 0 and drawing a block of negative height. */
function dayOffsets(session) {
	const base = midnight(new Date(session.start_time)).getTime();
	const from = (new Date(session.start_time).getTime() - base) / 36e5;
	const to = Math.min(24, (new Date(session.end_time).getTime() - base) / 36e5);
	return {
		from,
		to: to <= from ? Math.min(24, from + 1) : to
	};
}
/** Sports have no slug on the player's booking rows, so the name stands in — the
*  tenant calendar falls back to exactly the same key, which is what keeps one
*  sport the same colour on both calendars. */
var styleOf = (s) => sportStyle(s.first.courts?.sports?.name?.toLowerCase());
var isDeadSession = (s) => s.first.status === "cancelled" || s.first.status === "expired";
/** "7 PM", "7:30 PM" — the minutes only earn their space when they are not zero. */
var chipTime = (iso) => new Date(iso).toLocaleTimeString("en-PH", {
	hour: "numeric",
	minute: "2-digit"
}).replace(":00", "");
/**
* The player's calendar.
*
* Built on the tenant calendar's vocabulary — view pills, ‹ Today ›, sport-coloured
* blocks on an hour grid, a now-line, and a list of the selected day underneath — so
* a player who has seen a venue's calendar already knows how to read this one.
*
* What differs is the axis, because a player's question is different. A venue asks
* "which of my courts is busy", so its columns are courts. A player asks "when am I
* playing", so the columns are days: a month to see the shape of the month, a week
* to see the shape of the week, a day when there is more than one game in it.
*
* The hour window is derived from the bookings on screen rather than fixed at 24
* hours. Nobody books 3 AM, and a grid that devotes two thirds of its height to
* hours no one plays is the reason a day view gets ignored; `Full 24h` is there for
* the rare booking that falls outside the window.
*/
function CalendarView({ rows, idx, userId }) {
	const [mode, setMode] = (0, import_react.useState)("month");
	const [anchor, setAnchor] = (0, import_react.useState)(() => midnight(/* @__PURE__ */ new Date()));
	const [selected, setSelected] = (0, import_react.useState)(() => dayKey(/* @__PURE__ */ new Date()));
	const [showCancelled, setShowCancelled] = (0, import_react.useState)(false);
	const [fullDay, setFullDay] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => setNow(/* @__PURE__ */ new Date()), 6e4);
		return () => clearInterval(id);
	}, []);
	const sessions = (0, import_react.useMemo)(() => groupBookingSessions(rows), [rows]);
	const visible = (0, import_react.useMemo)(() => showCancelled ? sessions : sessions.filter((s) => !isDeadSession(s)), [sessions, showCancelled]);
	const cancelledCount = (0, import_react.useMemo)(() => sessions.filter(isDeadSession).length, [sessions]);
	const byDay = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const s of visible) {
			const k = dayKey(s.start_time);
			const list = m.get(k);
			if (list) list.push(s);
			else m.set(k, [s]);
		}
		for (const list of m.values()) list.sort((a, b) => a.start_time.localeCompare(b.start_time));
		return m;
	}, [visible]);
	const [periodStart, periodEnd] = (0, import_react.useMemo)(() => {
		if (mode === "day") {
			const s = midnight(anchor);
			return [s, addDays(s, 1)];
		}
		if (mode === "week") {
			const s = startOfWeek(anchor);
			return [s, addDays(s, 7)];
		}
		const s = startOfMonth(anchor);
		return [s, new Date(s.getFullYear(), s.getMonth() + 1, 1)];
	}, [mode, anchor]);
	const daysInView = (0, import_react.useMemo)(() => {
		if (mode === "day") return [midnight(anchor)];
		if (mode === "week") {
			const s = startOfWeek(anchor);
			return Array.from({ length: 7 }, (_, i) => addDays(s, i));
		}
		const first = startOfMonth(anchor);
		const gridStart = addDays(first, -first.getDay());
		return Array.from({ length: 42 }, (_, i) => addDays(gridStart, i));
	}, [mode, anchor]);
	const periodSessions = (0, import_react.useMemo)(() => visible.filter((s) => {
		const t = new Date(s.start_time).getTime();
		return t >= periodStart.getTime() && t < periodEnd.getTime();
	}), [
		visible,
		periodStart,
		periodEnd
	]);
	(0, import_react.useEffect)(() => {
		const within = (k) => {
			const t = (/* @__PURE__ */ new Date(`${k}T00:00:00`)).getTime();
			return t >= periodStart.getTime() && t < periodEnd.getTime();
		};
		if (within(selected)) return;
		const todayKey = dayKey(/* @__PURE__ */ new Date());
		if (within(todayKey)) {
			setSelected(todayKey);
			return;
		}
		const booked = daysInView.filter((d) => d >= periodStart && d < periodEnd).map(dayKey).find((k) => (byDay.get(k)?.length ?? 0) > 0);
		setSelected(booked ?? dayKey(periodStart));
	}, [
		selected,
		periodStart,
		periodEnd,
		daysInView,
		byDay
	]);
	const gridSessions = (0, import_react.useMemo)(() => {
		if (mode === "month") return [];
		const keys = new Set(daysInView.map(dayKey));
		return visible.filter((s) => keys.has(dayKey(s.start_time)));
	}, [
		mode,
		daysInView,
		visible
	]);
	const [hourStart, hourEnd] = (0, import_react.useMemo)(() => {
		if (fullDay) return [0, 24];
		let lo = 24;
		let hi = 0;
		for (const s of gridSessions) {
			const { from, to } = dayOffsets(s);
			lo = Math.min(lo, Math.floor(from));
			hi = Math.max(hi, Math.ceil(to));
		}
		if (lo >= hi) return [7, 22];
		return [Math.max(0, lo - 1), Math.min(24, hi + 1)];
	}, [gridSessions, fullDay]);
	const rowH = mode === "day" ? 56 : 44;
	const hours = Math.max(1, hourEnd - hourStart);
	const gridHeight = hours * rowH;
	const todayKey = dayKey(now);
	const nowOffset = now.getHours() + now.getMinutes() / 60;
	const nowVisible = nowOffset >= hourStart && nowOffset <= hourEnd;
	const nudge = (delta) => {
		if (mode === "month") setAnchor((d) => new Date(d.getFullYear(), d.getMonth() + delta, 1));
		else if (mode === "week") setAnchor((d) => addDays(d, delta * 7));
		else setAnchor((d) => addDays(d, delta));
	};
	const goToday = () => {
		const t = midnight(/* @__PURE__ */ new Date());
		setAnchor(t);
		setSelected(dayKey(t));
	};
	const periodLabel = mode === "month" ? periodStart.toLocaleDateString("en-PH", {
		month: "long",
		year: "numeric"
	}) : mode === "week" ? `${periodStart.toLocaleDateString("en-PH", {
		month: "short",
		day: "numeric"
	})} – ${addDays(periodStart, 6).toLocaleDateString("en-PH", {
		month: "short",
		day: "numeric",
		year: "numeric"
	})}` : periodStart.toLocaleDateString("en-PH", {
		weekday: "long",
		month: "long",
		day: "numeric",
		year: "numeric"
	});
	const live = periodSessions.filter((s) => !isDeadSession(s));
	const hoursBooked = live.reduce((n, s) => n + s.hours, 0);
	const due = live.reduce((n, s) => n + sessionBalance(s, idx), 0);
	const dayList = byDay.get(selected) ?? [];
	const selectDay = (d) => {
		setSelected(dayKey(d));
		if (mode === "month" && (d < periodStart || d >= periodEnd)) setAnchor(midnight(d));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground",
						children: "Player workspace"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-cabinet text-2xl font-bold tracking-tight sm:text-3xl",
						children: "Your calendar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							"Every court you have booked, by ",
							mode,
							". Pick a day to see the detail."
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/explore",
					search: {},
					className: "rounded-full bg-primary px-4 py-2 text-sm font-bold text-primary-foreground hover:opacity-90",
					children: "Find a court"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "inline-flex overflow-hidden rounded-full border border-border bg-card",
							children: CAL_MODES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMode(m.key),
								"aria-pressed": mode === m.key,
								className: "px-4 py-1.5 text-xs transition " + (mode === m.key ? "bg-foreground font-semibold text-background" : "font-medium text-muted-foreground hover:bg-secondary"),
								children: m.label
							}, m.key))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => nudge(-1),
									"aria-label": `Previous ${mode}`,
									className: "grid h-8 w-8 place-items-center rounded-full border border-border bg-card hover:bg-secondary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: goToday,
									className: "rounded-full px-4 py-1.5 text-xs font-semibold " + (dayKey(periodStart) <= todayKey && todayKey < dayKey(periodEnd) ? "bg-primary text-primary-foreground" : "border border-border bg-card hover:bg-secondary"),
									children: "Today"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => nudge(1),
									"aria-label": `Next ${mode}`,
									className: "grid h-8 w-8 place-items-center rounded-full border border-border bg-card hover:bg-secondary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold sm:text-base",
							children: periodLabel
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [mode !== "month" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFullDay((v) => !v),
						title: "The grid trims itself to the hours you actually booked",
						className: "rounded-full border border-border bg-card px-3 py-1 text-[11px] font-semibold hover:bg-secondary",
						children: fullDay ? "Full 24h" : "Fitted hours"
					}), cancelledCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setShowCancelled((v) => !v),
						"aria-pressed": showCancelled,
						className: "rounded-full px-3 py-1 text-[11px] font-semibold " + (showCancelled ? "bg-foreground text-background" : "border border-border bg-card hover:bg-secondary"),
						children: [
							"Cancelled (",
							cancelledCount,
							")"
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						icon: CalendarDays,
						label: mode === "month" ? "This month" : mode === "week" ? "This week" : "This day",
						value: String(live.length),
						hint: live.length === 1 ? "session" : "sessions",
						tone: "primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						icon: Timer,
						label: "Court time",
						value: humanHours(hoursBooked),
						hint: "booked in view"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						icon: Wallet,
						label: "Balance due",
						value: peso(due),
						hint: due > 0 ? "still to pay" : "all settled",
						tone: due > 0 ? "warning" : "neutral"
					})
				]
			}),
			mode === "month" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-2xl border border-border bg-card shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-7 border-b border-border bg-secondary/40",
					children: WEEKDAY_HEADS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-2 py-2 text-center text-[10px] font-bold uppercase tracking-wider text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: d
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sm:hidden",
							children: d[0]
						})]
					}, d))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-7",
					children: daysInView.map((d, i) => {
						const k = dayKey(d);
						const list = byDay.get(k) ?? [];
						const outside = d < periodStart || d >= periodEnd;
						const isToday = k === todayKey;
						const isSel = k === selected;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => selectDay(d),
							"aria-pressed": isSel,
							className: "min-h-22 border-border p-1.5 text-left align-top transition sm:min-h-28 sm:p-2 " + (i % 7 === 0 ? "" : "border-l ") + (i >= 7 ? "border-t " : "") + (outside ? "bg-muted/30 " : "") + (isSel ? "bg-primary/10 ring-2 ring-inset ring-primary " : "hover:bg-secondary/60"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-6 w-6 place-items-center rounded-full text-xs font-bold tabular-nums " + (isToday ? "bg-primary text-primary-foreground" : outside ? "text-muted-foreground/60" : "text-foreground"),
										children: d.getDate()
									}), list.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[9px] font-bold text-muted-foreground sm:hidden",
										children: list.length
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 flex flex-wrap gap-0.5 sm:hidden",
									children: list.slice(0, 4).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 w-1.5 rounded-full ${styleOf(s).dot} ${isDeadSession(s) ? "opacity-40" : ""}` }, s.key))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 hidden flex-col gap-0.5 sm:flex",
									children: [list.slice(0, 3).map((s) => {
										const st = styleOf(s);
										const dead = isDeadSession(s);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											title: `${formatSessionLabel(s.start_time, s.end_time)} · ${s.first.courts?.venues?.name ?? "Venue"} · ${s.first.courts?.name ?? ""}`,
											className: `flex items-center gap-1 truncate rounded px-1 py-0.5 text-[10px] font-semibold ${st.bg} ${st.text} ${dead ? "opacity-50 line-through" : ""}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 w-1.5 shrink-0 rounded-full ${st.dot}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "truncate",
												children: [
													chipTime(s.start_time),
													" · ",
													s.first.courts?.name ?? "Court"
												]
											})]
										}, s.key);
									}), list.length > 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "px-1 text-[10px] font-semibold text-muted-foreground",
										children: [
											"+",
											list.length - 3,
											" more"
										]
									})]
								})
							]
						}, k);
					})
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-border bg-card shadow-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nice-scroll max-h-[64vh] overflow-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: mode === "week" ? "min-w-[38rem]" : "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sticky top-0 z-20 flex border-b border-border bg-card/95 backdrop-blur",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sticky left-0 z-30 w-14 shrink-0 bg-card/95" }), daysInView.map((d) => {
								const k = dayKey(d);
								const isToday = k === todayKey;
								const isSel = k === selected;
								const count = (byDay.get(k) ?? []).length;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => selectDay(d),
									className: "flex-1 border-l border-border px-2 py-2 text-center transition " + (isSel ? "bg-primary/10" : "hover:bg-secondary/60"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-[10px] font-bold uppercase tracking-wider text-muted-foreground",
											children: d.toLocaleDateString("en-PH", { weekday: "short" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mx-auto mt-0.5 grid h-6 w-6 place-items-center rounded-full font-cabinet text-sm font-bold tabular-nums " + (isToday ? "bg-primary text-primary-foreground" : ""),
											children: d.getDate()
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-0.5 block text-[9px] font-semibold text-muted-foreground",
											children: count === 0 ? "—" : `${count} booked`
										})
									]
								}, k);
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sticky left-0 z-10 w-14 shrink-0 bg-card",
								style: { height: gridHeight },
								children: Array.from({ length: hours }).map((_, i) => {
									const h = hourStart + i;
									const label = h === 0 ? "12 AM" : h === 12 ? "12 PM" : h > 12 ? `${h - 12} PM` : `${h} AM`;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										style: { height: rowH },
										className: "relative",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `absolute right-2 whitespace-nowrap text-[10px] font-medium leading-none text-muted-foreground ${i === 0 ? "top-0.5" : "top-0 -translate-y-1/2"}`,
											children: label
										})
									}, h);
								})
							}), daysInView.map((d) => {
								const k = dayKey(d);
								const list = byDay.get(k) ?? [];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `relative flex-1 border-l border-border ${k === selected ? "bg-primary/[0.04]" : ""}`,
									style: { height: gridHeight },
									children: [
										Array.from({ length: hours }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											style: {
												top: i * rowH,
												height: rowH
											},
											className: `absolute inset-x-0 border-t ${(hourStart + i) % 6 === 0 ? "border-border" : "border-border/40"}`
										}, i)),
										list.map((s) => {
											const { from, to } = dayOffsets(s);
											const top = Math.max(0, (from - hourStart) * rowH);
											const height = Math.max(20, (Math.min(to, hourEnd) - Math.max(from, hourStart)) * rowH - 3);
											const st = styleOf(s);
											const dead = isDeadSession(s);
											const court = s.first.courts;
											const range = formatTimeRange(s.start_time, s.end_time);
											const roomy = height >= 46;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setSelected(k),
												title: `${range} · ${court?.venues?.name ?? "Venue"} · ${court?.name ?? ""} (${s.hours}h)`,
												style: {
													top,
													height
												},
												className: `absolute inset-x-1 flex flex-col justify-center overflow-hidden rounded-lg border px-1.5 py-0.5 text-left shadow-sm transition hover:brightness-95 ${st.bg} ${st.border} ${st.text} ${dead ? "opacity-50" : ""}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex min-w-0 items-center gap-1 text-[11px] font-bold leading-tight",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 w-1.5 shrink-0 rounded-full ${st.dot}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "truncate",
														children: court?.name ?? "Court"
													})]
												}), roomy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate text-[10px] leading-tight opacity-80",
													children: range
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate text-[10px] leading-tight opacity-70",
													children: court?.venues?.name ?? "Venue"
												})] })]
											}, s.key);
										}),
										k === todayKey && nowVisible && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											"aria-hidden": true,
											className: "pointer-events-none absolute inset-x-0 z-10 border-t-2 border-primary",
											style: { top: (nowOffset - hourStart) * rowH },
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -left-0.5 -top-1 h-2 w-2 rounded-full bg-primary" })
										})
									]
								}, k);
							})]
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "font-display text-base font-bold",
						children: [(/* @__PURE__ */ new Date(`${selected}T00:00:00`)).toLocaleDateString("en-PH", {
							weekday: "long",
							month: "long",
							day: "numeric"
						}), selected === todayKey && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 rounded-full bg-primary/12 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary",
							children: "Today"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-full bg-secondary px-2.5 py-0.5 text-xs font-semibold tabular-nums text-muted-foreground",
						children: [
							dayList.length,
							" ",
							dayList.length === 1 ? "booking" : "bookings"
						]
					})]
				}), dayList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-xl border border-dashed border-border py-10 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: "Nothing booked this day"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: "Free to play — find a court and fill it."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/explore",
							search: {},
							className: "mt-4 inline-flex rounded-full bg-primary px-4 py-2 text-xs font-bold text-primary-foreground hover:opacity-90",
							children: "Browse courts"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-border",
					children: dayList.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDayRow, {
						session: s,
						idx,
						userId
					}, s.key))
				})]
			})
		]
	});
}
/** One session on the selected day. The actions are the ones that only make sense
*  from a calendar — get me there, put it in my phone — plus a way back to the
*  booking card in My Bookings, where paying, messaging and cancelling live. */
function CalendarDayRow({ session, idx, userId }) {
	const court = session.first.courts;
	const st = styleOf(session);
	const dead = isDeadSession(session);
	const balance = sessionBalance(session, idx);
	const directions = directionsUrl(court);
	const addToCalendar = () => {
		const blob = new Blob([icsForSession(session)], { type: "text/calendar;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `booking-${session.first.id}.ics`;
		a.click();
		URL.revokeObjectURL(url);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: `flex flex-wrap items-center justify-between gap-3 py-3 ${dead ? "opacity-60" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 items-start gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${st.dot}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-bold tabular-nums",
					children: [formatSessionLabel(session.start_time, session.end_time), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-2 text-xs font-medium text-muted-foreground",
						children: [session.hours, "h"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-0.5 truncate text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-foreground",
							children: court?.venues?.name ?? "Venue"
						}),
						" · ",
						court?.map_emoji ?? "🏟️",
						" ",
						court?.name ?? "Court",
						court?.sports?.name ? ` · ${court.sports.name}` : ""
					]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, {
					session,
					userId
				}),
				balance > 0 && !dead && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "rounded-full bg-amber-500/15 px-2 py-0.5 text-[11px] font-semibold text-amber-700 dark:text-amber-300",
					children: [peso(balance), " due"]
				}),
				!dead && directions && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: directions,
					target: "_blank",
					rel: "noreferrer",
					title: "Directions",
					className: "inline-flex items-center gap-1 rounded-lg border border-border px-2 py-1 text-[11px] font-semibold hover:bg-secondary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "h-3 w-3" }), " Directions"]
				}),
				!dead && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: addToCalendar,
					title: "Download an .ics for this session",
					className: "inline-flex items-center gap-1 rounded-lg border border-border px-2 py-1 text-[11px] font-semibold hover:bg-secondary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarPlus, { className: "h-3 w-3" }), " Add"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/dashboard",
					search: { booking: session.first.id },
					title: "Open this booking in My Bookings",
					className: "inline-flex items-center gap-1 rounded-lg border border-border px-2 py-1 text-[11px] font-semibold hover:bg-secondary",
					children: ["Details ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3 w-3" })]
				})
			]
		})]
	});
}
/** One favorited court, shown with the venue it belongs to.
*
*  The whole tile is the link, and it lands on the venue page with `?court=` set —
*  the same URL the venue's own "Book now" button produces, so a favorite drops the
*  player straight into the booking panel for that court rather than at the top of
*  a page they then have to search.
*
*  A court can be favorited and later retired, or its venue deactivated. That tile
*  stops being a link and says so, rather than sending the player to a court they
*  cannot book. The heart still works, so the list can be tidied. */
function FavoriteCourtTile({ court, userId }) {
	const venue = court.venues;
	const soon = !!court.coming_soon;
	const retired = !court.is_active || !venue || !venue.is_active;
	const image = court.images?.[0];
	const rules = normalizeRules(court.rate_rules);
	const hrs = effectiveHours({
		inherit_venue_hours: court.inherit_venue_hours,
		operating_hours: court.operating_hours
	}, venue?.operating_hours);
	const base = Number(court.hourly_rate);
	const varies = hasVariablePricing(base, rules, hrs);
	const lo = varies ? minRate(base, rules, hrs) : base;
	const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: image,
			alt: court.name,
			className: `h-36 w-full object-cover ${retired ? "grayscale" : ""}`
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `court-pattern h-36 ${retired ? "grayscale" : ""}` }), (soon || retired) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute left-3 top-3 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow " + (retired ? "bg-muted-foreground" : "bg-amber-500"),
			children: retired ? "Unavailable" : "Coming soon"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1 rounded-full bg-secondary px-2 py-1 font-medium text-secondary-foreground",
					children: [court.map_emoji && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: court.map_emoji
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: court.sports?.name ?? "Court" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold text-muted-foreground",
					children: court.is_indoor ? "Indoor" : "Outdoor"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 truncate font-display text-xl font-bold tracking-tight",
				children: court.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 flex items-start gap-1.5 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-3.5 w-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-foreground",
						children: venue?.name ?? "Venue removed"
					}), venue?.address && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate",
						children: venue.address
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-end justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					varies && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mr-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground",
						children: "from"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl font-extrabold tabular-nums",
						children: peso(lo)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: " / hour"
					})
				] }), retired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "Not bookable"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 text-xs font-bold text-primary-foreground transition group-hover:brightness-110",
					children: [soon ? "View court" : "Book again", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5" })]
				})]
			})
		]
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "group relative overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition hover:shadow-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoriteButton, {
			courtId: court.id,
			courtName: court.name,
			userId,
			className: "absolute right-3 top-3"
		}), retired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "block cursor-default",
			children: body
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/venues/$venueId",
			params: { venueId: String(venue.id) },
			search: { court: court.id },
			className: "block",
			children: body
		})]
	});
}
/** The Favorites pane: every court the player hearted, newest first, each with the
*  venue it belongs to and a route straight back into booking it. */
function FavoritesView({ userId }) {
	const favQ = useFavoriteCourts(userId);
	const rows = favQ.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
			title: "Favorites",
			sub: favQ.isLoading ? "Loading your saved courts…" : rows.length === 0 ? "Courts you save show up here" : `${rows.length} saved court${rows.length === 1 ? "" : "s"} — tap one to book it again`,
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/explore",
				search: {},
				className: "rounded-full bg-primary px-4 py-2 text-sm font-bold text-primary-foreground transition hover:opacity-90",
				children: "Find a court"
			})
		}), favQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-3",
			children: [
				0,
				1,
				2
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse rounded-2xl bg-secondary/50" }, i))
		}) : favQ.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive",
			children: "Your favorites could not be loaded. Refresh the page to try again."
		}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid min-h-[45vh] place-items-center rounded-2xl border border-dashed border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-sm px-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "h-7 w-7" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 font-cabinet text-xl font-bold tracking-tight",
						children: "No favorites yet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Open a venue and hover a court tile — the heart in its corner saves that court here, so booking it again is two clicks instead of a search."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/explore",
						search: {},
						className: "mt-6 inline-flex rounded-full bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground transition hover:opacity-90",
						children: "Browse venues"
					})
				]
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-3",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoriteCourtTile, {
				court: row.courts,
				userId
			}, row.court_id))
		})]
	});
}
function PlayerWorkspace({ userId, fullName, email, view, focusBookingId }) {
	const qc = useQueryClient();
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const [collapsed, setCollapsed] = (0, import_react.useState)(false);
	const [period, setPeriod] = (0, import_react.useState)("all");
	const [chat, setChat] = (0, import_react.useState)(null);
	const bookingsQ = useQuery({
		queryKey: ["player-bookings", userId],
		queryFn: async () => {
			const { data, error } = await supabase.from("bookings").select(BOOKING_SELECT).eq("user_id", userId).order("start_time", { ascending: false }).limit(400);
			if (error) throw error;
			return data ?? [];
		}
	});
	const txQ = useQuery({
		queryKey: ["player-transactions", userId],
		queryFn: async () => {
			const { data, error } = await supabase.from("transactions").select(TX_SELECT).eq("user_id", userId).order("created_at", { ascending: false }).limit(800);
			if (error) throw error;
			return data ?? [];
		}
	});
	const rows = (0, import_react.useMemo)(() => bookingsQ.data ?? [], [bookingsQ.data]);
	const txs = (0, import_react.useMemo)(() => txQ.data ?? [], [txQ.data]);
	const idx = (0, import_react.useMemo)(() => indexTransactions(txs), [txs]);
	const stats = (0, import_react.useMemo)(() => buildPlayerStats({
		rows,
		transactions: txs,
		userId,
		period
	}), [
		rows,
		txs,
		userId,
		period
	]);
	const retryFn = useServerFn(retryBookingPayment);
	const cancelPendingFn = useServerFn(cancelPendingBookings);
	const [payFor, setPayFor] = (0, import_react.useState)(null);
	const [payMethod, setPayMethod] = (0, import_react.useState)("gcash");
	const [payBusy, setPayBusy] = (0, import_react.useState)(false);
	const [payErr, setPayErr] = (0, import_react.useState)(null);
	const openPay = (s) => {
		setPayFor({
			ids: s.ids,
			amount: sessionBalance(s, idx),
			label: `${s.first.courts?.venues?.name ?? ""} · ${s.first.courts?.name ?? ""}`
		});
		setPayErr(null);
	};
	const submitPay = async () => {
		if (!payFor) return;
		setPayBusy(true);
		setPayErr(null);
		try {
			const res = await retryFn({ data: {
				bookingIds: payFor.ids,
				method: payMethod,
				origin: window.location.origin
			} });
			window.location.href = res.checkoutUrl;
		} catch (e) {
			setPayErr(e.message);
			setPayBusy(false);
		}
	};
	const cancelMut = useMutation({
		mutationFn: async (session) => {
			if (sessionPaid(session, idx) === 0 && session.first.status === "pending") {
				await cancelPendingFn({ data: { bookingIds: session.ids } });
				return;
			}
			const { error } = await supabase.from("bookings").update({
				status: "cancelled",
				cancelled_at: (/* @__PURE__ */ new Date()).toISOString(),
				cancelled_by: userId,
				cancel_reason: "Cancelled by player"
			}).in("id", session.ids).eq("user_id", userId);
			if (error) throw error;
		},
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["player-bookings", userId] });
			qc.invalidateQueries({ queryKey: ["player-transactions", userId] });
		}
	});
	const askCancel = (s) => {
		const when = `${fmtDateShort(s.start_time)} · ${formatSessionLabel(s.start_time, s.end_time)}`;
		const paid = sessionPaid(s, idx);
		const note = paid > 0 ? `\n\n${peso(paid)} has been paid. Any refund follows the venue's policy.` : "\n\nThis booking is not paid, so nothing will be charged.";
		if (confirm(`Cancel this booking?\n\n${when}${note}`)) cancelMut.mutate(s);
	};
	const openChat = (s) => {
		const vId = s.first.courts?.venues?.id;
		if (!vId) return;
		setChat({
			bookingId: s.first.id,
			venueId: vId,
			title: s.first.courts?.venues?.name ?? "Venue",
			subtitle: `${fmtDate(s.start_time)} · ${formatSessionLabel(s.start_time, s.end_time)}`
		});
	};
	const periodLabel = PERIODS.find((p) => p.key === period)?.label ?? "All time";
	const loading = bookingsQ.isLoading || txQ.isLoading;
	(0, import_react.useEffect)(() => {
		if (!focusBookingId || loading) return;
		const el = document.getElementById(`booking-${focusBookingId}`);
		if (el) el.scrollIntoView({
			behavior: "smooth",
			block: "center"
		});
	}, [focusBookingId, loading]);
	const shell = (children) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PlayerShell, {
		section: view === "calendar" ? "calendar" : view === "favorites" ? "favorites" : "bookings",
		mobileOpen,
		setMobileOpen,
		collapsed,
		setCollapsed,
		userId,
		fullName,
		onSignOut: async () => {
			await supabase.auth.signOut();
			window.location.href = "/";
		},
		children: [
			children,
			chat && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingChat, {
				bookingId: chat.bookingId,
				venueId: chat.venueId,
				playerId: userId,
				meId: userId,
				title: chat.title,
				subtitle: chat.subtitle,
				onClose: () => setChat(null)
			}),
			payFor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 grid place-items-center bg-black/50 px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-2xl border border-border bg-card p-5 shadow-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-lg font-bold",
								children: "Complete payment"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: payFor.label
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setPayFor(null),
								className: "rounded-lg p-1 hover:bg-muted",
								disabled: payBusy,
								"aria-label": "Close",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-xl bg-secondary/60 p-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: [
										payFor.ids.length,
										" hour",
										payFor.ids.length > 1 ? "s" : ""
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display font-bold tabular-nums",
									children: peso(payFor.amount)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[11px] text-muted-foreground",
								children: "The full amount is collected online; your slot is held once it clears."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-wider text-muted-foreground",
								children: "Payment method"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 grid grid-cols-2 gap-2",
								children: [
									{
										v: "gcash",
										l: "GCash"
									},
									{
										v: "paymaya",
										l: "Maya"
									},
									{
										v: "grab_pay",
										l: "GrabPay"
									},
									{
										v: "qrph",
										l: "QR Ph"
									}
								].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setPayMethod(m.v),
									disabled: payBusy,
									className: `rounded-lg border px-3 py-2 text-sm font-semibold transition ${payMethod === m.v ? "border-primary bg-primary/10 text-primary" : "border-border hover:border-primary/50"}`,
									children: m.l
								}, m.v))
							})]
						}),
						payErr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs font-medium text-destructive",
							children: payErr
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setPayFor(null),
								disabled: payBusy,
								className: "flex-1 rounded-lg border border-border px-4 py-2 text-sm font-semibold hover:bg-muted disabled:opacity-50",
								children: "Not now"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: submitPay,
								disabled: payBusy,
								className: "flex-1 rounded-lg bg-primary px-4 py-2 text-sm font-bold text-primary-foreground hover:opacity-90 disabled:opacity-50",
								children: payBusy ? "Redirecting…" : "Continue to pay"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-[10px] text-muted-foreground",
							children: "Your slot is only reserved after payment succeeds."
						})
					]
				})
			})
		]
	});
	if (view === "calendar") return shell(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarView, {
		rows,
		idx,
		userId
	}));
	if (view === "favorites") return shell(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoritesView, { userId }));
	if (loading) return shell(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-56 animate-pulse rounded-3xl bg-secondary/50" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					0,
					1,
					2,
					3
				].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-28 animate-pulse rounded-2xl bg-secondary/40" }, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-2xl bg-secondary/40" })
		]
	}));
	if (!stats.hasAnyBooking) return shell(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-[60vh] place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-sm text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-primary/10 text-3xl",
					children: "🎾"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-5 font-cabinet text-2xl font-bold tracking-tight",
					children: "No bookings yet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Find a court and schedule your first game. Your schedule, spending and stats all show up here once you do."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/explore",
					search: {},
					className: "mt-6 inline-flex rounded-full bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground transition hover:opacity-90",
					children: "Find a court"
				})
			]
		})
	}));
	return shell(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground",
				children: "Player workspace"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-1 font-cabinet text-2xl font-bold tracking-tight sm:text-3xl",
				children: ["Welcome back, ", fullName || email.split("@")[0]]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/explore",
				search: {},
				className: "rounded-full bg-primary px-4 py-2 text-sm font-bold text-primary-foreground transition hover:opacity-90",
				children: "Find a court"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5",
			children: stats.next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NextGame, {
				session: stats.next,
				idx,
				onPay: openPay,
				onCancel: askCancel
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-3xl border border-dashed border-border p-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-base font-bold",
						children: "No upcoming games"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Book a court and it will appear here with a countdown."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/explore",
						search: {},
						className: "mt-4 inline-flex rounded-full bg-primary px-5 py-2 text-sm font-bold text-primary-foreground hover:opacity-90",
						children: "Find a court"
					})
				]
			})
		}),
		stats.spend.outstanding > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-wrap items-center gap-2 rounded-2xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-medium text-amber-800 dark:text-amber-200",
				children: [peso(stats.spend.outstanding), " still to pay across your upcoming bookings. Slots are only reserved once payment clears."]
			})]
		}),
		stats.upcoming.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpcomingSection, {
			sessions: stats.upcoming,
			idx,
			userId,
			focusBookingId,
			onPay: openPay,
			onCancel: askCancel,
			onMessage: openChat
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				title: "Your activity",
				sub: "Totals below follow this period",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: period,
					onChange: (e) => setPeriod(e.target.value),
					"aria-label": "Statistics period",
					className: "rounded-full border border-border bg-card px-3 py-1.5 text-xs font-bold outline-none transition focus:border-primary",
					children: PERIODS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p.key,
						children: p.label
					}, p.key))
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						icon: CalendarDays,
						label: "Upcoming",
						value: String(stats.counts.upcoming),
						hint: stats.next ? countdownLabel(stats.next.start_time) : "Nothing booked",
						tone: "primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						icon: Trophy,
						label: "Completed",
						value: String(stats.counts.completed),
						hint: `${stats.sports.length} sport${stats.sports.length === 1 ? "" : "s"} played`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						icon: Timer,
						label: "Hours played",
						value: humanHours(stats.hoursPlayed),
						hint: stats.sessionsPlayed ? `${humanHours(stats.avgSessionHours)} average` : "No games yet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatTile, {
						icon: stats.spend.outstanding > 0 ? TriangleAlert : Wallet,
						label: "Total spent",
						value: pesoShort(stats.spend.thisPeriod),
						hint: stats.spend.outstanding > 0 ? `${peso(stats.spend.outstanding)} still due` : `${peso(stats.avgPerBooking)} per game`,
						tone: stats.spend.outstanding > 0 ? "warning" : "neutral"
					})
				]
			})]
		}),
		stats.hasHistory ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpendingSection, {
				stats,
				periodLabel
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SportsSection, { stats }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Insights, {
				stats,
				periodLabel
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground",
			children: "Your spending and sports breakdown unlock once you have played your first game."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CancellationSummary, {
			stats,
			periodLabel
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistorySection, {
			stats,
			idx,
			userId,
			focusBookingId,
			onMessage: openChat
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8" })
	] }));
}
/** `view` picks which player pane is showing. A search param rather than a separate route so
*  the whole dashboard — including the tenant side, which ignores it — stays one route with
*  one auth guard and one data layer. */
var chLogo = { url: "/CHicon.png" };
var NAV = [
	{
		key: "dashboard",
		label: "Dashboard",
		icon: LayoutDashboard
	},
	{
		key: "calendar",
		label: "Calendar",
		icon: CalendarDays
	},
	{
		key: "bookings",
		label: "Bookings",
		icon: BookOpen
	},
	{
		key: "courts",
		label: "Venues & Courts",
		icon: LandPlot
	},
	{
		key: "customers",
		label: "Customers",
		icon: Users
	},
	{
		key: "team",
		label: "Team",
		icon: UserCog
	},
	{
		key: "transactions",
		label: "Transactions",
		icon: Receipt
	},
	{
		key: "vouchers",
		label: "Vouchers",
		icon: TicketPercent
	},
	{
		key: "settings",
		label: "Settings",
		icon: Settings
	}
];
var TIMEZONE_OPTIONS = [
	{
		value: "Asia/Manila",
		label: "Philippines — Asia/Manila (PHT, UTC+8)"
	},
	{
		value: "Asia/Singapore",
		label: "Singapore — Asia/Singapore (UTC+8)"
	},
	{
		value: "Asia/Hong_Kong",
		label: "Hong Kong — Asia/Hong_Kong (UTC+8)"
	},
	{
		value: "Asia/Kuala_Lumpur",
		label: "Malaysia — Asia/Kuala_Lumpur (UTC+8)"
	},
	{
		value: "Asia/Jakarta",
		label: "Indonesia (WIB) — Asia/Jakarta (UTC+7)"
	},
	{
		value: "Asia/Bangkok",
		label: "Thailand — Asia/Bangkok (UTC+7)"
	},
	{
		value: "Asia/Tokyo",
		label: "Japan — Asia/Tokyo (UTC+9)"
	},
	{
		value: "Asia/Seoul",
		label: "South Korea — Asia/Seoul (UTC+9)"
	},
	{
		value: "Asia/Taipei",
		label: "Taiwan — Asia/Taipei (UTC+8)"
	},
	{
		value: "Australia/Sydney",
		label: "Australia — Australia/Sydney (UTC+10/11)"
	},
	{
		value: "UTC",
		label: "UTC"
	}
];
var TZ_BOUNDS = [
	{
		tz: "Asia/Manila",
		country: "Philippines",
		minLat: 4.5,
		maxLat: 21.5,
		minLng: 116,
		maxLng: 127
	},
	{
		tz: "Asia/Singapore",
		country: "Singapore",
		minLat: 1.15,
		maxLat: 1.5,
		minLng: 103.6,
		maxLng: 104.05
	},
	{
		tz: "Asia/Hong_Kong",
		country: "Hong Kong",
		minLat: 22.15,
		maxLat: 22.58,
		minLng: 113.83,
		maxLng: 114.44
	},
	{
		tz: "Asia/Kuala_Lumpur",
		country: "Malaysia",
		minLat: .85,
		maxLat: 7.4,
		minLng: 99.6,
		maxLng: 119.3
	},
	{
		tz: "Asia/Jakarta",
		country: "Indonesia (WIB)",
		minLat: -8.8,
		maxLat: 6.1,
		minLng: 95,
		maxLng: 141
	},
	{
		tz: "Asia/Bangkok",
		country: "Thailand",
		minLat: 5.6,
		maxLat: 20.5,
		minLng: 97.3,
		maxLng: 105.7
	},
	{
		tz: "Asia/Tokyo",
		country: "Japan",
		minLat: 24,
		maxLat: 45.6,
		minLng: 122.9,
		maxLng: 146
	},
	{
		tz: "Asia/Seoul",
		country: "South Korea",
		minLat: 33,
		maxLat: 38.7,
		minLng: 124.5,
		maxLng: 131
	},
	{
		tz: "Asia/Taipei",
		country: "Taiwan",
		minLat: 21.8,
		maxLat: 25.4,
		minLng: 119.3,
		maxLng: 122.1
	},
	{
		tz: "Australia/Sydney",
		country: "Australia",
		minLat: -44,
		maxLat: -10,
		minLng: 112,
		maxLng: 154
	}
];
var PH_BOUNDS = TZ_BOUNDS[0];
function suggestTimezone(lat, lng) {
	if (lat == null || lng == null) return null;
	for (const b of TZ_BOUNDS) if (lat >= b.minLat && lat <= b.maxLat && lng >= b.minLng && lng <= b.maxLng) return {
		tz: b.tz,
		country: b.country
	};
	return null;
}
function isInPhilippines(lat, lng) {
	if (lat == null || lng == null) return false;
	return lat >= PH_BOUNDS.minLat && lat <= PH_BOUNDS.maxLat && lng >= PH_BOUNDS.minLng && lng <= PH_BOUNDS.maxLng;
}
var ACTIVE_INFO_TEXT = "A venue can only be set inactive when none of its courts have upcoming or in-progress confirmed bookings. If bookings exist, wait until their end time passes. Any pending (awaiting-payment) bookings will be automatically cancelled and those players will be notified to pick another venue. Inactive venues are hidden from the landing page map and list.";
function CourtStatusField({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-end gap-1.5 pb-2 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex cursor-pointer items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				checked: value,
				onChange: (e) => onChange(e.target.checked),
				className: "h-4 w-4 accent-primary"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "whitespace-nowrap",
				children: "Active"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "group relative inline-flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				tabIndex: 0,
				"aria-label": "Court status help",
				className: "grid h-4 w-4 cursor-help place-items-center rounded-full border border-border text-[10px] font-bold leading-none text-muted-foreground",
				children: "?"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "pointer-events-none absolute bottom-full left-1/2 z-50 mb-2 hidden w-64 -translate-x-1/2 rounded-lg border border-border bg-popover p-2.5 text-[11px] leading-relaxed text-popover-foreground shadow-lg group-hover:block group-focus-within:block",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Active" }),
					" courts are visible to players and open for booking.",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"You can set a court to ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Inactive" }),
					" only when it has no upcoming bookings or scheduled sessions. If bookings still exist, deactivation is blocked — cancel them or wait until they finish first."
				]
			})]
		})]
	});
}
var DAYS = [
	{
		key: "mon",
		label: "Mon"
	},
	{
		key: "tue",
		label: "Tue"
	},
	{
		key: "wed",
		label: "Wed"
	},
	{
		key: "thu",
		label: "Thu"
	},
	{
		key: "fri",
		label: "Fri"
	},
	{
		key: "sat",
		label: "Sat"
	},
	{
		key: "sun",
		label: "Sun"
	}
];
function Dashboard() {
	const { user } = Route.useRouteContext();
	const qc = useQueryClient();
	const search = Route.useSearch();
	const [section, setSection] = (0, import_react.useState)("dashboard");
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	const [collapsed, setCollapsed] = (0, import_react.useState)(false);
	const [createVenueOpen, setCreateVenueOpen] = (0, import_react.useState)(false);
	const [addCourtOpen, setAddCourtOpen] = (0, import_react.useState)(false);
	const [createGroupOpen, setCreateGroupOpen] = (0, import_react.useState)(false);
	const profileQ = useQuery({
		queryKey: ["profile", user.id],
		queryFn: async () => {
			const { data, error } = await supabase.from("profiles").select("*").eq("id", user.id).maybeSingle();
			if (error) throw error;
			return data;
		}
	});
	const venuesQ = useQuery({
		queryKey: ["my-venues", user.id],
		queryFn: async () => {
			const { data: staffRows, error: se } = await supabase.from("staff").select("venue_id").eq("user_id", user.id);
			if (se) throw se;
			const ids = (staffRows ?? []).map((r) => r.venue_id);
			if (ids.length === 0) return [];
			const { data, error } = await supabase.from("venues").select("*").in("id", ids).order("id", { ascending: false });
			if (error) throw error;
			return data;
		}
	});
	const metadataName = typeof user.user_metadata?.full_name === "string" ? user.user_metadata.full_name : "";
	const fullName = profileQ.data?.full_name ?? metadataName;
	if (profileQ.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TenantShell, {
		userId: user.id,
		section,
		setSection,
		mobileOpen,
		setMobileOpen,
		collapsed,
		setCollapsed,
		fullName,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {})
	});
	const metadataRole = user.user_metadata?.role === "tenant" ? "tenant" : "player";
	if ((profileQ.data?.role === "tenant" ? "tenant" : metadataRole) !== "tenant") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerWorkspace, {
		userId: user.id,
		fullName,
		email: user.email ?? "",
		view: search.view ?? "bookings",
		focusBookingId: search.booking
	});
	const venues = venuesQ.data ?? [];
	const loadingVenues = venuesQ.isLoading;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TenantShell, {
		userId: user.id,
		section,
		setSection,
		mobileOpen,
		setMobileOpen,
		collapsed,
		setCollapsed,
		fullName,
		children: [
			section === "dashboard" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nice-scroll min-h-0 flex-1 overflow-y-auto pr-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardOverview, {
					venues,
					loading: loadingVenues,
					setSection
				})
			}),
			section === "courts" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
						title: "Venues & Courts",
						subtitle: "Manage your venues and courts."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenuesCourtsActions, {
						hasVenues: venues.length > 0,
						onCreateVenue: () => setCreateVenueOpen(true),
						onAddCourt: () => setAddCourtOpen(true),
						onCreateGroup: () => setCreateGroupOpen(true)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenuesCourtsGlance, { venues }),
					loadingVenues ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {}) : venues.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "No venues yet",
						body: "Create your first venue to start adding courts and taking bookings.",
						cta: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setCreateVenueOpen(true),
							className: "rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90",
							children: "+ Create venue"
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						id: "add-court-anchor",
						className: "flex min-h-0 flex-1 flex-col",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenuesCourtsTabs, { venues })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateVenueDrawer, {
						open: createVenueOpen,
						onClose: () => setCreateVenueOpen(false),
						onCreated: () => {
							qc.invalidateQueries({ queryKey: ["my-venues"] });
							setCreateVenueOpen(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddCourtDrawer, {
						open: addCourtOpen,
						onClose: () => setAddCourtOpen(false),
						venues,
						onCreated: () => {
							[
								"my-venues",
								"venues-courts-glance",
								"venues-court-counts",
								"all-tenant-courts",
								"venues-courts-table",
								"courts",
								"group-eligible-courts",
								"physical-courts-full",
								"physical-courts",
								"venues-group-counts"
							].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
							setAddCourtOpen(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateGroupDrawer, {
						open: createGroupOpen,
						onClose: () => setCreateGroupOpen(false),
						venues,
						onCreated: () => {
							[
								"physical-courts-full",
								"physical-courts",
								"tenant-venues-full",
								"venues-group-counts",
								"group-eligible-courts",
								"all-tenant-courts",
								"court-block-rules"
							].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
							setCreateGroupOpen(false);
						}
					})
				]
			}),
			section === "calendar" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nice-scroll min-h-0 flex-1 overflow-y-auto pr-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarSection, { venues })
			}),
			section === "bookings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nice-scroll min-h-0 flex-1 overflow-y-auto pr-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingsSection, {
					venues,
					userId: user.id
				})
			}),
			section === "customers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nice-scroll min-h-0 flex-1 overflow-y-auto pr-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomersSection, { venues })
			}),
			section === "team" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nice-scroll min-h-0 flex-1 overflow-y-auto pr-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComingSoon, {
					title: "Team",
					body: "Invite staff, assign roles and manage permissions per venue."
				})
			}),
			section === "transactions" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nice-scroll min-h-0 flex-1 overflow-y-auto pr-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionsSection, { venues })
			}),
			section === "vouchers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nice-scroll min-h-0 flex-1 overflow-y-auto pr-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VouchersSection, { venues })
			}),
			section === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nice-scroll min-h-0 flex-1 overflow-y-auto pr-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsSection, {
					fullName: profileQ.data?.full_name ?? "",
					email: user.email ?? "",
					role: profileQ.data?.role ?? "tenant",
					userId: user.id,
					onSaved: () => qc.invalidateQueries({ queryKey: ["profile", user.id] })
				})
			})
		]
	});
}
function TenantShell({ children, section, setSection, mobileOpen, setMobileOpen, collapsed, setCollapsed, userId, fullName }) {
	const current = NAV.find((n) => n.key === section);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh w-full",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "sticky top-0 hidden shrink-0 self-start border-r-2 border-[#b8f05a]/40 bg-linear-to-b from-[#0f4a40] to-[#09231f] text-white md:flex md:h-dvh md:flex-col transition-[width] duration-200 " + (collapsed ? "md:w-16" : "md:w-62.5"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarBody, {
					section,
					setSection,
					collapsed,
					setCollapsed,
					fullName
				})
			}),
			mobileOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-1200 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Close menu",
					onClick: () => setMobileOpen(false),
					className: "absolute inset-0 bg-black/40"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "absolute inset-y-0 left-0 flex w-62.5 flex-col border-r-2 border-[#b8f05a]/40 bg-linear-to-b from-[#0f4a40] to-[#09231f] text-white shadow-xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarBody, {
						section,
						setSection: (s) => {
							setSection(s);
							setMobileOpen(false);
						},
						collapsed: false,
						setCollapsed: () => {},
						onClose: () => setMobileOpen(false),
						fullName
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-full min-w-0 flex-1 flex-col overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b border-border bg-background px-4 py-2 md:hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setMobileOpen(true),
								className: "inline-flex items-center gap-2 rounded-md border border-border px-2.5 py-1.5 text-sm font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-4 w-4" }), " Menu"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-semibold",
								children: current?.label ?? "Dashboard"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationBell, { userId })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden items-center justify-end border-b border-border bg-background px-6 py-2 md:flex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationBell, { userId })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto flex w-full max-w-6xl min-h-0 flex-1 flex-col overflow-hidden px-4 py-6 sm:px-6 sm:py-8",
						children
					})
				]
			})
		]
	});
}
function SidebarBody({ section, setSection, collapsed, setCollapsed, onClose, fullName }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2 border-b border-white/10 px-3 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-w-0 items-center gap-2",
				children: collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: chLogo.url,
					alt: "CourtHub",
					className: "h-7 w-7 shrink-0 rounded-full object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "logo-glaze shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/courthub-wordmark.png",
						alt: "CourtHub",
						width: 983,
						height: 240,
						className: "h-7 w-auto object-contain"
					})
				})
			}), onClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onClose,
				"aria-label": "Close",
				className: "rounded-md p-1 text-white/70 transition-colors hover:bg-white/10 hover:text-[#b8f05a]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setCollapsed(!collapsed),
				"aria-label": collapsed ? "Expand sidebar" : "Collapse sidebar",
				className: "hidden rounded-md p-1 text-white/70 transition-colors hover:bg-white/10 hover:text-[#b8f05a] md:inline-flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-4 w-4" })
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "flex-1 overflow-y-auto p-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1",
				children: NAV.map(({ key, label, icon: Icon }) => {
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setSection(key),
						title: collapsed ? label : void 0,
						className: "flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors " + (section === key ? "bg-[#b8f05a] text-[#102521] shadow-sm" : "text-white/75 hover:bg-white/10 hover:text-[#b8f05a]"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 shrink-0" }), !collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: label
						})]
					}) }, key);
				})
			})
		}),
		!collapsed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-white/10 px-3 py-3.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "logo-glaze",
				style: { "--logo-glaze-src": "url(/role-tenant.png)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/role-tenant.png",
					alt: "",
					className: "h-8 w-auto object-contain"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 truncate font-display text-sm font-bold tracking-tight text-white",
				children: fullName || "Venue manager"
			})]
		})
	] });
}
function SectionHeader({ title, subtitle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-muted-foreground",
				children: "Tenant workspace"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-2xl font-semibold sm:text-3xl",
				children: title
			}),
			subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: subtitle
			})
		]
	});
}
function ComingSoon({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, { title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-dashed border-border bg-card p-10 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: body
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-xs font-medium uppercase tracking-wider text-primary",
			children: "Coming soon"
		})]
	})] });
}
function DashboardOverview({ venues, loading, setSection }) {
	const venueIds = venues.map((v) => v.id);
	const statsQ = useQuery({
		queryKey: ["tenant-stats", venueIds.join(",")],
		enabled: venueIds.length > 0,
		queryFn: async () => {
			const { data: courts } = await supabase.from("courts").select("id, venue_id").in("venue_id", venueIds);
			const courtIds = (courts ?? []).map((c) => c.id);
			let upcoming = 0;
			if (courtIds.length) {
				const { count } = await supabase.from("bookings").select("id", {
					count: "exact",
					head: true
				}).in("court_id", courtIds).gte("end_time", (/* @__PURE__ */ new Date()).toISOString());
				upcoming = count ?? 0;
			}
			return {
				courts: courtIds.length,
				upcoming
			};
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
		title: "Dashboard",
		subtitle: "Your workspace at a glance."
	}), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: "Venues",
				value: venues.length
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: "Courts",
				value: statsQ.data?.courts ?? 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: "Upcoming bookings",
				value: statsQ.data?.upcoming ?? 0
			})
		]
	})] });
}
function VenuesCourtsActions({ hasVenues, onCreateVenue, onAddCourt, onCreateGroup }) {
	const handleAddCourt = () => {
		if (!hasVenues) {
			alert("Create a venue first, then you can add courts to it.");
			onCreateVenue();
			return;
		}
		onAddCourt();
	};
	const handleCreateGroup = () => {
		if (!hasVenues) {
			alert("Create a venue first — court groups belong to a venue.");
			onCreateVenue();
			return;
		}
		onCreateGroup();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4 flex flex-wrap items-center justify-end gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: handleCreateGroup,
				className: "rounded-lg border border-border bg-card px-3 py-2 text-sm font-semibold hover:border-primary",
				children: "+ Create group"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: handleAddCourt,
				className: "rounded-lg border border-border bg-card px-3 py-2 text-sm font-semibold hover:border-primary",
				children: "+ Add court"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onCreateVenue,
				className: "rounded-lg bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90",
				children: "+ Create venue"
			})
		]
	});
}
function CreateVenueDrawer({ open, onClose, onCreated }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			window.removeEventListener("keydown", onKey);
			document.body.style.overflow = prev;
		};
	}, [open, onClose]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-1200 " + (open ? "pointer-events-auto" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			onClick: onClose,
			className: "absolute inset-0 bg-black/40 transition-opacity duration-300 " + (open ? "opacity-100" : "opacity-0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "absolute right-0 top-0 h-full w-full max-w-xl overflow-y-auto bg-background shadow-2xl transition-transform duration-300 ease-out " + (open ? "translate-x-0" : "translate-x-full"),
			role: "dialog",
			"aria-modal": "true",
			"aria-label": "Create venue",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background/95 px-4 py-3 backdrop-blur sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold",
					children: "Create venue"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					"aria-label": "Close",
					className: "rounded-md border border-border px-2 py-1 text-sm hover:bg-secondary",
					children: "✕"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-4 sm:p-6",
				children: open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateVenue, {
					onCreated,
					onCancel: onClose
				})
			})]
		})]
	});
}
function CreateGroupDrawer({ open, onClose, venues, onCreated }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			window.removeEventListener("keydown", onKey);
			document.body.style.overflow = prev;
		};
	}, [open, onClose]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-1200 " + (open ? "pointer-events-auto" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			onClick: onClose,
			className: "absolute inset-0 bg-black/40 transition-opacity duration-300 " + (open ? "opacity-100" : "opacity-0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "absolute right-0 top-0 h-full w-full max-w-xl overflow-y-auto bg-background shadow-2xl transition-transform duration-300 ease-out " + (open ? "translate-x-0" : "translate-x-full"),
			role: "dialog",
			"aria-modal": "true",
			"aria-label": "Create court group",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background/95 px-4 py-3 backdrop-blur sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold",
					children: "Create court group"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					"aria-label": "Close",
					className: "rounded-md border border-border px-2 py-1 text-sm hover:bg-secondary",
					children: "✕"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-4 sm:p-6",
				children: open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateGroupForm, {
					venues,
					onCreated,
					onCancel: onClose
				})
			})]
		})]
	});
}
function CreateGroupForm({ venues, onCreated, onCancel }) {
	const [venueId, setVenueId] = (0, import_react.useState)(venues[0]?.id ?? 0);
	const [name, setName] = (0, import_react.useState)("");
	const [emoji, setEmoji] = (0, import_react.useState)(null);
	const [description, setDescription] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)(null);
	const courtsQ = useQuery({
		queryKey: ["group-eligible-courts", venueId],
		enabled: !!venueId,
		queryFn: async () => {
			const { data, error } = await supabase.from("courts").select("id, name, hourly_rate, physical_court_id, sports(name)").eq("venue_id", venueId).order("id");
			if (error) throw error;
			return data;
		}
	});
	const [selected, setSelected] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [rules, setRules] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const toggle = (id) => {
		setSelected((prev) => {
			const next = new Set(prev);
			if (next.has(id)) next.delete(id);
			else next.add(id);
			setRules(allPairsEnabled(Array.from(next)));
			return next;
		});
	};
	const selectedCourts = (courtsQ.data ?? []).filter((c) => selected.has(c.id)).map((c) => ({
		id: c.id,
		name: c.name,
		sport: c.sports?.name ?? null
	}));
	const mut = useMutation({
		mutationFn: async () => {
			if (!venueId) throw new Error("Pick a venue");
			if (!name.trim()) throw new Error("Group name is required");
			const { data: pc, error } = await supabase.from("physical_courts").insert({
				venue_id: venueId,
				name: name.trim(),
				map_emoji: emoji,
				description: description.trim() || null
			}).select("id").single();
			if (error) throw error;
			const ids = Array.from(selected);
			if (ids.length > 0) {
				const { error: upErr } = await supabase.from("courts").update({ physical_court_id: pc.id }).in("id", ids);
				if (upErr) throw upErr;
				const { error: delErr } = await supabase.from("court_block_rules").delete().in("court_id", ids);
				if (delErr) throw delErr;
				const rows = Array.from(rules).map((k) => k.split(">").map(Number)).filter(([a, b]) => selected.has(a) && selected.has(b)).map(([a, b]) => ({
					court_id: a,
					blocked_court_id: b,
					venue_id: venueId
				}));
				if (rows.length > 0) {
					const { error: insErr } = await supabase.from("court_block_rules").insert(rows);
					if (insErr) throw insErr;
				}
			}
		},
		onSuccess: onCreated,
		onError: (e) => setErr(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			mut.mutate();
		},
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-primary/30 bg-primary/5 p-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-semibold text-primary",
					children: "What is a court group?"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-muted-foreground",
					children: [
						"A group represents one ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "shared space" }),
						" that can be set up for different sports (e.g. 1 basketball ↔ 3 badminton ↔ 4 pickleball). Bookings across grouped courts automatically block each other."
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted-foreground",
					children: "Venue"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: venueId,
					onChange: (e) => setVenueId(Number(e.target.value)),
					className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm",
					children: venues.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: v.id,
						children: v.name
					}, v.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				label: "Group name (e.g. \"Court 1 — Main Slab\")",
				value: name,
				onChange: setName,
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl border border-border bg-background p-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiPicker, {
					label: "Group emoji",
					value: emoji,
					fallback: "🏟️",
					onChange: setEmoji,
					hint: "Shown on the map and in the courts table."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				label: "About this Group",
				value: description,
				onChange: setDescription,
				placeholder: "Court size, surface, lighting, house rules…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-dashed border-border p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-semibold",
						children: "Assign existing courts to this group"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "Tick every court that lives on this same shared space (e.g. 3 badminton + 4 pickleball courts painted on one hall)."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 max-h-64 overflow-y-auto nice-scroll",
						children: courtsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 animate-pulse rounded-lg bg-muted" }) : (courtsQ.data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "No courts in this venue yet. You can create the group now and assign courts later from Add / Edit court."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid gap-2",
							children: (courtsQ.data ?? []).map((c) => {
								const checked = selected.has(c.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-3 rounded-lg border p-2 text-sm " + (checked ? "border-primary bg-primary/5" : "border-border"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked,
										onChange: () => toggle(c.id)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-medium",
											children: c.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[11px] text-muted-foreground",
											children: [
												c.sports?.name ?? "—",
												" · ₱",
												Number(c.hourly_rate).toFixed(0),
												"/hr"
											]
										})]
									})]
								}, c.id);
							})
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtBlockRulesEditor, {
				courts: selectedCourts,
				rules,
				onChange: setRules
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive",
				children: err
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onCancel,
					className: "rounded-lg border border-border bg-background px-4 py-2 text-sm font-semibold hover:border-primary",
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					disabled: mut.isPending || !name.trim() || !venueId,
					className: "rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50",
					children: mut.isPending ? "Creating…" : "Create group"
				})]
			})
		]
	});
}
function VenuesCourtsGlance({ venues }) {
	const venueIds = venues.map((v) => v.id);
	const q = useQuery({
		queryKey: ["venues-courts-glance", venueIds.join(",")],
		enabled: venueIds.length > 0,
		queryFn: async () => {
			const { data } = await supabase.from("courts").select("id, is_indoor").in("venue_id", venueIds);
			const rows = data ?? [];
			const indoor = rows.filter((c) => c.is_indoor).length;
			return {
				total: rows.length,
				indoor,
				outdoor: rows.length - indoor
			};
		}
	});
	const total = q.data?.total ?? 0;
	const indoor = q.data?.indoor ?? 0;
	const outdoor = q.data?.outdoor ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6 grid gap-3 grid-cols-2 lg:grid-cols-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: "Total venues",
				value: venues.length
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: "Total courts",
				value: total
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: "Indoor courts",
				value: indoor
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
				label: "Outdoor courts",
				value: outdoor
			})
		]
	});
}
function StatCard({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card p-4 shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 font-display text-3xl font-semibold",
			children: value
		})]
	});
}
function Skeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-2xl bg-muted" });
}
function EmptyState({ title, body, cta }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-dashed border-border p-12 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: body
			}),
			cta && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: cta
			})
		]
	});
}
function TagInput({ label, placeholder, values, onChange, hint }) {
	const [draft, setDraft] = (0, import_react.useState)("");
	const add = () => {
		const t = draft.trim();
		if (!t) return;
		if (values.some((v) => v.toLowerCase() === t.toLowerCase())) {
			setDraft("");
			return;
		}
		onChange([...values, t]);
		setDraft("");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-medium text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex flex-wrap items-center gap-1.5 rounded-lg border border-input bg-background px-2 py-2 focus-within:ring-2 focus-within:ring-ring",
				children: [values.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary",
					children: [v, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": `Remove ${v}`,
						onClick: () => onChange(values.filter((x) => x !== v)),
						className: "rounded-full text-primary/70 hover:text-primary",
						children: "×"
					})]
				}, v)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: draft,
					onChange: (e) => setDraft(e.target.value),
					onKeyDown: (e) => {
						if (e.key === "Enter" || e.key === ",") {
							e.preventDefault();
							add();
						} else if (e.key === "Backspace" && !draft && values.length) onChange(values.slice(0, -1));
					},
					onBlur: add,
					placeholder: values.length ? "" : placeholder ?? "Type and press Enter",
					className: "min-w-[8ch] flex-1 bg-transparent px-1 py-0.5 text-sm outline-none"
				})]
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-[11px] text-muted-foreground",
				children: hint
			})
		]
	});
}
function FeesEditor({ items, onChange, notes, onNotesChange }) {
	const update = (i, patch) => onChange(items.map((it, idx) => idx === i ? {
		...it,
		...patch
	} : it));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 rounded-xl border border-border bg-background p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
					children: "Fees & Charges"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onChange([...items, {
						label: "",
						amount: 0
					}]),
					className: "rounded-md border border-border bg-background px-2 py-1 text-xs font-medium hover:border-primary hover:text-primary",
					children: "+ Add fee"
				})]
			}),
			items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] text-muted-foreground",
				children: "No line-item fees yet. Add things like racket rental, shuttlecock, guest fee, etc."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-1.5",
				children: items.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[1fr,110px,auto] items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: it.label,
							onChange: (e) => update(i, { label: e.target.value }),
							placeholder: "e.g. Racket rental",
							className: "rounded-lg border border-input bg-background px-2 py-1.5 text-sm outline-none focus:ring-2 focus:ring-ring"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1 rounded-lg border border-input bg-background px-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: "₱"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 0,
								step: "0.01",
								value: Number.isFinite(it.amount) ? it.amount : 0,
								onChange: (e) => update(i, { amount: Number(e.target.value) }),
								className: "w-full bg-transparent py-1.5 text-sm outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Remove fee",
							onClick: () => onChange(items.filter((_, idx) => idx !== i)),
							className: "rounded-md border border-border px-2 py-1 text-xs text-muted-foreground hover:border-destructive hover:text-destructive",
							children: "Remove"
						})
					]
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block pt-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] font-medium text-muted-foreground",
					children: "Notes (optional)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: notes,
					onChange: (e) => onNotesChange(e.target.value),
					rows: 2,
					placeholder: "Any extra pricing notes, discounts, or conditions.",
					className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
				})]
			})
		]
	});
}
function CreateVenue({ onCreated, onCancel }) {
	const [name, setName] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const detectedTz = Intl.DateTimeFormat().resolvedOptions().timeZone;
	const [timezone, setTimezone] = (0, import_react.useState)(TIMEZONE_OPTIONS.some((t) => t.value === detectedTz) ? detectedTz : "Asia/Manila");
	const [lat, setLat] = (0, import_react.useState)(null);
	const [lng, setLng] = (0, import_react.useState)(null);
	const [mapEmoji, setMapEmoji] = (0, import_react.useState)(null);
	const [description, setDescription] = (0, import_react.useState)("");
	const [images, setImages] = (0, import_react.useState)([]);
	const [pickerOpen, setPickerOpen] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	const [tzConfirmed, setTzConfirmed] = (0, import_react.useState)(false);
	const [isActive, setIsActive] = (0, import_react.useState)(true);
	const [amenities, setAmenities] = (0, import_react.useState)([]);
	const [foodBeverages, setFoodBeverages] = (0, import_react.useState)([]);
	const [facilityServices, setFacilityServices] = (0, import_react.useState)([]);
	const [fees, setFees] = (0, import_react.useState)([]);
	const [feesNotes, setFeesNotes] = (0, import_react.useState)("");
	const [contactPhone, setContactPhone] = (0, import_react.useState)("");
	const [contactEmail, setContactEmail] = (0, import_react.useState)("");
	const [operatingHoursText, setOperatingHoursText] = (0, import_react.useState)("");
	const [openHours, setOpenHours] = (0, import_react.useState)(() => fullWeek());
	const [cancellationHours, setCancellationHours] = (0, import_react.useState)(24);
	const [cancellationNotes, setCancellationNotes] = (0, import_react.useState)("");
	const [rules, setRules] = (0, import_react.useState)("");
	const uploadPrefix = (0, import_react.useRef)(`venues/new-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`).current;
	const suggested = suggestTimezone(lat, lng);
	const pinInPH = isInPhilippines(lat, lng);
	const tzMismatch = !!(suggested && suggested.tz !== timezone);
	const pinOutsidePH = lat != null && lng != null && !pinInPH;
	const mut = useMutation({
		mutationFn: async () => {
			if (lat == null || lng == null) throw new Error("Please pin your venue on the map before creating.");
			if (!pinInPH) throw new Error("CourtHub currently supports venues in the Philippines only. Please pin a location within the Philippines.");
			if (tzMismatch && !tzConfirmed) throw new Error(`Timezone doesn't match your pin (${suggested?.country}). Confirm the override or switch to ${suggested?.tz}.`);
			const cleanFees = fees.filter((f) => f.label.trim() && Number.isFinite(f.amount)).map((f) => ({
				label: f.label.trim(),
				amount: Number(f.amount)
			}));
			const { error } = await supabase.from("venues").insert({
				name,
				address,
				timezone,
				latitude: lat,
				longitude: lng,
				map_emoji: mapEmoji,
				description: description.trim() || null,
				images,
				is_active: isActive,
				amenities,
				food_beverages: foodBeverages,
				facility_services: facilityServices,
				fees: cleanFees,
				fees_notes: feesNotes.trim() || null,
				contact_phone: contactPhone.trim() || null,
				contact_email: contactEmail.trim() || null,
				operating_hours_text: operatingHoursText.trim() || null,
				operating_hours: openHours,
				refund_cutoff_hours: Number.isFinite(cancellationHours) ? Math.max(0, Math.floor(cancellationHours)) : 24,
				cancellation_notes: cancellationNotes.trim() || null,
				rules: rules.trim() || null
			});
			if (error) throw error;
		},
		onSuccess: () => {
			setName("");
			setAddress("");
			setLat(null);
			setLng(null);
			setMapEmoji(null);
			setDescription("");
			setImages([]);
			setErr(null);
			setTzConfirmed(false);
			setIsActive(true);
			setAmenities([]);
			setFoodBeverages([]);
			setFacilityServices([]);
			setFees([]);
			setFeesNotes("");
			setContactPhone("");
			setContactEmail("");
			setOperatingHoursText("");
			setCancellationHours(24);
			setCancellationNotes("");
			setRules("");
			onCreated();
		},
		onError: (e) => setErr(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-card p-4 shadow-sm sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-bold",
				children: "New venue"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "A venue holds one or more courts."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (e) => {
					e.preventDefault();
					mut.mutate();
				},
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Venue name",
						value: name,
						onChange: setName,
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Address",
						value: address,
						onChange: setAddress,
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted-foreground",
								children: "Timezone"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: timezone,
								onChange: (e) => setTimezone(e.target.value),
								className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring",
								children: TIMEZONE_OPTIONS.map((tz) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: tz.value,
									children: tz.label
								}, tz.value))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-[11px] text-muted-foreground",
								children: "Used to display court hours and bookings in the venue's local time."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2 rounded-xl border border-dashed border-border bg-secondary/30 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-semibold uppercase tracking-wider text-muted-foreground",
								children: "Map location"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPickerOpen(true),
								className: "rounded-md border border-border bg-background px-2.5 py-1 text-xs font-medium hover:border-primary hover:text-primary",
								children: lat != null ? "Change pin" : "📍 Pick on map"
							})]
						}), lat != null && lng != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setPickerOpen(true),
							className: "mt-2 block w-full overflow-hidden rounded-lg border border-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative h-28 w-full overflow-hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
									title: "Selected location",
									src: osmEmbedUrl(lat, lng),
									className: "pointer-events-none absolute left-0 right-0 -top-6 h-48 w-full",
									loading: "lazy"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "pointer-events-none absolute right-2 top-2 inline-flex items-center gap-1 rounded-full bg-emerald-500 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-white shadow",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-white" }), " Pinned"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-secondary/40 px-3 py-1.5 text-left font-mono text-[11px] text-muted-foreground",
								children: [
									lat.toFixed(6),
									", ",
									lng.toFixed(6)
								]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[11px] text-muted-foreground",
							children: "Tap \"Pick on map\" to drop a pin so players can find your venue."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPicker, {
						open: pickerOpen,
						initialLat: lat,
						initialLng: lng,
						onClose: () => setPickerOpen(false),
						onSave: (la, ln) => {
							setLat(la);
							setLng(ln);
							setPickerOpen(false);
							const s = suggestTimezone(la, ln);
							if (s) {
								setTimezone(s.tz);
								setTzConfirmed(false);
							}
						},
						title: "Pin your venue"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2 rounded-xl border border-border bg-secondary/20 p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiPicker, {
							label: "Map emoji (venue pin)",
							value: mapEmoji,
							fallback: "🎾",
							onChange: setMapEmoji,
							hint: "Shown on the landing-page map. Individual courts can override this."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							label: "About this Venue (optional)",
							value: description,
							onChange: setDescription,
							placeholder: "Tell players about your venue — parking, amenities, house rules…"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
							label: "Venue photos",
							pathPrefix: uploadPrefix,
							images,
							onChange: setImages
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagInput, {
							label: "Amenities",
							values: amenities,
							onChange: setAmenities,
							placeholder: "e.g. Parking, Showers, Wi-Fi",
							hint: "Press Enter or comma to add. Shown to players on the venue page."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagInput, {
							label: "Food & Beverages",
							values: foodBeverages,
							onChange: setFoodBeverages,
							placeholder: "e.g. Cafe, Vending machine, Water refill"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagInput, {
							label: "Facility Services",
							values: facilityServices,
							onChange: setFacilityServices,
							placeholder: "e.g. Racket rental, Coaching, Ball machine"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeesEditor, {
							items: fees,
							onChange: setFees,
							notes: feesNotes,
							onNotesChange: setFeesNotes
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Inquiry phone (shown to players)",
						value: contactPhone,
						onChange: setContactPhone
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Inquiry email (optional)",
						value: contactEmail,
						onChange: setContactEmail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OperatingHoursEditor, {
							hours: openHours,
							onChange: setOpenHours,
							hint: "Courts follow these hours by default. Players can only book inside this window, and closed hours are hidden everywhere."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							label: "Operating hours note (optional)",
							value: operatingHoursText,
							onChange: setOperatingHoursText,
							placeholder: "Extra note shown to players, e.g. Holiday hours may vary"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted-foreground",
								children: "Cancellation cutoff (hours before start)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 0,
								step: 1,
								value: cancellationHours,
								onChange: (e) => setCancellationHours(Number(e.target.value)),
								className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-[11px] text-muted-foreground",
								children: "Default 24h. Set to 0 to allow last-minute cancellations."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							label: "Cancellation policy notes (optional)",
							value: cancellationNotes,
							onChange: setCancellationNotes,
							placeholder: "e.g. Full refund up to 24h before. 50% within 24h. No refund after start."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							label: "Venue rules (one per line)",
							value: rules,
							onChange: setRules,
							placeholder: "e.g.\n- Wear non-marking shoes\n- No outside food or drinks\n- Arrive 10 minutes early"
						})
					}),
					pinOutsidePH && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-xs text-destructive",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Location not supported." }),
							" CourtHub is currently available for venues in the ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Philippines" }),
							" only. Please move your pin within the Philippines to continue."
						]
					}),
					tzMismatch && pinInPH && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2 rounded-lg border border-amber-400/50 bg-amber-50 px-3 py-2 text-xs text-amber-900 dark:bg-amber-500/10 dark:text-amber-200",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Timezone doesn't match your pin." }),
								" Based on your map location this venue looks like it's in ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: suggested?.country }),
								" (",
								suggested?.tz,
								"), but you selected ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: timezone }),
								". Court hours and bookings will display in the wrong local time if this is incorrect."
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => {
									setTimezone(suggested.tz);
									setTzConfirmed(false);
								},
								className: "shrink-0 rounded-md border border-amber-500/60 bg-background px-2 py-1 text-[11px] font-semibold text-amber-800 hover:bg-amber-100 dark:text-amber-100",
								children: ["Use ", suggested?.tz]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-2 flex items-center gap-2 text-[11px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: tzConfirmed,
									onChange: (e) => setTzConfirmed(e.target.checked)
								}),
								"I confirm this venue uses ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono",
									children: timezone
								}),
								" even though the pin is elsewhere."
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2 flex items-center gap-2 rounded-lg border border-border bg-secondary/20 px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: isActive,
									onChange: (e) => setIsActive(e.target.checked),
									className: "h-4 w-4 accent-primary"
								}), "Active"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								tabIndex: 0,
								role: "button",
								"aria-label": "About the active status",
								title: ACTIVE_INFO_TEXT,
								className: "grid h-4 w-4 cursor-help place-items-center rounded-full border border-muted-foreground/40 text-[10px] font-bold text-muted-foreground hover:border-primary hover:text-primary",
								children: "?"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto text-[11px] text-muted-foreground",
								children: "Ticked by default — the venue will appear on the landing page."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: mut.isPending || pinOutsidePH || tzMismatch && !tzConfirmed,
							className: "rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60",
							children: mut.isPending ? "Creating…" : "Create venue"
						}), onCancel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onCancel,
							className: "rounded-lg border border-border px-4 py-2 text-sm",
							children: "Cancel"
						})]
					}),
					err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "sm:col-span-2 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive",
						children: err
					})
				]
			})
		]
	});
}
function fmtHour(x) {
	const p = x < 12 ? "AM" : "PM";
	return `${x % 12 === 0 ? 12 : x % 12}:00 ${p}`;
}
function buildInitialWeekly(source) {
	const out = {};
	for (const d of DAYS) out[d.key] = new Set(source?.[d.key] ?? []);
	return out;
}
function buildInitialDates(source) {
	const map = {};
	for (const [date, hrs] of Object.entries(source ?? {})) map[date] = new Set(hrs);
	return map;
}
function weeklyToPayload(weekly) {
	const out = {};
	for (const d of DAYS) out[d.key] = Array.from(weekly[d.key] ?? []).sort((a, b) => a - b);
	return out;
}
function datesToPayload(dateBlocks) {
	const out = {};
	for (const [date, set] of Object.entries(dateBlocks)) out[date] = Array.from(set).sort((a, b) => a - b);
	return out;
}
function AvailabilityGrid({ weekly, setWeekly, dateBlocks, setDateBlocks, hours }) {
	const [mode, setMode] = (0, import_react.useState)("weekly");
	const openOnDay = (day) => hours ? openHoursForDay(hours, day) : null;
	const toggleWeekly = (day, hour) => {
		setWeekly((prev) => {
			const next = {
				...prev,
				[day]: new Set(prev[day])
			};
			if (next[day].has(hour)) next[day].delete(hour);
			else next[day].add(hour);
			return next;
		});
	};
	const setAllDayWeekly = (day, block) => {
		setWeekly((prev) => ({
			...prev,
			[day]: new Set(block ? Array.from({ length: 24 }, (_, i) => i) : [])
		}));
	};
	const localISO = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
	const shiftDate = (iso, days) => {
		const d = /* @__PURE__ */ new Date(`${iso}T00:00:00`);
		d.setDate(d.getDate() + days);
		return localISO(d);
	};
	const [selectedDate, setSelectedDate] = (0, import_react.useState)(localISO(/* @__PURE__ */ new Date()));
	const hasOverride = Object.prototype.hasOwnProperty.call(dateBlocks, selectedDate);
	const currentDateSet = dateBlocks[selectedDate] ?? /* @__PURE__ */ new Set();
	const toggleDate = (hour) => {
		setDateBlocks((prev) => {
			const set = new Set(prev[selectedDate] ?? []);
			if (set.has(hour)) set.delete(hour);
			else set.add(hour);
			return {
				...prev,
				[selectedDate]: set
			};
		});
	};
	const setAllForDate = (block) => {
		setDateBlocks((prev) => ({
			...prev,
			[selectedDate]: new Set(block ? Array.from({ length: 24 }, (_, i) => i) : [])
		}));
	};
	const clearOverride = () => {
		setDateBlocks((prev) => {
			const next = { ...prev };
			delete next[selectedDate];
			return next;
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "inline-flex rounded-lg border border-border bg-background p-0.5 text-xs",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setMode("weekly"),
				className: "rounded-md px-3 py-1.5 font-semibold " + (mode === "weekly" ? "bg-primary text-primary-foreground" : "text-muted-foreground"),
				children: "Weekly pattern"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setMode("date"),
				className: "rounded-md px-3 py-1.5 font-semibold " + (mode === "date" ? "bg-primary text-primary-foreground" : "text-muted-foreground"),
				children: "Specific date"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-[11px] text-muted-foreground",
			children: "Tap an hour to block it (red = closed to players). Weekly rules repeat every week. Specific-date overrides apply only to that date and do NOT inherit weekly blocks. Past hours and hours already booked by players are also unavailable automatically."
		}),
		mode === "weekly" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 space-y-3",
			children: DAYS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border bg-background p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-semibold",
						children: d.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1 text-[10px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setAllDayWeekly(d.key, false),
							className: "rounded border border-border px-2 py-0.5 hover:border-primary hover:text-primary",
							children: "Open all"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setAllDayWeekly(d.key, true),
							className: "rounded border border-border px-2 py-0.5 hover:border-destructive hover:text-destructive",
							children: "Close all"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 grid grid-cols-1 gap-1.5 sm:grid-cols-2 lg:grid-cols-3",
					children: Array.from({ length: 24 }, (_, h) => h).map((h) => {
						const open = openOnDay(d.key);
						const closed = !!open && !open.has(h);
						const isBlocked = weekly[d.key]?.has(h);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: closed,
							onClick: () => toggleWeekly(d.key, h),
							title: closed ? "Outside operating hours" : void 0,
							className: "rounded px-2 py-1.5 text-[11px] font-semibold leading-tight tabular-nums whitespace-nowrap transition " + (closed ? "cursor-not-allowed bg-muted text-muted-foreground/60 line-through" : isBlocked ? "bg-destructive/15 text-destructive ring-1 ring-destructive/30" : "bg-primary/10 text-foreground hover:bg-primary/20"),
							children: [
								fmtHour(h),
								" – ",
								fmtHour((h + 1) % 24)
							]
						}, h);
					})
				})]
			}, d.key))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 rounded-lg border border-border bg-background p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Date:"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSelectedDate(shiftDate(selectedDate, -1)),
							className: "rounded border border-border px-2 py-1 hover:border-primary hover:text-primary",
							children: "←"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							value: selectedDate,
							onChange: (e) => setSelectedDate(e.target.value),
							className: "rounded border border-input bg-background px-2 py-1"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSelectedDate(shiftDate(selectedDate, 1)),
							className: "rounded border border-border px-2 py-1 hover:border-primary hover:text-primary",
							children: "→"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 rounded-full px-2 py-0.5 " + (hasOverride ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"),
							children: hasOverride ? "Override active (weekly ignored)" : "No override · weekly applies"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-1 text-[10px]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setAllForDate(false),
							className: "rounded border border-border px-2 py-0.5 hover:border-primary hover:text-primary",
							children: "Open all day"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setAllForDate(true),
							className: "rounded border border-border px-2 py-0.5 hover:border-destructive hover:text-destructive",
							children: "Close all day"
						}),
						hasOverride && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: clearOverride,
							className: "rounded border border-border px-2 py-0.5 hover:border-primary hover:text-primary",
							children: "Remove override (use weekly)"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-1 gap-1.5 sm:grid-cols-2 lg:grid-cols-3",
					children: Array.from({ length: 24 }, (_, h) => h).map((h) => {
						const openSet = hours ? openHoursForDate(hours, selectedDate) : null;
						const closed = !!openSet && !openSet.has(h);
						const isBlocked = currentDateSet.has(h);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: closed,
							onClick: () => toggleDate(h),
							title: closed ? "Outside operating hours" : void 0,
							className: "rounded px-2 py-1.5 text-[11px] font-semibold leading-tight tabular-nums whitespace-nowrap transition " + (closed ? "cursor-not-allowed bg-muted text-muted-foreground/60 line-through" : isBlocked ? "bg-destructive/15 text-destructive ring-1 ring-destructive/30" : "bg-primary/10 text-foreground hover:bg-primary/20"),
							children: [
								fmtHour(h),
								" – ",
								fmtHour((h + 1) % 24)
							]
						}, h);
					})
				}),
				Object.keys(dateBlocks).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 border-t border-border pt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] font-semibold uppercase tracking-wider text-muted-foreground",
						children: "Existing overrides"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 flex flex-wrap gap-1.5",
						children: Object.entries(dateBlocks).sort(([a], [b]) => a.localeCompare(b)).map(([date, set]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelectedDate(date),
							className: "rounded-full border px-2 py-0.5 text-[11px] " + (date === selectedDate ? "border-primary bg-primary/10 text-primary" : "border-border hover:border-primary hover:text-primary"),
							children: [
								(/* @__PURE__ */ new Date(`${date}T00:00:00`)).toLocaleDateString(),
								" · ",
								set.size,
								" hr",
								set.size === 1 ? "" : "s"
							]
						}) }, date))
					})]
				})
			]
		})
	] });
}
function useVenueHours(venueId) {
	return useQuery({
		queryKey: ["venue-hours", venueId],
		enabled: !!venueId,
		queryFn: async () => {
			const { data, error } = await supabase.from("venues").select("operating_hours").eq("id", venueId).single();
			if (error) throw error;
			return normalizeHours(data.operating_hours);
		}
	}).data ?? fullWeek();
}
function AvailabilityEditor({ court, onDone, onCancel }) {
	const [err, setErr] = (0, import_react.useState)(null);
	const courtHours = effectiveHours(court, useVenueHours(court.venue_id));
	const [weekly, setWeekly] = (0, import_react.useState)(() => buildInitialWeekly(court.blocked_hours));
	const [dateBlocks, setDateBlocks] = (0, import_react.useState)(() => buildInitialDates(court.blocked_dates));
	const mut = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("courts").update({
				blocked_hours: weeklyToPayload(weekly),
				blocked_dates: datesToPayload(dateBlocks)
			}).eq("id", court.id);
			if (error) throw error;
		},
		onSuccess: onDone,
		onError: (e) => setErr(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "col-span-full rounded-xl border border-primary/40 bg-secondary/30 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "font-semibold",
					children: ["Availability · ", court.name]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Hours outside the operating window are greyed out. Use this to block extra hours inside opening hours, or override a specific date."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onCancel,
						type: "button",
						className: "rounded-lg border border-border px-3 py-1.5 text-xs",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => mut.mutate(),
						disabled: mut.isPending,
						className: "rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground disabled:opacity-60",
						children: mut.isPending ? "Saving…" : "Save"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvailabilityGrid, {
					weekly,
					setWeekly,
					dateBlocks,
					setDateBlocks,
					hours: courtHours
				})
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive",
				children: err
			})
		]
	});
}
function InlineAvailability({ weekly, setWeekly, dateBlocks, setDateBlocks, hours }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const weeklyBlocked = DAYS.reduce((s, d) => s + (weekly[d.key]?.size ?? 0), 0);
	const dateOverrides = Object.keys(dateBlocks).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 rounded-xl border border-primary/30 bg-primary/5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setOpen((v) => !v),
			className: "flex w-full items-center justify-between gap-2 px-3 py-2.5 text-left",
			"aria-expanded": open,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs font-semibold uppercase tracking-wider text-primary",
				children: "Manage availability (optional)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-0.5 text-[11px] text-muted-foreground",
				children: weeklyBlocked === 0 && dateOverrides === 0 ? "All hours open by default. Tap to block specific weekly hours or add date overrides." : `${weeklyBlocked} weekly blocked hour${weeklyBlocked === 1 ? "" : "s"} · ${dateOverrides} date override${dateOverrides === 1 ? "" : "s"}`
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-primary transition-transform " + (open ? "rotate-180" : ""),
				children: "▾"
			})]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-primary/20 p-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvailabilityGrid, {
				weekly,
				setWeekly,
				dateBlocks,
				setDateBlocks,
				hours
			})
		})]
	});
}
function useSportsQuery(enabled) {
	return useQuery({
		queryKey: ["sports"],
		queryFn: async () => {
			const { data, error } = await supabase.from("sports").select("id, name, slug").order("name");
			if (error) throw error;
			return data;
		},
		enabled
	});
}
function sportEmoji(slug) {
	switch (slug) {
		case "pickleball": return "🥎";
		case "tennis": return "🎾";
		case "basketball": return "🏀";
		case "table-tennis": return "🏓";
		case "badminton": return "🏸";
		case "volleyball": return "🏐";
		case "football":
		case "soccer": return "⚽";
		default: return "🏟️";
	}
}
function AddCourt({ venueId, venueEmoji, onCreated, alwaysOpen, onCancel }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [rate, setRate] = (0, import_react.useState)("25");
	const [sportId, setSportId] = (0, import_react.useState)("");
	const [isIndoor, setIsIndoor] = (0, import_react.useState)(false);
	const [comingSoon, setComingSoon] = (0, import_react.useState)(false);
	const [isActive, setIsActive] = (0, import_react.useState)(true);
	const [description, setDescription] = (0, import_react.useState)("");
	const [images, setImages] = (0, import_react.useState)([]);
	const [mapEmoji, setMapEmoji] = (0, import_react.useState)(null);
	const [surfaceType, setSurfaceType] = (0, import_react.useState)("");
	const [playerCapacity, setPlayerCapacity] = (0, import_react.useState)("");
	const [availWeekly, setAvailWeekly] = (0, import_react.useState)(() => buildInitialWeekly(null));
	const [availDates, setAvailDates] = (0, import_react.useState)(() => buildInitialDates(null));
	const [voucherEnabled, setVoucherEnabled] = (0, import_react.useState)(false);
	const [rateRules, setRateRules] = (0, import_react.useState)([]);
	const venueHours = useVenueHours(venueId);
	const [inheritHours, setInheritHours] = (0, import_react.useState)(true);
	const [ownHours, setOwnHours] = (0, import_react.useState)(() => fullWeek());
	const courtHours = inheritHours ? venueHours : ownHours;
	const [err, setErr] = (0, import_react.useState)(null);
	const sportsQ = useSportsQuery(open || !!alwaysOpen);
	const selectedSport = sportsQ.data?.find((s) => String(s.id) === sportId);
	const fallbackEmoji = venueEmoji || sportEmoji(selectedSport?.slug) || "🎾";
	const mut = useMutation({
		mutationFn: async () => {
			const { data: pcRow, error: pcErr } = await supabase.from("physical_courts").insert({
				venue_id: venueId,
				name: `${name.trim() || "Court"} slab`,
				map_emoji: mapEmoji ?? venueEmoji ?? null
			}).select("id").single();
			if (pcErr) throw pcErr;
			const pcId = pcRow.id;
			const createdPcId = pcRow.id;
			const cap = 1;
			const footprint = 1 / cap;
			const { error } = await supabase.from("courts").insert({
				venue_id: venueId,
				sport_id: Number(sportId),
				physical_court_id: pcId,
				capacity: cap,
				footprint,
				name,
				hourly_rate: Number(rate),
				is_indoor: isIndoor,
				coming_soon: comingSoon,
				is_active: isActive,
				description: description || null,
				images,
				map_emoji: mapEmoji,
				surface_type: surfaceType.trim() || null,
				player_capacity: playerCapacity ? Math.max(1, Math.floor(Number(playerCapacity))) : null,
				blocked_hours: weeklyToPayload(availWeekly),
				blocked_dates: datesToPayload(availDates),
				voucher_enabled: voucherEnabled,
				rate_rules: normalizeRules(rateRules),
				inherit_venue_hours: inheritHours,
				operating_hours: inheritHours ? {} : ownHours
			});
			if (error) {
				if (createdPcId !== null) await supabase.from("physical_courts").delete().eq("id", createdPcId);
				throw error;
			}
		},
		onSuccess: () => {
			setOpen(false);
			setName("");
			setRate("25");
			setSportId("");
			setIsIndoor(false);
			setComingSoon(false);
			setIsActive(true);
			setDescription("");
			setImages([]);
			setMapEmoji(null);
			setSurfaceType("");
			setPlayerCapacity("");
			setAvailWeekly(buildInitialWeekly(null));
			setAvailDates(buildInitialDates(null));
			setVoucherEnabled(false);
			setRateRules([]);
			setErr(null);
			onCreated();
		},
		onError: (e) => setErr(e.message)
	});
	if (!open && !alwaysOpen) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick: () => setOpen(true),
		className: "grid min-h-32 place-items-center rounded-xl border-2 border-dashed border-border p-4 text-sm font-medium text-muted-foreground hover:border-primary hover:text-primary",
		children: "+ Add court"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (!sportId) {
				setErr("Pick a sport");
				return;
			}
			mut.mutate();
		},
		className: "col-span-full rounded-xl border border-border bg-secondary/30 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Court name",
						value: name,
						onChange: setName,
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Hourly rate (₱)",
						value: rate,
						onChange: setRate,
						type: "number",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Sport"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: sportId,
							onChange: (e) => setSportId(e.target.value),
							required: true,
							className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Select…"
							}), (sportsQ.data ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s.id,
								children: s.name
							}, s.id))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-end gap-2 pb-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: isIndoor,
							onChange: (e) => setIsIndoor(e.target.checked)
						}), "Indoor court"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-end gap-2 pb-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: comingSoon,
							onChange: (e) => setComingSoon(e.target.checked)
						}), "Coming soon"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-end gap-2 pb-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: voucherEnabled,
							onChange: (e) => setVoucherEnabled(e.target.checked)
						}), "Accept vouchers"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtStatusField, {
						value: isActive,
						onChange: setIsActive
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-[11px] text-muted-foreground",
				children: "Tick \"Coming soon\" if this court isn't open yet. Tick \"Accept vouchers\" to let players redeem discount codes you create in the Vouchers module for this court."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RateRulesEditor, {
				baseRate: Number(rate) || 0,
				rules: rateRules,
				onChange: setRateRules
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtHoursEditor, {
				inherit: inheritHours,
				onInheritChange: setInheritHours,
				hours: ownHours,
				onHoursChange: setOwnHours,
				venueHours
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Surface type"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							list: "court-surface-suggestions",
							value: surfaceType,
							onChange: (e) => setSurfaceType(e.target.value),
							placeholder: "e.g. Hardwood, Concrete, Synthetic, Clay, Rubber, Acrylic",
							className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("datalist", {
							id: "court-surface-suggestions",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Hardwood" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Concrete" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Synthetic" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Acrylic" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Rubber" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Clay" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Grass" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Artificial turf" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Vinyl flooring" })
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					label: "Player capacity (max players per match)",
					value: playerCapacity,
					onChange: setPlayerCapacity,
					type: "number"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						label: "About this Court",
						value: description,
						onChange: setDescription,
						placeholder: "Court size, surface, lighting, rules, etc."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
						label: "Court photos",
						pathPrefix: `courts/venue-${venueId}/new-${Date.now()}`,
						images,
						onChange: setImages
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-xl border border-border bg-background p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiPicker, {
							label: "Court map emoji",
							value: mapEmoji,
							fallback: fallbackEmoji,
							onChange: setMapEmoji,
							hint: "Falls back to the venue emoji, then the sport default."
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineAvailability, {
				weekly: availWeekly,
				setWeekly: setAvailWeekly,
				dateBlocks: availDates,
				setDateBlocks: setAvailDates,
				hours: courtHours
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive",
				children: err
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					disabled: mut.isPending,
					className: "rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60",
					children: mut.isPending ? "Adding…" : "Add court"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						if (onCancel) onCancel();
						else setOpen(false);
					},
					className: "rounded-lg border border-border px-4 py-2 text-sm",
					children: "Cancel"
				})]
			})
		]
	});
}
function AddCourtDrawer({ open, onClose, venues, onCreated }) {
	const [venueId, setVenueId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setVenueId(venues.length === 1 ? venues[0].id : null);
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			window.removeEventListener("keydown", onKey);
			document.body.style.overflow = prev;
		};
	}, [
		open,
		onClose,
		venues
	]);
	const selectedVenue = venues.find((v) => v.id === venueId) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-1200 " + (open ? "pointer-events-auto" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			onClick: onClose,
			className: "absolute inset-0 bg-black/40 transition-opacity duration-300 " + (open ? "opacity-100" : "opacity-0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "absolute right-0 top-0 h-full w-full max-w-xl overflow-y-auto bg-background shadow-2xl transition-transform duration-300 ease-out " + (open ? "translate-x-0" : "translate-x-full"),
			role: "dialog",
			"aria-modal": "true",
			"aria-label": "Add court",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background/95 px-4 py-3 backdrop-blur sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold",
					children: "Add court"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					"aria-label": "Close",
					className: "rounded-md border border-border px-2 py-1 text-sm hover:bg-secondary",
					children: "✕"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 p-4 sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Venue"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: venueId ?? "",
							onChange: (e) => setVenueId(e.target.value ? Number(e.target.value) : null),
							className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Select a venue…"
							}), venues.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: v.id,
								children: v.name
							}, v.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[11px] text-muted-foreground",
							children: "Choose which venue this court belongs to."
						})
					]
				}), selectedVenue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddCourt, {
					venueId: selectedVenue.id,
					venueEmoji: selectedVenue.map_emoji ?? null,
					alwaysOpen: true,
					onCancel: onClose,
					onCreated
				}, selectedVenue.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground",
					children: "Pick a venue above to start adding a court."
				})]
			})]
		})]
	});
}
function EditCourt({ court, venueEmoji, onDone, onCancel }) {
	const [name, setName] = (0, import_react.useState)(court.name);
	const [rate, setRate] = (0, import_react.useState)(String(court.hourly_rate));
	const [sportId, setSportId] = (0, import_react.useState)(String(court.sport_id ?? ""));
	const [isIndoor, setIsIndoor] = (0, import_react.useState)(court.is_indoor);
	const [comingSoon, setComingSoon] = (0, import_react.useState)(!!court.coming_soon);
	const [isActive, setIsActive] = (0, import_react.useState)(court.is_active !== false);
	const [description, setDescription] = (0, import_react.useState)(court.description ?? "");
	const [images, setImages] = (0, import_react.useState)(court.images ?? []);
	const [mapEmoji, setMapEmoji] = (0, import_react.useState)(court.map_emoji ?? null);
	const [surfaceType, setSurfaceType] = (0, import_react.useState)(court.surface_type ?? "");
	const [playerCapacity, setPlayerCapacity] = (0, import_react.useState)((court.player_capacity ?? "") === null ? "" : String(court.player_capacity ?? ""));
	const [availWeekly, setAvailWeekly] = (0, import_react.useState)(() => buildInitialWeekly(court.blocked_hours));
	const [availDates, setAvailDates] = (0, import_react.useState)(() => buildInitialDates(court.blocked_dates));
	const [voucherEnabled, setVoucherEnabled] = (0, import_react.useState)(!!court.voucher_enabled);
	const [rateRules, setRateRules] = (0, import_react.useState)(() => normalizeRules(court.rate_rules));
	const venueHours = useVenueHours(court.venue_id);
	const [inheritHours, setInheritHours] = (0, import_react.useState)(court.inherit_venue_hours !== false);
	const [ownHours, setOwnHours] = (0, import_react.useState)(() => normalizeHours(court.operating_hours));
	const courtHours = inheritHours ? venueHours : ownHours;
	const [err, setErr] = (0, import_react.useState)(null);
	const sportsQ = useSportsQuery(true);
	const sharedSpaceQ = useQuery({
		queryKey: [
			"edit-court-shared-space",
			court.id,
			court.physical_court_id
		],
		enabled: !!court.physical_court_id,
		queryFn: async () => {
			const [groupRes, membersRes, rulesRes] = await Promise.all([
				supabase.from("physical_courts").select("id, name").eq("id", court.physical_court_id).maybeSingle(),
				supabase.from("courts").select("id, name, sports(name)").eq("physical_court_id", court.physical_court_id).order("id"),
				supabase.from("court_block_rules").select("court_id, blocked_court_id").or(`court_id.eq.${court.id},blocked_court_id.eq.${court.id}`)
			]);
			if (groupRes.error) throw groupRes.error;
			if (membersRes.error) throw membersRes.error;
			if (rulesRes.error) throw rulesRes.error;
			const members = membersRes.data ?? [];
			const names = new Map(members.map((member) => [member.id, member.name]));
			return {
				groupName: groupRes.data?.name ?? "Shared space",
				members,
				blocks: (rulesRes.data ?? []).filter((rule) => rule.court_id === court.id).map((rule) => names.get(rule.blocked_court_id) ?? `Court #${rule.blocked_court_id}`),
				blockedBy: (rulesRes.data ?? []).filter((rule) => rule.blocked_court_id === court.id).map((rule) => names.get(rule.court_id) ?? `Court #${rule.court_id}`)
			};
		}
	});
	const selectedSport = sportsQ.data?.find((s) => String(s.id) === sportId);
	const fallbackEmoji = venueEmoji || sportEmoji(selectedSport?.slug ?? court.sports?.slug) || "🎾";
	const sharedSpace = sharedSpaceQ.data;
	const isSharedSpace = (sharedSpace?.members.length ?? 0) >= 2;
	const mut = useMutation({
		mutationFn: async () => {
			const { error } = await supabase.from("courts").update({
				name,
				hourly_rate: Number(rate),
				sport_id: Number(sportId),
				is_indoor: isIndoor,
				coming_soon: comingSoon,
				is_active: isActive,
				description: description || null,
				images,
				map_emoji: mapEmoji,
				surface_type: surfaceType.trim() || null,
				player_capacity: playerCapacity ? Math.max(1, Math.floor(Number(playerCapacity))) : null,
				blocked_hours: weeklyToPayload(availWeekly),
				blocked_dates: datesToPayload(availDates),
				voucher_enabled: voucherEnabled,
				rate_rules: normalizeRules(rateRules),
				inherit_venue_hours: inheritHours,
				operating_hours: inheritHours ? {} : ownHours
			}).eq("id", court.id);
			if (error) throw error;
		},
		onSuccess: onDone,
		onError: (e) => setErr(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: (e) => {
			e.preventDefault();
			if (!sportId) {
				setErr("Pick a sport");
				return;
			}
			mut.mutate();
		},
		className: "col-span-full rounded-xl border border-primary/40 bg-secondary/30 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Court name",
						value: name,
						onChange: setName,
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Hourly rate (₱)",
						value: rate,
						onChange: setRate,
						type: "number",
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Sport"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: sportId,
							onChange: (e) => setSportId(e.target.value),
							required: true,
							className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Select…"
							}), (sportsQ.data ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s.id,
								children: s.name
							}, s.id))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-end gap-2 pb-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: isIndoor,
							onChange: (e) => setIsIndoor(e.target.checked)
						}), "Indoor court"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-end gap-2 pb-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: comingSoon,
							onChange: (e) => setComingSoon(e.target.checked)
						}), "Coming soon"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-end gap-2 pb-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: voucherEnabled,
							onChange: (e) => setVoucherEnabled(e.target.checked)
						}), "Accept vouchers"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtStatusField, {
						value: isActive,
						onChange: setIsActive
					})
				]
			}),
			isSharedSpace && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center gap-2 rounded-xl border border-primary/30 bg-primary/5 px-3 py-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full border border-primary/30 bg-background px-2 py-1 text-[11px] font-semibold text-primary",
						children: "Shared space"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HoverCard, {
						openDelay: 150,
						closeDelay: 100,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoverCardTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Shared space details",
								className: "inline-flex h-5 w-5 items-center justify-center rounded-full border border-primary/50 text-[11px] font-bold text-primary hover:bg-primary/10",
								children: "?"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HoverCardContent, {
							align: "start",
							className: "w-80 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold text-foreground",
									children: "Shared space details"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-muted-foreground",
									children: [
										"This court belongs to ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium text-foreground",
											children: sharedSpace.groupName
										}),
										" with ",
										sharedSpace.members.filter((member) => member.id !== court.id).length,
										" linked court",
										sharedSpace.members.length === 2 ? "" : "s",
										"."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 space-y-2 rounded-lg border border-border bg-secondary/30 p-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-foreground",
											children: "Blocks:"
										}),
										" ",
										sharedSpace.blocks.length ? sharedSpace.blocks.join(", ") : "No courts"
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-foreground",
											children: "Blocked by:"
										}),
										" ",
										sharedSpace.blockedBy.length ? sharedSpace.blockedBy.join(", ") : "No courts"
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-muted-foreground",
									children: "Manage linked courts and directional rules from the Court Groups tab."
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "This court shares a physical playing area."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RateRulesEditor, {
				baseRate: Number(rate) || 0,
				rules: rateRules,
				onChange: setRateRules
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtHoursEditor, {
				inherit: inheritHours,
				onInheritChange: setInheritHours,
				hours: ownHours,
				onHoursChange: setOwnHours,
				venueHours
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Surface type"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							list: "court-surface-suggestions-edit",
							value: surfaceType,
							onChange: (e) => setSurfaceType(e.target.value),
							placeholder: "e.g. Hardwood, Concrete, Synthetic, Clay, Rubber, Acrylic",
							className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("datalist", {
							id: "court-surface-suggestions-edit",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Hardwood" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Concrete" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Synthetic" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Acrylic" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Rubber" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Clay" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Grass" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Artificial turf" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "Vinyl flooring" })
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					label: "Player capacity (max players per match)",
					value: playerCapacity,
					onChange: setPlayerCapacity,
					type: "number"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						label: "About this Court",
						value: description,
						onChange: setDescription
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
						label: "Court photos",
						pathPrefix: `courts/${court.id}`,
						images,
						onChange: setImages
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-xl border border-border bg-background p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiPicker, {
							label: "Court map emoji",
							value: mapEmoji,
							fallback: fallbackEmoji,
							onChange: setMapEmoji,
							hint: "Falls back to the venue emoji, then the sport default."
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineAvailability, {
				weekly: availWeekly,
				setWeekly: setAvailWeekly,
				dateBlocks: availDates,
				setDateBlocks: setAvailDates,
				hours: courtHours
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive",
				children: err
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					disabled: mut.isPending,
					className: "rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60",
					children: mut.isPending ? "Saving…" : "Save changes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onCancel,
					className: "rounded-lg border border-border px-4 py-2 text-sm",
					children: "Cancel"
				})]
			})
		]
	});
}
function Textarea(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium text-muted-foreground",
			children: props.label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			value: props.value,
			onChange: (e) => props.onChange(e.target.value),
			placeholder: props.placeholder,
			rows: 3,
			className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
		})]
	});
}
function Input(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium text-muted-foreground",
			children: props.label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: props.type ?? "text",
			required: props.required,
			value: props.value,
			onChange: (e) => props.onChange(e.target.value),
			className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
		})]
	});
}
function osmEmbedUrl(lat, lng, delta = .005) {
	return `https://www.openstreetmap.org/export/embed.html?bbox=${[
		lng - delta,
		lat - delta,
		lng + delta,
		lat + delta
	].join(",")}&layer=mapnik&marker=${lat},${lng}`;
}
function VenueLocation({ venue, onSaved }) {
	const [pickerOpen, setPickerOpen] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	const [mapView, setMapView] = (0, import_react.useState)("internal");
	const [internalOpen, setInternalOpen] = (0, import_react.useState)(false);
	const mut = useMutation({
		mutationFn: async ({ lat, lng }) => {
			const { error } = await supabase.from("venues").update({
				latitude: lat,
				longitude: lng
			}).eq("id", venue.id);
			if (error) throw error;
		},
		onSuccess: () => {
			setPickerOpen(false);
			setErr(null);
			onSaved();
		},
		onError: (e) => setErr(e.message)
	});
	const hasLoc = venue.latitude != null && venue.longitude != null;
	const googleEmbedUrl = (lat, lng) => `https://maps.google.com/maps?q=${lat},${lng}&z=15&output=embed`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full sm:w-72",
		children: [
			hasLoc ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-xl border border-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 border-b border-border bg-secondary/40 p-1 text-[11px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMapView("internal"),
							className: `flex-1 rounded-md px-2 py-1 font-medium transition ${mapView === "internal" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
							children: "🗺️ Internal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMapView("google"),
							className: `flex-1 rounded-md px-2 py-1 font-medium transition ${mapView === "google" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`,
							children: "🌐 Google"
						})]
					}),
					mapView === "internal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setInternalOpen(true),
						className: "group relative block w-full text-left",
						title: "View on internal map",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative h-32 w-full overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
								title: `${venue.name} map`,
								src: osmEmbedUrl(venue.latitude, venue.longitude),
								className: "pointer-events-none absolute left-0 right-0 -top-6 h-48 w-full",
								loading: "lazy"
							}, "internal")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pointer-events-none absolute inset-0 flex items-center justify-center bg-black/0 text-xs font-semibold text-transparent transition group-hover:bg-black/40 group-hover:text-white",
							children: "🔍 View on map"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `https://www.google.com/maps?q=${venue.latitude},${venue.longitude}`,
						target: "_blank",
						rel: "noreferrer",
						className: "group relative block w-full",
						title: "Open in Google Maps",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative h-32 w-full overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
								title: `${venue.name} map`,
								src: googleEmbedUrl(venue.latitude, venue.longitude),
								className: "pointer-events-none absolute inset-0 h-full w-full",
								loading: "lazy"
							}, "google")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pointer-events-none absolute inset-0 flex items-center justify-center bg-black/0 text-xs font-semibold text-transparent transition group-hover:bg-black/40 group-hover:text-white",
							children: "🔍 Open in Google Maps"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-end gap-2 bg-secondary/40 px-3 py-2 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setPickerOpen(true),
							className: "rounded-md border border-border bg-background px-2 py-1 font-medium hover:border-primary hover:text-primary",
							children: "Edit pin"
						})
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setPickerOpen(true),
				className: "w-full rounded-xl border-2 border-dashed border-border px-3 py-4 text-xs font-medium text-muted-foreground hover:border-primary hover:text-primary",
				children: "📍 Add map location"
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 rounded-md bg-destructive/10 px-2 py-1 text-xs text-destructive",
				children: err
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPicker, {
				open: pickerOpen,
				initialLat: venue.latitude,
				initialLng: venue.longitude,
				onClose: () => setPickerOpen(false),
				onSave: (lat, lng) => mut.mutate({
					lat,
					lng
				}),
				saving: mut.isPending,
				title: `Pin ${venue.name}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapViewModal, {
				venue: internalOpen ? venue : null,
				onClose: () => setInternalOpen(false)
			})
		]
	});
}
function VenueEditor({ venue, courtsCount, initialEditing = false, onDoneEditing }) {
	const qc = useQueryClient();
	const [editing, setEditing] = (0, import_react.useState)(initialEditing);
	const [confirmDel, setConfirmDel] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)(venue.name);
	const [address, setAddress] = (0, import_react.useState)(venue.address);
	const [description, setDescription] = (0, import_react.useState)(venue.description ?? "");
	const [images, setImages] = (0, import_react.useState)(venue.images ?? []);
	const [timezone, setTimezone] = (0, import_react.useState)(venue.timezone || "Asia/Manila");
	const [mapEmoji, setMapEmoji] = (0, import_react.useState)(venue.map_emoji ?? null);
	const [err, setErr] = (0, import_react.useState)(null);
	const [delErr, setDelErr] = (0, import_react.useState)(null);
	const [tzConfirmed, setTzConfirmed] = (0, import_react.useState)(false);
	const [isActive, setIsActive] = (0, import_react.useState)(venue.is_active !== false);
	const [amenities, setAmenities] = (0, import_react.useState)(venue.amenities ?? []);
	const [foodBeverages, setFoodBeverages] = (0, import_react.useState)(venue.food_beverages ?? []);
	const [facilityServices, setFacilityServices] = (0, import_react.useState)(venue.facility_services ?? []);
	const [fees, setFees] = (0, import_react.useState)(Array.isArray(venue.fees) ? venue.fees : []);
	const [feesNotes, setFeesNotes] = (0, import_react.useState)(venue.fees_notes ?? "");
	const [contactPhone, setContactPhone] = (0, import_react.useState)(venue.contact_phone ?? "");
	const [contactEmail, setContactEmail] = (0, import_react.useState)(venue.contact_email ?? "");
	const [operatingHoursText, setOperatingHoursText] = (0, import_react.useState)(venue.operating_hours_text ?? "");
	const [openHours, setOpenHours] = (0, import_react.useState)(() => normalizeHours(venue.operating_hours));
	const [conflicts, setConflicts] = (0, import_react.useState)(null);
	const [conflictBusy, setConflictBusy] = (0, import_react.useState)(false);
	const cancelConflictsFn = useServerFn(cancelBookingsWithRefund);
	const [cancellationHours, setCancellationHours] = (0, import_react.useState)(venue.refund_cutoff_hours ?? 24);
	const [cancellationNotes, setCancellationNotes] = (0, import_react.useState)(venue.cancellation_notes ?? "");
	const [rules, setRules] = (0, import_react.useState)(venue.rules ?? "");
	const suggested = suggestTimezone(venue.latitude, venue.longitude);
	const tzMismatch = !!(suggested && suggested.tz !== timezone);
	const hoursChanged = JSON.stringify(openHours) !== JSON.stringify(normalizeHours(venue.operating_hours));
	const save = useMutation({
		mutationFn: async (opts) => {
			if (tzMismatch && !tzConfirmed) throw new Error(`Timezone doesn't match this venue's pin (${suggested?.country}). Confirm the override or switch to ${suggested?.tz}.`);
			if (!opts?.force && hoursChanged) {
				const found = await findHoursConflicts({
					venueId: venue.id,
					newVenueHours: openHours
				});
				if (found.length > 0) {
					setConflicts(found);
					return "blocked";
				}
			}
			const { error } = await supabase.from("venues").update({
				name,
				address,
				description: description || null,
				images,
				timezone,
				map_emoji: mapEmoji,
				is_active: isActive,
				amenities,
				food_beverages: foodBeverages,
				facility_services: facilityServices,
				fees: fees.filter((f) => f.label.trim() && Number.isFinite(f.amount)).map((f) => ({
					label: f.label.trim(),
					amount: Number(f.amount)
				})),
				fees_notes: feesNotes.trim() || null,
				contact_phone: contactPhone.trim() || null,
				contact_email: contactEmail.trim() || null,
				operating_hours_text: operatingHoursText.trim() || null,
				operating_hours: openHours,
				refund_cutoff_hours: Number.isFinite(cancellationHours) ? Math.max(0, Math.floor(cancellationHours)) : 24,
				cancellation_notes: cancellationNotes.trim() || null,
				rules: rules.trim() || null
			}).eq("id", venue.id);
			if (error) throw error;
			return "saved";
		},
		onSuccess: (res) => {
			if (res === "blocked") return;
			setConflicts(null);
			setEditing(false);
			setErr(null);
			setTzConfirmed(false);
			qc.invalidateQueries({ queryKey: ["my-venues"] });
			onDoneEditing?.();
		},
		onError: (e) => setErr(e.message)
	});
	const del = useMutation({
		mutationFn: async () => {
			const { data: courts, error: cErr } = await supabase.from("courts").select("id").eq("venue_id", venue.id);
			if (cErr) throw cErr;
			const courtIds = (courts ?? []).map((c) => c.id);
			if (courtIds.length > 0) {
				const { count, error: bErr } = await supabase.from("bookings").select("id", {
					count: "exact",
					head: true
				}).in("court_id", courtIds);
				if (bErr) throw bErr;
				if ((count ?? 0) > 0) throw new Error("This venue has existing bookings and cannot be deleted.");
				const { error: dcErr } = await supabase.from("courts").delete().in("id", courtIds);
				if (dcErr) throw dcErr;
			}
			const { error } = await supabase.from("venues").delete().eq("id", venue.id);
			if (error) throw error;
		},
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["my-venues"] });
			qc.invalidateQueries({ queryKey: ["venues-court-counts"] });
			qc.invalidateQueries({ queryKey: ["venues-courts-glance"] });
		},
		onError: (e) => setDelErr(e.message)
	});
	if (editing) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-secondary/20 p-3 sm:p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Venue name",
						value: name,
						onChange: setName,
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Address",
						value: address,
						onChange: setAddress,
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block sm:col-span-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted-foreground",
								children: "Timezone"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: timezone,
								onChange: (e) => {
									setTimezone(e.target.value);
									setTzConfirmed(false);
								},
								className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring",
								children: [TIMEZONE_OPTIONS.some((t) => t.value === timezone) ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: timezone,
									children: [timezone, " (current)"]
								}), TIMEZONE_OPTIONS.map((tz) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: tz.value,
									children: tz.label
								}, tz.value))]
							}),
							tzMismatch && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 rounded-lg border border-amber-400/50 bg-amber-50 px-3 py-2 text-xs text-amber-900 dark:bg-amber-500/10 dark:text-amber-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Timezone doesn't match the pin." }),
										" This venue's map pin is in ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: suggested?.country }),
										" (",
										suggested?.tz,
										"). Changing it away from the suggested zone means court hours and bookings will display in a different local time."
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											setTimezone(suggested.tz);
											setTzConfirmed(false);
										},
										className: "shrink-0 rounded-md border border-amber-500/60 bg-background px-2 py-1 text-[11px] font-semibold text-amber-800 hover:bg-amber-100 dark:text-amber-100",
										children: ["Use ", suggested?.tz]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-2 flex items-center gap-2 text-[11px]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: tzConfirmed,
											onChange: (e) => setTzConfirmed(e.target.checked)
										}),
										"I confirm this venue uses ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono",
											children: timezone
										}),
										"."
									]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-muted-foreground",
							children: "About this Venue"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: description,
							onChange: (e) => setDescription(e.target.value),
							rows: 3,
							placeholder: "Tell players what makes this venue great.",
							className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
							label: "Venue photos",
							pathPrefix: `venues/${venue.id}`,
							images,
							onChange: setImages
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagInput, {
							label: "Amenities",
							values: amenities,
							onChange: setAmenities,
							placeholder: "e.g. Parking, Showers, Wi-Fi",
							hint: "Press Enter or comma to add."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagInput, {
							label: "Food & Beverages",
							values: foodBeverages,
							onChange: setFoodBeverages,
							placeholder: "e.g. Cafe, Vending machine, Water refill"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TagInput, {
							label: "Facility Services",
							values: facilityServices,
							onChange: setFacilityServices,
							placeholder: "e.g. Racket rental, Coaching, Ball machine"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeesEditor, {
							items: fees,
							onChange: setFees,
							notes: feesNotes,
							onNotesChange: setFeesNotes
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Inquiry phone (shown to players)",
						value: contactPhone,
						onChange: setContactPhone
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Inquiry email (optional)",
						value: contactEmail,
						onChange: setContactEmail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OperatingHoursEditor, {
							hours: openHours,
							onChange: setOpenHours,
							hint: "Courts follow these hours by default. Players can only book inside this window, and closed hours are hidden everywhere."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							label: "Operating hours note (optional)",
							value: operatingHoursText,
							onChange: setOperatingHoursText,
							placeholder: "Extra note shown to players, e.g. Holiday hours may vary"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted-foreground",
								children: "Cancellation cutoff (hours before start)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 0,
								step: 1,
								value: cancellationHours,
								onChange: (e) => setCancellationHours(Number(e.target.value)),
								className: "mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-[11px] text-muted-foreground",
								children: "Default 24h. Set to 0 to allow last-minute cancellations."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							label: "Cancellation policy notes (optional)",
							value: cancellationNotes,
							onChange: setCancellationNotes,
							placeholder: "e.g. Full refund up to 24h before. 50% within 24h. No refund after start."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							label: "Venue rules (one per line)",
							value: rules,
							onChange: setRules,
							placeholder: "e.g.\n- Wear non-marking shoes\n- No outside food or drinks\n- Arrive 10 minutes early"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2 rounded-xl border border-border bg-background p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiPicker, {
							label: "Map emoji (venue pin)",
							value: mapEmoji,
							fallback: "🎾",
							onChange: setMapEmoji,
							hint: "Shown on the landing-page map. Individual courts can override this."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2 flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: isActive,
									onChange: (e) => setIsActive(e.target.checked),
									className: "h-4 w-4 accent-primary"
								}), "Active"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								tabIndex: 0,
								role: "button",
								"aria-label": "About the active status",
								title: ACTIVE_INFO_TEXT,
								className: "grid h-4 w-4 cursor-help place-items-center rounded-full border border-muted-foreground/40 text-[10px] font-bold text-muted-foreground hover:border-primary hover:text-primary",
								children: "?"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto text-[11px] text-muted-foreground",
								children: "Untick to hide this venue from players."
							})
						]
					})
				]
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 rounded-md bg-destructive/10 px-2 py-1 text-xs text-destructive",
				children: err
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => save.mutate({}),
					disabled: save.isPending || tzMismatch && !tzConfirmed,
					className: "rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground disabled:opacity-60",
					children: save.isPending ? "Saving…" : "Save changes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						setEditing(false);
						setName(venue.name);
						setAddress(venue.address);
						setDescription(venue.description ?? "");
						setImages(venue.images ?? []);
						setTimezone(venue.timezone || "Asia/Manila");
						setMapEmoji(venue.map_emoji ?? null);
						setTzConfirmed(false);
						setIsActive(venue.is_active !== false);
						setAmenities(venue.amenities ?? []);
						setFoodBeverages(venue.food_beverages ?? []);
						setFacilityServices(venue.facility_services ?? []);
						setFees(Array.isArray(venue.fees) ? venue.fees : []);
						setFeesNotes(venue.fees_notes ?? "");
						setContactPhone(venue.contact_phone ?? "");
						setContactEmail(venue.contact_email ?? "");
						setOperatingHoursText(venue.operating_hours_text ?? "");
						setCancellationHours(venue.refund_cutoff_hours ?? 24);
						setCancellationNotes(venue.cancellation_notes ?? "");
						setRules(venue.rules ?? "");
						setErr(null);
					},
					className: "rounded-lg border border-border px-3 py-1.5 text-xs",
					children: "Cancel"
				})]
			}),
			conflicts && conflicts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoursConflictDialog, {
				conflicts,
				busy: conflictBusy || save.isPending,
				onDismiss: () => setConflicts(null),
				onKeep: () => save.mutate({ force: true }),
				onCancelThem: async () => {
					setConflictBusy(true);
					try {
						await cancelConflictsFn({ data: {
							bookingIds: conflicts.flatMap((c) => c.bookingIds),
							reason: "The venue's operating hours changed and this slot is no longer available.",
							refundMode: "auto"
						} });
						save.mutate({ force: true });
					} catch (e) {
						setErr(e.message);
						setConflicts(null);
					} finally {
						setConflictBusy(false);
					}
				}
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-bold",
				children: venue.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					venue.address,
					" · ",
					venue.timezone
				]
			}),
			venue.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: venue.description
			}),
			(venue.images?.length ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 flex gap-2 overflow-x-auto",
				children: venue.images.slice(0, 4).map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src,
					alt: `${venue.name} ${i + 1}`,
					className: "h-16 w-24 flex-none rounded-md object-cover",
					loading: "lazy"
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setEditing(true),
					className: "rounded-md border border-border px-2.5 py-1 text-xs font-medium hover:border-primary hover:text-primary",
					children: "✎ Edit venue"
				}), !confirmDel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						setConfirmDel(true);
						setDelErr(null);
					},
					className: "rounded-md border border-destructive/40 px-2.5 py-1 text-xs font-medium text-destructive hover:bg-destructive/10",
					children: "Delete venue"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 rounded-md border border-destructive/40 bg-destructive/5 px-2.5 py-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs",
							children: [
								"Delete \"",
								venue.name,
								"\"",
								courtsCount > 0 ? ` and its ${courtsCount} court${courtsCount === 1 ? "" : "s"}` : "",
								"?"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => del.mutate(),
							disabled: del.isPending,
							className: "rounded-md bg-destructive px-2 py-0.5 text-xs font-semibold text-destructive-foreground disabled:opacity-60",
							children: del.isPending ? "Deleting…" : "Confirm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setConfirmDel(false),
							className: "rounded-md border border-border bg-background px-2 py-0.5 text-xs",
							children: "Cancel"
						})
					]
				})]
			}),
			delErr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 rounded-md bg-destructive/10 px-2 py-1 text-xs text-destructive",
				children: delErr
			})
		]
	});
}
function SettingsSection({ fullName, email, role, userId, onSaved }) {
	const [name, setName] = (0, import_react.useState)(fullName);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [msg, setMsg] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(null);
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const qc = useQueryClient();
	const paySettingsQ = useQuery({
		queryKey: ["venue-payment-settings"],
		enabled: role === "tenant",
		queryFn: async () => {
			const { data, error } = await supabase.from("venues").select("id, name, payment_mode, refund_cutoff_hours");
			if (error) throw error;
			return data;
		}
	});
	const savePaymentSettings = async (venueId, mode, cutoff) => {
		const { error } = await supabase.from("venues").update({
			payment_mode: mode,
			refund_cutoff_hours: cutoff
		}).eq("id", venueId);
		if (error) alert(error.message);
		else qc.invalidateQueries({ queryKey: ["venue-payment-settings"] });
	};
	const save = async () => {
		setSaving(true);
		setMsg(null);
		setErr(null);
		const { error } = await supabase.from("profiles").update({ full_name: name.trim() }).eq("id", userId);
		setSaving(false);
		if (error) {
			setErr(error.message);
			return;
		}
		setMsg("Saved.");
		onSaved();
	};
	const signOut = async () => {
		setSigningOut(true);
		await supabase.auth.signOut();
		window.location.href = "/";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: "Settings",
				subtitle: "Manage your account and preferences."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-5 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base font-semibold",
						children: "Account"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "Your profile information."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-medium text-muted-foreground",
									children: "Full name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: name,
									onChange: (e) => setName(e.target.value),
									className: "mt-1 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm",
									placeholder: "Your full name"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-medium text-muted-foreground",
									children: "Email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: email,
									readOnly: true,
									className: "mt-1 w-full rounded-lg border border-border bg-muted px-3 py-2 text-sm text-muted-foreground"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-medium text-muted-foreground",
									children: "Role"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: role,
									readOnly: true,
									className: "mt-1 w-full rounded-lg border border-border bg-muted px-3 py-2 text-sm capitalize text-muted-foreground"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-wrap items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: save,
								disabled: saving || !name.trim() || name.trim() === fullName,
								className: "rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60",
								children: saving ? "Saving…" : "Save changes"
							}),
							msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-primary",
								children: msg
							}),
							err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-destructive",
								children: err
							})
						]
					})
				]
			}),
			role === "tenant" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-5 sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base font-semibold",
						children: "Payment configuration"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: [
							"Settle at venue keeps payment offline. Choose ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Full payment" }),
							" to collect the whole amount online through GCash, Maya, GrabPay and QR Ph. Refund cutoff blocks player-initiated refunds inside the window before the booking."
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-secondary px-3 py-1 text-[11px] font-semibold",
						children: "PayMongo · Test mode"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-3",
					children: [
						paySettingsQ.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Loading venues…"
						}),
						!paySettingsQ.isLoading && (paySettingsQ.data ?? []).map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenuePaymentRow, {
							venue: v,
							onSave: savePaymentSettings
						}, v.id)),
						!paySettingsQ.isLoading && (paySettingsQ.data?.length ?? 0) === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Create a venue first to configure payment settings."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-destructive/30 bg-card p-5 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base font-semibold",
						children: "Session"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "Sign out of your CourtHub account on this device."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: signOut,
						disabled: signingOut,
						className: "mt-4 rounded-lg border border-destructive/40 bg-destructive/10 px-4 py-2 text-sm font-semibold text-destructive disabled:opacity-60",
						children: signingOut ? "Signing out…" : "Sign out"
					})
				]
			})
		]
	});
}
function VenuesCourtsTabs({ venues }) {
	const [tab, setTab] = (0, import_react.useState)("venues");
	const venueIds = venues.map((v) => v.id);
	const courtsTotalQ = useQuery({
		queryKey: ["venues-court-counts", venueIds],
		enabled: venueIds.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.from("courts").select("venue_id").in("venue_id", venueIds);
			if (error) throw error;
			const map = {};
			(data ?? []).forEach((c) => {
				map[c.venue_id] = (map[c.venue_id] ?? 0) + 1;
			});
			return map;
		}
	});
	const courtsTotal = Object.values(courtsTotalQ.data ?? {}).reduce((a, b) => a + b, 0);
	const groupsTotal = useQuery({
		queryKey: ["venues-group-counts", venueIds],
		enabled: venueIds.length > 0,
		queryFn: async () => {
			const { data: pcs, error } = await supabase.from("physical_courts").select("id").in("venue_id", venueIds);
			if (error) throw error;
			const pcIds = (pcs ?? []).map((p) => p.id);
			if (pcIds.length === 0) return 0;
			const { data: cs, error: cErr } = await supabase.from("courts").select("physical_court_id").in("physical_court_id", pcIds);
			if (cErr) throw cErr;
			const counts = /* @__PURE__ */ new Map();
			(cs ?? []).forEach((c) => counts.set(c.physical_court_id, (counts.get(c.physical_court_id) ?? 0) + 1));
			return pcIds.filter((id) => (counts.get(id) ?? 0) >= 2).length;
		}
	}).data ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col rounded-2xl border border-border bg-card shadow-sm overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex border-b border-border bg-secondary/30",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabBtn, {
					active: tab === "venues",
					onClick: () => setTab("venues"),
					children: ["Venues ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-1.5 inline-flex min-w-5.5 items-center justify-center rounded-full bg-linear-to-br from-primary via-cyan-400 to-sky-500 px-1.5 py-0.5 text-[10px] font-bold text-primary-foreground shadow-[0_2px_8px_-2px_rgba(9,230,210,0.6)] ring-1 ring-white/40",
						children: venues.length
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabBtn, {
					active: tab === "courts",
					onClick: () => setTab("courts"),
					children: ["Courts ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-1.5 inline-flex min-w-5.5 items-center justify-center rounded-full bg-linear-to-br from-primary via-cyan-400 to-sky-500 px-1.5 py-0.5 text-[10px] font-bold text-primary-foreground shadow-[0_2px_8px_-2px_rgba(9,230,210,0.6)] ring-1 ring-white/40",
						children: courtsTotal
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabBtn, {
					active: tab === "groups",
					onClick: () => setTab("groups"),
					children: [
						"Court Groups ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1.5 inline-flex min-w-5.5 items-center justify-center rounded-full bg-linear-to-br from-primary via-cyan-400 to-sky-500 px-1.5 py-0.5 text-[10px] font-bold text-primary-foreground shadow-[0_2px_8px_-2px_rgba(9,230,210,0.6)] ring-1 ring-white/40",
							children: groupsTotal
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "group relative ml-1 inline-flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "inline-flex h-4 w-4 cursor-help items-center justify-center rounded-full border border-current text-[10px] font-bold leading-none opacity-70",
								children: "?"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "pointer-events-none absolute left-1/2 top-full z-50 mt-2 hidden w-64 -translate-x-1/2 rounded-lg border border-border bg-popover p-3 text-left text-xs font-normal normal-case text-popover-foreground shadow-lg group-hover:block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold text-primary",
									children: "What is a Court Group / Physical Surface?"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 block text-muted-foreground",
									children: [
										"One shared space can host different sports — e.g. ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "1 basketball" }),
										" ↔ ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "3 badminton" }),
										" ↔ ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "4 pickleball" }),
										". Group those courts here so a booking on one automatically blocks the conflicting slots on the others."
									]
								})]
							})]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "nice-scroll min-h-0 flex-1 overflow-y-auto overflow-x-auto",
			children: [
				tab === "venues" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenuesTab, { venues }),
				tab === "courts" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtsTab, { venues }),
				tab === "groups" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtGroupsTab, { venues })
			]
		})]
	});
}
function TabBtn({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick,
		className: "relative px-4 sm:px-6 py-3 text-sm font-semibold transition " + (active ? "text-foreground" : "text-muted-foreground hover:text-foreground"),
		children: [children, active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-primary" })]
	});
}
var VENUE_COLUMNS = [
	{
		id: "emoji",
		label: "Emoji",
		defaultOn: true
	},
	{
		id: "name",
		label: "Venue",
		required: true,
		defaultOn: true
	},
	{
		id: "location",
		label: "Location",
		defaultOn: true
	},
	{
		id: "description",
		label: "About this Venue",
		defaultOn: true
	},
	{
		id: "created_at",
		label: "Created At",
		defaultOn: true
	},
	{
		id: "map",
		label: "Map",
		defaultOn: true
	},
	{
		id: "courts",
		label: "Courts",
		defaultOn: true
	},
	{
		id: "status",
		label: "Venue Status",
		defaultOn: true
	},
	{
		id: "actions",
		label: "Actions",
		required: true,
		defaultOn: true
	},
	{
		id: "history",
		label: "History",
		defaultOn: true
	},
	{
		id: "amenities",
		label: "Amenities"
	},
	{
		id: "food_beverages",
		label: "Food & Beverages"
	},
	{
		id: "facility_services",
		label: "Facility Services"
	},
	{
		id: "fees",
		label: "Fees & Charges"
	},
	{
		id: "contact_phone",
		label: "Inquiry Phone"
	},
	{
		id: "contact_email",
		label: "Inquiry Email"
	},
	{
		id: "operating_hours",
		label: "Operating Hours"
	},
	{
		id: "cancellation",
		label: "Cancellation Policy"
	},
	{
		id: "rules",
		label: "Venue Rules"
	}
];
var VENUE_COLS_STORAGE_KEY = "venues-tab-columns-v1";
var DEFAULT_VENUE_COLS = VENUE_COLUMNS.filter((c) => c.defaultOn || c.required).map((c) => c.id);
var COURT_COLUMNS = [
	{
		id: "emoji",
		label: "Emoji",
		defaultOn: true
	},
	{
		id: "name",
		label: "Court",
		required: true,
		defaultOn: true
	},
	{
		id: "description",
		label: "About This Court",
		defaultOn: true
	},
	{
		id: "venue",
		label: "Venue",
		defaultOn: true
	},
	{
		id: "sport",
		label: "Sport",
		defaultOn: true
	},
	{
		id: "type",
		label: "Type",
		defaultOn: true
	},
	{
		id: "rate",
		label: "Rate / hr",
		defaultOn: true
	},
	{
		id: "status",
		label: "Status",
		defaultOn: true
	},
	{
		id: "created_at",
		label: "Created At",
		defaultOn: true
	},
	{
		id: "actions",
		label: "Actions",
		required: true,
		defaultOn: true
	},
	{
		id: "history",
		label: "History"
	},
	{
		id: "voucher",
		label: "Voucher"
	},
	{
		id: "surface",
		label: "Surface"
	},
	{
		id: "capacity",
		label: "Capacity"
	}
];
var COURT_COLS_STORAGE_KEY = "courts-tab-columns-v1";
var DEFAULT_COURT_COLS = COURT_COLUMNS.filter((c) => c.defaultOn || c.required).map((c) => c.id);
var GROUP_COLUMNS = [
	{
		id: "emoji",
		label: "Emoji",
		defaultOn: true
	},
	{
		id: "name",
		label: "Group",
		required: true,
		defaultOn: true
	},
	{
		id: "description",
		label: "About this group",
		defaultOn: true
	},
	{
		id: "courts_count",
		label: "Courts",
		defaultOn: true
	},
	{
		id: "rules",
		label: "Blocking rules",
		defaultOn: true
	},
	{
		id: "actions",
		label: "Actions",
		required: true,
		defaultOn: true
	},
	{
		id: "sports",
		label: "Sports"
	}
];
var GROUP_COLS_STORAGE_KEY = "groups-tab-columns-v1";
var DEFAULT_GROUP_COLS = GROUP_COLUMNS.filter((c) => c.defaultOn || c.required).map((c) => c.id);
function useColumnPrefs(columns, defaults, storageKey, prefKey) {
	const [selected, setSelected] = (0, import_react.useState)(defaults);
	const sanitize = (arr) => {
		const valid = arr.filter((id) => columns.some((c) => c.id === id));
		return [...columns.filter((c) => c.required).map((c) => c.id).filter((id) => !valid.includes(id)), ...valid];
	};
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(storageKey);
			if (raw) setSelected(sanitize(JSON.parse(raw)));
		} catch {}
		(async () => {
			const { data: auth } = await supabase.auth.getUser();
			const uid = auth.user?.id;
			if (!uid) return;
			const { data } = await supabase.from("user_preferences").select("prefs").eq("user_id", uid).maybeSingle();
			const cols = (data?.prefs)?.[prefKey];
			if (Array.isArray(cols) && cols.length) {
				const merged = sanitize(cols);
				setSelected(merged);
				try {
					localStorage.setItem(storageKey, JSON.stringify(merged));
				} catch {}
			}
		})();
	}, []);
	const save = (next) => {
		const clean = sanitize(next);
		setSelected(clean);
		try {
			localStorage.setItem(storageKey, JSON.stringify(clean));
		} catch {}
		(async () => {
			const { data: auth } = await supabase.auth.getUser();
			const uid = auth.user?.id;
			if (!uid) return;
			const { data: existing } = await supabase.from("user_preferences").select("prefs").eq("user_id", uid).maybeSingle();
			const merged = {
				...existing?.prefs ?? {},
				[prefKey]: clean
			};
			await supabase.from("user_preferences").upsert({
				user_id: uid,
				prefs: merged,
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			}, { onConflict: "user_id" });
		})();
	};
	return {
		selected,
		save
	};
}
var useVenueColumns = () => useColumnPrefs(VENUE_COLUMNS, DEFAULT_VENUE_COLS, VENUE_COLS_STORAGE_KEY, "venues_columns");
var useCourtColumns = () => useColumnPrefs(COURT_COLUMNS, DEFAULT_COURT_COLS, COURT_COLS_STORAGE_KEY, "courts_columns");
var useGroupColumns = () => useColumnPrefs(GROUP_COLUMNS, DEFAULT_GROUP_COLS, GROUP_COLS_STORAGE_KEY, "groups_columns");
function useColumnPresets(prefKey) {
	const [presets, setPresets] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		(async () => {
			const { data: auth } = await supabase.auth.getUser();
			const uid = auth.user?.id;
			if (!uid) return;
			const { data } = await supabase.from("user_preferences").select("prefs").eq("user_id", uid).maybeSingle();
			const list = (data?.prefs)?.[prefKey];
			if (Array.isArray(list)) setPresets(list);
		})();
	}, [prefKey]);
	const persist = async (next) => {
		setPresets(next);
		const { data: auth } = await supabase.auth.getUser();
		const uid = auth.user?.id;
		if (!uid) return;
		const { data: existing } = await supabase.from("user_preferences").select("prefs").eq("user_id", uid).maybeSingle();
		const merged = {
			...existing?.prefs ?? {},
			[prefKey]: next
		};
		await supabase.from("user_preferences").upsert({
			user_id: uid,
			prefs: merged,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		}, { onConflict: "user_id" });
	};
	return {
		presets,
		persist
	};
}
function ColumnConfigModal({ open, onClose, selected, onApply, columns = VENUE_COLUMNS, defaults = DEFAULT_VENUE_COLS, presetKey = "venues_column_presets" }) {
	const [localSelected, setLocalSelected] = (0, import_react.useState)(selected);
	const [availActive, setAvailActive] = (0, import_react.useState)(null);
	const [selActive, setSelActive] = (0, import_react.useState)(null);
	const [availQuery, setAvailQuery] = (0, import_react.useState)("");
	const [selQuery, setSelQuery] = (0, import_react.useState)("");
	const [presetName, setPresetName] = (0, import_react.useState)("");
	const [showSaveForm, setShowSaveForm] = (0, import_react.useState)(false);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const { presets, persist } = useColumnPresets(presetKey);
	(0, import_react.useEffect)(() => {
		if (open) {
			setLocalSelected(selected);
			setAvailActive(null);
			setSelActive(null);
			setAvailQuery("");
			setSelQuery("");
			setPresetName("");
			setShowSaveForm(false);
			setDeleteTarget(null);
		}
	}, [open, selected]);
	if (!open) return null;
	const availableCols = columns.filter((c) => !localSelected.includes(c.id));
	const selectedCols = localSelected.map((id) => columns.find((c) => c.id === id)).filter(Boolean);
	const filteredAvail = availableCols.filter((c) => c.label.toLowerCase().includes(availQuery.toLowerCase()));
	const filteredSel = selectedCols.filter((c) => c.label.toLowerCase().includes(selQuery.toLowerCase()));
	const moveToSelected = () => {
		if (!availActive) return;
		setLocalSelected([...localSelected, availActive]);
		setAvailActive(null);
	};
	const moveToAvailable = () => {
		if (!selActive) return;
		if (columns.find((c) => c.id === selActive)?.required) return;
		setLocalSelected(localSelected.filter((id) => id !== selActive));
		setSelActive(null);
	};
	const moveUp = () => {
		if (!selActive) return;
		const idx = localSelected.indexOf(selActive);
		if (idx <= 0) return;
		const next = [...localSelected];
		[next[idx - 1], next[idx]] = [next[idx], next[idx - 1]];
		setLocalSelected(next);
	};
	const moveDown = () => {
		if (!selActive) return;
		const idx = localSelected.indexOf(selActive);
		if (idx < 0 || idx >= localSelected.length - 1) return;
		const next = [...localSelected];
		[next[idx + 1], next[idx]] = [next[idx], next[idx + 1]];
		setLocalSelected(next);
	};
	const resetDefault = () => setLocalSelected(defaults);
	const apply = () => {
		onApply(localSelected);
		onClose();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4",
		onClick: (e) => {
			if (e.target === e.currentTarget) onClose();
		},
		role: "dialog",
		"aria-modal": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-2xl overflow-hidden rounded-2xl bg-background shadow-2xl",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border px-5 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base font-semibold",
						children: "Column Configuration"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						className: "rounded-md p-1 text-muted-foreground hover:bg-secondary",
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 border-b border-border bg-secondary/20 px-5 py-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5 text-xs font-medium text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "h-3.5 w-3.5" }), " Presets"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: "",
							onChange: (e) => {
								const p = presets.find((x) => x.name === e.target.value);
								if (p) setLocalSelected(p.columns);
								e.currentTarget.value = "";
							},
							className: "rounded-md border border-border bg-background px-2 py-1 text-xs outline-none focus:border-primary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: presets.length ? "Load preset…" : "No presets yet"
							}), presets.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.name,
								children: p.name
							}, p.name))]
						}),
						presets.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: "",
							onChange: (e) => {
								const name = e.target.value;
								if (!name) return;
								setDeleteTarget(name);
								e.currentTarget.value = "";
							},
							className: "rounded-md border border-border bg-background px-2 py-1 text-xs text-destructive outline-none focus:border-destructive",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Delete…"
							}), presets.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.name,
								children: p.name
							}, p.name))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "ml-auto flex items-center gap-2",
							children: showSaveForm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									autoFocus: true,
									value: presetName,
									onChange: (e) => setPresetName(e.target.value),
									placeholder: "Preset name",
									className: "rounded-md border border-border bg-background px-2 py-1 text-xs outline-none focus:border-primary",
									onKeyDown: (e) => {
										if (e.key === "Enter") {
											const n = presetName.trim();
											if (!n) return;
											const next = presets.some((p) => p.name === n) ? presets.map((p) => p.name === n ? {
												name: n,
												columns: localSelected
											} : p) : [...presets, {
												name: n,
												columns: localSelected
											}];
											persist(next);
											setPresetName("");
											setShowSaveForm(false);
										}
										if (e.key === "Escape") {
											setShowSaveForm(false);
											setPresetName("");
										}
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										const n = presetName.trim();
										if (!n) return;
										const next = presets.some((p) => p.name === n) ? presets.map((p) => p.name === n ? {
											name: n,
											columns: localSelected
										} : p) : [...presets, {
											name: n,
											columns: localSelected
										}];
										persist(next);
										setPresetName("");
										setShowSaveForm(false);
									},
									className: "rounded-md bg-primary px-2 py-1 text-xs font-semibold text-primary-foreground hover:bg-primary/90",
									children: "Save"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setShowSaveForm(false);
										setPresetName("");
									},
									className: "rounded-md border border-border px-2 py-1 text-xs hover:bg-secondary",
									children: "Cancel"
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setShowSaveForm(true),
								className: "inline-flex items-center gap-1.5 rounded-md border border-primary/40 bg-primary/10 px-2.5 py-1 text-xs font-semibold text-primary hover:bg-primary/20",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-3.5 w-3.5" }), " Save as preset"]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 gap-4 p-5 sm:grid-cols-[1fr_auto_1fr]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-h-0 flex-col",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-1 text-xs font-medium text-muted-foreground",
									children: "Available Columns"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative mb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: availQuery,
										onChange: (e) => setAvailQuery(e.target.value),
										placeholder: "Search…",
										className: "w-full rounded-md border border-border bg-background py-1.5 pl-7 pr-2 text-xs outline-none focus:border-primary"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "h-56 overflow-y-auto rounded-md border border-border bg-secondary/20",
									children: [filteredAvail.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "p-3 text-center text-xs italic text-muted-foreground",
										children: "No columns"
									}), filteredAvail.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setAvailActive(c.id),
										onDoubleClick: () => {
											setLocalSelected([...localSelected, c.id]);
											setAvailActive(null);
										},
										className: "block w-full px-3 py-1.5 text-left text-xs transition " + (availActive === c.id ? "bg-primary/15 text-foreground" : "text-foreground/80 hover:bg-secondary"),
										children: c.label
									}) }, c.id))]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-row items-center justify-center gap-2 sm:flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: moveToSelected,
								disabled: !availActive,
								title: "Add",
								className: "inline-flex h-8 w-8 items-center justify-center rounded-md border border-border text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary disabled:opacity-40 disabled:hover:bg-transparent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: moveToAvailable,
								disabled: !selActive || columns.find((c) => c.id === selActive)?.required,
								title: "Remove",
								className: "inline-flex h-8 w-8 items-center justify-center rounded-md border border-border text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary disabled:opacity-40 disabled:hover:bg-transparent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-h-0 flex-col",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-1 text-xs font-medium text-muted-foreground",
									children: "Selected Columns"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative mb-2 flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: selQuery,
												onChange: (e) => setSelQuery(e.target.value),
												placeholder: "Search…",
												className: "w-full rounded-md border border-border bg-background py-1.5 pl-7 pr-2 text-xs outline-none focus:border-primary"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: moveUp,
											disabled: !selActive,
											title: "Move up",
											className: "inline-flex h-7 w-7 items-center justify-center rounded-md border border-border text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary disabled:opacity-40",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "h-3.5 w-3.5" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: moveDown,
											disabled: !selActive,
											title: "Move down",
											className: "inline-flex h-7 w-7 items-center justify-center rounded-md border border-border text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary disabled:opacity-40",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3.5 w-3.5" })
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "h-56 overflow-y-auto rounded-md border border-border bg-secondary/20",
									children: [filteredSel.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "p-3 text-center text-xs italic text-muted-foreground",
										children: "No columns"
									}), filteredSel.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setSelActive(c.id),
										onDoubleClick: () => {
											if (!c.required) {
												setLocalSelected(localSelected.filter((id) => id !== c.id));
												setSelActive(null);
											}
										},
										className: "flex w-full items-center justify-between px-3 py-1.5 text-left text-xs transition " + (selActive === c.id ? "bg-primary/15 text-foreground" : "text-foreground/80 hover:bg-secondary"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.label }), c.required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-full bg-muted px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-muted-foreground",
											children: "Required"
										})]
									}) }, c.id))]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2 border-t border-border px-5 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: resetDefault,
						className: "rounded-md border border-border px-3 py-1.5 text-xs font-semibold uppercase tracking-wide hover:bg-secondary",
						children: "Reset to Default"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onClose,
							className: "rounded-md border border-border px-4 py-1.5 text-xs font-semibold uppercase tracking-wide hover:bg-secondary",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: apply,
							className: "rounded-md bg-primary px-4 py-1.5 text-xs font-semibold uppercase tracking-wide text-primary-foreground hover:bg-primary/90",
							children: "OK"
						})]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
			open: !!deleteTarget,
			onOpenChange: (o) => {
				if (!o) setDeleteTarget(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Delete preset?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
				"This will permanently remove the preset ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-semibold text-foreground",
					children: [
						"\"",
						deleteTarget,
						"\""
					]
				}),
				". This action cannot be undone."
			] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
				onClick: () => {
					if (deleteTarget) persist(presets.filter((p) => p.name !== deleteTarget));
					setDeleteTarget(null);
				},
				className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
				children: "Delete"
			})] })] })
		})]
	});
}
function VenuesTab({ venues }) {
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [viewing, setViewing] = (0, import_react.useState)(null);
	const [history, setHistory] = (0, import_react.useState)(null);
	const [courtsFor, setCourtsFor] = (0, import_react.useState)(null);
	const [colCfgOpen, setColCfgOpen] = (0, import_react.useState)(false);
	const { selected: visibleCols, save: saveCols } = useVenueColumns();
	const venueIds = venues.map((v) => v.id);
	const courtsCountQ = useQuery({
		queryKey: ["venues-court-counts", venueIds],
		enabled: venueIds.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.from("courts").select("venue_id").in("venue_id", venueIds);
			if (error) throw error;
			const map = {};
			(data ?? []).forEach((c) => {
				map[c.venue_id] = (map[c.venue_id] ?? 0) + 1;
			});
			return map;
		}
	});
	const countFor = (id) => courtsCountQ.data?.[id] ?? 0;
	const renderHeader = (id) => {
		switch (id) {
			case "emoji": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-2 py-2 w-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setColCfgOpen(true),
					title: "Configure columns",
					"aria-label": "Configure columns",
					className: "inline-flex h-7 w-7 items-center justify-center rounded-md border border-border bg-background text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableProperties, { className: "h-4 w-4" })
				})
			}, id);
			case "name": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5",
				children: "Venue"
			}, id);
			case "location": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5",
				children: "Location"
			}, id);
			case "description": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5",
				children: "ABOUT THIS VENUE"
			}, id);
			case "created_at": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-32",
				children: "CREATED AT"
			}, id);
			case "map": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-20 text-center",
				children: "Map"
			}, id);
			case "courts": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-24 text-center",
				children: "Courts"
			}, id);
			case "status": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-28 text-center",
				children: "Status"
			}, id);
			case "actions": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-40 text-right",
				children: "Actions"
			}, id);
			case "history": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-24 text-center",
				children: "History"
			}, id);
			case "amenities": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-50",
				children: "Amenities"
			}, id);
			case "food_beverages": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-50",
				children: "Food & Beverages"
			}, id);
			case "facility_services": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-50",
				children: "Facility Services"
			}, id);
			case "fees": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-24 text-center",
				children: "Fees"
			}, id);
			case "contact_phone": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-36",
				children: "Inquiry Phone"
			}, id);
			case "contact_email": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-48",
				children: "Inquiry Email"
			}, id);
			case "operating_hours": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-50",
				children: "Operating Hours"
			}, id);
			case "cancellation": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-50",
				children: "Cancellation"
			}, id);
			case "rules": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-50",
				children: "Rules"
			}, id);
			default: return null;
		}
	};
	const renderCell = (id, v, idx) => {
		switch (id) {
			case "emoji": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-xl leading-none",
				children: v.map_emoji ?? "🎾"
			}, id);
			case "name": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
				className: "px-3 py-3 whitespace-nowrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 whitespace-nowrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold whitespace-nowrap",
						children: v.name
					}), idx === 0 && venues.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 rounded-full bg-linear-to-r from-primary via-cyan-400 to-sky-500 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-primary-foreground shadow-[0_2px_8px_-2px_rgba(9,230,210,0.7)] ring-1 ring-white/40",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 animate-pulse rounded-full bg-white" }), "Newest"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] text-muted-foreground",
					children: v.timezone
				})]
			}, id);
			case "location": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-muted-foreground min-w-45",
				children: v.address
			}, id);
			case "description": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-muted-foreground w-60 min-w-60 max-w-60",
				children: v.description ? v.description.length > 40 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HoverCard, {
					openDelay: 80,
					closeDelay: 200,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoverCardTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block w-full truncate cursor-help border-b border-dotted border-muted-foreground/40",
							children: v.description
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoverCardContent, {
						side: "bottom",
						align: "start",
						sideOffset: 6,
						collisionPadding: 16,
						avoidCollisions: true,
						className: "w-[min(32rem,92vw)] overflow-y-auto whitespace-pre-wrap text-xs leading-relaxed",
						style: {
							overflowWrap: "anywhere",
							wordBreak: "break-word",
							maxHeight: "var(--radix-hover-card-content-available-height)"
						},
						children: v.description
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block w-full truncate",
					children: v.description
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "italic opacity-60",
					children: "No description"
				})
			}, id);
			case "created_at": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-muted-foreground whitespace-nowrap",
				children: v.created_at ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: new Date(v.created_at).toLocaleDateString(void 0, {
							year: "numeric",
							month: "short",
							day: "numeric"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-muted-foreground",
						children: new Date(v.created_at).toLocaleTimeString(void 0, {
							hour: "numeric",
							minute: "2-digit"
						})
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "italic opacity-60",
					children: "—"
				})
			}, id);
			case "map": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-center",
				children: v.latitude != null && v.longitude != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setViewing(v),
					title: "View on map",
					"aria-label": `View ${v.name} on map`,
					className: "inline-flex h-9 w-9 items-center justify-center rounded-full border border-border text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground italic",
					children: "No pin"
				})
			}, id);
			case "courts": {
				const n = countFor(v.id);
				const has = n > 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-3 py-3 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setCourtsFor(v),
						title: has ? `View ${n} court${n === 1 ? "" : "s"} under this venue` : "No courts yet",
						"aria-label": `View courts under ${v.name}`,
						className: "relative inline-flex h-9 w-9 items-center justify-center rounded-full border transition " + (has ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-600 hover:border-emerald-500 hover:bg-emerald-500/20" : "border-border text-muted-foreground hover:border-primary hover:bg-primary/10 hover:text-primary"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "h-4 w-4" }), has && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute -top-1 -right-1 min-w-4 h-4 px-1 rounded-full bg-emerald-500 text-white text-[10px] font-semibold leading-4 text-center shadow",
							children: n
						})]
					})
				}, id);
			}
			case "status": {
				const active = v.is_active !== false;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-3 py-3 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-semibold " + (active ? "bg-emerald-500/10 text-emerald-600 ring-1 ring-emerald-500/30" : "bg-red-500/10 text-red-600 ring-1 ring-red-500/30"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full " + (active ? "bg-emerald-500 animate-pulse" : "bg-red-500") }), active ? "Active" : "Inactive"]
					})
				}, id);
			}
			case "actions": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-end gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setEditing(v),
						title: "Edit venue",
						"aria-label": `Edit ${v.name}`,
						className: "inline-flex h-7 w-7 items-center justify-center rounded-full border border-border text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteVenueButton, { venue: v })]
				})
			}, id);
			case "history": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setHistory(v),
					title: "Audit history",
					"aria-label": `View audit history for ${v.name}`,
					className: "inline-flex h-9 w-9 items-center justify-center rounded-full border border-border text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "h-4 w-4" })
				})
			}, id);
			case "amenities":
			case "food_beverages":
			case "facility_services": {
				const arr = (id === "amenities" ? v.amenities : id === "food_beverages" ? v.food_beverages : v.facility_services) ?? [];
				if (!arr.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-3 py-3 text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "italic opacity-60",
						children: "—"
					})
				}, id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-3 py-3 text-muted-foreground w-50 min-w-50 max-w-50",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HoverCard, {
						openDelay: 80,
						closeDelay: 200,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoverCardTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block w-full truncate cursor-help border-b border-dotted border-muted-foreground/40 text-xs",
								children: arr.join(", ")
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoverCardContent, {
							side: "bottom",
							align: "start",
							sideOffset: 6,
							collisionPadding: 16,
							avoidCollisions: true,
							className: "w-[min(32rem,92vw)] overflow-y-auto text-xs",
							style: { maxHeight: "var(--radix-hover-card-content-available-height)" },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1",
								children: arr.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-secondary px-2 py-0.5",
									children: t
								}, i))
							})
						})]
					})
				}, id);
			}
			case "fees": {
				const feesArr = Array.isArray(v.fees) ? v.fees : [];
				if (!feesArr.length && !v.fees_notes) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-3 py-3 text-center text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "italic opacity-60",
						children: "—"
					})
				}, id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-3 py-3 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HoverCard, {
						openDelay: 80,
						closeDelay: 200,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoverCardTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-semibold text-primary cursor-help",
								children: [
									feesArr.length,
									" item",
									feesArr.length === 1 ? "" : "s"
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HoverCardContent, {
							side: "bottom",
							align: "center",
							sideOffset: 6,
							collisionPadding: 16,
							avoidCollisions: true,
							className: "w-[min(28rem,92vw)] overflow-y-auto text-xs",
							style: { maxHeight: "var(--radix-hover-card-content-available-height)" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-1",
								children: feesArr.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: f.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-semibold",
										children: ["₱", Number(f.amount).toLocaleString()]
									})]
								}, i))
							}), v.fees_notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 border-t border-border pt-2 text-muted-foreground whitespace-pre-wrap",
								children: v.fees_notes
							})]
						})]
					})
				}, id);
			}
			case "contact_phone": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-muted-foreground whitespace-nowrap text-xs",
				children: v.contact_phone || /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "italic opacity-60",
					children: "—"
				})
			}, id);
			case "contact_email": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-muted-foreground whitespace-nowrap text-xs",
				children: v.contact_email || /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "italic opacity-60",
					children: "—"
				})
			}, id);
			case "operating_hours":
			case "rules": {
				const text = id === "operating_hours" ? v.operating_hours_text : v.rules;
				if (!text) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-3 py-3 text-muted-foreground w-50",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "italic opacity-60",
						children: "—"
					})
				}, id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-3 py-3 text-muted-foreground w-50 min-w-50 max-w-50",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HoverCard, {
						openDelay: 80,
						closeDelay: 200,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoverCardTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block w-full truncate cursor-help border-b border-dotted border-muted-foreground/40 text-xs",
								children: text
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoverCardContent, {
							side: "bottom",
							align: "start",
							sideOffset: 6,
							collisionPadding: 16,
							avoidCollisions: true,
							className: "w-[min(32rem,92vw)] overflow-y-auto whitespace-pre-wrap text-xs leading-relaxed",
							style: {
								overflowWrap: "anywhere",
								wordBreak: "break-word",
								maxHeight: "var(--radix-hover-card-content-available-height)"
							},
							children: text
						})]
					})
				}, id);
			}
			case "cancellation": {
				const hrs = v.refund_cutoff_hours;
				const notes = v.cancellation_notes;
				if (hrs == null && !notes) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-3 py-3 text-muted-foreground w-50",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "italic opacity-60",
						children: "—"
					})
				}, id);
				const summary = hrs != null ? `Cancel up to ${hrs}h before` : "See notes";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-3 py-3 text-muted-foreground w-50 min-w-50 max-w-50",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HoverCard, {
						openDelay: 80,
						closeDelay: 200,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoverCardTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block w-full truncate cursor-help border-b border-dotted border-muted-foreground/40 text-xs",
								children: [summary, notes ? ` — ${notes}` : ""]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HoverCardContent, {
							side: "bottom",
							align: "start",
							sideOffset: 6,
							collisionPadding: 16,
							avoidCollisions: true,
							className: "w-[min(32rem,92vw)] overflow-y-auto text-xs",
							style: { maxHeight: "var(--radix-hover-card-content-available-height)" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold text-foreground",
								children: summary
							}), notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 whitespace-pre-wrap text-muted-foreground",
								children: notes
							})]
						})]
					})
				}, id);
			}
			default: return null;
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-245 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "sticky top-0 z-10 bg-secondary/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [!visibleCols.includes("emoji") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "w-8 pl-2 pr-0 py-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setColCfgOpen(true),
						title: "Configure columns",
						"aria-label": "Configure columns",
						className: "inline-flex h-7 w-7 items-center justify-center rounded-md border border-border bg-background text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableProperties, { className: "h-4 w-4" })
					})
				}), visibleCols.map((id) => renderHeader(id))] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: venues.map((v, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-border align-top hover:bg-secondary/20",
				children: [!visibleCols.includes("emoji") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { className: "w-8 pl-2 pr-0 py-3" }), visibleCols.map((id) => renderCell(id, v, idx))]
			}, v.id)) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnConfigModal, {
			open: colCfgOpen,
			onClose: () => setColCfgOpen(false),
			selected: visibleCols,
			onApply: saveCols
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditVenueDrawer, {
			venue: editing,
			onClose: () => setEditing(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapViewModal, {
			venue: viewing,
			onClose: () => setViewing(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditHistoryModal, {
			venue: history,
			onClose: () => setHistory(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenueCourtsModal, {
			venue: courtsFor,
			onClose: () => setCourtsFor(null)
		})
	] });
}
function VenueCourtsModal({ venue, onClose }) {
	const { data, isLoading } = useQuery({
		queryKey: ["venue-courts-list", venue?.id],
		enabled: !!venue,
		queryFn: async () => {
			const { data, error } = await supabase.from("courts").select("id, name, hourly_rate, is_indoor, coming_soon, map_emoji, sports(name)").eq("venue_id", venue.id).order("id");
			if (error) throw error;
			return data;
		}
	});
	if (!venue) return null;
	const courts = data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4",
		onClick: onClose,
		role: "dialog",
		"aria-modal": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-lg overflow-hidden rounded-2xl bg-background shadow-2xl",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4 border-b border-border px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-lg font-bold",
					children: ["Courts at ", venue.name]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						"View only — ",
						courts.length,
						" court",
						courts.length === 1 ? "" : "s"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "rounded-full p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground",
					"aria-label": "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-[70vh] overflow-y-auto p-4",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-sm text-muted-foreground",
					children: "Loading…"
				}) : courts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-sm text-muted-foreground italic",
					children: "No courts yet under this venue."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border",
					children: courts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-2xl leading-none",
								children: c.map_emoji ?? "🎾"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate font-semibold",
										children: c.name
									}), c.coming_soon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-amber-500/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-amber-700",
										children: "Coming soon"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] text-muted-foreground",
									children: [
										c.sports?.name ?? "Sport",
										" · ",
										c.is_indoor ? "Indoor" : "Outdoor"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "whitespace-nowrap text-sm font-semibold text-primary",
								children: [
									"₱",
									Number(c.hourly_rate).toFixed(0),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-normal text-muted-foreground",
										children: " /hr"
									})
								]
							})
						]
					}, c.id))
				})
			})]
		})
	});
}
function AuditHistoryModal({ venue, onClose }) {
	const { data, isLoading } = useQuery({
		queryKey: ["venue-audit", venue?.id],
		enabled: !!venue,
		queryFn: async () => {
			const { data, error } = await supabase.from("venue_audit_log").select("*").eq("venue_id", venue.id).order("created_at", { ascending: false });
			if (error) throw error;
			return data ?? [];
		}
	});
	if (!venue) return null;
	const fmt = (iso) => new Date(iso).toLocaleString(void 0, {
		year: "numeric",
		month: "short",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-80 flex items-center justify-center bg-black/60 p-4",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-lg rounded-2xl border border-border bg-card shadow-xl",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border px-5 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: "Audit history"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-semibold",
					children: venue.name
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "rounded-full p-1.5 text-muted-foreground hover:bg-secondary/60 hover:text-foreground",
					"aria-label": "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-[60vh] overflow-y-auto px-5 py-4",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-8 text-center text-sm text-muted-foreground",
					children: "Loading…"
				}) : !data || data.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-8 text-center text-sm text-muted-foreground italic",
					children: "No history yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "relative space-y-4 border-l border-border pl-5",
					children: data.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute -left-6.5 top-1.5 h-3 w-3 rounded-full ring-4 ring-card ${e.action === "created" ? "bg-primary" : "bg-amber-500"}` }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-flex rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${e.action === "created" ? "bg-primary/15 text-primary" : "bg-amber-500/15 text-amber-600 dark:text-amber-400"}`,
									children: e.action === "created" ? "Created" : "Last modified"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: fmt(e.created_at)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "by "
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: e.actor_name?.trim() || "Unknown"
								})]
							}),
							e.action === "updated" && e.changes && Object.keys(e.changes).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1.5 flex flex-wrap gap-1",
								children: Object.keys(e.changes).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex rounded-md bg-secondary/60 px-1.5 py-0.5 text-[10px] text-muted-foreground",
									children: k
								}, k))
							})
						]
					}, e.id))
				})
			})]
		})
	});
}
function DeleteVenueButton({ venue }) {
	const qc = useQueryClient();
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	const del = useMutation({
		mutationFn: async () => {
			const { data: courts, error: cErr } = await supabase.from("courts").select("id").eq("venue_id", venue.id);
			if (cErr) throw cErr;
			const courtIds = (courts ?? []).map((c) => c.id);
			if (courtIds.length > 0) {
				const { count, error: bErr } = await supabase.from("bookings").select("id", {
					count: "exact",
					head: true
				}).in("court_id", courtIds);
				if (bErr) throw bErr;
				if ((count ?? 0) > 0) throw new Error("This venue has existing bookings and cannot be deleted.");
				const { error: dcErr } = await supabase.from("courts").delete().in("id", courtIds);
				if (dcErr) throw dcErr;
			}
			const { error } = await supabase.from("venues").delete().eq("id", venue.id);
			if (error) throw error;
		},
		onSuccess: () => {
			setConfirming(false);
			setErr(null);
			qc.invalidateQueries({ queryKey: ["my-venues"] });
			qc.invalidateQueries({ queryKey: ["venues-court-counts"] });
			qc.invalidateQueries({ queryKey: ["venues-courts-glance"] });
		},
		onError: (e) => setErr(e.message)
	});
	(0, import_react.useEffect)(() => {
		if (!confirming) return;
		const onKey = (e) => {
			if (e.key === "Escape") {
				setConfirming(false);
				setErr(null);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [confirming]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => {
			setConfirming(true);
			setErr(null);
		},
		title: "Delete venue",
		"aria-label": `Delete ${venue.name}`,
		className: "inline-flex h-7 w-7 items-center justify-center rounded-full border border-destructive/40 text-destructive transition hover:bg-destructive/10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3.5 w-3.5" })
	}), confirming && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-100 flex items-center justify-center bg-black/50 p-4",
		onClick: () => {
			if (!del.isPending) {
				setConfirming(false);
				setErr(null);
			}
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-2xl border border-border bg-background p-5 shadow-xl",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-base font-bold",
					children: [
						"Delete \"",
						venue.name,
						"\"?"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "This permanently removes the venue and all its courts. Venues with existing bookings cannot be deleted."
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 rounded-md bg-destructive/10 px-2 py-1 text-xs text-destructive",
					children: err
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							setConfirming(false);
							setErr(null);
						},
						disabled: del.isPending,
						className: "rounded-lg border border-border px-3 py-1.5 text-xs",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => del.mutate(),
						disabled: del.isPending,
						className: "rounded-lg bg-destructive px-3 py-1.5 text-xs font-semibold text-destructive-foreground disabled:opacity-60",
						children: del.isPending ? "Deleting…" : "Delete venue"
					})]
				})
			]
		})
	})] });
}
function MapViewModal({ venue, onClose }) {
	const open = venue !== null;
	const elRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			window.removeEventListener("keydown", onKey);
			document.body.style.overflow = prev;
		};
	}, [open, onClose]);
	(0, import_react.useEffect)(() => {
		if (!open || !venue || venue.latitude == null || venue.longitude == null) return;
		let map = null;
		let cancelled = false;
		(async () => {
			const L = (await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).default ?? await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (!document.getElementById("leaflet-css")) {
				const link = document.createElement("link");
				link.id = "leaflet-css";
				link.rel = "stylesheet";
				link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
				document.head.appendChild(link);
			}
			if (cancelled || !elRef.current) return;
			map = L.map(elRef.current, {
				zoomControl: true,
				attributionControl: false
			}).setView([venue.latitude, venue.longitude], 16);
			L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(map);
			const icon = L.divIcon({
				className: "",
				html: `<div style="width:44px;height:44px;border-radius:9999px;background:#fff;border:2px solid #ef4444;display:flex;align-items:center;justify-content:center;font-size:22px;box-shadow:0 6px 18px rgba(0,0,0,.2);">${venue.map_emoji ?? "🎾"}</div>`,
				iconSize: [44, 44],
				iconAnchor: [22, 22]
			});
			L.marker([venue.latitude, venue.longitude], { icon }).addTo(map);
			setTimeout(() => map.invalidateSize(), 80);
		})();
		return () => {
			cancelled = true;
			if (map) map.remove();
		};
	}, [open, venue]);
	if (!open || !venue) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-1300 flex items-center justify-center p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			onClick: onClose,
			className: "absolute inset-0 bg-black/60"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			className: "relative z-10 w-full max-w-3xl overflow-hidden rounded-2xl bg-background shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3 border-b border-border px-4 py-3 sm:px-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xl leading-none",
								children: venue.map_emoji ?? "🎾"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "truncate text-base font-bold sm:text-lg",
								children: venue.name
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-0.5 truncate text-xs text-muted-foreground",
							children: venue.address
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						"aria-label": "Close",
						className: "rounded-md border border-border px-2 py-1 text-sm hover:bg-secondary",
						children: "✕"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: elRef,
						className: "h-[60vh] w-full"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapInfoButton, {
						getCenter: () => venue.latitude != null && venue.longitude != null ? {
							lat: venue.latitude,
							lng: venue.longitude
						} : null,
						className: "bottom-3 right-3"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2 border-t border-border px-4 py-3 text-xs sm:px-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: "View only · edits are made from the Edit action."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `https://www.google.com/maps?q=${venue.latitude},${venue.longitude}`,
						target: "_blank",
						rel: "noreferrer",
						className: "font-semibold text-primary hover:underline",
						children: "Open in Google Maps ↗"
					})]
				})
			]
		})]
	});
}
function EditVenueDrawer({ venue, onClose }) {
	const qc = useQueryClient();
	const open = venue !== null;
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			window.removeEventListener("keydown", onKey);
			document.body.style.overflow = prev;
		};
	}, [open, onClose]);
	const courtsQ = useQuery({
		queryKey: ["courts-count", venue?.id],
		enabled: open,
		queryFn: async () => {
			const { count } = await supabase.from("courts").select("id", {
				count: "exact",
				head: true
			}).eq("venue_id", venue.id);
			return count ?? 0;
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-1200 " + (open ? "pointer-events-auto" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			onClick: onClose,
			className: "absolute inset-0 bg-black/40 transition-opacity duration-300 " + (open ? "opacity-100" : "opacity-0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "absolute right-0 top-0 h-full w-full max-w-xl overflow-y-auto bg-background shadow-2xl transition-transform duration-300 ease-out " + (open ? "translate-x-0" : "translate-x-full"),
			role: "dialog",
			"aria-modal": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background/95 px-4 py-3 backdrop-blur sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold",
					children: "Edit venue"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					"aria-label": "Close",
					className: "rounded-md border border-border px-2 py-1 text-sm hover:bg-secondary",
					children: "✕"
				})]
			}), open && venue && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 p-4 sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenueEditor, {
					venue,
					courtsCount: courtsQ.data ?? 0,
					initialEditing: true,
					onDoneEditing: onClose
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground",
						children: "Map location"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenueLocation, {
						venue,
						onSaved: () => qc.invalidateQueries({ queryKey: ["my-venues"] })
					})]
				})]
			})]
		})]
	});
}
function DeleteCourtButton({ court, onDeleted }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	const usageQ = useQuery({
		queryKey: ["court-delete-usage", court.id],
		enabled: open,
		queryFn: async () => {
			const nowIso = (/* @__PURE__ */ new Date()).toISOString();
			const [all, upcoming, paid] = await Promise.all([
				supabase.from("bookings").select("id", {
					count: "exact",
					head: true
				}).eq("court_id", court.id),
				supabase.from("bookings").select("id", {
					count: "exact",
					head: true
				}).eq("court_id", court.id).eq("status", "confirmed").gte("start_time", nowIso),
				supabase.from("bookings").select("id", {
					count: "exact",
					head: true
				}).eq("court_id", court.id).eq("payment_status", "paid")
			]);
			if (all.error) throw all.error;
			if (upcoming.error) throw upcoming.error;
			if (paid.error) throw paid.error;
			return {
				total: all.count ?? 0,
				upcoming: upcoming.count ?? 0,
				paid: paid.count ?? 0
			};
		}
	});
	const usage = usageQ.data;
	const blocked = !!usage && usage.total > 0;
	const del = useMutation({
		mutationFn: async () => {
			const { count, error: cErr } = await supabase.from("bookings").select("id", {
				count: "exact",
				head: true
			}).eq("court_id", court.id);
			if (cErr) throw cErr;
			if ((count ?? 0) > 0) throw new Error("This court has booking history and cannot be deleted.");
			const { error } = await supabase.from("courts").delete().eq("id", court.id);
			if (error) throw error;
		},
		onSuccess: () => {
			setOpen(false);
			setErr(null);
			onDeleted();
		},
		onError: (e) => setErr(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => {
			setOpen(true);
			setErr(null);
		},
		title: "Delete court",
		"aria-label": `Delete ${court.name}`,
		className: "inline-flex h-7 w-7 items-center justify-center rounded-full border border-destructive/40 text-destructive align-middle transition hover:bg-destructive/10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3.5 w-3.5" })
	}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-1300 flex items-center justify-center whitespace-normal bg-black/50 p-4 text-left",
		onClick: () => {
			if (!del.isPending) setOpen(false);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md whitespace-normal wrap-break-word rounded-2xl border border-border bg-background p-5 text-left shadow-xl",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-base font-bold",
					children: [
						"Delete \"",
						court.name,
						"\"?"
					]
				}),
				usageQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Checking bookings…"
				}) : blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 rounded-lg border border-destructive/30 bg-destructive/10 p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-2 text-destructive",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: "This court can't be deleted."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "mt-1 list-disc space-y-0.5 pl-4",
									children: [
										usage.upcoming > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											usage.upcoming,
											" upcoming confirmed booking",
											usage.upcoming === 1 ? "" : "s"
										] }),
										usage.paid > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											usage.paid,
											" paid transaction",
											usage.paid === 1 ? "" : "s",
											" on record"
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
											usage.total,
											" booking record",
											usage.total === 1 ? "" : "s",
											" in total"
										] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-muted-foreground",
									children: [
										"Booking and payment history must stay intact. Set the court to ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Inactive" }),
										" in Edit court instead — it disappears from players but keeps its records."
									]
								})
							]
						})]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "This court has no bookings or transactions. Deleting it is permanent and removes its pricing, hours and images."
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 rounded-md bg-destructive/10 px-2 py-1 text-xs text-destructive",
					children: err
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setOpen(false),
						disabled: del.isPending,
						className: "rounded-lg border border-border px-3 py-1.5 text-xs",
						children: "Close"
					}), !blocked && !usageQ.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => del.mutate(),
						disabled: del.isPending,
						className: "rounded-lg bg-destructive px-3 py-1.5 text-xs font-semibold text-destructive-foreground disabled:opacity-60",
						children: del.isPending ? "Deleting…" : "Delete court"
					})]
				})
			]
		})
	})] });
}
function CourtsTab({ venues }) {
	const qc = useQueryClient();
	const venueIds = venues.map((v) => v.id);
	const courtsQ = useQuery({
		queryKey: ["all-tenant-courts", venueIds.join(",")],
		enabled: venueIds.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.from("courts").select("*, sports(name)").in("venue_id", venueIds).order("created_at", { ascending: false }).order("id", { ascending: false });
			if (error) throw error;
			const byId = new Map(venues.map((v) => [v.id, v]));
			return data.map((c) => ({
				...c,
				venue: byId.get(c.venue_id)
			}));
		}
	});
	const [venueFilter, setVenueFilter] = (0, import_react.useState)("all");
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [managingHours, setManagingHours] = (0, import_react.useState)(null);
	const [historyCourt, setHistoryCourt] = (0, import_react.useState)(null);
	const [colCfgOpen, setColCfgOpen] = (0, import_react.useState)(false);
	const { selected: visibleCols, save: saveCols } = useCourtColumns();
	const rows = (courtsQ.data ?? []).filter((c) => venueFilter === "all" || c.venue_id === venueFilter);
	const invalidate = () => {
		[
			"all-tenant-courts",
			"venues-courts-glance",
			"venues-court-counts",
			"venues-courts-table",
			"courts",
			"physical-courts-full",
			"physical-courts",
			"venues-group-counts",
			"group-eligible-courts"
		].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
	};
	const cfgButton = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => setColCfgOpen(true),
		title: "Configure columns",
		"aria-label": "Configure columns",
		className: "inline-flex h-7 w-7 items-center justify-center rounded-md border border-border bg-background text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableProperties, { className: "h-4 w-4" })
	});
	const renderHeader = (id) => {
		switch (id) {
			case "emoji": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-4 py-2.5 w-10",
				children: cfgButton
			}, id);
			case "name": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5",
				children: "Court"
			}, id);
			case "description": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5",
				children: "About This Court"
			}, id);
			case "venue": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5",
				children: "Venue"
			}, id);
			case "sport": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5",
				children: "Sport"
			}, id);
			case "type": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5",
				children: "Type"
			}, id);
			case "surface": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5",
				children: "Surface"
			}, id);
			case "capacity": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 text-center",
				children: "Capacity"
			}, id);
			case "rate": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 text-right",
				children: "Rate / hr"
			}, id);
			case "voucher": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 text-center",
				children: "Voucher"
			}, id);
			case "status": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5",
				children: "Status"
			}, id);
			case "created_at": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-32",
				children: "Created At"
			}, id);
			case "history": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 w-24 text-center",
				children: "History"
			}, id);
			case "actions": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2.5 text-right",
				children: "Actions"
			}, id);
			default: return null;
		}
	};
	const renderCell = (id, c) => {
		switch (id) {
			case "emoji": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-4 py-3 text-xl leading-none",
				children: c.map_emoji ?? c.venue.map_emoji ?? "🎾"
			}, id);
			case "name": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-semibold",
					children: c.name
				})
			}, id);
			case "description": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: c.description?.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					title: c.description,
					className: "line-clamp-2 max-w-65 whitespace-normal wrap-break-word text-[12px] leading-snug text-muted-foreground",
					children: c.description
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "—"
				})
			}, id);
			case "venue": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-2.5 py-1 text-[13px] font-semibold leading-tight text-foreground ring-1 ring-primary/20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-base leading-none",
						children: c.venue.map_emoji ?? "🏟️"
					}), c.venue.name]
				})
			}, id);
			case "sport": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-muted-foreground",
				children: c.sports?.name ?? "—"
			}, id);
			case "type": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-muted-foreground",
				children: c.is_indoor ? "Indoor" : "Outdoor"
			}, id);
			case "surface": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-muted-foreground",
				children: c.surface_type?.trim() ? c.surface_type : "—"
			}, id);
			case "capacity": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-center tabular-nums text-muted-foreground",
				children: c.player_capacity ?? "—"
			}, id);
			case "rate": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-[15px] font-bold tabular-nums text-foreground [text-shadow:0_0_10px_rgba(250,204,21,0.85)]",
					children: ["₱", Number(c.hourly_rate).toFixed(0)]
				})
			}, id);
			case "voucher": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-center",
				children: c.voucher_enabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-600 ring-1 ring-emerald-500/30",
					children: "True"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-muted px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground ring-1 ring-border",
					children: "False"
				})
			}, id);
			case "status": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: c.coming_soon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-amber-600 ring-1 ring-amber-500/30",
					children: "Coming soon"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-emerald-600 ring-1 ring-emerald-500/30",
					children: "ACTIVE"
				})
			}, id);
			case "created_at": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: c.created_at ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col leading-tight",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: new Date(c.created_at).toLocaleDateString(void 0, {
							year: "numeric",
							month: "short",
							day: "numeric"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-muted-foreground",
						children: new Date(c.created_at).toLocaleTimeString(void 0, {
							hour: "numeric",
							minute: "2-digit"
						})
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "—"
				})
			}, id);
			case "history": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setHistoryCourt(c),
					title: "Audit history",
					"aria-label": `View audit history for ${c.name}`,
					className: "inline-flex h-7 w-7 items-center justify-center rounded-full border border-border text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "h-3.5 w-3.5" })
				})
			}, id);
			case "actions": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-end gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setEditing(c),
						title: "Edit court",
						"aria-label": `Edit ${c.name}`,
						className: "inline-flex h-7 w-7 items-center justify-center rounded-full border border-border text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteCourtButton, {
						court: c,
						onDeleted: invalidate
					})]
				})
			}, id);
			default: return null;
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sticky top-0 z-20 flex items-center gap-2 border-b border-border bg-background/95 px-4 py-2 backdrop-blur",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "text-xs text-muted-foreground",
				children: "Filter venue:"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				value: venueFilter === "all" ? "all" : String(venueFilter),
				onChange: (e) => setVenueFilter(e.target.value === "all" ? "all" : Number(e.target.value)),
				className: "rounded-md border border-input bg-background px-2 py-1 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "all",
					children: "All venues"
				}), venues.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: v.id,
					children: v.name
				}, v.id))]
			})]
		}),
		courtsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 animate-pulse rounded-lg bg-muted" })
		}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-8 text-center text-sm text-muted-foreground",
			children: [
				"No courts yet. Use ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Add court" }),
				" to create one."
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-225 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "sticky top-10.25 z-10 bg-secondary/60 text-left text-[11px] uppercase tracking-wider text-muted-foreground backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [!visibleCols.includes("emoji") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "w-8 pl-2 pr-0 py-2.5",
					children: cfgButton
				}), visibleCols.map((id) => renderHeader(id))] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-border align-middle hover:bg-secondary/20",
				children: [!visibleCols.includes("emoji") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { className: "w-8 pl-2 pr-0 py-3" }), visibleCols.map((id) => renderCell(id, c))]
			}, c.id)) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnConfigModal, {
			open: colCfgOpen,
			onClose: () => setColCfgOpen(false),
			selected: visibleCols,
			onApply: saveCols,
			columns: COURT_COLUMNS,
			defaults: DEFAULT_COURT_COLS,
			presetKey: "courts_column_presets"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtAuditHistoryModal, {
			court: historyCourt,
			onClose: () => setHistoryCourt(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtDrawer, {
			title: "Edit court",
			open: editing !== null,
			onClose: () => setEditing(null),
			children: editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditCourt, {
				court: editing,
				venueEmoji: editing.venue.map_emoji,
				onDone: () => {
					invalidate();
					setEditing(null);
				},
				onCancel: () => setEditing(null)
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtDrawer, {
			title: "Manage availability",
			open: managingHours !== null,
			onClose: () => setManagingHours(null),
			children: managingHours && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvailabilityEditor, {
				court: managingHours,
				onDone: () => {
					invalidate();
					setManagingHours(null);
				},
				onCancel: () => setManagingHours(null)
			})
		})
	] });
}
function CourtAuditHistoryModal({ court, onClose }) {
	const { data, isLoading } = useQuery({
		queryKey: ["court-audit", court?.id],
		enabled: !!court,
		queryFn: async () => {
			const { data, error } = await supabase.from("court_audit_log").select("*").eq("court_id", court.id).order("created_at", { ascending: false });
			if (error) throw error;
			return data ?? [];
		}
	});
	if (!court) return null;
	const fmt = (iso) => new Date(iso).toLocaleString(void 0, {
		year: "numeric",
		month: "short",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-1300 flex items-center justify-center bg-black/60 p-4",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-lg rounded-2xl border border-border bg-card shadow-xl",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border px-5 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: "Court history"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-semibold",
					children: court.name
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "rounded-full p-1.5 text-muted-foreground hover:bg-secondary/60 hover:text-foreground",
					"aria-label": "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-[60vh] overflow-y-auto px-5 py-4",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-8 text-center text-sm text-muted-foreground",
					children: "Loading…"
				}) : !data || data.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-8 text-center text-sm text-muted-foreground italic",
					children: "No history yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "relative space-y-4 border-l border-border pl-5",
					children: data.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute -left-6.5 top-1.5 h-3 w-3 rounded-full ring-4 ring-card ${e.action === "created" ? "bg-primary" : "bg-amber-500"}` }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-flex rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${e.action === "created" ? "bg-primary/15 text-primary" : "bg-amber-500/15 text-amber-600 dark:text-amber-400"}`,
									children: e.action === "created" ? "Created" : "Last modified"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: fmt(e.created_at)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "by "
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: e.actor_name?.trim() || "Unknown"
								})]
							}),
							e.action === "updated" && e.changes && Object.keys(e.changes).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1.5 flex flex-wrap gap-1",
								children: Object.keys(e.changes).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex rounded-md bg-secondary/60 px-1.5 py-0.5 text-[10px] text-muted-foreground",
									children: k
								}, k))
							})
						]
					}, e.id))
				})
			})]
		})
	});
}
function CourtDrawer({ title, open, onClose, children }) {
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			window.removeEventListener("keydown", onKey);
			document.body.style.overflow = prev;
		};
	}, [open, onClose]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-1200 " + (open ? "pointer-events-auto" : "pointer-events-none"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			onClick: onClose,
			className: "absolute inset-0 bg-black/40 transition-opacity duration-300 " + (open ? "opacity-100" : "opacity-0")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "absolute right-0 top-0 h-full w-full max-w-2xl overflow-y-auto bg-background shadow-2xl transition-transform duration-300 ease-out " + (open ? "translate-x-0" : "translate-x-full"),
			role: "dialog",
			"aria-modal": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background/95 px-4 py-3 backdrop-blur sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-bold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					"aria-label": "Close",
					className: "rounded-md border border-border px-2 py-1 text-sm hover:bg-secondary",
					children: "✕"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "p-4 sm:p-6",
				children: open && children
			})]
		})]
	});
}
function CourtGroupsTab({ venues }) {
	const [venueId, setVenueId] = (0, import_react.useState)(venues[0]?.id ?? null);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [colCfgOpen, setColCfgOpen] = (0, import_react.useState)(false);
	const { selected: visibleCols, save: saveCols } = useGroupColumns();
	(0, import_react.useEffect)(() => {
		if (!venueId && venues[0]) setVenueId(venues[0].id);
	}, [venues, venueId]);
	const groupsQ = useQuery({
		queryKey: ["physical-courts-full", venueId],
		enabled: !!venueId,
		queryFn: async () => {
			const { data: pcs, error } = await supabase.from("physical_courts").select("id, venue_id, name, map_emoji, description").eq("venue_id", venueId).order("id");
			if (error) throw error;
			const pcIds = (pcs ?? []).map((p) => p.id);
			if (pcIds.length === 0) return [];
			const { data: cs, error: cErr } = await supabase.from("courts").select("id, name, physical_court_id, sports(name)").in("physical_court_id", pcIds);
			if (cErr) throw cErr;
			const byPc = /* @__PURE__ */ new Map();
			(cs ?? []).forEach((c) => {
				const arr = byPc.get(c.physical_court_id) ?? [];
				arr.push({
					id: c.id,
					name: c.name,
					sport: c.sports?.name ?? null
				});
				byPc.set(c.physical_court_id, arr);
			});
			const courtIds = (cs ?? []).map((c) => c.id);
			const rulesByCourt = /* @__PURE__ */ new Map();
			if (courtIds.length > 0) {
				const { data: rs, error: rErr } = await supabase.from("court_block_rules").select("court_id").in("court_id", courtIds);
				if (rErr) throw rErr;
				(rs ?? []).forEach((r) => rulesByCourt.set(r.court_id, (rulesByCourt.get(r.court_id) ?? 0) + 1));
			}
			return (pcs ?? []).map((p) => {
				const layouts = byPc.get(p.id) ?? [];
				const rulesCount = layouts.reduce((sum, l) => sum + (rulesByCourt.get(l.id) ?? 0), 0);
				return {
					...p,
					layouts,
					rulesCount
				};
			}).filter((g) => g.layouts.length >= 2);
		}
	});
	const groups = groupsQ.data ?? [];
	const cfgButton = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => setColCfgOpen(true),
		title: "Configure columns",
		"aria-label": "Configure columns",
		className: "inline-flex h-7 w-7 items-center justify-center rounded-md border border-border bg-background text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableProperties, { className: "h-4 w-4" })
	});
	const renderHeader = (id) => {
		switch (id) {
			case "emoji": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2 w-10 font-semibold",
				children: cfgButton
			}, id);
			case "name": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2 font-semibold",
				children: "Group"
			}, id);
			case "description": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2 font-semibold",
				children: "About this group"
			}, id);
			case "courts_count": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2 font-semibold text-center",
				children: "Courts"
			}, id);
			case "rules": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2 font-semibold text-center",
				children: "Blocking rules"
			}, id);
			case "sports": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2 font-semibold",
				children: "Sports"
			}, id);
			case "actions": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "px-3 py-2 font-semibold text-right",
				children: "Actions"
			}, id);
			default: return null;
		}
	};
	const renderCell = (id, g) => {
		switch (id) {
			case "emoji": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-lg leading-none",
				children: g.map_emoji ?? "🏟️"
			}, id);
			case "name": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: g.name
				})
			}, id);
			case "description": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-muted-foreground",
				children: g.description || "—"
			}, id);
			case "courts_count": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "inline-flex items-center rounded-full bg-primary/10 px-2 py-0.5 text-[11px] font-semibold text-primary ring-1 ring-primary/20",
					children: g.layouts.length
				})
			}, id);
			case "rules": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3 text-center",
				children: g.rulesCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center rounded-full bg-secondary px-2 py-0.5 text-[11px] font-semibold text-foreground ring-1 ring-border",
					children: [
						g.rulesCount,
						" ",
						g.rulesCount === 1 ? "rule" : "rules",
						" set up"
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "No rules yet"
				})
			}, id);
			case "sports": {
				const list = Array.from(new Set(g.layouts.map((l) => l.sport).filter(Boolean)));
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-3 py-3 text-muted-foreground text-xs",
					children: list.length ? list.join(", ") : "—"
				}, id);
			}
			case "actions": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-end gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setEditing(g),
						title: "Edit group",
						"aria-label": `Edit ${g.name}`,
						className: "inline-flex h-9 w-9 items-center justify-center rounded-full border border-border text-muted-foreground transition hover:border-primary hover:bg-primary/10 hover:text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteGroupButton, { group: g })]
				})
			}, id);
			default: return null;
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 p-4 sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium text-muted-foreground",
						children: "Venue"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: venueId ?? "",
						onChange: (e) => setVenueId(e.target.value ? Number(e.target.value) : null),
						className: "mt-1 rounded-lg border border-input bg-background px-3 py-2 text-sm",
						children: venues.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: v.id,
							children: v.name
						}, v.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						"Use ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-foreground",
							children: "+ Create group"
						}),
						" to bundle courts that share the same physical space."
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-auto nice-scroll px-4 pb-6 sm:px-6",
				children: groupsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 animate-pulse rounded-xl bg-muted" }) : groups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground",
					children: [
						"No shared-surface groups yet for this venue. Click ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-foreground",
							children: "+ Create group"
						}),
						" above to bundle courts that share one physical space."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-180 border-separate border-spacing-0 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "sticky top-0 z-10 bg-background",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-left text-xs uppercase tracking-wide text-muted-foreground",
							children: [!visibleCols.includes("emoji") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "w-8 pl-2 pr-0 py-2",
								children: cfgButton
							}), visibleCols.map((id) => renderHeader(id))]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border align-top",
						children: [!visibleCols.includes("emoji") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { className: "w-8 pl-2 pr-0 py-3" }), visibleCols.map((id) => renderCell(id, g))]
					}, g.id)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnConfigModal, {
				open: colCfgOpen,
				onClose: () => setColCfgOpen(false),
				selected: visibleCols,
				onApply: saveCols,
				columns: GROUP_COLUMNS,
				defaults: DEFAULT_GROUP_COLS,
				presetKey: "groups_column_presets"
			}),
			editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditGroupDrawer, {
				group: editing,
				onClose: () => setEditing(null)
			})
		]
	});
}
function DeleteGroupButton({ group }) {
	const qc = useQueryClient();
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	const mut = useMutation({
		mutationFn: async () => {
			const courtIds = group.layouts.map((l) => l.id);
			if (courtIds.length > 0) {
				const { count, error } = await supabase.from("bookings").select("id", {
					count: "exact",
					head: true
				}).in("court_id", courtIds).eq("status", "confirmed").gte("end_time", (/* @__PURE__ */ new Date()).toISOString());
				if (error) throw error;
				if ((count ?? 0) > 0) throw new Error("This group has upcoming confirmed bookings and cannot be deleted until they finish or are cancelled.");
				for (const c of group.layouts) {
					const { data: pc, error: pcErr } = await supabase.from("physical_courts").insert({
						venue_id: group.venue_id ?? void 0,
						name: c.name
					}).select("id").single();
					if (pcErr) throw pcErr;
					const { error: upErr } = await supabase.from("courts").update({
						physical_court_id: pc.id,
						capacity: 1,
						footprint: 1
					}).eq("id", c.id);
					if (upErr) throw upErr;
				}
			}
			const { error } = await supabase.from("physical_courts").delete().eq("id", group.id);
			if (error) throw error;
		},
		onSuccess: () => {
			setConfirm(false);
			setErr(null);
			[
				"physical-courts-full",
				"physical-courts",
				"tenant-venues-full",
				"venues-group-counts",
				"group-eligible-courts",
				"all-tenant-courts",
				"court-block-rules"
			].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
		},
		onError: (e) => setErr(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => {
			setErr(null);
			setConfirm(true);
		},
		title: "Delete group",
		"aria-label": `Delete ${group.name}`,
		className: "inline-flex h-9 w-9 items-center justify-center rounded-full border border-border text-muted-foreground transition hover:border-destructive hover:bg-destructive/10 hover:text-destructive",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
	}), confirm && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-70 grid place-items-center bg-black/50 p-4",
		onClick: () => !mut.isPending && setConfirm(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-2xl border border-destructive/40 bg-background p-5 shadow-2xl",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-10 w-10 shrink-0 place-items-center rounded-full bg-destructive/10 text-destructive",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-5 w-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-base font-semibold",
							children: "Delete group permanently?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-foreground",
									children: group.name
								}),
								" will be ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-destructive",
									children: "permanently deleted"
								}),
								". Its courts remain but each becomes independent again."
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-xs text-destructive",
					children: [
						"⚠ This action is ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "permanent" }),
						" and cannot be undone."
					]
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive",
					children: err
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: mut.isPending,
						onClick: () => setConfirm(false),
						className: "rounded-lg border border-border bg-background px-4 py-2 text-sm font-semibold hover:border-primary",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: mut.isPending,
						onClick: () => mut.mutate(),
						className: "rounded-lg bg-destructive px-4 py-2 text-sm font-semibold text-destructive-foreground disabled:opacity-50",
						children: mut.isPending ? "Deleting…" : "Delete permanently"
					})]
				})
			]
		})
	})] });
}
function EditGroupDrawer({ group, onClose }) {
	const qc = useQueryClient();
	const [name, setName] = (0, import_react.useState)(group.name);
	const [emoji, setEmoji] = (0, import_react.useState)(group.map_emoji);
	const [description, setDescription] = (0, import_react.useState)(group.description ?? "");
	const [addSel, setAddSel] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [detachSel, setDetachSel] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [err, setErr] = (0, import_react.useState)(null);
	const memberSet = new Set(group.layouts.map((l) => l.id));
	const eligibleQ = useQuery({
		queryKey: [
			"group-add-eligible",
			group.venue_id,
			group.id
		],
		queryFn: async () => {
			const { data, error } = await supabase.from("courts").select("id, name, physical_court_id, sports(name)").eq("venue_id", group.venue_id).order("id");
			if (error) throw error;
			return data ?? [];
		}
	});
	const memberIds = [...group.layouts.filter((l) => !detachSel.has(l.id)).map((l) => l.id), ...Array.from(addSel)];
	const rulesQ = useQuery({
		queryKey: [
			"court-block-rules",
			group.id,
			group.layouts.map((l) => l.id).join(",")
		],
		enabled: group.layouts.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.from("court_block_rules").select("court_id, blocked_court_id").in("court_id", group.layouts.map((l) => l.id));
			if (error) throw error;
			return (data ?? []).map((r) => ruleKey(r.court_id, r.blocked_court_id));
		}
	});
	const [rulesDraft, setRulesDraft] = (0, import_react.useState)(null);
	const rules = rulesDraft ?? new Set(rulesQ.data ?? []);
	const ruleCourts = [...group.layouts.filter((l) => !detachSel.has(l.id)).map((l) => ({
		id: l.id,
		name: l.name,
		sport: l.sport
	})), ...(eligibleQ.data ?? []).filter((c) => addSel.has(c.id)).map((c) => ({
		id: c.id,
		name: c.name,
		sport: c.sports?.name ?? null
	}))];
	const toggleAdd = (id) => {
		setAddSel((prev) => {
			const next = new Set(prev);
			if (next.has(id)) next.delete(id);
			else next.add(id);
			return next;
		});
	};
	const toggleDetach = (id) => {
		setErr(null);
		setDetachSel((prev) => {
			const next = new Set(prev);
			if (next.has(id)) next.delete(id);
			else next.add(id);
			return next;
		});
	};
	const mut = useMutation({
		mutationFn: async () => {
			if (!name.trim()) throw new Error("Group name is required");
			const { error } = await supabase.from("physical_courts").update({
				name: name.trim(),
				map_emoji: emoji,
				description: description.trim() || null
			}).eq("id", group.id);
			if (error) throw error;
			for (const id of Array.from(detachSel)) {
				const { count, error: cErr } = await supabase.from("bookings").select("id", {
					count: "exact",
					head: true
				}).eq("court_id", id).eq("status", "confirmed").gte("end_time", (/* @__PURE__ */ new Date()).toISOString());
				if (cErr) throw cErr;
				if ((count ?? 0) > 0) throw new Error("A court you unticked has upcoming confirmed bookings and cannot be detached until they finish or are cancelled.");
				const { data: pc, error: pcErr } = await supabase.from("physical_courts").insert({
					venue_id: group.venue_id,
					name: `Slab ${Date.now()}`
				}).select("id").single();
				if (pcErr) throw pcErr;
				const { error: dErr } = await supabase.from("courts").update({ physical_court_id: pc.id }).eq("id", id);
				if (dErr) throw dErr;
				const { error: rErr } = await supabase.from("court_block_rules").delete().eq("court_id", id);
				if (rErr) throw rErr;
			}
			for (const id of Array.from(addSel)) {
				const { error: upErr } = await supabase.from("courts").update({ physical_court_id: group.id }).eq("id", id);
				if (upErr) throw upErr;
			}
			const ids = memberIds;
			if (ids.length > 0) {
				const { error: delErr } = await supabase.from("court_block_rules").delete().in("court_id", ids);
				if (delErr) throw delErr;
				const rows = Array.from(rules).map((k) => k.split(">").map(Number)).filter(([a, b]) => ids.includes(a) && ids.includes(b)).map(([a, b]) => ({
					court_id: a,
					blocked_court_id: b,
					venue_id: group.venue_id
				}));
				if (rows.length > 0) {
					const { error: insErr } = await supabase.from("court_block_rules").insert(rows);
					if (insErr) throw insErr;
				}
			}
		},
		onSuccess: () => {
			[
				"physical-courts-full",
				"physical-courts",
				"tenant-venues-full",
				"venues-group-counts",
				"group-eligible-courts",
				"all-tenant-courts",
				"court-block-rules"
			].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
			onClose();
		},
		onError: (e) => setErr(e.message)
	});
	const eligible = eligibleQ.data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-70 flex",
		onClick: onClose,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1 bg-black/50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "h-full w-full max-w-lg overflow-y-auto bg-background shadow-2xl nice-scroll",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-0 z-10 flex items-center justify-between border-b border-border bg-background px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-lg font-semibold",
					children: "Edit group"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "rounded-full p-1 text-muted-foreground hover:bg-secondary hover:text-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (e) => {
					e.preventDefault();
					mut.mutate();
				},
				className: "grid gap-4 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-primary/30 bg-primary/5 p-3 text-xs text-muted-foreground",
						children: [
							"Editing the ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "text-foreground",
								children: "whole group"
							}),
							" — group name, emoji, description, and which courts belong to this shared space."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						label: "Group name",
						value: name,
						onChange: setName,
						required: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-xl border border-border bg-background p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmojiPicker, {
							label: "Group emoji",
							value: emoji,
							fallback: "🏟️",
							onChange: setEmoji,
							hint: "Shown on the map and in the courts table."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						label: "About this Group (optional)",
						value: description,
						onChange: setDescription,
						placeholder: "Court size, surface, lighting, house rules…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtBlockRulesEditor, {
						courts: ruleCourts,
						rules,
						onChange: setRulesDraft
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-dashed border-border p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold",
								children: "Courts in this group"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: "Tick courts from this venue to include them in this group; untick to detach."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid gap-2",
								children: [eligible.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "No courts in this venue."
								}), eligible.map((c) => {
									const isMember = memberSet.has(c.id);
									const checked = isMember ? !detachSel.has(c.id) : addSel.has(c.id);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: `flex items-center gap-2 rounded-lg border px-2 py-2 text-sm ${checked ? "border-primary bg-primary/5" : "border-border"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked,
											onChange: () => isMember ? toggleDetach(c.id) : toggleAdd(c.id)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex-1 min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "truncate font-medium",
												children: c.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] text-muted-foreground",
												children: c.sports?.name ?? "—"
											})]
										})]
									}, c.id);
								})]
							})
						]
					}),
					err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive",
						children: err
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onClose,
							className: "rounded-lg border border-border bg-background px-4 py-2 text-sm font-semibold hover:border-primary",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: mut.isPending || !name.trim(),
							className: "rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50",
							children: mut.isPending ? "Saving…" : "Save changes"
						})]
					})
				]
			})]
		})]
	});
}
function TransactionsSection({ venues }) {
	useQueryClient();
	const [venueFilter, setVenueFilter] = (0, import_react.useState)("all");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("all");
	const txQ = useQuery({
		queryKey: [
			"tenant-transactions",
			venueFilter,
			statusFilter
		],
		queryFn: async () => {
			let q = supabase.from("transactions").select("*").order("created_at", { ascending: false }).limit(500);
			if (venueFilter !== "all") q = q.eq("venue_id", venueFilter);
			if (statusFilter !== "all") q = q.eq("status", statusFilter);
			const { data, error } = await q;
			if (error) throw error;
			return data ?? [];
		}
	});
	const rows = txQ.data ?? [];
	const paid = rows.filter((r) => r.status === "paid");
	const now = Date.now();
	const sumSince = (ms) => paid.filter((r) => new Date(r.paid_at ?? r.created_at).getTime() >= now - ms).reduce((s, r) => s + Number(r.amount), 0);
	const todaySum = sumSince(24 * 36e5);
	const weekSum = sumSince(168 * 36e5);
	const monthSum = sumSince(720 * 36e5);
	const uniqueCustomers = new Set(paid.map((r) => r.user_id)).size;
	const totalBookings = new Set(paid.map((r) => r.booking_id)).size;
	const currency = (n) => "₱" + n.toLocaleString("en-PH", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	});
	const fmtDate = (iso) => new Date(iso).toLocaleString("en-PH", {
		dateStyle: "medium",
		timeStyle: "short"
	});
	const statusBadge = (s) => {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `rounded-full px-2 py-0.5 text-[11px] font-semibold capitalize ${{
				paid: "bg-primary/15 text-primary",
				pending: "bg-amber-500/15 text-amber-700",
				failed: "bg-destructive/15 text-destructive",
				refunded: "bg-muted text-muted-foreground",
				cancelled: "bg-muted text-muted-foreground"
			}[s] ?? "bg-secondary text-foreground"}`,
			children: s
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: "Transactions",
				subtitle: "Track online payments, refunds and customer activity across your venues."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerKpi, {
						label: "Sales · Today",
						value: currency(todaySum)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerKpi, {
						label: "Sales · 7 days",
						value: currency(weekSum)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerKpi, {
						label: "Sales · 30 days",
						value: currency(monthSum)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerKpi, {
						label: "Paid bookings",
						value: String(totalBookings)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerKpi, {
						label: "Unique customers",
						value: String(uniqueCustomers)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: venueFilter,
						onChange: (e) => setVenueFilter(e.target.value === "all" ? "all" : Number(e.target.value)),
						className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All venues"
						}), venues.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: v.id,
							children: v.name
						}, v.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: statusFilter,
						onChange: (e) => setStatusFilter(e.target.value),
						className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "All statuses"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "paid",
								children: "Paid"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "pending",
								children: "Pending"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "failed",
								children: "Failed"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "refunded",
								children: "Refunded"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-auto rounded-full bg-secondary px-3 py-1 text-xs font-semibold",
						children: [
							"PayMongo · ",
							paid[0]?.mode === "live" ? "Live" : "Test",
							" mode"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-border bg-card shadow-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nice-scroll max-h-[55vh] overflow-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "sticky top-0 z-10 bg-secondary/70 text-xs uppercase tracking-wide text-muted-foreground backdrop-blur",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Amount"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Method"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "PayMongo payment ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Booking"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Venue"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: txQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-6 text-muted-foreground",
							colSpan: 7,
							children: "Loading…"
						}) }) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-6 text-muted-foreground",
							colSpan: 7,
							children: "No transactions yet. Once players start paying online, they'll show up here."
						}) }) : rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 whitespace-nowrap",
									children: fmtDate(r.paid_at ?? r.created_at)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-semibold",
									children: currency(Number(r.amount))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 capitalize",
									children: r.method.replace("_", " ")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: statusBadge(r.status)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
										className: "text-xs font-semibold",
										children: r.raw?.payment_id ?? "—"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: ["#", r.booking_id]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: venues.find((v) => v.id === r.venue_id)?.name ?? `Venue #${r.venue_id}`
								})
							]
						}, r.id)) })]
					})
				})
			})
		]
	});
}
function VenuePaymentRow({ venue, onSave }) {
	const [mode, setMode] = (0, import_react.useState)(venue.payment_mode);
	const [cutoff, setCutoff] = (0, import_react.useState)(venue.refund_cutoff_hours);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const dirty = mode !== venue.payment_mode || cutoff !== venue.refund_cutoff_hours;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 rounded-xl border border-border bg-background p-3 sm:grid-cols-[1fr_auto_auto_auto] sm:items-end",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold",
				children: venue.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11px] text-muted-foreground",
				children: [
					"Current: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium capitalize",
						children: venue.payment_mode === "none" ? "settle at venue" : venue.payment_mode
					}),
					" · Refund cutoff ",
					venue.refund_cutoff_hours,
					"h"
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] font-medium text-muted-foreground",
					children: "Payment mode"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: mode,
					onChange: (e) => setMode(e.target.value),
					className: "mt-1 w-full rounded-lg border border-border bg-card px-2 py-1.5 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "none",
						children: "Settle at venue"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "full",
						children: "Full payment"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] font-medium text-muted-foreground",
					children: "Refund cutoff (hrs)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					min: 0,
					value: cutoff,
					onChange: (e) => setCutoff(Number(e.target.value)),
					className: "mt-1 w-24 rounded-lg border border-border bg-card px-2 py-1.5 text-sm"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: !dirty || saving,
				onClick: async () => {
					setSaving(true);
					await onSave(venue.id, mode, cutoff);
					setSaving(false);
				},
				className: "rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground disabled:opacity-50",
				children: saving ? "Saving…" : "Save"
			})
		]
	});
}
function BookingsSection({ venues, userId }) {
	const qc = useQueryClient();
	const [venueFilter, setVenueFilter] = (0, import_react.useState)("all");
	const [status, setStatus] = (0, import_react.useState)("upcoming");
	const [payFilter, setPayFilter] = (0, import_react.useState)("all");
	const [cancelTarget, setCancelTarget] = (0, import_react.useState)(null);
	const [chat, setChat] = (0, import_react.useState)(null);
	const [nowMs, setNowMs] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		const interval = window.setInterval(() => setNowMs(Date.now()), 1e3);
		return () => window.clearInterval(interval);
	}, []);
	const bookingsQ = useQuery({
		queryKey: [
			"tenant-bookings",
			venueFilter,
			status,
			payFilter
		],
		queryFn: async () => {
			let q = supabase.from("bookings").select("id, court_id, user_id, start_time, end_time, status, payment_status, refund_status, created_at, unit_price, discount_amount, courts(name, venue_id, venues(name))").order("start_time", { ascending: false }).limit(500);
			if (payFilter !== "all") q = q.eq("payment_status", payFilter);
			const { data, error } = await q;
			if (error) throw error;
			const nowIso = (/* @__PURE__ */ new Date()).toISOString();
			let rows = data ?? [];
			if (venueFilter !== "all") rows = rows.filter((r) => r.courts?.venue_id === venueFilter);
			if (status === "upcoming") rows = rows.filter((r) => r.end_time >= nowIso && (r.status === "pending" || r.status === "confirmed"));
			else if (status === "past") rows = rows.filter((r) => r.end_time < nowIso && r.status !== "cancelled" && r.status !== "expired");
			else if (status === "cancelled") rows = rows.filter((r) => r.status === "cancelled");
			else if (status === "expired") rows = rows.filter((r) => r.status === "expired");
			return rows;
		}
	});
	const uids = Array.from(new Set((bookingsQ.data ?? []).map((r) => r.user_id)));
	const namesQ = useQuery({
		queryKey: ["profile-names", uids.sort().join(",")],
		enabled: uids.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.from("profiles").select("id, full_name, phone").in("id", uids);
			if (error) throw error;
			return data ?? [];
		}
	});
	const nameMap = new Map((namesQ.data ?? []).map((p) => [p.id, p]));
	const rows = bookingsQ.data ?? [];
	const sessions = groupBookingSessions(rows).sort((a, b) => b.start_time.localeCompare(a.start_time));
	const totalUpcoming = rows.filter((r) => r.end_time >= (/* @__PURE__ */ new Date()).toISOString() && (r.status === "pending" || r.status === "confirmed")).length;
	const paidCount = rows.filter((r) => r.payment_status === "paid").length;
	const unpaidCount = rows.filter((r) => r.payment_status === "pending" && r.status === "pending").length;
	const payBadge = (s, refundStatus) => {
		const map = {
			paid: "bg-primary/15 text-primary",
			pending: "bg-amber-500/15 text-amber-700",
			unpaid: "bg-amber-500/15 text-amber-700",
			failed: "bg-destructive/10 text-destructive",
			cancelled: "bg-muted text-muted-foreground",
			refunded: "bg-muted text-muted-foreground"
		};
		const label = refundStatus === "pending" ? "Awaiting refund" : s === "pending" ? "Payment pending" : s.replace(/_/g, " ");
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `rounded-full px-2 py-0.5 text-[11px] font-semibold capitalize ${map[s] ?? "bg-secondary"}`,
			children: label
		});
	};
	const stBadge = (s) => {
		const map = {
			confirmed: "bg-primary/10 text-primary",
			cancelled: "bg-destructive/10 text-destructive",
			pending: "bg-amber-500/15 text-amber-700",
			expired: "bg-muted text-muted-foreground"
		};
		const label = s === "pending" ? "Payment in progress" : s;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `rounded-full px-2 py-0.5 text-[11px] font-semibold capitalize ${map[s] ?? "bg-secondary"}`,
			children: label
		});
	};
	const paymentHoldRemaining = (booking) => {
		if (booking.status !== "pending" || booking.payment_status !== "pending") return null;
		const seconds = Math.max(0, Math.ceil((new Date(booking.created_at).getTime() + 15 * 6e4 - nowMs) / 1e3));
		if (seconds === 0) return "Payment hold expired";
		return `Hold expires in ${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: "Bookings",
				subtitle: "Monitor every reservation across your venues."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerKpi, {
						label: "Upcoming",
						value: String(totalUpcoming)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerKpi, {
						label: "Paid",
						value: String(paidCount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerKpi, {
						label: "Awaiting payment",
						value: String(unpaidCount)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: venueFilter,
						onChange: (e) => setVenueFilter(e.target.value === "all" ? "all" : Number(e.target.value)),
						className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All venues"
						}), venues.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: v.id,
							children: v.name
						}, v.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: status,
						onChange: (e) => setStatus(e.target.value),
						className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "upcoming",
								children: "Upcoming"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "past",
								children: "Past"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "cancelled",
								children: "Cancelled"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "expired",
								children: "Expired"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "All"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: payFilter,
						onChange: (e) => setPayFilter(e.target.value),
						className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "all",
								children: "Any payment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "paid",
								children: "Paid"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "pending",
								children: "Payment pending"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "unpaid",
								children: "Unpaid (legacy)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "failed",
								children: "Failed"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "cancelled",
								children: "Cancelled"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "refunded",
								children: "Refunded"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-border bg-card shadow-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nice-scroll max-h-[65vh] overflow-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "sticky top-0 z-10 bg-secondary/70 text-xs uppercase tracking-wide text-muted-foreground backdrop-blur",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "When"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Venue · Court"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Customer"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Payment"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-right",
									children: "Actions"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: bookingsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-6 text-muted-foreground",
							colSpan: 6,
							children: "Loading…"
						}) }) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-6 text-muted-foreground",
							colSpan: 6,
							children: "No bookings match these filters yet."
						}) }) : sessions.map((s) => {
							const r = s.first;
							const p = nameMap.get(r.user_id);
							const paid = s.items.some((i) => i.payment_status === "paid");
							const cancelled = r.status === "cancelled";
							const venueId = r.courts?.venue_id;
							const label = `${formatDateLabel(s.start_time)} · ${formatSessionLabel(s.start_time, s.end_time)} · ${r.courts?.name ?? `Court #${r.court_id}`}`;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-border",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3 whitespace-nowrap",
										children: [
											formatDateLabel(s.start_time),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] text-muted-foreground",
												children: formatSessionLabel(s.start_time, s.end_time)
											}),
											s.ids.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[10px] uppercase tracking-wider text-muted-foreground",
												children: [s.ids.length, " slots"]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3",
										children: [r.courts?.venues?.name ?? "—", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-muted-foreground",
											children: r.courts?.name ?? `Court #${r.court_id}`
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3",
										children: [p?.full_name || "Player", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-muted-foreground",
											children: p?.phone || r.user_id.slice(0, 8)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3",
										children: [stBadge(r.status), paymentHoldRemaining(r) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-1 text-[10px] font-medium text-amber-700",
											children: paymentHoldRemaining(r)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: payBadge(r.payment_status, r.refund_status)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-end gap-1.5 whitespace-nowrap",
											children: [venueId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setChat({
													bookingId: r.id,
													venueId,
													playerId: r.user_id,
													title: p?.full_name || "Player",
													subtitle: label
												}),
												className: "rounded-lg border border-border px-2.5 py-1.5 text-[11px] font-semibold hover:border-primary hover:text-primary",
												children: "Message"
											}), !cancelled && r.status !== "expired" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setCancelTarget({
													bookingIds: s.ids,
													label,
													hasPaid: paid
												}),
												className: "rounded-lg border border-destructive/40 px-2.5 py-1.5 text-[11px] font-semibold text-destructive hover:bg-destructive/10",
												children: "Cancel"
											})]
										})
									})
								]
							}, s.key);
						}) })]
					})
				})
			}),
			cancelTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CancelRefundDialog, {
				target: cancelTarget,
				onClose: () => setCancelTarget(null),
				onDone: () => {
					qc.invalidateQueries({ queryKey: ["tenant-bookings"] });
					qc.invalidateQueries({ queryKey: ["notifications"] });
				}
			}),
			chat && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingChat, {
				bookingId: chat.bookingId,
				venueId: chat.venueId,
				playerId: chat.playerId,
				meId: userId,
				title: `Chat with ${chat.title}`,
				subtitle: chat.subtitle,
				onClose: () => setChat(null)
			})
		]
	});
}
function CustomersSection({ venues }) {
	const [venueFilter, setVenueFilter] = (0, import_react.useState)("all");
	const dataQ = useQuery({
		queryKey: ["tenant-customers", venueFilter],
		queryFn: async () => {
			let bq = supabase.from("bookings").select("id, user_id, start_time, end_time, payment_status, status, courts!inner(venue_id)").order("start_time", { ascending: false }).limit(2e3);
			if (venueFilter !== "all") bq = bq.eq("courts.venue_id", venueFilter);
			const { data: bookings, error } = await bq;
			if (error) throw error;
			const txQ = supabase.from("transactions").select("user_id, amount, status, venue_id");
			const { data: txs } = venueFilter === "all" ? await txQ : await txQ.eq("venue_id", venueFilter);
			const uids = Array.from(new Set((bookings ?? []).map((b) => b.user_id)));
			const { data: profiles } = uids.length > 0 ? await supabase.from("profiles").select("id, full_name, phone").in("id", uids) : { data: [] };
			const map = /* @__PURE__ */ new Map();
			for (const b of bookings ?? []) {
				const cur = map.get(b.user_id) ?? {
					id: b.user_id,
					name: "",
					phone: "",
					bookings: 0,
					paidBookings: 0,
					spent: 0,
					lastAt: null
				};
				cur.bookings += 1;
				if (b.payment_status === "paid") cur.paidBookings += 1;
				if (!cur.lastAt || b.start_time > cur.lastAt) cur.lastAt = b.start_time;
				map.set(b.user_id, cur);
			}
			for (const t of txs ?? []) {
				if (t.status !== "paid") continue;
				const cur = map.get(t.user_id);
				if (cur) cur.spent += Number(t.amount);
			}
			for (const p of profiles ?? []) {
				const cur = map.get(p.id);
				if (cur) {
					cur.name = p.full_name ?? "";
					cur.phone = p.phone ?? "";
				}
			}
			return Array.from(map.values()).sort((a, b) => b.spent - a.spent || b.bookings - a.bookings);
		}
	});
	const rows = dataQ.data ?? [];
	const totalCustomers = rows.length;
	const totalSpent = rows.reduce((s, r) => s + r.spent, 0);
	const repeat = rows.filter((r) => r.bookings > 1).length;
	const currency = (n) => "₱" + n.toLocaleString("en-PH", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: "Customers",
				subtitle: "Players who have booked your venues."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerKpi, {
						label: "Total customers",
						value: String(totalCustomers)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerKpi, {
						label: "Repeat customers",
						value: String(repeat)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerKpi, {
						label: "Lifetime revenue",
						value: currency(totalSpent)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: venueFilter,
					onChange: (e) => setVenueFilter(e.target.value === "all" ? "all" : Number(e.target.value)),
					className: "rounded-lg border border-border bg-background px-3 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: "All venues"
					}), venues.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: v.id,
						children: v.name
					}, v.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-border bg-card shadow-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nice-scroll max-h-[65vh] overflow-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "sticky top-0 z-10 bg-secondary/70 text-xs uppercase tracking-wide text-muted-foreground backdrop-blur",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Customer"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Phone"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Bookings"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Paid"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Spent"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Last booking"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: dataQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-6 text-muted-foreground",
							colSpan: 6,
							children: "Loading…"
						}) }) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-6 text-muted-foreground",
							colSpan: 6,
							children: "No customers yet — once players book, they'll show up here."
						}) }) : rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-3 font-medium",
									children: [r.name || "Player", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] text-muted-foreground",
										children: [r.id.slice(0, 8), "…"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: r.phone || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: r.bookings
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: r.paidBookings
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-semibold",
									children: currency(r.spent)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-muted-foreground",
									children: r.lastAt ? new Date(r.lastAt).toLocaleDateString("en-PH", { dateStyle: "medium" }) : "—"
								})
							]
						}, r.id)) })]
					})
				})
			})
		]
	});
}
function CalendarSection({ venues }) {
	const [venueFilter, setVenueFilter] = (0, import_react.useState)("all");
	const [sportFilter, setSportFilter] = (0, import_react.useState)("all");
	const [day, setDay] = (0, import_react.useState)(() => {
		const d = /* @__PURE__ */ new Date();
		d.setHours(0, 0, 0, 0);
		return d;
	});
	const dayStart = new Date(day);
	const dayEnd = new Date(day);
	dayEnd.setDate(dayEnd.getDate() + 1);
	const venueIds = venueFilter === "all" ? venues.map((v) => v.id) : [venueFilter];
	const courtsQ = useQuery({
		queryKey: ["cal-courts", venueIds.slice().sort((a, b) => a - b).join(",")],
		enabled: venueIds.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.from("courts").select("id, name, venue_id, sport_id, sports(name, slug)").in("venue_id", venueIds).order("venue_id", { ascending: true }).order("name", { ascending: true });
			if (error) throw error;
			return data ?? [];
		}
	});
	const bookingsQ = useQuery({
		queryKey: [
			"cal-bookings",
			venueIds.slice().sort((a, b) => a - b).join(","),
			dayStart.toISOString()
		],
		enabled: venueIds.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.from("bookings").select("id, court_id, user_id, start_time, end_time, status, payment_status, courts!inner(name, venue_id, sport_id, venues(name), sports(name, slug))").lt("start_time", dayEnd.toISOString()).gt("end_time", dayStart.toISOString()).in("courts.venue_id", venueIds).neq("status", "cancelled").order("start_time", { ascending: true });
			if (error) throw error;
			return data ?? [];
		}
	});
	const uids = Array.from(new Set((bookingsQ.data ?? []).map((r) => r.user_id)));
	const namesQ = useQuery({
		queryKey: ["cal-profile-names", uids.slice().sort().join(",")],
		enabled: uids.length > 0,
		queryFn: async () => {
			const { data, error } = await supabase.from("profiles").select("id, full_name").in("id", uids);
			if (error) throw error;
			return data ?? [];
		}
	});
	const nameMap = new Map((namesQ.data ?? []).map((p) => [p.id, p.full_name]));
	const allCourts = courtsQ.data ?? [];
	const sportsInView = Array.from(new Map(allCourts.filter((c) => c.sports).map((c) => [c.sports.slug ?? c.sports.name.toLowerCase(), c.sports])).values());
	const courtsShown = sportFilter === "all" ? allCourts : allCourts.filter((c) => (c.sports?.slug ?? c.sports?.name.toLowerCase()) === sportFilter);
	const sessions = groupBookingSessions((bookingsQ.data ?? []).filter((b) => {
		if (sportFilter === "all") return true;
		return (b.courts?.sports?.slug ?? b.courts?.sports?.name.toLowerCase()) === sportFilter;
	}));
	const [compact, setCompact] = (0, import_react.useState)(true);
	const HOUR_START = 0;
	const HOURS = 24 - HOUR_START;
	const ROW_H = compact ? 34 : 60;
	const gridHeight = HOURS * ROW_H;
	const isToday = (() => {
		const t = /* @__PURE__ */ new Date();
		t.setHours(0, 0, 0, 0);
		return t.getTime() === day.getTime();
	})();
	const nudgeDay = (delta) => {
		const d = new Date(day);
		d.setDate(d.getDate() + delta);
		setDay(d);
	};
	const dayLabel = day.toLocaleDateString("en-PH", {
		month: "long",
		day: "numeric",
		year: "numeric"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
				title: "Calendar",
				subtitle: "Full 24-hour day view across every court, sport and player."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex overflow-hidden rounded-full border border-border bg-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "bg-foreground px-4 py-1.5 text-xs font-semibold text-background",
								children: "Day"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: true,
								className: "px-4 py-1.5 text-xs font-medium text-muted-foreground/60",
								children: "Schedule"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => nudgeDay(-1),
									className: "grid h-8 w-8 place-items-center rounded-full border border-border bg-card text-sm hover:bg-secondary",
									"aria-label": "Previous day",
									children: "‹"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => {
										const t = /* @__PURE__ */ new Date();
										t.setHours(0, 0, 0, 0);
										setDay(t);
									},
									className: `rounded-full px-4 py-1.5 text-xs font-semibold ${isToday ? "bg-primary text-primary-foreground" : "border border-border bg-card hover:bg-secondary"}`,
									children: "Today"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => nudgeDay(1),
									className: "grid h-8 w-8 place-items-center rounded-full border border-border bg-card text-sm hover:bg-secondary",
									"aria-label": "Next day",
									children: "›"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-semibold sm:text-base",
						children: dayLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setCompact((v) => !v),
								className: "rounded-full border border-border bg-card px-3 py-1 text-[11px] font-semibold hover:bg-secondary",
								title: "Toggle row height — compact fits all 24 hours on one screen",
								children: compact ? "Compact 24h" : "Expanded 24h"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: venueFilter,
								onChange: (e) => setVenueFilter(e.target.value === "all" ? "all" : Number(e.target.value)),
								className: "rounded-lg border border-border bg-background px-3 py-1.5 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "all",
									children: "All venues"
								}), venues.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: v.id,
									children: v.name
								}, v.id))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex flex-wrap items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setSportFilter("all"),
									className: `rounded-full px-3 py-1 text-[11px] font-semibold ${sportFilter === "all" ? "bg-primary text-primary-foreground" : "border border-border bg-card hover:bg-secondary"}`,
									children: "All"
								}), sportsInView.map((s) => {
									const slug = s.slug ?? s.name.toLowerCase();
									const active = sportFilter === slug;
									const st = sportStyle(slug);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setSportFilter(active ? "all" : slug),
										className: `inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-semibold ${active ? "bg-foreground text-background" : "border border-border bg-card hover:bg-secondary"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-2 w-2 rounded-full ${st.dot}` }), s.name]
									}, slug);
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-border bg-card shadow-sm",
				children: courtsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-6 text-sm text-muted-foreground",
					children: "Loading calendar…"
				}) : courtsShown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-6 text-sm text-muted-foreground",
					children: "No courts to display. Add a court to see it here."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nice-scroll max-h-[72vh] overflow-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-max",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sticky top-0 z-20 flex border-b border-border bg-card/95 backdrop-blur",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sticky left-0 z-30 w-16 shrink-0 bg-card/95" }), courtsShown.map((c) => {
								const st = sportStyle(c.sports?.slug ?? c.sports?.name.toLowerCase());
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-40 shrink-0 border-l border-border px-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "truncate text-[10px] font-bold uppercase tracking-wider text-muted-foreground",
										children: c.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-0.5 inline-flex items-center gap-1 text-[10px] text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 w-1.5 rounded-full ${st.dot}` }), c.sports?.name ?? "Sport"]
									})]
								}, c.id);
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sticky left-0 z-10 w-16 shrink-0 bg-card",
								style: { height: gridHeight },
								children: Array.from({ length: HOURS }).map((_, i) => {
									const h = HOUR_START + i;
									const label = h === 0 ? "12 AM" : h === 12 ? "12 PM" : h > 12 ? `${h - 12} PM` : `${h} AM`;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										style: { height: ROW_H },
										className: "relative border-t border-transparent",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `absolute right-2 whitespace-nowrap text-[10px] font-medium leading-none text-muted-foreground ${i === 0 ? "top-0.5" : "top-0 -translate-y-1/2"}`,
											children: label
										})
									}, h);
								})
							}), courtsShown.map((c) => {
								const colSessions = sessions.filter((s) => s.first.court_id === c.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative w-40 shrink-0 border-l border-border",
									style: { height: gridHeight },
									children: [
										Array.from({ length: HOURS }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											style: {
												top: i * ROW_H,
												height: ROW_H
											},
											className: `absolute inset-x-0 border-t ${(HOUR_START + i) % 6 === 0 ? "border-border" : "border-border/40"}`
										}, i)),
										colSessions.map((sess) => {
											const b = sess.first;
											const s = new Date(sess.start_time);
											const e = new Date(sess.end_time);
											const startH = s < dayStart ? 0 : s.getHours() + s.getMinutes() / 60;
											const rawEnd = e > dayEnd ? 24 : e.getHours() + e.getMinutes() / 60;
											const endH = rawEnd <= startH ? 24 : rawEnd;
											const top = Math.max(0, (startH - HOUR_START) * ROW_H);
											const height = Math.max(22, (endH - startH) * ROW_H - 3);
											const st = sportStyle(b.courts?.sports?.slug ?? b.courts?.sports?.name.toLowerCase());
											const sportName = b.courts?.sports?.name ?? "Booking";
											const player = nameMap.get(b.user_id) || "Player";
											const range = `${s.toLocaleTimeString("en-PH", {
												hour: "numeric",
												minute: "2-digit"
											})} – ${e.toLocaleTimeString("en-PH", {
												hour: "numeric",
												minute: "2-digit"
											})}`;
											const density = height < 34 ? "xs" : height < 58 ? "sm" : "full";
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												style: {
													top,
													height
												},
												title: `${player} · ${sportName} · ${range} (${sess.hours} hr${sess.hours > 1 ? "s" : ""})`,
												className: `absolute inset-x-1 flex flex-col justify-center overflow-hidden rounded-lg border ${st.bg} ${st.border} ${st.text} px-1.5 py-0.5 shadow-sm`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex min-w-0 items-center gap-1 text-[11px] font-semibold leading-tight",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-1.5 w-1.5 shrink-0 rounded-full ${st.dot}` }),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "truncate",
																children: player
															}),
															density === "xs" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "ml-auto shrink-0 whitespace-nowrap text-[10px] font-medium opacity-70",
																children: [sess.hours, "h"]
															})
														]
													}),
													density !== "xs" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "truncate whitespace-nowrap text-[10px] leading-tight opacity-75",
														children: [
															range,
															" · ",
															sess.hours,
															"h"
														]
													}),
													density === "full" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "truncate whitespace-nowrap text-[10px] leading-tight opacity-80",
														children: sportName
													})
												]
											}, sess.key);
										}),
										isToday && (() => {
											const now = /* @__PURE__ */ new Date();
											return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "pointer-events-none absolute inset-x-0 z-10 border-t-2 border-primary",
												style: { top: (now.getHours() + now.getMinutes() / 60 - HOUR_START) * ROW_H }
											});
										})()
									]
								}, c.id);
							})]
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-4 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 text-sm font-semibold",
					children: [
						"Players booked on ",
						dayLabel,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 rounded-full bg-secondary px-2 py-0.5 text-[11px] font-medium text-muted-foreground",
							children: sessions.length
						})
					]
				}), bookingsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "Loading bookings…"
				}) : sessions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "No bookings for this date."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border",
					children: sessions.map((sess) => {
						const b = sess.first;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-center justify-between gap-2 py-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-2 w-2 shrink-0 rounded-full ${sportStyle(b.courts?.sports?.slug ?? b.courts?.sports?.name.toLowerCase()).dot}` }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate font-semibold",
										children: nameMap.get(b.user_id) || "Player"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "truncate text-muted-foreground",
										children: [
											b.courts?.sports?.name ?? "Sport",
											" · ",
											b.courts?.name,
											" · ",
											b.courts?.venues?.name
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: formatSessionLabel(sess.start_time, sess.end_time)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-2 py-0.5 text-[10px] font-semibold ${sess.items.some((i) => i.payment_status === "paid") ? "bg-emerald-100 text-emerald-800" : "bg-secondary text-muted-foreground"}`,
									children: sess.items.some((i) => i.payment_status === "paid") ? "Paid" : "Unpaid"
								})]
							})]
						}, sess.key);
					})
				})]
			})
		]
	});
}
/** Shared stat tile used by the tenant sections (transactions, bookings, customers).
*  The player workspace uses `PlayerTile` instead — see the note there. */
function PlayerKpi({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card p-4 shadow-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-semibold uppercase tracking-wider text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-2xl font-semibold tabular-nums",
				children: value
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-[11px] text-muted-foreground",
				children: hint
			})
		]
	});
}
function VouchersSection({ venues }) {
	const qc = useQueryClient();
	const [venueId, setVenueId] = (0, import_react.useState)(venues[0]?.id ?? null);
	const vq = useQuery({
		queryKey: ["vouchers", venueId],
		queryFn: async () => {
			if (!venueId) return [];
			const { data, error } = await supabase.from("vouchers").select("id, code, discount_type, discount_value, expires_at, max_uses, one_per_user, min_booking_amount, is_active, notes, created_at").eq("venue_id", venueId).order("created_at", { ascending: false });
			if (error) throw error;
			return data ?? [];
		},
		enabled: !!venueId
	});
	const usageQ = useQuery({
		queryKey: ["voucher-usage", venueId],
		queryFn: async () => {
			if (!venueId) return {};
			const ids = (vq.data ?? []).map((v) => v.id);
			if (ids.length === 0) return {};
			const { data, error } = await supabase.from("voucher_redemptions").select("voucher_id").in("voucher_id", ids);
			if (error) throw error;
			const map = {};
			for (const r of data ?? []) map[r.voucher_id] = (map[r.voucher_id] ?? 0) + 1;
			return map;
		},
		enabled: !!venueId && !!vq.data
	});
	const [code, setCode] = (0, import_react.useState)("");
	const [discountType, setDiscountType] = (0, import_react.useState)("percent");
	const [discountValue, setDiscountValue] = (0, import_react.useState)("10");
	const [expiresAt, setExpiresAt] = (0, import_react.useState)("");
	const [maxUses, setMaxUses] = (0, import_react.useState)("");
	const [onePerUser, setOnePerUser] = (0, import_react.useState)(true);
	const [minAmount, setMinAmount] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)(null);
	const genCode = () => {
		const alpha = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
		let s = "";
		for (let i = 0; i < 8; i++) s += alpha[Math.floor(Math.random() * 31)];
		setCode(s);
	};
	const createMut = useMutation({
		mutationFn: async () => {
			if (!venueId) throw new Error("Pick a venue");
			const c = code.trim().toUpperCase();
			if (!c) throw new Error("Voucher code is required");
			const val = Number(discountValue);
			if (!val || val <= 0) throw new Error("Discount must be greater than 0");
			if (discountType === "percent" && val > 100) throw new Error("Percentage cannot exceed 100");
			const payload = {
				venue_id: venueId,
				code: c,
				discount_type: discountType,
				discount_value: val,
				expires_at: expiresAt ? new Date(expiresAt).toISOString() : null,
				max_uses: maxUses ? Math.max(1, Math.floor(Number(maxUses))) : null,
				one_per_user: onePerUser,
				min_booking_amount: minAmount ? Number(minAmount) : null,
				notes: notes.trim() || null,
				is_active: true
			};
			const { error } = await supabase.from("vouchers").insert(payload);
			if (error) throw error;
		},
		onSuccess: () => {
			setCode("");
			setDiscountValue("10");
			setExpiresAt("");
			setMaxUses("");
			setMinAmount("");
			setNotes("");
			setErr(null);
			qc.invalidateQueries({ queryKey: ["vouchers", venueId] });
		},
		onError: (e) => setErr(e.message)
	});
	const toggleActive = useMutation({
		mutationFn: async ({ id, is_active }) => {
			const { error } = await supabase.from("vouchers").update({ is_active }).eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => qc.invalidateQueries({ queryKey: ["vouchers", venueId] })
	});
	const del = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("vouchers").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => qc.invalidateQueries({ queryKey: ["vouchers", venueId] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-bold",
				children: "Vouchers"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Create discount codes players can redeem when booking a court that accepts vouchers."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted-foreground",
					children: "Venue:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "rounded-md border bg-background px-2 py-1.5 text-sm",
					value: venueId ?? "",
					onChange: (e) => setVenueId(e.target.value ? Number(e.target.value) : null),
					children: venues.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: v.id,
						children: v.name
					}, v.id))
				})]
			}),
			venueId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketPercent, { className: "h-5 w-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Create voucher"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1 block text-xs font-medium",
								children: "Code"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: code,
									onChange: (e) => setCode(e.target.value.toUpperCase()),
									placeholder: "e.g. SUMMER10",
									className: "w-full rounded-md border bg-background px-2 py-1.5 text-sm uppercase"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: genCode,
									className: "rounded-md border px-2 text-xs hover:bg-secondary",
									children: "Auto"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1 block text-xs font-medium",
								children: "Discount type"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: discountType,
								onChange: (e) => setDiscountType(e.target.value),
								className: "w-full rounded-md border bg-background px-2 py-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "percent",
									children: "Percentage (%)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "amount",
									children: "Fixed amount (₱)"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1 block text-xs font-medium",
								children: discountType === "percent" ? "Percentage off" : "Amount off (₱)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: "1",
								value: discountValue,
								onChange: (e) => setDiscountValue(e.target.value),
								className: "w-full rounded-md border bg-background px-2 py-1.5 text-sm"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1 block text-xs font-medium",
								children: "Expires at (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "datetime-local",
								value: expiresAt,
								onChange: (e) => setExpiresAt(e.target.value),
								className: "w-full rounded-md border bg-background px-2 py-1.5 text-sm"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1 block text-xs font-medium",
								children: "Max total uses (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: "1",
								value: maxUses,
								onChange: (e) => setMaxUses(e.target.value),
								className: "w-full rounded-md border bg-background px-2 py-1.5 text-sm"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "mb-1 block text-xs font-medium",
								children: "Minimum booking amount (₱, optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: "0",
								value: minAmount,
								onChange: (e) => setMinAmount(e.target.value),
								className: "w-full rounded-md border bg-background px-2 py-1.5 text-sm"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: onePerUser,
									onChange: (e) => setOnePerUser(e.target.checked)
								}), "One redemption per player"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "sm:col-span-2 lg:col-span-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1 block text-xs font-medium",
									children: "Notes (optional, internal)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: notes,
									onChange: (e) => setNotes(e.target.value),
									className: "w-full rounded-md border bg-background px-2 py-1.5 text-sm"
								})]
							})
						]
					}),
					err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 text-sm text-red-600",
						children: err
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => createMut.mutate(),
							disabled: createMut.isPending,
							className: "rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-50",
							children: createMut.isPending ? "Creating…" : "Create voucher"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-[11px] text-muted-foreground",
						children: [
							"Players can only redeem a voucher on courts where you've ticked ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Accept vouchers" }),
							" (in Add/Edit court)."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b px-4 py-2 text-sm font-semibold",
					children: [
						"Vouchers (",
						vq.data?.length ?? 0,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nice-scroll overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-secondary/50 text-xs uppercase tracking-wider text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-left",
									children: "Code"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-left",
									children: "Discount"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-left",
									children: "Uses"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-left",
									children: "Expires"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-left",
									children: "Min ₱"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-left",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-right",
									children: "Actions"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [(vq.data ?? []).map((v) => {
							const used = usageQ.data?.[v.id] ?? 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 font-mono font-semibold",
										children: v.code
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: v.discount_type === "percent" ? `${v.discount_value}%` : `₱${Number(v.discount_value).toFixed(2)}`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "p-3",
										children: [
											used,
											v.max_uses ? ` / ${v.max_uses}` : "",
											v.one_per_user && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "ml-1 text-[10px] text-muted-foreground",
												children: "(1/player)"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: v.expires_at ? new Date(v.expires_at).toLocaleString() : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: v.min_booking_amount ? `₱${Number(v.min_booking_amount).toFixed(2)}` : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => toggleActive.mutate({
												id: v.id,
												is_active: !v.is_active
											}),
											className: `rounded-full px-2 py-0.5 text-xs font-medium ${v.is_active ? "bg-emerald-100 text-emerald-700" : "bg-muted text-muted-foreground"}`,
											children: v.is_active ? "Active" : "Inactive"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 text-right",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => {
												if (window.confirm(`Delete voucher ${v.code}? Existing redemptions will be removed.`)) del.mutate(v.id);
											},
											className: "rounded-md border px-2 py-1 text-xs text-red-600 hover:bg-red-50",
											children: "Delete"
										})
									})
								]
							}, v.id);
						}), (vq.data ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 7,
							className: "p-6 text-center text-muted-foreground",
							children: "No vouchers yet."
						}) })] })]
					})
				})]
			})
		]
	});
}
//#endregion
export { Dashboard as component, datesToPayload, osmEmbedUrl, sportEmoji, weeklyToPayload };
