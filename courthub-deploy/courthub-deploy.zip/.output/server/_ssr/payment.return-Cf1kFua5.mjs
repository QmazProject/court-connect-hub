import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Dd0V2lPq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { g as Link, v as useSearch } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as useServerFn, i as groupBookingSessions, n as formatSessionLabel, t as formatDateLabel } from "./booking-groups-DLdni8PO.mjs";
import { t as cancelPendingBookings } from "./paymongo.functions-BVintJM4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/payment.return-Cf1kFua5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PaymentReturn() {
	const { ref, status } = useSearch({ from: "/payment/return" });
	const [txStatus, setTxStatus] = (0, import_react.useState)(status === "cancel" ? "cancelled" : "pending");
	const [amount, setAmount] = (0, import_react.useState)(null);
	const [pollCount, setPollCount] = (0, import_react.useState)(0);
	const [reservationState, setReservationState] = (0, import_react.useState)("active");
	const [refundPending, setRefundPending] = (0, import_react.useState)(false);
	const [slot, setSlot] = (0, import_react.useState)(null);
	const cancelFn = useServerFn(cancelPendingBookings);
	const didCancel = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (status !== "cancel" || !ref || didCancel.current) return;
		const bookingId = Number(ref.split("_")[1]);
		if (!bookingId) return;
		didCancel.current = true;
		(async () => {
			const { data: primary } = await supabase.from("transactions").select("provider_ref").eq("booking_id", bookingId).order("created_at", { ascending: false }).limit(1).maybeSingle();
			const { data: sessionRows } = primary?.provider_ref ? await supabase.from("transactions").select("booking_id").eq("provider_ref", primary.provider_ref) : { data: [] };
			const ids = Array.from(/* @__PURE__ */ new Set([bookingId, ...(sessionRows ?? []).map((r) => r.booking_id)]));
			try {
				await cancelFn({ data: { bookingIds: ids } });
			} catch (e) {
				console.error("cancel pending", e);
			}
		})();
	}, [
		status,
		ref,
		cancelFn
	]);
	(0, import_react.useEffect)(() => {
		if (!ref || status === "cancel") return;
		let cancelled = false;
		const poll = async () => {
			const bookingId = Number(ref.split("_")[1]);
			if (!bookingId) return;
			const { data } = await supabase.from("transactions").select("status, amount, provider_ref").eq("booking_id", bookingId).order("created_at", { ascending: false }).limit(1).maybeSingle();
			if (cancelled || !data) return;
			let total = Number(data.amount);
			let ids = [bookingId];
			if (data.provider_ref) {
				const { data: sess } = await supabase.from("transactions").select("booking_id, amount").eq("provider_ref", data.provider_ref);
				if (sess && sess.length > 0) {
					total = sess.reduce((s, t) => s + Number(t.amount ?? 0), 0);
					ids = Array.from(new Set(sess.map((t) => t.booking_id)));
				}
			}
			if (cancelled) return;
			setAmount(total);
			const { data: bks } = await supabase.from("bookings").select("id, court_id, start_time, end_time, status, payment_status, refund_status, courts(name, venues(id, name, images))").in("id", ids);
			if (!cancelled && bks && bks.length > 0) {
				if (bks.some((booking) => booking.status === "expired")) setReservationState("expired");
				else if (bks.some((booking) => booking.status === "cancelled")) setReservationState("cancelled");
				setRefundPending(bks.some((booking) => booking.refund_status === "pending"));
				const s = groupBookingSessions(bks)[0];
				setSlot({
					date: formatDateLabel(s.start_time),
					range: formatSessionLabel(s.start_time, s.end_time),
					court: s.first.courts?.name ?? null,
					venue: s.first.courts?.venues?.name ?? null,
					venueImage: s.first.courts?.venues?.images?.[0] ?? null,
					venueId: s.first.courts?.venues?.id ?? null
				});
			}
			if ([
				"paid",
				"failed",
				"cancelled",
				"refunded"
			].includes(data.status)) setTxStatus(data.status);
		};
		const timer = setInterval(() => {
			setPollCount((n) => n + 1);
			poll();
		}, 2500);
		poll();
		return () => {
			cancelled = true;
			clearInterval(timer);
		};
	}, [ref, status]);
	const timedOut = pollCount > 20 && txStatus === "pending";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh w-full items-center justify-center overflow-hidden p-4 sm:p-6",
		children: [
			slot?.venueImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000",
				style: { backgroundImage: `url(${slot.venueImage})` }
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[#061a17]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-black/60 backdrop-blur-xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative w-full max-w-sm rounded-3xl border border-white/10 bg-[#09231f]/95 p-8 text-center text-white shadow-2xl animate-in fade-in zoom-in duration-300",
				children: [
					status === "cancel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-white/10 text-3xl",
							children: "✕"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-5 text-2xl font-bold",
							children: "Payment cancelled"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-white/60",
							children: "Your reservation was not placed. You can try again anytime from your dashboard."
						})
					] }) : reservationState === "expired" || reservationState === "cancelled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-white/10 text-3xl",
							children: "⌛"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-5 text-2xl font-bold",
							children: "Reservation expired"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-white/60",
							children: refundPending ? "Your payment was received after the hold ended and is awaiting refund." : "Create a new booking to reserve another available slot."
						})
					] }) : txStatus === "paid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#b8f05a]/20 text-3xl text-[#b8f05a]",
							children: "✓"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-5 font-display text-2xl font-bold text-[#b8f05a]",
							children: "Payment received"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-white/70",
							children: [amount != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"We received ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-semibold text-white",
									children: ["₱", amount.toFixed(2)]
								}),
								". "
							] }) : null, "Your booking is confirmed!"]
						})
					] }) : txStatus === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-red-500/20 text-3xl text-red-400",
							children: "!"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-5 text-2xl font-bold text-red-400",
							children: "Payment failed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-white/60",
							children: "The provider reported a failure. You can retry from your dashboard."
						})
					] }) : timedOut ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-white/10 text-3xl",
							children: "⏳"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-5 text-2xl font-bold",
							children: "Still processing…"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-white/60",
							children: "This can take a minute. Your booking will appear in your dashboard once confirmed."
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-12 w-12 animate-spin rounded-full border-4 border-white/20 border-t-[#b8f05a]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-6 font-display text-xl font-bold tracking-tight",
							children: "Confirming payment…"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-white/50",
							children: "Hang tight, we're syncing securely."
						})
					] }),
					slot && status !== "cancel" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 overflow-hidden rounded-2xl border border-white/10 bg-white/5 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "border-b border-white/10 bg-white/5 px-4 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-widest text-white/40",
								children: "Your Session"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-4",
							children: [(slot.venue || slot.court) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-base font-semibold text-white",
								children: [slot.venue ?? "Venue", slot.court ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-white/50",
									children: [" · ", slot.court]
								}) : null]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-col gap-1 text-sm text-white/70",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-white/40",
											children: "📅"
										}),
										" ",
										slot.date
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-white/40",
											children: "⏱️"
										}),
										" ",
										slot.range
									]
								})]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/dashboard",
							className: "w-full rounded-xl bg-[#b8f05a] px-4 py-3.5 text-center text-sm font-bold text-[#102521] shadow-lg shadow-[#b8f05a]/20 transition hover:bg-[#d3ff87]",
							children: "Go to My Bookings"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: slot?.venueId ? "/venues/$venueId" : "/",
							params: slot?.venueId ? { venueId: String(slot.venueId) } : {},
							className: "w-full rounded-xl border border-white/15 bg-white/5 px-4 py-3.5 text-center text-sm font-bold text-white transition hover:bg-white/10",
							children: "Back to Venue"
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { PaymentReturn as component };
