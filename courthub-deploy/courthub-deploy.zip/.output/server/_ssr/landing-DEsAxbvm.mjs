import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as booleanType, o as objectType, s as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/landing-DEsAxbvm.js
var $$splitComponentImporter = () => import("./landing-B9tFllL-.mjs");
var landingSearchSchema = objectType({
	/** Set by /dashboard and the legacy header when an unauthenticated visitor is bounced
	*  here; LandingPage consumes it once and clears it so a refresh does not reopen the sheet. */
	signin: booleanType().optional().catch(false),
	/** Opens the sheet straight on the player/tenant role picker, for "create account" links
	*  arriving from pages that have no auth UI of their own (explore, venue detail). */
	signup: booleanType().optional().catch(false),
	sport: stringType().optional()
});
var Route = createFileRoute("/landing")({
	validateSearch: landingSearchSchema,
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: () => ({ meta: [
		{ title: "CourtHub — Find & book premium sports courts" },
		{
			name: "description",
			content: "Discover courts near you on the map, filter by sport and price, and book in seconds."
		},
		{
			property: "og:title",
			content: "CourtHub — Find & book premium sports courts"
		},
		{
			property: "og:description",
			content: "Map-first court discovery. Filter, browse and book premium venues."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] })
});
//#endregion
export { Route as t };
