import { c as createServerFn } from "./createServerFn-BFFE07zL.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-BwdutfJC.mjs";
import { a as numberType, i as enumType, o as objectType, s as stringType, t as arrayType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-MBa5GZ-L.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/paymongo.functions-BND0fiHI.js
var StartCheckoutInput = objectType({
	courtId: numberType().int().positive(),
	date: stringType().regex(/^\d{4}-\d{2}-\d{2}$/),
	hours: arrayType(numberType().int().min(0).max(23)).min(1).max(12),
	method: enumType([
		"gcash",
		"paymaya",
		"grab_pay",
		"qrph",
		"card"
	]),
	origin: stringType().url(),
	voucherCode: stringType().trim().min(1).max(64).optional()
});
var startBookingCheckout_createServerFn_handler = createServerRpc({
	id: "26fd7c53c370fd96e0e67e35bf95d425edea2701038c7097f1bdf6cd22226fe6",
	name: "startBookingCheckout",
	filename: "src/lib/paymongo.functions.ts"
}, (opts) => startBookingCheckout.__executeServer(opts));
var startBookingCheckout = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => StartCheckoutInput.parse(data)).handler(startBookingCheckout_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { supabaseAdmin } = await import("./client.server-Bw6iWMJ-.mjs");
	await supabaseAdmin.rpc("expire_pending_payment_holds");
	const { createCheckoutSession, paymongoMode } = await import("./paymongo.server-iZzYBd36.mjs");
	const { data: court, error: courtErr } = await supabase.from("courts").select("id, name, hourly_rate, rate_rules, capacity, venue_id, venues(name, payment_mode, refund_cutoff_hours, timezone)").eq("id", data.courtId).maybeSingle();
	if (courtErr || !court) throw new Error("Court not found");
	const venue = court.venues;
	if (!venue) throw new Error("Venue not found");
	if (venue.payment_mode === "none") throw new Error("This venue is not accepting online payments");
	const totalHours = data.hours.length;
	const { normalizeRules, rateForDayHour, DAY_KEYS } = await import("./court-pricing-CFeeeUa8.mjs").then((n) => n.l).then((n) => n.a);
	const rules = normalizeRules(court.rate_rules);
	const dayKey = DAY_KEYS[(/* @__PURE__ */ new Date(`${data.date}T00:00:00Z`)).getUTCDay()];
	const unitPrices = data.hours.map((h) => rateForDayHour(Number(court.hourly_rate), rules, dayKey, h));
	const fullAmount = unitPrices.reduce((a, b) => a + b, 0);
	let voucherId = null;
	let discountAmount = 0;
	if (data.voucherCode) {
		const { data: vp, error: vErr } = await supabase.rpc("preview_voucher", {
			_code: data.voucherCode,
			_court_id: data.courtId,
			_amount: fullAmount
		});
		if (vErr) throw new Error(vErr.message);
		const row = Array.isArray(vp) ? vp[0] : vp;
		if (!row || !row.ok) throw new Error(row?.reason || "Invalid voucher");
		voucherId = row.voucher_id;
		discountAmount = Number(row.discount) || 0;
	}
	const discountedTotal = Math.max(0, fullAmount - discountAmount);
	const centavos = Math.round(discountedTotal * 100);
	if (centavos < 2e3) throw new Error("Minimum online payment is ₱20.00");
	const { zonedHourToUtc, DEFAULT_TIMEZONE } = await import("./tz-DFiTOGcp.mjs").then((n) => n.n).then((n) => n.n);
	const tz = venue.timezone || DEFAULT_TIMEZONE;
	const rows = data.hours.map((h, idx) => {
		const start = zonedHourToUtc(data.date, h, tz);
		const end = new Date(start.getTime() + 3600 * 1e3);
		return {
			court_id: data.courtId,
			user_id: userId,
			start_time: start.toISOString(),
			end_time: end.toISOString(),
			status: "pending",
			payment_status: "pending",
			unit_price: unitPrices[idx],
			voucher_id: idx === 0 ? voucherId : null,
			discount_amount: idx === 0 ? Number(discountAmount.toFixed(2)) : 0
		};
	});
	const { data: inserted, error: insErr } = await supabase.from("bookings").insert(rows).select("id");
	if (insErr) throw new Error(insErr.message);
	const bookingIds = (inserted ?? []).map((r) => r.id);
	if (bookingIds.length === 0) throw new Error("Failed to create booking");
	const reference = `bk_${bookingIds[0]}_${Date.now().toString(36)}`;
	const successUrl = `${data.origin}/payment/return?ref=${encodeURIComponent(reference)}&status=success`;
	const cancelUrl = `${data.origin}/payment/return?ref=${encodeURIComponent(reference)}&status=cancel`;
	let session;
	try {
		session = await createCheckoutSession({
			amountCentavos: centavos,
			description: `${venue.name} — ${court.name} (${totalHours} hr${totalHours > 1 ? "s" : ""})`,
			referenceNumber: reference,
			lineItemName: `${court.name} · ${totalHours} hour${totalHours > 1 ? "s" : ""}`,
			methods: [data.method],
			successUrl,
			cancelUrl,
			metadata: {
				booking_ids: bookingIds.join(","),
				venue_id: String(court.venue_id),
				court_id: String(data.courtId),
				user_id: userId
			}
		});
	} catch (e) {
		await supabase.from("bookings").delete().in("id", bookingIds);
		throw e;
	}
	const mode = paymongoMode();
	const perBookingCentavos = Math.round(centavos / bookingIds.length);
	const txRows = bookingIds.map((bid) => ({
		booking_id: bid,
		venue_id: court.venue_id,
		user_id: userId,
		amount: perBookingCentavos / 100,
		currency: "PHP",
		method: data.method,
		provider: "paymongo",
		provider_ref: session.data.id,
		raw: { payment_kind: "full" },
		status: "pending",
		mode
	}));
	const { error: txErr } = await supabaseAdmin.from("transactions").insert(txRows);
	if (txErr) {
		await supabase.from("bookings").update({
			status: "cancelled",
			payment_status: "cancelled",
			cancel_reason: "Checkout session could not be recorded"
		}).in("id", bookingIds);
		throw new Error(`Could not create payment reservation: ${txErr.message}`);
	}
	return {
		checkoutUrl: session.data.attributes.checkout_url,
		sessionId: session.data.id,
		reference,
		amount: centavos / 100
	};
});
var RetryInput = objectType({
	bookingIds: arrayType(numberType().int().positive()).min(1).max(12),
	method: enumType([
		"gcash",
		"paymaya",
		"grab_pay",
		"qrph",
		"card"
	]),
	origin: stringType().url()
});
var retryBookingPayment_createServerFn_handler = createServerRpc({
	id: "be439ce63edc5e5594bbd7284bd1ac44c879681c4b4dd145f5a24ed9cc21d269",
	name: "retryBookingPayment",
	filename: "src/lib/paymongo.functions.ts"
}, (opts) => retryBookingPayment.__executeServer(opts));
var retryBookingPayment = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => RetryInput.parse(d)).handler(retryBookingPayment_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { createCheckoutSession, paymongoMode } = await import("./paymongo.server-iZzYBd36.mjs");
	const { supabaseAdmin } = await import("./client.server-Bw6iWMJ-.mjs");
	await supabaseAdmin.rpc("expire_pending_payment_holds");
	const { data: bookings, error: bErr } = await supabase.from("bookings").select("id, court_id, user_id, start_time, end_time, status, payment_status, created_at, unit_price, courts(name, hourly_rate, venue_id, venues(name, payment_mode))").in("id", data.bookingIds);
	if (bErr || !bookings || bookings.length === 0) throw new Error("Bookings not found");
	if (bookings.length !== data.bookingIds.length) throw new Error("Some bookings could not be loaded");
	for (const b of bookings) {
		if (b.user_id !== userId) throw new Error("Not your booking");
		if (b.payment_status === "paid") throw new Error("Booking already paid");
		if (b.status !== "pending") throw new Error("Your reservation has expired or was cancelled. Create a new booking to continue.");
		if (new Date(b.created_at).getTime() <= Date.now() - 15 * 6e4) throw new Error("Your reservation has expired. Create a new booking to continue.");
	}
	if (new Set(bookings.map((b) => b.court_id)).size > 1) throw new Error("All bookings must be on the same court");
	const first = bookings[0];
	const venue = first.courts.venues;
	if (!venue || venue.payment_mode === "none") throw new Error("This venue is not accepting online payments");
	const totalHours = bookings.length;
	const fullAmount = bookings.reduce((sum, b) => sum + Number(b.unit_price ?? first.courts.hourly_rate), 0);
	const centavos = Math.round(fullAmount * 100);
	if (centavos < 2e3) throw new Error("Minimum online payment is ₱20.00");
	const bookingIds = bookings.map((b) => b.id).sort((a, b) => a - b);
	const reference = `bk_${bookingIds[0]}_${Date.now().toString(36)}`;
	const successUrl = `${data.origin}/payment/return?ref=${encodeURIComponent(reference)}&status=success`;
	const cancelUrl = `${data.origin}/payment/return?ref=${encodeURIComponent(reference)}&status=cancel`;
	const session = await createCheckoutSession({
		amountCentavos: centavos,
		description: `${venue.name} — ${first.courts.name} (${totalHours} hr${totalHours > 1 ? "s" : ""})`,
		referenceNumber: reference,
		lineItemName: `${first.courts.name} · ${totalHours} hour${totalHours > 1 ? "s" : ""}`,
		methods: [data.method],
		successUrl,
		cancelUrl,
		metadata: {
			booking_ids: bookingIds.join(","),
			venue_id: String(first.courts.venue_id),
			court_id: String(first.court_id),
			user_id: userId,
			retry: "1"
		}
	});
	const { error: pendingErr } = await supabase.from("bookings").update({ payment_status: "pending" }).in("id", bookingIds).eq("status", "pending");
	if (pendingErr) throw new Error(pendingErr.message);
	await supabaseAdmin.from("transactions").update({ status: "cancelled" }).in("booking_id", bookingIds).eq("status", "pending");
	const mode = paymongoMode();
	const perBookingCentavos = Math.round(centavos / bookingIds.length);
	const txRows = bookingIds.map((bid) => ({
		booking_id: bid,
		venue_id: first.courts.venue_id,
		user_id: userId,
		amount: perBookingCentavos / 100,
		currency: "PHP",
		method: data.method,
		provider: "paymongo",
		provider_ref: session.data.id,
		raw: { payment_kind: "full" },
		status: "pending",
		mode
	}));
	const { error: txErr } = await supabaseAdmin.from("transactions").insert(txRows);
	if (txErr) throw new Error(`Could not create payment retry: ${txErr.message}`);
	return {
		checkoutUrl: session.data.attributes.checkout_url,
		sessionId: session.data.id,
		reference,
		amount: centavos / 100
	};
});
var CancelInput = objectType({ bookingIds: arrayType(numberType().int().positive()).min(1).max(24) });
var cancelPendingBookings_createServerFn_handler = createServerRpc({
	id: "c2aa49c683db0cb78455296515329f39bb48aa934e9e71e23722a9e6e5eed05f",
	name: "cancelPendingBookings",
	filename: "src/lib/paymongo.functions.ts"
}, (opts) => cancelPendingBookings.__executeServer(opts));
var cancelPendingBookings = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => CancelInput.parse(d)).handler(cancelPendingBookings_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: cancelled, error } = await supabase.from("bookings").update({
		status: "cancelled",
		payment_status: "cancelled",
		cancelled_at: (/* @__PURE__ */ new Date()).toISOString(),
		cancelled_by: userId,
		cancel_reason: "Payment cancelled by player"
	}).in("id", data.bookingIds).eq("user_id", userId).eq("status", "pending").neq("payment_status", "paid").select("id");
	if (error) throw new Error(error.message);
	const ids = (cancelled ?? []).map((booking) => booking.id);
	if (ids.length > 0) {
		const { supabaseAdmin } = await import("./client.server-Bw6iWMJ-.mjs");
		await supabaseAdmin.from("transactions").update({ status: "cancelled" }).in("booking_id", ids).eq("status", "pending");
	}
	return {
		ok: true,
		cancelled: ids.length
	};
});
var getCheckoutStatus_createServerFn_handler = createServerRpc({
	id: "6081a66a0be53dc472b738bb285741ca4f94b199f4d4bf8e3ad705abfb1051c5",
	name: "getCheckoutStatus",
	filename: "src/lib/paymongo.functions.ts"
}, (opts) => getCheckoutStatus.__executeServer(opts));
var getCheckoutStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ reference: stringType().min(1) }).parse(data)).handler(getCheckoutStatus_createServerFn_handler, async ({ data, context }) => {
	const { supabase } = context;
	const bookingId = Number(data.reference.split("_")[1]);
	const query = supabase.from("transactions").select("id, status, amount, method, booking_id, provider_ref, paid_at");
	const { data: tx } = await (Number.isInteger(bookingId) && bookingId > 0 ? query.eq("booking_id", bookingId) : query.eq("provider_ref", data.reference)).limit(1);
	if (tx && tx.length > 0) return {
		status: tx[0].status,
		amount: tx[0].amount,
		method: tx[0].method
	};
	return {
		status: "pending",
		amount: null,
		method: null
	};
});
var RefundInput = objectType({ bookingId: numberType().int().positive() });
var refundBookingFn_createServerFn_handler = createServerRpc({
	id: "3be948fb1c3eba65ff6979d4d5666c9a95208cfe5a608cbc3a5239159e4a9362",
	name: "refundBookingFn",
	filename: "src/lib/paymongo.functions.ts"
}, (opts) => refundBookingFn.__executeServer(opts));
var refundBookingFn = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => RefundInput.parse(d)).handler(refundBookingFn_createServerFn_handler, async ({ data, context }) => {
	const { supabase, userId } = context;
	const { data: booking, error } = await supabase.from("bookings").select("id, user_id, start_time, status, payment_status, courts(venues(refund_cutoff_hours))").eq("id", data.bookingId).maybeSingle();
	if (error || !booking) throw new Error("Booking not found");
	if (booking.user_id !== userId) throw new Error("Not your booking");
	if (booking.payment_status !== "paid") throw new Error("Booking is not paid");
	const cutoff = booking.courts.venues.refund_cutoff_hours ?? 24;
	if ((new Date(booking.start_time).getTime() - Date.now()) / 36e5 < cutoff) throw new Error(`Refunds require cancelling at least ${cutoff} hours before start time`);
	const { supabaseAdmin } = await import("./client.server-Bw6iWMJ-.mjs");
	const { data: tx } = await supabaseAdmin.from("transactions").select("id, amount, raw, provider_ref").eq("booking_id", booking.id).eq("status", "paid").maybeSingle();
	if (!tx) throw new Error("Paid transaction not found");
	const paymentId = tx.raw?.payment_id;
	if (!paymentId) throw new Error("No PayMongo payment id on record");
	const { refundPayment } = await import("./paymongo.server-iZzYBd36.mjs");
	await refundPayment({
		paymentId,
		amountCentavos: Math.round(Number(tx.amount) * 100),
		reason: "requested_by_customer"
	});
	await supabaseAdmin.from("transactions").update({
		status: "refunded",
		refunded_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", tx.id);
	await supabaseAdmin.from("bookings").update({
		status: "cancelled",
		payment_status: "refunded"
	}).eq("id", booking.id);
	return { ok: true };
});
//#endregion
export { cancelPendingBookings_createServerFn_handler, getCheckoutStatus_createServerFn_handler, refundBookingFn_createServerFn_handler, retryBookingPayment_createServerFn_handler, startBookingCheckout_createServerFn_handler };
