import "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as enumType, o as objectType, r as coerce } from "../_libs/zod.mjs";
require_react();
require_jsx_runtime();
var $$splitComponentImporter = () => import("./dashboard-DuG25dPy.mjs");
/** `view` picks which player pane is showing. A search param rather than a separate route so
*  the whole dashboard — including the tenant side, which ignores it — stays one route with
*  one auth guard and one data layer. */
var dashboardSearchSchema = objectType({
	view: enumType([
		"bookings",
		"calendar",
		"favorites"
	]).optional().catch("bookings"),
	booking: coerce.number().int().positive().optional().catch(void 0)
});
var Route = createFileRoute("/_authenticated/dashboard")({
	validateSearch: dashboardSearchSchema,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
