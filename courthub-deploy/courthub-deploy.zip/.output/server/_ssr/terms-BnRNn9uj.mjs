import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { a as TERMS, n as LegalPage } from "./LegalDocument-B84apQRn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-BnRNn9uj.js
var import_jsx_runtime = require_jsx_runtime();
function TermsRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegalPage, {
		doc: TERMS,
		counterpart: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/privacy",
			className: "text-sm font-bold text-[#12806d] transition hover:underline",
			children: "Read the Privacy Policy"
		})
	});
}
//#endregion
export { TermsRoute as component };
