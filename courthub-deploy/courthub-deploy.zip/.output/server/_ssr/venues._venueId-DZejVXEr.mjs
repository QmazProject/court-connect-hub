import { i as __toESM } from "../_runtime.mjs";
import { A as peso, C as minRate, D as openHoursForDate, E as normalizeRules, F as rateForHour, M as priceForHours, S as maxRate, T as normalizeHours, d as describeWeek, f as describeWindow, j as priceBreakdown, m as effectiveHours, v as hasVariablePricing } from "./court-pricing-CFeeeUa8.mjs";
import { t as supabase } from "./client-Dd0V2lPq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime, d as DialogContent, f as DialogDescription, h as DialogTitle, l as Dialog, m as DialogPortal, p as DialogOverlay, u as DialogClose } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as PopoverTrigger, i as PopoverContent, n as MapPicker, o as cn, r as Popover } from "./popover-Z5PgJyYY.mjs";
import { B as MapPin, F as Navigation, J as Info, N as Phone, U as LogIn, a as UtensilsCrossed, ct as ChevronLeft, i as Wallet, it as ClipboardList, k as RotateCcw, l as UserPlus, lt as ChevronDown, n as Wrench, nt as Clock, pt as CalendarDays, st as ChevronRight, t as X, tt as Compass, x as Sparkles } from "../_libs/lucide-react.mjs";
import { i as startBookingCheckout } from "./paymongo.functions-BVintJM4.mjs";
import { n as FavoriteButton, r as buttonVariants, t as Button } from "./FavoriteButton-WKzUJGL1.mjs";
import { a as zonedDayOfWeek, i as zonedDayBoundsUtc, o as zonedHour, r as zonedDateISO, s as zonedHourToUtc, t as addZonedDays } from "./tz-DFiTOGcp.mjs";
import { t as RateCard } from "./RateCard-BjVMWMb4.mjs";
import { t as Route } from "./venues._venueId-B8m7HfCs.mjs";
import { n as getDefaultClassNames, t as DayPicker } from "../_libs/react-day-picker.mjs";
import { t as Drawer } from "../_libs/vaul.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/venues._venueId-DZejVXEr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Calendar({ className, classNames, showOutsideDays = true, captionLayout = "label", buttonVariant = "ghost", formatters, components, ...props }) {
	const defaultClassNames = getDefaultClassNames();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DayPicker, {
		showOutsideDays,
		className: cn("bg-background group/calendar p-3 [--cell-size:2rem] [[data-slot=card-content]_&]:bg-transparent [[data-slot=popover-content]_&]:bg-transparent", String.raw`rtl:**:[.rdp-button\_next>svg]:rotate-180`, String.raw`rtl:**:[.rdp-button\_previous>svg]:rotate-180`, className),
		captionLayout,
		formatters: {
			formatMonthDropdown: (date) => date.toLocaleString("default", { month: "short" }),
			...formatters
		},
		classNames: {
			root: cn("w-fit", defaultClassNames.root),
			months: cn("relative flex flex-col gap-4 md:flex-row", defaultClassNames.months),
			month: cn("flex w-full flex-col gap-4", defaultClassNames.month),
			nav: cn("absolute inset-x-0 top-0 flex w-full items-center justify-between gap-1", defaultClassNames.nav),
			button_previous: cn(buttonVariants({ variant: buttonVariant }), "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50", defaultClassNames.button_previous),
			button_next: cn(buttonVariants({ variant: buttonVariant }), "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50", defaultClassNames.button_next),
			month_caption: cn("flex h-(--cell-size) w-full items-center justify-center px-(--cell-size)", defaultClassNames.month_caption),
			dropdowns: cn("flex h-(--cell-size) w-full items-center justify-center gap-1.5 text-sm font-medium", defaultClassNames.dropdowns),
			dropdown_root: cn("has-focus:border-ring border-input shadow-xs has-focus:ring-ring/50 has-focus:ring-[3px] relative rounded-md border", defaultClassNames.dropdown_root),
			dropdown: cn("bg-popover absolute inset-0 opacity-0", defaultClassNames.dropdown),
			caption_label: cn("select-none font-medium", captionLayout === "label" ? "text-sm" : "[&>svg]:text-muted-foreground flex h-8 items-center gap-1 rounded-md pl-2 pr-1 text-sm [&>svg]:size-3.5", defaultClassNames.caption_label),
			table: "w-full border-collapse",
			weekdays: cn("flex", defaultClassNames.weekdays),
			weekday: cn("text-muted-foreground flex-1 select-none rounded-md text-[0.8rem] font-normal", defaultClassNames.weekday),
			week: cn("mt-2 flex w-full", defaultClassNames.week),
			week_number_header: cn("w-(--cell-size) select-none", defaultClassNames.week_number_header),
			week_number: cn("text-muted-foreground select-none text-[0.8rem]", defaultClassNames.week_number),
			day: cn("group/day relative aspect-square h-full w-full select-none p-0 text-center [&:first-child[data-selected=true]_button]:rounded-l-md [&:last-child[data-selected=true]_button]:rounded-r-md", defaultClassNames.day),
			range_start: cn("bg-accent rounded-l-md", defaultClassNames.range_start),
			range_middle: cn("rounded-none", defaultClassNames.range_middle),
			range_end: cn("bg-accent rounded-r-md", defaultClassNames.range_end),
			today: cn("bg-accent text-accent-foreground rounded-md data-[selected=true]:rounded-none", defaultClassNames.today),
			outside: cn("text-muted-foreground aria-selected:text-muted-foreground", defaultClassNames.outside),
			disabled: cn("text-muted-foreground opacity-50", defaultClassNames.disabled),
			hidden: cn("invisible", defaultClassNames.hidden),
			...classNames
		},
		components: {
			Root: ({ className, rootRef, ...props }) => {
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"data-slot": "calendar",
					ref: rootRef,
					className: cn(className),
					...props
				});
			},
			Chevron: ({ className, orientation, ...props }) => {
				if (orientation === "left") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
					className: cn("size-4", className),
					...props
				});
				if (orientation === "right") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
					className: cn("size-4", className),
					...props
				});
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					className: cn("size-4", className),
					...props
				});
			},
			DayButton: CalendarDayButton,
			WeekNumber: ({ children, ...props }) => {
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					...props,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-(--cell-size) items-center justify-center text-center",
						children
					})
				});
			},
			...components
		},
		...props
	});
}
function CalendarDayButton({ className, day, modifiers, ...props }) {
	const defaultClassNames = getDefaultClassNames();
	const ref = import_react.useRef(null);
	import_react.useEffect(() => {
		if (modifiers.focused) ref.current?.focus();
	}, [modifiers.focused]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		ref,
		variant: "ghost",
		size: "icon",
		"data-day": day.date.toLocaleDateString(),
		"data-selected-single": modifiers.selected && !modifiers.range_start && !modifiers.range_end && !modifiers.range_middle,
		"data-range-start": modifiers.range_start,
		"data-range-end": modifiers.range_end,
		"data-range-middle": modifiers.range_middle,
		className: cn("data-[selected-single=true]:bg-primary data-[selected-single=true]:text-primary-foreground data-[range-middle=true]:bg-accent data-[range-middle=true]:text-accent-foreground data-[range-start=true]:bg-primary data-[range-start=true]:text-primary-foreground data-[range-end=true]:bg-primary data-[range-end=true]:text-primary-foreground group-data-[focused=true]/day:border-ring group-data-[focused=true]/day:ring-ring/50 flex aspect-square h-auto w-full min-w-(--cell-size) flex-col gap-1 font-normal leading-none data-[range-end=true]:rounded-md data-[range-middle=true]:rounded-none data-[range-start=true]:rounded-md group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10 group-data-[focused=true]/day:ring-[3px] [&>span]:text-xs [&>span]:opacity-70", defaultClassNames.day, className),
		...props
	});
}
var MOBILE_BREAKPOINT = 768;
function useIsMobile() {
	const [isMobile, setIsMobile] = import_react.useState(void 0);
	import_react.useEffect(() => {
		const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
		const onChange = () => {
			setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
		};
		mql.addEventListener("change", onChange);
		setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
		return () => mql.removeEventListener("change", onChange);
	}, []);
	return !!isMobile;
}
var Sheet = Dialog;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-[1200] bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-[1200] gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
var Drawer$1 = ({ shouldScaleBackground = true, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Root, {
	shouldScaleBackground,
	...props
});
Drawer$1.displayName = "Drawer";
Drawer.Trigger;
var DrawerPortal = Drawer.Portal;
Drawer.Close;
var DrawerOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Overlay, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80", className),
	...props
}));
DrawerOverlay.displayName = Drawer.Overlay.displayName;
var DrawerContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DrawerPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawerOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Drawer.Content, {
	ref,
	className: cn("fixed inset-x-0 bottom-0 z-50 mt-24 flex h-auto flex-col rounded-t-[10px] border bg-background", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted" }), children]
})] }));
DrawerContent.displayName = "DrawerContent";
var DrawerHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("grid gap-1.5 p-4 text-center sm:text-left", className),
	...props
});
DrawerHeader.displayName = "DrawerHeader";
var DrawerFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("mt-auto flex flex-col gap-2 p-4", className),
	...props
});
DrawerFooter.displayName = "DrawerFooter";
var DrawerTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Title, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DrawerTitle.displayName = Drawer.Title.displayName;
var DrawerDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer.Description, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DrawerDescription.displayName = Drawer.Description.displayName;
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b border-border px-4 py-2.5 last:border-b-0 sm:odd:border-r",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-0.5 text-sm font-medium text-foreground",
			children: value
		})]
	});
}
var DAY_KEYS = [
	"sun",
	"mon",
	"tue",
	"wed",
	"thu",
	"fri",
	"sat"
];
function shiftISO(iso, days) {
	return addZonedDays(iso, days);
}
function fmtHour(h) {
	const period = h < 12 ? "AM" : "PM";
	return `${h % 12 === 0 ? 12 : h % 12}:00 ${period}`;
}
function groupHourRanges(hours) {
	if (hours.length === 0) return [];
	const sorted = [...hours].sort((a, b) => a - b);
	const out = [];
	let start = sorted[0];
	let prev = sorted[0];
	for (let i = 1; i < sorted.length; i++) {
		const h = sorted[i];
		if (h === prev + 1) prev = h;
		else {
			out.push({
				start,
				end: prev + 1
			});
			start = h;
			prev = h;
		}
	}
	out.push({
		start,
		end: prev + 1
	});
	return out;
}
var PM_METHODS = [
	{
		key: "gcash",
		label: "GCash",
		emoji: "💙"
	},
	{
		key: "paymaya",
		label: "Maya",
		emoji: "💚"
	},
	{
		key: "grab_pay",
		label: "GrabPay",
		emoji: "🟢"
	},
	{
		key: "qrph",
		label: "QR Ph",
		emoji: "🔳"
	}
];
function CourtBookingContent({ courtId, onClose, userId }) {
	const qc = useQueryClient();
	const [date, setDate] = (0, import_react.useState)(() => zonedDateISO());
	const [selected, setSelected] = (0, import_react.useState)([]);
	const [signInGate, setSignInGate] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	const [checkoutOpen, setCheckoutOpen] = (0, import_react.useState)(false);
	const [payLoading, setPayLoading] = (0, import_react.useState)(null);
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	const [carouselIdx, setCarouselIdx] = (0, import_react.useState)(0);
	const [voucherCode, setVoucherCode] = (0, import_react.useState)("");
	const [voucher, setVoucher] = (0, import_react.useState)(null);
	const [voucherErr, setVoucherErr] = (0, import_react.useState)(null);
	const [voucherLoading, setVoucherLoading] = (0, import_react.useState)(false);
	const courtQ = useQuery({
		queryKey: ["court", courtId],
		queryFn: async () => {
			const { data, error } = await supabase.from("courts").select("id, name, hourly_rate, is_indoor, operating_hours, inherit_venue_hours, blocked_hours, blocked_dates, description, amenities, images, coming_soon, capacity, physical_court_id, map_emoji, surface_type, player_capacity, voucher_enabled, rate_rules, sports(name), venues(name, address, timezone, latitude, longitude, payment_mode, refund_cutoff_hours, operating_hours)").eq("id", courtId).maybeSingle();
			if (error) throw error;
			return data;
		}
	});
	const sharedSpaceQ = useQuery({
		queryKey: [
			"court-shared-space",
			courtId,
			courtQ.data?.physical_court_id
		],
		enabled: !!courtQ.data?.physical_court_id,
		queryFn: async () => {
			const { count, error } = await supabase.from("courts").select("id", {
				count: "exact",
				head: true
			}).eq("physical_court_id", courtQ.data.physical_court_id);
			if (error) throw error;
			return (count ?? 0) >= 2;
		}
	});
	const dayBounds = (0, import_react.useMemo)(() => zonedDayBoundsUtc(date), [date]);
	const availQ = useQuery({
		queryKey: [
			"avail",
			courtId,
			date
		],
		refetchInterval: 1e4,
		refetchOnWindowFocus: true,
		queryFn: async () => {
			const { data, error } = await supabase.rpc("get_court_availability", {
				_court_id: courtId,
				_from: dayBounds.start.toISOString(),
				_to: dayBounds.end.toISOString()
			});
			if (error) throw error;
			const rows = data ?? [];
			const map = /* @__PURE__ */ new Map();
			rows.forEach((row) => {
				const h = zonedHour(row.hour_start);
				map.set(h, {
					remaining: row.remaining,
					blockedByOther: row.blocked_by_other_sport,
					heldForPayment: row.held_for_payment
				});
			});
			return map;
		},
		enabled: !!courtQ.data
	});
	(0, import_react.useEffect)(() => {
		const channel = supabase.channel(`avail-${courtId}-${date}`).on("postgres_changes", {
			event: "*",
			schema: "public",
			table: "bookings"
		}, () => {
			qc.invalidateQueries({ queryKey: [
				"avail",
				courtId,
				date
			] });
			qc.invalidateQueries({ queryKey: ["venue-day-bookings"] });
		}).subscribe();
		return () => {
			supabase.removeChannel(channel);
		};
	}, [
		courtId,
		date,
		qc
	]);
	const ownBookingsQ = useQuery({
		queryKey: [
			"court-own-bookings",
			courtId,
			date,
			userId
		],
		enabled: !!courtQ.data && !!userId,
		queryFn: async () => {
			if (!userId) return [];
			const { data, error } = await supabase.from("bookings").select("start_time, end_time, status, payment_status, created_at").eq("court_id", courtId).eq("user_id", userId).lt("start_time", dayBounds.end.toISOString()).gt("end_time", dayBounds.start.toISOString());
			if (error) throw error;
			return data ?? [];
		}
	});
	const bookMut = useMutation({
		mutationFn: async (hours) => {
			const { data: userData } = await supabase.auth.getUser();
			if (!userData.user) throw new Error("Please sign in to book a court.");
			const rows = [...hours].sort((a, b) => a - b).map((hour, idx) => {
				const start = zonedHourToUtc(date, hour);
				const end = new Date(start.getTime() + 3600 * 1e3);
				const applyVoucher = idx === 0 && voucher;
				return {
					court_id: courtId,
					user_id: userData.user.id,
					start_time: start.toISOString(),
					end_time: end.toISOString(),
					status: "confirmed",
					unit_price: rateForHour(Number(courtQ.data.hourly_rate), normalizeRules(courtQ.data.rate_rules), date, hour),
					voucher_id: applyVoucher ? voucher.id : null,
					discount_amount: applyVoucher ? voucher.discount : 0
				};
			});
			const { error } = await supabase.from("bookings").insert(rows);
			if (error) throw error;
		},
		onSuccess: () => {
			setSelected([]);
			setErr(null);
			setVoucher(null);
			setVoucherCode("");
			qc.invalidateQueries({ queryKey: [
				"avail",
				courtId,
				date
			] });
		},
		onError: (e) => {
			if (/exclusion|overlap|conflict/i.test(e.message)) {
				setErr("One of those hours was just taken. Pick another slot.");
				qc.invalidateQueries({ queryKey: [
					"avail",
					courtId,
					date
				] });
			} else setErr(e.message);
		}
	});
	async function applyVoucher() {
		if (!voucherCode.trim() || !courtQ.data) return;
		setVoucherLoading(true);
		setVoucherErr(null);
		try {
			const rules = normalizeRules(courtQ.data.rate_rules);
			const amount = selected.length ? priceForHours(Number(courtQ.data.hourly_rate), rules, date, selected) : Number(courtQ.data.hourly_rate);
			const { data, error } = await supabase.rpc("preview_voucher", {
				_code: voucherCode.trim(),
				_court_id: courtId,
				_amount: amount
			});
			if (error) throw error;
			const row = Array.isArray(data) ? data[0] : data;
			if (!row?.ok) {
				setVoucher(null);
				setVoucherErr(row?.reason || "Invalid voucher");
				return;
			}
			setVoucher({
				id: row.voucher_id,
				discount: Number(row.discount),
				type: row.discount_type,
				value: Number(row.discount_value)
			});
		} catch (e) {
			setVoucher(null);
			setVoucherErr(e.message);
		} finally {
			setVoucherLoading(false);
		}
	}
	const ownSlotInfo = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const b of ownBookingsQ.data ?? []) {
			const start = new Date(b.start_time).getTime();
			const end = new Date(b.end_time).getTime();
			const startHr = Math.floor((start - dayBounds.start.getTime()) / 36e5);
			const endHr = Math.ceil((end - dayBounds.start.getTime()) / 36e5);
			const isHold = b.status === "pending" && b.payment_status !== "paid";
			for (let h = startHr; h < endHr; h++) map.set(h, { kind: isHold ? "hold" : "booking" });
		}
		return map;
	}, [ownBookingsQ.data, dayBounds.start]);
	if (courtQ.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-2xl bg-muted" })
	});
	if (!courtQ.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-xl font-bold",
			children: "Court not found"
		})
	});
	const court = courtQ.data;
	const rules = normalizeRules(court.rate_rules);
	const baseRate = Number(court.hourly_rate);
	const venueHours = normalizeHours(court.venues?.operating_hours);
	const courtHours = effectiveHours({
		inherit_venue_hours: court.inherit_venue_hours,
		operating_hours: court.operating_hours
	}, venueHours);
	const variablePricing = hasVariablePricing(baseRate, rules, courtHours);
	const rateOf = (hour) => rateForHour(baseRate, rules, date, hour);
	const subtotal = priceForHours(baseRate, rules, date, selected);
	const breakdown = priceBreakdown(baseRate, rules, date, selected);
	const dow = DAY_KEYS[zonedDayOfWeek(date)];
	const dateOverride = court.blocked_dates?.[date];
	const blocked = new Set(dateOverride ?? court.blocked_hours?.[dow] ?? []);
	const openHours = openHoursForDate(courtHours, date);
	const slots = Array.from({ length: 24 }, (_, i) => i).filter((h) => openHours.has(h));
	const closedToday = slots.length === 0;
	const capacity = Math.max(1, court.capacity ?? 1);
	const slotInfo = (hour) => availQ.data?.get(hour) ?? {
		remaining: capacity,
		blockedByOther: false,
		heldForPayment: false
	};
	const isBooked = (hour) => slotInfo(hour).remaining <= 0 && !slotInfo(hour).blockedByOther;
	const isBlockedBySport = (hour) => slotInfo(hour).blockedByOther;
	const isPaymentHold = (hour) => slotInfo(hour).heldForPayment;
	const isBlocked = (hour) => blocked.has(hour);
	const isPast = (hour) => {
		return zonedHourToUtc(date, hour).getTime() < Date.now();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			signInGate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-1400 grid place-items-center bg-[#061a17]/70 p-4 backdrop-blur-sm motion-safe:animate-[landing-overlay-in_.2s_ease-out_both]",
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "booking-gate-title",
				onMouseDown: () => setSignInGate(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm overflow-hidden rounded-3xl border border-[#b8f05a]/40 bg-white text-[#102521] shadow-2xl shadow-[#09231f]/30 motion-safe:animate-[modal-pop-in_.32s_cubic-bezier(0.22,1,0.36,1)_both]",
					onMouseDown: (event) => event.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden bg-[#09231f] px-6 pb-6 pt-5 text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-12 -top-16 h-40 w-40 rounded-full bg-[#b8f05a]/20 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-bold uppercase tracking-[.18em] text-[#b8f05a]",
								children: "Almost there"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "booking-gate-title",
								className: "mt-1.5 font-display text-xl font-bold",
								children: "Sign in to reserve this slot"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setSignInGate(false),
								"aria-label": "Close",
								className: "rounded-full border border-white/20 p-1.5 text-white/80 transition hover:bg-white/10 hover:text-white",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-6 pb-6 pt-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-[#5e746e]",
								children: "Browsing is open to everyone. Booking needs an account so your reservation has somewhere to live and the venue knows who is coming."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 grid gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/landing",
									search: { signin: true },
									className: "inline-flex items-center justify-center gap-2 rounded-full bg-[#0b3d35] px-4 py-3 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-[#126152]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogIn, { className: "h-4 w-4" }), " Sign in"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/landing",
									search: { signup: true },
									className: "inline-flex items-center justify-center gap-2 rounded-full border border-[#0b3d35] px-4 py-3 text-sm font-bold text-[#0b3d35] transition hover:-translate-y-0.5 hover:bg-[#eff5ed]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4" }), " Create an account"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-center text-xs text-[#5e746e]",
								children: "Your selected hours are not held until a booking is confirmed."
							})
						]
					})]
				})
			}),
			onClose && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-0 z-10 flex items-center justify-between border-b border-[#b8f05a]/25 bg-[#0b3d35]/95 px-4 py-2.5 text-white backdrop-blur",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-[11px] font-extrabold uppercase tracking-[0.24em] text-[#b8f05a]",
					children: "Reserve your court"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					"aria-label": "Close",
					className: "rounded-full p-1.5 text-white/75 transition hover:bg-white/10 hover:text-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 overflow-y-auto px-5 py-5",
				children: [
					court.coming_soon && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-5 rounded-2xl border-2 border-amber-500/40 bg-amber-500/10 p-5 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "inline-block rounded-full bg-amber-500 px-3 py-1 text-xs font-bold uppercase tracking-wider text-white",
								children: "Coming soon"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 text-lg font-bold",
								children: "This court isn't open for booking yet"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "Check back soon."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-5 overflow-hidden rounded-2xl border border-[#dce8e2] bg-card shadow-[0_10px_28px_rgba(16,37,33,0.06)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "border-b border-[#dce8e2] bg-gradient-to-r from-[#0b3d35] via-[#126152] to-[#12806d] px-4 py-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-[11px] font-extrabold uppercase italic tracking-[0.3em] text-[#d9ff9b]",
								children: "Court profile"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid grid-cols-1 gap-0 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "Sport type",
									value: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1.5",
										children: [court.map_emoji && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-base leading-none",
											children: court.map_emoji
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: court.sports?.name ?? "—" })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "Court type",
									value: court.is_indoor ? "Indoor" : "Outdoor"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "Court name",
									value: court.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "Court location",
									value: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold",
											children: court.venues?.name ?? "—"
										}), court.venues?.address && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-0.5 block text-xs text-muted-foreground",
											children: court.venues.address
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "Rate",
									value: variablePricing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-bold text-primary",
												children: ["from ", peso(minRate(baseRate, rules, courtHours))]
											}),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs text-muted-foreground",
												children: ["/ hour · up to ", peso(maxRate(baseRate, rules, courtHours))]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-0.5 block text-[10px] font-semibold uppercase tracking-wide text-muted-foreground",
												children: "Rates vary by time & day"
											})
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-primary",
											children: peso(baseRate)
										}),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground",
											children: "/ hour"
										})
									] })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "Surface type",
									value: court.surface_type || /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Not specified"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "Player capacity",
									value: court.player_capacity ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										court.player_capacity,
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs text-muted-foreground",
											children: ["player", court.player_capacity === 1 ? "" : "s"]
										})
									] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Not specified"
									})
								})
							]
						})]
					}),
					sharedSpaceQ.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-5 rounded-2xl border border-primary/25 bg-primary/5 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-semibold text-foreground",
							children: "Shared playing space"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs leading-relaxed text-muted-foreground",
							children: "This court shares a playing area with other court layouts. Some time slots may be unavailable when a linked court is booked."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold uppercase tracking-wider text-muted-foreground",
								children: "Court images"
							}), (court.images?.length ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [
									carouselIdx + 1,
									" / ",
									court.images.length
								]
							})]
						}), (court.images?.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-56 w-full flex-col items-center justify-center rounded-xl border border-dashed border-border bg-muted/40 text-center sm:h-72",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									className: "h-10 w-10 text-muted-foreground/60",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: "1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
											x: "3",
											y: "3",
											width: "18",
											height: "18",
											rx: "2"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: "8.5",
											cy: "8.5",
											r: "1.5"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m21 15-5-5L5 21" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm font-medium text-muted-foreground",
									children: "No image set"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground/80",
									children: "The tenant hasn't uploaded photos for this court yet."
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative overflow-hidden rounded-xl border border-border bg-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setLightbox(carouselIdx),
								className: "block w-full",
								"aria-label": "Enlarge image",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: court.images[carouselIdx],
									alt: `${court.name} photo ${carouselIdx + 1}`,
									className: "h-56 w-full object-cover sm:h-72",
									loading: "lazy"
								})
							}), court.images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setCarouselIdx((carouselIdx - 1 + court.images.length) % court.images.length),
								className: "absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/60 p-2 text-white hover:bg-black/80",
								"aria-label": "Previous image",
								children: "‹"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setCarouselIdx((carouselIdx + 1) % court.images.length),
								className: "absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/60 p-2 text-white hover:bg-black/80",
								"aria-label": "Next image",
								children: "›"
							})] })]
						}), court.images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex gap-2 overflow-x-auto pb-1",
							children: court.images.map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setCarouselIdx(i),
								className: "flex-shrink-0 overflow-hidden rounded-lg border-2 transition " + (i === carouselIdx ? "border-primary" : "border-transparent opacity-70 hover:opacity-100"),
								"aria-label": `Show image ${i + 1}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src,
									alt: "",
									className: "h-14 w-20 object-cover",
									loading: "lazy"
								})
							}, i))
						})] })]
					}),
					(court.description || (court.amenities?.length ?? 0) > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mb-5 rounded-2xl border border-border bg-card p-4",
						children: [court.description && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: "About this court"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 whitespace-pre-line text-sm text-muted-foreground",
							children: court.description
						})] }), (court.amenities?.length ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground",
							children: "Amenities"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 flex flex-wrap gap-1.5",
							children: court.amenities.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rounded-full border border-border bg-secondary px-2.5 py-0.5 text-xs font-medium",
								children: a
							}, a))
						})] })]
					}),
					!court.coming_soon && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl border border-[#dce8e2] bg-gradient-to-br from-white via-white to-[#eaf5d8]/70 p-4 shadow-[0_10px_28px_rgba(16,37,33,0.06)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-base font-semibold",
									children: "Pick a Time Slots"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-1.5 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												setDate(shiftISO(date, -1));
												setSelected([]);
												setErr(null);
											},
											className: "rounded-lg border border-border bg-background px-2 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary",
											"aria-label": "Previous day",
											children: "← Prev"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												setDate(zonedDateISO());
												setSelected([]);
												setErr(null);
											},
											className: "rounded-lg border border-border bg-background px-2 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary",
											children: "Today"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												setDate(shiftISO(date, 1));
												setSelected([]);
												setErr(null);
											},
											className: "rounded-lg border border-border bg-background px-2 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary",
											"aria-label": "Next day",
											children: "Next →"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "date",
											value: date,
											onChange: (e) => {
												setDate(e.target.value);
												setSelected([]);
												setErr(null);
											},
											className: "rounded-lg border border-input bg-background px-2 py-1.5 text-xs"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted-foreground",
								children: closedToday ? "This court is closed on this date. Pick another day." : `Open ${describeWindow(courtHours[[
									"sun",
									"mon",
									"tue",
									"wed",
									"thu",
									"fri",
									"sat"
								][zonedDayOfWeek(date)]])} · tap a time slot to select or deselect it; consecutive slots are automatically combined into a single time range.`
							}),
							variablePricing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RateCard, {
								baseRate,
								rules,
								hours: courtHours,
								className: "mt-3"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2 text-[10px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-sm border border-green-500/50 bg-green-200" }), " Available"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-sm border border-yellow-500/60 bg-yellow-300" }), " Selected"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-sm border border-primary/50 bg-primary/15" }), " Your booking"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-sm border border-amber-500/60 bg-amber-200" }), " Payment hold"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-sm border border-red-500/50 bg-red-300" }), " Booked"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-sm border border-amber-400/60 bg-amber-200/60" }), " Unavailable"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-sm border border-orange-500/50 bg-orange-300" }), " Past"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 grid grid-cols-3 gap-1.5 sm:grid-cols-4",
								children: slots.map((h) => {
									const info = slotInfo(h);
									const otherSport = isBlockedBySport(h);
									const paymentHold = isPaymentHold(h);
									const booked = isBooked(h);
									const blockedSlot = isBlocked(h);
									const past = isPast(h);
									const mine = ownSlotInfo.get(h);
									const disabled = booked || blockedSlot || past || otherSport;
									const active = selected.includes(h);
									const label = blockedSlot ? "Unavailable" : mine ? mine.kind === "hold" ? "Your hold" : "Your booking" : paymentHold ? "On hold" : otherSport ? "Other sport" : booked ? "Booked" : past ? "Past" : capacity > 1 ? `${info.remaining}/${capacity} left` : "";
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										disabled,
										onClick: () => {
											setErr(null);
											setSelected((prev) => prev.includes(h) ? prev.filter((x) => x !== h) : [...prev, h].sort((a, b) => a - b));
										},
										title: mine ? "Booked by you" : paymentHold ? "Temporarily held while another player completes payment" : otherSport ? "Booked for a different sport" : label,
										className: "flex flex-col items-center rounded-lg border px-1.5 py-1.5 text-xs font-medium transition " + (active ? "border-yellow-500 bg-yellow-300 text-yellow-950" : mine ? "cursor-not-allowed border-primary/50 bg-primary/10 text-primary" : paymentHold ? "cursor-not-allowed border-amber-500/60 bg-amber-200 text-amber-950" : booked ? "cursor-not-allowed border-red-500/50 bg-red-300 text-red-900" : otherSport ? "cursor-not-allowed border-purple-400/60 bg-purple-200/60 text-purple-900" : blockedSlot ? "cursor-not-allowed border-amber-400/60 bg-amber-200/60 text-amber-900" : past ? "cursor-not-allowed border-orange-500/50 bg-orange-300 text-orange-900" : "border-green-500/50 bg-green-200 text-green-900 hover:border-green-600 hover:bg-green-300"),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] leading-tight " + (disabled ? "line-through" : ""),
												children: [
													fmtHour(h),
													" – ",
													fmtHour((h + 1) % 24)
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-0.5 text-[10px] font-semibold tabular-nums",
												children: peso(rateOf(h))
											}),
											label && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-0.5 text-[9px] uppercase tracking-wide",
												children: label
											})
										]
									}, h);
								})
							}),
							err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive",
								children: err
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 border-t border-border pt-3",
								children: [
									court.voucher_enabled && selected.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-3 rounded-lg border border-primary/30 bg-primary/5 p-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mb-1.5 text-xs font-semibold uppercase tracking-wider text-primary",
												children: "Voucher code"
											}),
											voucher ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "rounded bg-emerald-100 px-2 py-0.5 font-mono text-xs font-semibold text-emerald-700",
														children: "Applied"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "ml-2",
														children: [
															voucher.type === "percent" ? `${voucher.value}% off` : `₱${voucher.value.toFixed(0)} off`,
															" — you save ",
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["₱", voucher.discount.toFixed(2)] })
														]
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => {
														setVoucher(null);
														setVoucherCode("");
														setVoucherErr(null);
													},
													className: "text-xs text-muted-foreground underline hover:text-foreground",
													children: "Remove"
												})]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													value: voucherCode,
													onChange: (e) => {
														setVoucherCode(e.target.value.toUpperCase());
														setVoucherErr(null);
													},
													placeholder: "Enter code",
													className: "flex-1 rounded-md border bg-background px-2 py-1.5 text-sm uppercase"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: applyVoucher,
													disabled: voucherLoading || !voucherCode.trim(),
													className: "rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground disabled:opacity-50",
													children: voucherLoading ? "Checking…" : "Apply"
												})]
											}),
											voucherErr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1.5 text-xs text-red-600",
												children: voucherErr
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm text-muted-foreground",
										children: selected.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											"Selected ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-semibold text-foreground",
												children: [
													selected.length,
													" hr",
													selected.length > 1 ? "s" : ""
												]
											}),
											voucher ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
												" · Subtotal ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "line-through",
													children: peso(subtotal)
												}),
												" · Total ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-semibold text-emerald-700",
													children: ["₱", Math.max(0, subtotal - voucher.discount).toFixed(2)]
												})
											] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" · Total ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-foreground",
												children: peso(subtotal)
											})] }),
											variablePricing && breakdown.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-1 text-[11px] text-muted-foreground",
												children: breakdown.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
													i > 0 && " + ",
													b.hours,
													" hr",
													b.hours > 1 ? "s" : "",
													" × ",
													peso(b.rate)
												] }, b.rate))
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-1.5 flex flex-wrap gap-1.5",
												children: groupHourRanges(selected).map((r) => {
													const hrs = r.end - r.start;
													return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "inline-flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-foreground",
														children: [
															fmtHour(r.start),
															" – ",
															fmtHour(r.end % 24),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "text-[10px] text-muted-foreground",
																children: [
																	"· ",
																	hrs,
																	" hr",
																	hrs > 1 ? "s" : ""
																]
															})
														]
													}, `${r.start}-${r.end}`);
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-[11px] text-muted-foreground",
												children: "Adjacent slots are combined into one segment."
											})
										] }) : "Choose one or more hours."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex flex-wrap gap-2",
										children: [selected.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setSelected([]),
											className: "rounded-lg border border-border bg-background px-3 py-2 text-sm font-semibold hover:border-primary hover:text-primary",
											children: "Clear"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											disabled: selected.length === 0 || bookMut.isPending,
											onClick: () => {
												if (selected.length === 0) return;
												if (!userId) {
													setSignInGate(true);
													return;
												}
												if ((court.venues?.payment_mode ?? "none") === "none") bookMut.mutate(selected);
												else {
													setErr(null);
													setCheckoutOpen(true);
												}
											},
											className: "flex-1 rounded-full bg-[#0b3d35] px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-[#126152] disabled:opacity-50",
											children: bookMut.isPending ? "Booking…" : court.venues?.payment_mode && court.venues.payment_mode !== "none" ? `Continue to payment${selected.length > 1 ? ` (${selected.length} hrs)` : ""}` : `Confirm booking${selected.length > 1 ? ` (${selected.length} hrs)` : ""}`
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 text-xs text-muted-foreground",
										children: [court.venues?.payment_mode === "full" && "Full payment required online to reserve the slot.", (!court.venues?.payment_mode || court.venues.payment_mode === "none") && "Payment handled at the venue."]
									})
								]
							})
						]
					})
				]
			}),
			checkoutOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckoutDrawer, {
				courtId,
				date,
				hours: selected,
				subtotal,
				breakdown,
				voucherCode: voucher ? voucherCode.trim() : null,
				discount: voucher?.discount ?? 0,
				paymentMode: court.venues?.payment_mode ?? "full",
				venueName: court.venues?.name ?? "CourtHub",
				courtName: court.name,
				onClose: () => {
					setCheckoutOpen(false);
					setPayLoading(null);
				},
				payLoading,
				setPayLoading,
				onError: (m) => {
					setErr(m);
					setCheckoutOpen(false);
				}
			}),
			lightbox !== null && court.images && court.images[lightbox] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-[1300] flex items-center justify-center bg-black/90 p-4",
				onClick: () => setLightbox(null),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: (e) => {
							e.stopPropagation();
							setLightbox(null);
						},
						className: "absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white hover:bg-white/20",
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
					}),
					lightbox > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: (e) => {
							e.stopPropagation();
							setLightbox(lightbox - 1);
						},
						className: "absolute left-4 rounded-full bg-white/10 p-3 text-white hover:bg-white/20",
						"aria-label": "Previous",
						children: "‹"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: court.images[lightbox],
						alt: `${court.name} photo ${lightbox + 1}`,
						className: "max-h-[85vh] max-w-[92vw] rounded-lg object-contain",
						onClick: (e) => e.stopPropagation()
					}),
					lightbox < court.images.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: (e) => {
							e.stopPropagation();
							setLightbox(lightbox + 1);
						},
						className: "absolute right-4 rounded-full bg-white/10 p-3 text-white hover:bg-white/20",
						"aria-label": "Next",
						children: "›"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full bg-black/60 px-3 py-1 text-xs text-white",
						children: [
							lightbox + 1,
							" / ",
							court.images.length
						]
					})
				]
			})
		]
	});
}
function CourtBookingPanel({ courtId, open, onOpenChange, userId }) {
	const isMobile = useIsMobile();
	const [renderedId, setRenderedId] = (0, import_react.useState)(courtId);
	const clearTimer = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (courtId) {
			if (clearTimer.current) clearTimeout(clearTimer.current);
			setRenderedId(courtId);
		} else if (renderedId !== null) clearTimer.current = setTimeout(() => setRenderedId(null), 550);
		return () => {
			if (clearTimer.current) clearTimeout(clearTimer.current);
		};
	}, [courtId, renderedId]);
	if (!renderedId) return null;
	if (isMobile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Drawer$1, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrawerContent, {
			className: "h-[92vh] p-0 transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtBookingContent, {
				courtId: renderedId,
				userId,
				onClose: () => onOpenChange(false)
			})
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			side: "right",
			className: "w-full max-w-xl overflow-hidden p-0 pl-11 sm:max-w-xl data-[state=open]:duration-500 data-[state=closed]:duration-500 data-[state=open]:ease-[cubic-bezier(0.22,1,0.36,1)] data-[state=closed]:ease-[cubic-bezier(0.7,0,0.84,0)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute inset-y-0 left-0 z-20 flex w-11 items-center justify-center border-r border-[#b8f05a]/30 bg-gradient-to-b from-[#09231f] via-[#0b3d35] to-[#12806d] shadow-[inset_-6px_0_12px_-8px_rgba(0,0,0,0.35)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "whitespace-nowrap font-display text-[17px] font-extrabold uppercase italic tracking-[0.4em] text-white drop-shadow-[0_1px_6px_rgba(0,0,0,0.45)] [writing-mode:vertical-rl] [transform:rotate(180deg)]",
					children: "Book a Court"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtBookingContent, {
				courtId: renderedId,
				userId,
				onClose: () => onOpenChange(false)
			})]
		})
	});
}
function CheckoutDrawer({ courtId, date, hours, subtotal, breakdown, voucherCode, discount, paymentMode, venueName, courtName, onClose, payLoading, setPayLoading, onError }) {
	const fullAmount = Math.max(0, subtotal - (discount || 0));
	const pay = async (method) => {
		setPayLoading(method);
		try {
			const res = await startBookingCheckout({ data: {
				courtId,
				date,
				hours,
				method,
				origin: window.location.origin,
				voucherCode: voucherCode || void 0
			} });
			window.location.href = res.checkoutUrl;
		} catch (e) {
			onError(e instanceof Error ? e.message : "Payment could not be started");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[70] flex items-end justify-center bg-black/60 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md overflow-hidden rounded-t-2xl border border-[#b8f05a]/35 bg-card p-6 shadow-2xl sm:rounded-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-extrabold uppercase tracking-[0.22em] text-primary",
							children: "CourtHub checkout"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-bold",
							children: "Choose payment method"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: [
								venueName,
								" · ",
								courtName
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						className: "rounded-full p-1 text-muted-foreground hover:bg-secondary",
						"aria-label": "Close",
						children: "✕"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 rounded-xl border border-[#dce8e2] bg-[#eaf5d8]/55 p-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Hours"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hours.length })]
						}),
						breakdown.length > 1 && breakdown.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex justify-between text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								b.hours,
								" hr",
								b.hours > 1 ? "s" : "",
								" × ",
								peso(b.rate)
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: peso(b.rate * b.hours) })]
						}, b.rate)),
						discount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Subtotal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: peso(subtotal) })]
						}),
						discount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex justify-between text-xs text-emerald-700",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Voucher discount" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["−₱", discount.toFixed(2)] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Total"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["₱", fullAmount.toFixed(2)] })]
						}),
						paymentMode === "full" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex justify-between border-t border-border pt-2 font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Due now" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-primary",
								children: ["₱", fullAmount.toFixed(2)]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 grid grid-cols-2 gap-2",
					children: PM_METHODS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						disabled: payLoading !== null,
						onClick: () => pay(m.key),
						className: "flex flex-col items-center rounded-xl border border-border bg-background p-3 text-sm font-semibold transition hover:border-primary hover:bg-primary/5 disabled:opacity-50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-2xl",
							children: m.emoji
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1",
							children: payLoading === m.key ? "Redirecting…" : m.label
						})]
					}, m.key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-[11px] text-muted-foreground",
					children: "Powered by PayMongo · Test mode."
				})
			]
		})
	});
}
var SPORT_EMOJI = {
	badminton: "🏸",
	basketball: "🏀",
	football: "⚽",
	pickleball: "🥎",
	squash: "🏟️",
	tennis: "🎾",
	volleyball: "🏐"
};
function haversineKm(a, b) {
	const R = 6371;
	const toRad = (d) => d * Math.PI / 180;
	const dLat = toRad(b.lat - a.lat);
	const dLng = toRad(b.lng - a.lng);
	const lat1 = toRad(a.lat);
	const lat2 = toRad(b.lat);
	const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
	return 2 * R * Math.asin(Math.sqrt(x));
}
function VenueDetail() {
	const { venueId } = Route.useParams();
	const { sport, court: openCourtId } = Route.useSearch();
	const navigate = useNavigate({ from: "/venues/$venueId" });
	const openCourt = (id) => navigate({
		search: (prev) => ({
			...prev,
			court: id ?? void 0
		}),
		replace: !id
	});
	const [imgIdx, setImgIdx] = (0, import_react.useState)(0);
	const [lightboxOpen, setLightboxOpen] = (0, import_react.useState)(false);
	const [openChip, setOpenChip] = (0, import_react.useState)(null);
	const chipsRef = (0, import_react.useRef)(null);
	const [panelHidden, setPanelHidden] = (0, import_react.useState)(false);
	const userQ = useQuery({
		queryKey: ["venue-current-user"],
		queryFn: async () => {
			const { data } = await supabase.auth.getUser();
			return data.user?.id ?? null;
		}
	});
	const venueQ = useQuery({
		queryKey: ["venue", venueId],
		queryFn: async () => {
			const { data, error } = await supabase.from("venues").select("id, name, address, latitude, longitude, description, images, amenities, food_beverages, facility_services, fees, fees_notes, contact_phone, contact_email, operating_hours_text, operating_hours, refund_cutoff_hours, cancellation_notes, rules").eq("id", Number(venueId)).maybeSingle();
			if (error) throw error;
			return data;
		}
	});
	const courtsQ = useQuery({
		queryKey: [
			"venue-courts",
			venueId,
			sport ?? "all"
		],
		queryFn: async () => {
			let q = supabase.from("courts").select("id, name, hourly_rate, rate_rules, is_indoor, description, amenities, images, coming_soon, operating_hours, inherit_venue_hours, map_emoji, sports!inner(name, slug)").eq("venue_id", Number(venueId)).eq("is_active", true).order("coming_soon", { ascending: true }).order("id");
			if (sport) q = q.eq("sports.slug", sport);
			const { data, error } = await q;
			if (error) throw error;
			return data;
		}
	});
	const venue = venueQ.data;
	const courts = courtsQ.data ?? [];
	const images = venue?.images ?? [];
	const hasImages = images.length > 0;
	const currentImg = hasImages ? images[(imgIdx % images.length + images.length) % images.length] : null;
	const prev = () => setImgIdx((i) => i - 1);
	const next = () => setImgIdx((i) => i + 1);
	const feesList = Array.isArray(venue?.fees) ? venue.fees : [];
	const rulesList = (venue?.rules ?? "").split(/\r?\n/).map((s) => s.replace(/^\s*[-•]\s*/, "").trim()).filter(Boolean);
	const visibleChips = (venue ? [
		{
			key: "about",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "h-4 w-4" }),
			label: "About",
			preview: venue.description ?? "",
			show: !!venue.description
		},
		{
			key: "location",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" }),
			label: "Location",
			preview: venue.address,
			show: !!venue.address
		},
		{
			key: "inquiries",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4" }),
			label: "Inquiries",
			preview: venue.contact_phone ?? venue.contact_email ?? "",
			show: !!(venue.contact_phone || venue.contact_email)
		},
		{
			key: "hours",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4" }),
			label: "Operating Hours",
			preview: describeWeek(normalizeHours(venue.operating_hours))[0]?.window ?? "",
			show: true
		},
		{
			key: "amenities",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" }),
			label: "Amenities",
			preview: `${venue.amenities?.length ?? 0} items`,
			show: (venue.amenities?.length ?? 0) > 0
		},
		{
			key: "fb",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UtensilsCrossed, { className: "h-4 w-4" }),
			label: "Food & Beverages",
			preview: `${venue.food_beverages?.length ?? 0} items`,
			show: (venue.food_beverages?.length ?? 0) > 0
		},
		{
			key: "fs",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "h-4 w-4" }),
			label: "Facility Services",
			preview: `${venue.facility_services?.length ?? 0} items`,
			show: (venue.facility_services?.length ?? 0) > 0
		},
		{
			key: "fees",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-4 w-4" }),
			label: "Fees & Charges",
			preview: feesList.length > 0 ? `${feesList.length} listed` : "See details",
			show: feesList.length > 0 || !!venue.fees_notes
		},
		{
			key: "cancellation",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }),
			label: "Cancellation",
			preview: venue.refund_cutoff_hours != null ? venue.refund_cutoff_hours > 0 ? `Cancel up to ${venue.refund_cutoff_hours}h before` : "Last-minute allowed" : "See policy",
			show: venue.refund_cutoff_hours != null || !!venue.cancellation_notes
		},
		{
			key: "rules",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "h-4 w-4" }),
			label: "Rules",
			preview: `${rulesList.length} rules`,
			show: rulesList.length > 0
		}
	] : []).filter((c) => c.show);
	const scrollChips = (dir) => {
		const el = chipsRef.current;
		if (!el) return;
		el.scrollBy({
			left: dir * Math.min(el.clientWidth * .8, 400),
			behavior: "smooth"
		});
	};
	const CheckList = ({ items }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-1 grid grid-cols-1 gap-1.5 sm:grid-cols-2",
		children: items.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-start gap-2 text-sm text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 20 20",
					fill: "currentColor",
					className: "h-3 w-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fillRule: "evenodd",
						d: "M16.7 5.3a1 1 0 010 1.4l-7.5 7.5a1 1 0 01-1.4 0L3.3 9.7a1 1 0 111.4-1.4l3.8 3.8 6.8-6.8a1 1 0 011.4 0z",
						clipRule: "evenodd"
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: v })]
		}, v))
	});
	const chipSubtitle = (key, venueName) => {
		switch (key) {
			case "about": return `Get to know ${venueName}`;
			case "location": return "Where to find us";
			case "inquiries": return "Reach out to the venue";
			case "hours": return "When we're open for play";
			case "amenities": return "What's included on-site";
			case "fb": return "Food & drinks available";
			case "fs": return "Services offered here";
			case "fees": return "Additional charges to note";
			case "cancellation": return "Refund & cancellation policy";
			case "rules": return "Please follow these guidelines";
		}
	};
	const renderChipModalBody = (key) => {
		if (!venue) return null;
		switch (key) {
			case "about": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-line text-sm leading-relaxed text-foreground",
				children: venue.description
			});
			case "location": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-foreground",
					children: venue.address
				}), venue.latitude != null && venue.longitude != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `https://www.google.com/maps/search/?api=1&query=${venue.latitude},${venue.longitude}`,
					target: "_blank",
					rel: "noreferrer",
					className: "inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline",
					children: "View on Google Maps →"
				})]
			});
			case "inquiries": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "space-y-2 text-sm",
				children: [venue.contact_phone && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
						className: "flex items-center gap-1.5 text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							children: "📱"
						}), "Phone"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "font-medium select-text",
						children: venue.contact_phone
					})]
				}), venue.contact_email && (() => {
					const email = venue.contact_email.trim();
					const isGmail = /@gmail\.com$/i.test(email);
					const href = isGmail ? `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(email)}` : `mailto:${email}`;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
							className: "flex items-center gap-1.5 text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								children: "✉️"
							}), "Email"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-medium break-all",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href,
								target: isGmail ? "_blank" : void 0,
								rel: isGmail ? "noreferrer" : void 0,
								className: "text-primary hover:underline",
								children: email
							})
						})]
					});
				})()]
			});
			case "hours": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border rounded-lg border border-border",
					children: describeWeek(normalizeHours(venue.operating_hours)).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-foreground",
							children: r.days
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: r.window
						})]
					}, r.days))
				}), venue.operating_hours_text && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "whitespace-pre-line text-xs text-muted-foreground",
					children: venue.operating_hours_text
				})]
			});
			case "amenities": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckList, { items: venue.amenities ?? [] });
			case "fb": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckList, { items: venue.food_beverages ?? [] });
			case "fs": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckList, { items: venue.facility_services ?? [] });
			case "fees": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [feesList.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border",
				children: feesList.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: f.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-semibold text-primary",
						children: ["₱", Number(f.amount).toFixed(2)]
					})]
				}, i))
			}), venue.fees_notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 whitespace-pre-line text-xs text-muted-foreground",
				children: venue.fees_notes
			})] });
			case "cancellation": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 text-sm",
				children: [venue.refund_cutoff_hours != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-foreground",
					children: venue.refund_cutoff_hours > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"Cancel up to ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold text-primary",
							children: [venue.refund_cutoff_hours, "h"]
						}),
						" before start time."
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "Last-minute cancellations allowed." })
				}), venue.cancellation_notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "whitespace-pre-line text-xs text-muted-foreground",
					children: venue.cancellation_notes
				})]
			});
			case "rules": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5 text-sm text-foreground",
				children: rulesList.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							viewBox: "0 0 20 20",
							fill: "currentColor",
							className: "h-3 w-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								fillRule: "evenodd",
								d: "M16.7 5.3a1 1 0 010 1.4l-7.5 7.5a1 1 0 01-1.4 0L3.3 9.7a1 1 0 111.4-1.4l3.8 3.8 6.8-6.8a1 1 0 011.4 0z",
								clipRule: "evenodd"
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r })]
				}, i))
			});
		}
	};
	const activeChip = visibleChips.find((c) => c.key === openChip) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pb-8 sm:pb-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "relative",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative h-80 w-full overflow-hidden bg-muted sm:h-110 lg:h-130",
					children: [
						currentImg ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setLightboxOpen(true),
							onMouseEnter: () => setPanelHidden(true),
							onMouseLeave: () => setPanelHidden(false),
							"aria-label": "View full size image",
							className: "group block h-full w-full cursor-zoom-in",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: currentImg,
								alt: venue?.name ?? "Venue",
								className: "h-full w-full object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								className: "pointer-events-none absolute inset-0 z-5 flex items-center justify-center bg-black/40 opacity-0 backdrop-blur-[1px] transition-opacity duration-300 group-hover:opacity-100",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-linear-to-r from-[#0b3d35] via-[#12806d] to-[#b8f05a] px-5 py-2.5 font-display text-[13px] font-extrabold uppercase italic tracking-[0.3em] text-white shadow-lg drop-shadow-[0_1px_6px_rgba(0,0,0,0.45)]",
									children: "View venue images"
								})
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "court-pattern h-full w-full" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-0 bottom-0 h-56 bg-linear-to-t from-black/70 via-black/30 to-transparent" }),
						hasImages && images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: prev,
								"aria-label": "Previous image",
								className: "absolute left-3 top-1/2 z-10 -translate-y-1/2 rounded-full bg-background/90 p-2.5 text-foreground shadow-lg backdrop-blur transition hover:bg-background sm:left-5 sm:p-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5 sm:h-6 sm:w-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: next,
								"aria-label": "Next image",
								className: "absolute right-3 top-1/2 z-10 -translate-y-1/2 rounded-full bg-background/90 p-2.5 text-foreground shadow-lg backdrop-blur transition hover:bg-background sm:right-5 sm:p-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-5 w-5 sm:h-6 sm:w-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute right-4 top-4 z-10 rounded-full bg-black/50 px-2.5 py-1 text-xs font-medium text-white backdrop-blur",
								children: [
									(imgIdx % images.length + images.length) % images.length + 1,
									" / ",
									images.length
								]
							})
						] }),
						venue && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `absolute inset-x-0 bottom-0 z-10 transition-all duration-300 ease-out ${panelHidden ? "pointer-events-none translate-y-4 opacity-0" : "translate-y-0 opacity-100"}`,
							onMouseEnter: () => setPanelHidden(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto max-w-5xl px-3 pb-3 sm:px-6 sm:pb-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-white/25 bg-black/35 px-3 py-2 shadow-lg ring-1 ring-white/10 backdrop-blur-xl backdrop-saturate-150 sm:px-4 sm:py-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
												className: "truncate text-sm font-semibold text-white drop-shadow sm:text-base",
												children: venue.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-0.5 flex items-center gap-1 truncate text-[11px] text-white/75 sm:text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-3 w-3 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "truncate",
													children: venue.address
												})]
											})]
										}), visibleChips.length > 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "hidden shrink-0 gap-1 sm:flex",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => scrollChips(-1),
												"aria-label": "Scroll left",
												className: "rounded-full border border-white/20 bg-white/10 p-1 text-white transition hover:bg-white/20",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-3.5 w-3.5" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => scrollChips(1),
												"aria-label": "Scroll right",
												className: "rounded-full border border-white/20 bg-white/10 p-1 text-white transition hover:bg-white/20",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5" })
											})]
										})]
									}), visibleChips.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										ref: chipsRef,
										className: "mt-2 flex snap-x snap-mandatory gap-1.5 overflow-x-auto pb-0.5 [-ms-overflow-style:none] scrollbar-none [&::-webkit-scrollbar]:hidden",
										children: visibleChips.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setOpenChip(c.key),
											className: "group flex shrink-0 snap-start items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-2.5 py-1.5 text-left text-white transition hover:border-primary/60 hover:bg-white/20",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/30 text-primary-foreground [&>svg]:h-3 [&>svg]:w-3",
												children: c.icon
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] font-medium tracking-wide",
												children: c.label
											})]
										}, c.key))
									})]
								})
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExploreCourts, {
				venue: venue ?? void 0,
				courts,
				loading: courtsQ.isLoading,
				selectedSport: sport,
				onSelectSport: (slug) => navigate({
					to: "/venues/$venueId",
					params: { venueId },
					search: slug ? { sport: slug } : {}
				}),
				onOpenCourt: (id) => openCourt(id),
				openCourtId: openCourtId ?? null,
				userId: userQ.data ?? null
			}),
			activeChip && venue && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-black/60 p-0 sm:items-center sm:p-4",
				onClick: () => setOpenChip(null),
				role: "dialog",
				"aria-modal": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					onClick: (e) => e.stopPropagation(),
					className: "w-full max-w-lg overflow-hidden rounded-t-3xl bg-background shadow-2xl sm:rounded-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mt-3 h-1 w-10 rounded-full bg-white/50 sm:hidden" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3 bg-linear-to-br from-primary/25 via-primary/10 to-accent/20 px-5 py-4 sm:px-6 sm:py-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md ring-2 ring-white/50 [&>svg]:h-5 [&>svg]:w-5",
									children: activeChip.icon
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg font-bold leading-tight text-foreground",
									children: activeChip.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-xs text-foreground/70",
									children: chipSubtitle(activeChip.key, venue.name)
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setOpenChip(null),
								"aria-label": "Close",
								className: "rounded-full p-2 text-foreground/70 hover:bg-white/40 hover:text-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "max-h-[65vh] overflow-y-auto px-5 py-5 sm:px-6",
							children: renderChipModalBody(activeChip.key)
						})
					]
				})
			}),
			lightboxOpen && currentImg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4",
				onClick: () => setLightboxOpen(false),
				role: "dialog",
				"aria-modal": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setLightboxOpen(false),
						"aria-label": "Close",
						className: "absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white transition hover:bg-white/20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-6 w-6" })
					}),
					hasImages && images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: (e) => {
							e.stopPropagation();
							prev();
						},
						"aria-label": "Previous image",
						className: "absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20 sm:left-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-6 w-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: (e) => {
							e.stopPropagation();
							next();
						},
						"aria-label": "Next image",
						className: "absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20 sm:right-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-6 w-6" })
					})] }),
					hasImages && images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full bg-white/10 px-3 py-1 text-sm font-medium text-white backdrop-blur",
						children: [
							(imgIdx % images.length + images.length) % images.length + 1,
							" / ",
							images.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: currentImg,
						alt: venue?.name ?? "Venue",
						className: "max-h-full max-w-full object-contain",
						onClick: (e) => e.stopPropagation()
					})
				]
			}),
			venueQ.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto mt-6 max-w-6xl px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 animate-pulse rounded-2xl bg-muted" })
			}),
			!venueQ.isLoading && !venue && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto mt-6 max-w-6xl px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: "Venue not found."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CourtBookingPanel, {
				courtId: openCourtId ?? null,
				open: !!openCourtId,
				userId: userQ.data ?? null,
				onOpenChange: (o) => {
					if (!o) openCourt(null);
				}
			})
		]
	});
}
function ExploreCourts({ venue, courts, loading, selectedSport, onSelectSport, onOpenCourt, openCourtId, userId }) {
	const allSportsQ = useQuery({
		queryKey: ["all-sports"],
		queryFn: async () => {
			const { data, error } = await supabase.from("sports").select("name, slug").order("name");
			if (error) throw error;
			return data ?? [];
		}
	});
	const venueSportsQ = useQuery({
		queryKey: ["venue-sports", venue?.id],
		enabled: !!venue?.id,
		queryFn: async () => {
			const { data, error } = await supabase.from("courts").select("sports!inner(slug)").eq("venue_id", venue.id).eq("is_active", true);
			if (error) throw error;
			const set = /* @__PURE__ */ new Set();
			for (const row of data ?? []) if (row.sports) set.add(row.sports.slug);
			return set;
		}
	});
	const allSports = allSportsQ.data ?? [];
	const venueSportSlugs = venueSportsQ.data ?? /* @__PURE__ */ new Set();
	const noCourtsForSport = !!selectedSport && !loading && courts.length === 0;
	const [sportsCollapsed, setSportsCollapsed] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return false;
		return window.localStorage.getItem("venue:sportsCollapsed") === "1";
	});
	(0, import_react.useEffect)(() => {
		try {
			window.localStorage.setItem("venue:sportsCollapsed", sportsCollapsed ? "1" : "0");
		} catch {}
	}, [sportsCollapsed]);
	const [playerLoc, setPlayerLoc] = (0, import_react.useState)(null);
	const [geoDenied, setGeoDenied] = (0, import_react.useState)(false);
	const [locationModalOpen, setLocationModalOpen] = (0, import_react.useState)(false);
	const [manualPickerOpen, setManualPickerOpen] = (0, import_react.useState)(false);
	const [courtImageView, setCourtImageView] = (0, import_react.useState)(null);
	const [geoBusy, setGeoBusy] = (0, import_react.useState)(false);
	const [locResolved, setLocResolved] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!noCourtsForSport) return;
		if (playerLoc || geoDenied || locResolved) return;
		try {
			if (sessionStorage.getItem("venue:locPrompted") === "1") {
				setLocResolved(true);
				return;
			}
		} catch {}
		setLocationModalOpen(true);
	}, [
		noCourtsForSport,
		playerLoc,
		geoDenied,
		locResolved
	]);
	function markPrompted() {
		try {
			sessionStorage.setItem("venue:locPrompted", "1");
		} catch {}
		setLocResolved(true);
	}
	function requestGeolocation() {
		if (typeof navigator === "undefined" || !navigator.geolocation) {
			setGeoDenied(true);
			markPrompted();
			setLocationModalOpen(false);
			return;
		}
		setGeoBusy(true);
		navigator.geolocation.getCurrentPosition((pos) => {
			setPlayerLoc({
				lat: pos.coords.latitude,
				lng: pos.coords.longitude
			});
			setGeoBusy(false);
			markPrompted();
			setLocationModalOpen(false);
		}, () => {
			setGeoDenied(true);
			setGeoBusy(false);
			markPrompted();
			setLocationModalOpen(false);
		}, {
			timeout: 8e3,
			maximumAge: 300 * 1e3
		});
	}
	function skipLocation() {
		setGeoDenied(true);
		markPrompted();
		setLocationModalOpen(false);
	}
	const anchor = playerLoc ?? (venue?.latitude != null && venue?.longitude != null ? {
		lat: venue.latitude,
		lng: venue.longitude
	} : null);
	const suggestQ = useQuery({
		queryKey: [
			"suggest-venues",
			selectedSport,
			venue?.id
		],
		enabled: noCourtsForSport && !!selectedSport,
		queryFn: async () => {
			const { data, error } = await supabase.from("courts").select("venue_id, hourly_rate, sports!inner(slug), venues!inner(id, name, address, latitude, longitude, images, map_emoji, is_active)").eq("sports.slug", selectedSport).eq("is_active", true).eq("venues.is_active", true).neq("venue_id", venue?.id ?? -1);
			if (error) throw error;
			const map = /* @__PURE__ */ new Map();
			for (const row of data ?? []) {
				const v = row.venues;
				const existing = map.get(v.id);
				if (existing) existing.minRate = Math.min(existing.minRate, Number(row.hourly_rate));
				else map.set(v.id, {
					id: v.id,
					name: v.name,
					address: v.address,
					lat: v.latitude,
					lng: v.longitude,
					images: v.images ?? [],
					emoji: v.map_emoji,
					minRate: Number(row.hourly_rate)
				});
			}
			return Array.from(map.values());
		}
	});
	const suggestions = (0, import_react.useMemo)(() => {
		const list = suggestQ.data ?? [];
		if (!anchor) return list.slice(0, 3).map((v) => ({
			...v,
			distanceKm: null
		}));
		return list.map((v) => ({
			...v,
			distanceKm: v.lat != null && v.lng != null ? haversineKm(anchor, {
				lat: v.lat,
				lng: v.lng
			}) : null
		})).sort((a, b) => {
			if (a.distanceKm == null && b.distanceKm == null) return 0;
			if (a.distanceKm == null) return 1;
			if (b.distanceKm == null) return -1;
			return a.distanceKm - b.distanceKm;
		}).slice(0, 3);
	}, [suggestQ.data, anchor]);
	const selectedSportName = selectedSport ? allSports.find((s) => s.slug === selectedSport)?.name ?? selectedSport : null;
	const todayStr = (0, import_react.useMemo)(() => zonedDateISO(), []);
	const [selectedDate, setSelectedDate] = (0, import_react.useState)(todayStr);
	const bookableCourtIds = (0, import_react.useMemo)(() => courts.filter((c) => !c.coming_soon).map((c) => c.id), [courts]);
	const dayBounds = (0, import_react.useMemo)(() => {
		const { start, end } = zonedDayBoundsUtc(selectedDate);
		return {
			startISO: start.toISOString(),
			endISO: end.toISOString(),
			startMs: start.getTime(),
			endMs: end.getTime()
		};
	}, [selectedDate]);
	const bookingsQ = useQuery({
		queryKey: [
			"venue-day-bookings",
			venue?.id,
			selectedDate,
			bookableCourtIds.join(",")
		],
		enabled: bookableCourtIds.length > 0 && !!venue?.id,
		refetchInterval: 15e3,
		refetchOnWindowFocus: true,
		queryFn: async () => {
			const { data, error } = await supabase.rpc("get_venue_day_bookings", {
				_venue_id: venue.id,
				_from: dayBounds.startISO,
				_to: dayBounds.endISO
			});
			if (error) throw error;
			const allowed = new Set(bookableCourtIds);
			return (data ?? []).filter((b) => allowed.has(b.court_id));
		}
	});
	const sharedQ = useQuery({
		queryKey: ["venue-block-rules", venue?.id],
		enabled: !!venue?.id,
		queryFn: async () => {
			const { data, error } = await supabase.from("court_block_rules").select("court_id, blocked_court_id, courts!court_block_rules_blocked_court_id_fkey(name, map_emoji)").eq("venue_id", venue.id);
			if (error) throw error;
			return data ?? [];
		}
	});
	const sharedPartners = (0, import_react.useMemo)(() => {
		const nameById = /* @__PURE__ */ new Map();
		for (const c of courts) nameById.set(c.id, `${c.map_emoji ? `${c.map_emoji} ` : ""}${c.name}`);
		const add = (id, label) => {
			const list = m.get(id) ?? [];
			if (!list.includes(label)) list.push(label);
			m.set(id, list);
		};
		const m = /* @__PURE__ */ new Map();
		for (const r of sharedQ.data ?? []) {
			const blockedLabel = `${r.courts?.map_emoji ? `${r.courts.map_emoji} ` : ""}${r.courts?.name ?? `Court #${r.blocked_court_id}`}`;
			const srcLabel = nameById.get(r.court_id) ?? `Court #${r.court_id}`;
			add(r.court_id, blockedLabel);
			add(r.blocked_court_id, srcLabel);
		}
		return m;
	}, [sharedQ.data, courts]);
	const weekdayKey = (0, import_react.useMemo)(() => {
		return [
			"sun",
			"mon",
			"tue",
			"wed",
			"thu",
			"fri",
			"sat"
		][zonedDayOfWeek(selectedDate)];
	}, [selectedDate]);
	const venueHours = (0, import_react.useMemo)(() => normalizeHours(venue?.operating_hours), [venue?.operating_hours]);
	const availability = (0, import_react.useMemo)(() => {
		const byCourt = /* @__PURE__ */ new Map();
		const dayStart = dayBounds.startMs;
		const now = Date.now();
		const isToday = selectedDate === todayStr;
		const isPast = selectedDate < todayStr;
		const nowHrCeil = isToday ? Math.min(24, Math.ceil((now - dayStart) / 36e5)) : 0;
		for (const c of courts) {
			if (c.coming_soon) continue;
			const openSet = openHoursForDate(effectiveHours({
				inherit_venue_hours: c.inherit_venue_hours,
				operating_hours: c.operating_hours
			}, venueHours), selectedDate);
			const total = openSet.size;
			const unavailable = /* @__PURE__ */ new Set();
			if (isPast) for (const h of openSet) unavailable.add(h);
			else if (isToday) {
				for (const h of openSet) if (h < nowHrCeil) unavailable.add(h);
			}
			const pastCount = unavailable.size;
			const bookedSet = /* @__PURE__ */ new Set();
			const blockingSources = new Set((sharedQ.data ?? []).filter((rule) => rule.blocked_court_id === c.id).map((rule) => rule.court_id));
			for (const b of bookingsQ.data ?? []) {
				if (b.court_id !== c.id && !blockingSources.has(b.court_id)) continue;
				const s = Math.max(new Date(b.start_time).getTime(), dayStart);
				const e = Math.min(new Date(b.end_time).getTime(), dayBounds.endMs);
				if (e <= s) continue;
				const startHr = Math.floor((s - dayStart) / 36e5);
				const endHr = Math.ceil((e - dayStart) / 36e5);
				for (let h = startHr; h < endHr; h++) {
					if (openSet.has(h) && !unavailable.has(h)) bookedSet.add(h);
					unavailable.add(h);
				}
			}
			byCourt.set(c.id, {
				total,
				booked: bookedSet.size,
				past: pastCount
			});
		}
		return byCourt;
	}, [
		courts,
		bookingsQ.data,
		dayBounds.endMs,
		dayBounds.startMs,
		selectedDate,
		sharedQ.data,
		weekdayKey,
		todayStr,
		venueHours
	]);
	const isPastDate = selectedDate < todayStr;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto mt-10 max-w-6xl px-4 sm:mt-14 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl",
					children: [
						"Explore Our Courts at",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "bg-linear-to-r from-primary to-primary/60 bg-clip-text text-transparent",
							children: venue?.name ?? "this venue"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-2 max-w-2xl text-sm text-muted-foreground sm:text-base",
					children: "Pick your game, book your slot, and play like it's your home court."
				})]
			}),
			allSports.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SportChip, {
						active: !selectedSport,
						emoji: "✨",
						label: "All",
						onClick: () => onSelectSport(null)
					}), allSports.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SportChip, {
						active: selectedSport === s.slug,
						emoji: SPORT_EMOJI[s.slug] ?? "🏟️",
						label: s.name,
						offered: venueSportSlugs.has(s.slug),
						onClick: () => onSelectSport(s.slug)
					}, s.slug))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-2xl border border-[#dce8e2] bg-linear-to-r from-white via-white to-[#eaf5d8] p-4 shadow-[0_12px_30px_rgba(16,37,33,0.07)] sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-xl bg-primary/10 p-2 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-semibold text-foreground",
							children: "Check court availability"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Select a date to view real-time court availability."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: (() => {
							const addDays = addZonedDays;
							const dow = zonedDayOfWeek(todayStr);
							const daysToSat = dow === 6 ? 0 : (6 - dow + 7) % 7;
							const thisWeekend = addDays(todayStr, daysToSat);
							const daysToNextMon = (8 - dow) % 7 || 7;
							const nextWeek = addDays(todayStr, daysToNextMon);
							const tomorrow = addDays(todayStr, 1);
							const shortcuts = [
								{
									label: "Today",
									value: todayStr
								},
								{
									label: "Tomorrow",
									value: tomorrow
								},
								{
									label: "This weekend",
									value: thisWeekend
								},
								{
									label: "Next week",
									value: nextWeek
								}
							];
							const activeShortcut = shortcuts.find((s) => s.value === selectedDate);
							const selectedD = /* @__PURE__ */ new Date(`${selectedDate}T00:00:00`);
							const displayLabel = activeShortcut?.label ?? selectedD.toLocaleDateString(void 0, {
								weekday: "short",
								month: "short",
								day: "numeric"
							});
							const minDate = /* @__PURE__ */ new Date(`${todayStr}T00:00:00`);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "inline-flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm font-medium text-foreground hover:border-primary/50 focus:border-primary focus:outline-none",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "h-4 w-4 text-primary" }), displayLabel]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverContent, {
								align: "end",
								className: "w-auto p-0 pointer-events-auto",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-2 gap-1.5 border-b border-border p-2",
									children: shortcuts.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setSelectedDate(s.value),
										className: cn("rounded-md px-3 py-1.5 text-xs font-medium text-center transition", selectedDate === s.value ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-muted"),
										children: s.label
									}, s.label))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, {
									mode: "single",
									selected: selectedD,
									onSelect: (d) => {
										if (!d) return;
										const off = d.getTimezoneOffset();
										setSelectedDate((/* @__PURE__ */ new Date(d.getTime() - off * 6e4)).toISOString().slice(0, 10));
									},
									disabled: { before: minDate },
									initialFocus: true,
									className: cn("p-3 pointer-events-auto")
								})]
							})] });
						})()
					})]
				}), isPastDate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-amber-600",
					children: "This date is in the past — availability is read-only."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-3",
					children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-48 animate-pulse rounded-2xl bg-muted" }, i))
				}) : courts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-3",
					children: courts.map((c) => {
						const soon = !!c.coming_soon;
						const avail = availability.get(c.id);
						const unavailable = avail ? Math.min(avail.booked + avail.past, avail.total) : 0;
						const remaining = avail ? Math.max(avail.total - unavailable, 0) : null;
						const pct = avail && avail.total > 0 ? Math.round(unavailable / avail.total * 100) : 0;
						const availTone = remaining == null ? "bg-muted text-muted-foreground" : remaining === 0 ? "bg-red-100 text-red-700" : remaining <= 2 ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700";
						const baseCls = "group relative overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition hover:shadow-md";
						const hasImages = !!(c.images && c.images.length > 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `${baseCls} ${soon ? "cursor-not-allowed" : ""}`,
							"aria-disabled": soon,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoriteButton, {
									courtId: c.id,
									courtName: c.name,
									userId,
									className: "absolute right-3 top-3"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => !soon && hasImages && setCourtImageView({
										images: c.images,
										name: c.name,
										idx: 0
									}),
									disabled: soon || !hasImages,
									className: "relative block w-full text-left",
									"aria-label": hasImages ? `View ${c.name} images` : c.name,
									children: [hasImages ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: c.images[0],
											alt: c.name,
											className: `h-40 w-full object-cover ${soon ? "opacity-70" : ""}`
										}),
										c.images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "absolute bottom-2 right-2 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-semibold text-white",
											children: [
												"+",
												c.images.length - 1,
												" photos"
											]
										}),
										!soon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											"aria-hidden": true,
											className: "pointer-events-none absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 backdrop-blur-[1px] transition-opacity duration-300 group-hover:opacity-100",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-linear-to-r from-[#0b3d35] via-[#12806d] to-[#b8f05a] px-4 py-2 font-display text-[12px] font-extrabold uppercase italic tracking-[0.3em] text-white shadow-lg drop-shadow-[0_1px_6px_rgba(0,0,0,0.45)]",
												children: "Click to view court images"
											})
										})
									] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `court-pattern h-40 ${soon ? "opacity-70" : ""}` }), soon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute left-3 top-3 rounded-full bg-amber-500 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow",
										children: "Coming soon"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1 rounded-full bg-secondary px-2 py-1 font-medium text-secondary-foreground",
												children: [c.map_emoji && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													"aria-hidden": true,
													children: c.map_emoji
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.sports?.name ?? "Sport" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm font-bold text-foreground",
												children: c.is_indoor ? "Indoor" : "Outdoor"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-3 font-display text-2xl font-bold tracking-tight",
											children: c.name
										}),
										(sharedPartners.get(c.id)?.length ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 inline-flex max-w-full items-start gap-1.5 rounded-lg border border-amber-300 bg-amber-50 px-2 py-1 text-[11px] font-semibold text-amber-800",
											title: `Shares a space with: ${sharedPartners.get(c.id).join(", ")}. Booking this court blocks those hours on the others.`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												"aria-hidden": true,
												children: "🔗"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "min-w-0",
												children: ["Shared space", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "ml-1 font-normal",
													children: [
														"— booking this blocks ",
														sharedPartners.get(c.id).slice(0, 2).join(", "),
														sharedPartners.get(c.id).length > 2 && ` +${sharedPartners.get(c.id).length - 2} more`
													]
												})]
											})]
										}),
										c.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 line-clamp-2 text-sm text-muted-foreground",
											children: c.description
										}),
										c.amenities && c.amenities.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-2 flex flex-wrap gap-1",
											children: c.amenities.slice(0, 3).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground",
												children: a
											}, a))
										}),
										!soon && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 rounded-xl border border-border/70 bg-muted/40 p-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-medium text-foreground",
													children: bookingsQ.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: "Checking availability…"
													}) : remaining == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: "No hours today"
													}) : remaining === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Fully booked" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: `inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-semibold ${availTone}`,
														children: [
															remaining,
															" slot",
															remaining === 1 ? "" : "s",
															" open"
														]
													}) })
												}), avail && avail.total > 0 && (avail.booked > 0 || avail.past > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-muted-foreground",
													children: [
														avail.booked > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [avail.booked, " booked"] }),
														avail.booked > 0 && avail.past > 0 && " · ",
														avail.past > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [avail.past, " passed"] })
													]
												})]
											}), avail && avail.total > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-2 h-1.5 overflow-hidden rounded-full bg-background",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `h-full transition-all ${pct >= 100 ? "bg-red-500" : pct >= 70 ? "bg-amber-500" : "bg-primary"}`,
													style: { width: `${pct}%` }
												})
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 flex items-center justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: (() => {
												const rr = normalizeRules(c.rate_rules);
												const hrs = effectiveHours({
													inherit_venue_hours: c.inherit_venue_hours,
													operating_hours: c.operating_hours
												}, venueHours);
												const varies = hasVariablePricing(Number(c.hourly_rate), rr, hrs);
												const lo = varies ? minRate(Number(c.hourly_rate), rr, hrs) : Number(c.hourly_rate);
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
													varies && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "mr-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground",
														children: "from"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-3xl font-extrabold text-[#0b3d35] [text-shadow:0_0_14px_rgba(184,240,90,0.7)]",
														children: ["₱", lo.toFixed(0)]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-sm text-muted-foreground",
														children: " / hour"
													}),
													varies && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "mt-0.5 block text-[10px] font-medium uppercase tracking-wide text-muted-foreground",
														children: [
															"up to ",
															peso(maxRate(Number(c.hourly_rate), rr, hrs)),
															" · varies by time & day"
														]
													})
												] });
											})() }), soon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-semibold text-amber-600",
												children: "Opening soon"
											}) : openCourtId === c.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												disabled: true,
												className: "rounded-lg bg-primary/15 px-4 py-2 text-sm font-semibold text-primary ring-1 ring-primary/40 cursor-default",
												children: "Selected ✅"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => onOpenCourt(c.id),
												className: "rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-sm transition hover:brightness-110 active:scale-[0.98]",
												children: "Book now"
											})]
										})
									]
								})
							]
						}, c.id);
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptySport, {
					sportName: selectedSportName,
					onClearFilter: () => onSelectSport(null),
					suggestions,
					suggestLoading: suggestQ.isLoading,
					usingPlayerLoc: !!playerLoc,
					anchorLabel: playerLoc ? "your location" : venue?.name ?? "this venue"
				}) })
			}),
			locationModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-900 flex items-end justify-center bg-black/50 p-4 backdrop-blur-sm sm:items-center",
				onClick: skipLocation,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md overflow-hidden rounded-2xl bg-card shadow-2xl",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative bg-linear-to-br from-primary/15 via-primary/5 to-transparent px-6 pt-6 pb-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: skipLocation,
									className: "absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground hover:bg-muted",
									"aria-label": "Close",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary/15 text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "h-6 w-6" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "mt-3 text-center font-display text-lg font-bold",
									children: [
										"Find ",
										selectedSportName ?? "this sport",
										" near you"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-center text-sm text-muted-foreground",
									children: [
										"This venue doesn't offer ",
										selectedSportName ?? "that sport",
										" yet. Share your location so we can rank the closest venues that do — or pick a spot on the map instead."
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 px-6 py-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: requestGeolocation,
									disabled: geoBusy,
									className: "flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow transition hover:opacity-90 disabled:opacity-60",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "h-4 w-4" }), geoBusy ? "Getting your location…" : "Use my current location"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										setLocationModalOpen(false);
										setManualPickerOpen(true);
									},
									className: "flex w-full items-center justify-center gap-2 rounded-xl border border-border bg-background px-4 py-2.5 text-sm font-semibold hover:bg-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" }), "Pick a spot on the map"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: skipLocation,
									className: "w-full rounded-xl px-4 py-2 text-xs font-medium text-muted-foreground hover:text-foreground",
									children: "Skip — rank by this venue instead"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "border-t border-border bg-muted/40 px-6 py-3 text-center text-[11px] text-muted-foreground",
							children: "Your location is used only in your browser to sort nearby venues. It's never stored or shared."
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPicker, {
				open: manualPickerOpen,
				initialLat: venue?.latitude ?? null,
				initialLng: venue?.longitude ?? null,
				onClose: () => {
					setManualPickerOpen(false);
					markPrompted();
				},
				onSave: (lat, lng) => {
					setPlayerLoc({
						lat,
						lng
					});
					setManualPickerOpen(false);
					markPrompted();
				},
				title: "Pick your location"
			}),
			courtImageView && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-1400 flex items-center justify-center bg-black/95 p-4",
				onClick: () => setCourtImageView(null),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute left-4 top-4 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-white",
						children: [
							courtImageView.name,
							" · ",
							courtImageView.idx + 1,
							" / ",
							courtImageView.images.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: (e) => {
							e.stopPropagation();
							setCourtImageView(null);
						},
						className: "absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white hover:bg-white/20",
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
					}),
					courtImageView.images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: (e) => {
							e.stopPropagation();
							setCourtImageView((s) => s && {
								...s,
								idx: (s.idx - 1 + s.images.length) % s.images.length
							});
						},
						className: "absolute left-4 rounded-full bg-white/10 p-3 text-2xl leading-none text-white hover:bg-white/20",
						"aria-label": "Previous",
						children: "‹"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: courtImageView.images[courtImageView.idx],
						alt: `${courtImageView.name} photo ${courtImageView.idx + 1}`,
						className: "max-h-[88vh] max-w-[94vw] rounded-lg object-contain",
						onClick: (e) => e.stopPropagation()
					}),
					courtImageView.images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: (e) => {
							e.stopPropagation();
							setCourtImageView((s) => s && {
								...s,
								idx: (s.idx + 1) % s.images.length
							});
						},
						className: "absolute right-4 rounded-full bg-white/10 p-3 text-2xl leading-none text-white hover:bg-white/20",
						"aria-label": "Next",
						children: "›"
					}),
					courtImageView.images.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute bottom-4 left-1/2 flex -translate-x-1/2 gap-2 rounded-full bg-black/60 p-2",
						children: courtImageView.images.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: (e) => {
								e.stopPropagation();
								setCourtImageView((s) => s && {
									...s,
									idx: i
								});
							},
							className: "h-2 w-2 rounded-full transition " + (i === courtImageView.idx ? "bg-white" : "bg-white/40 hover:bg-white/70"),
							"aria-label": `Go to image ${i + 1}`
						}, i))
					})
				]
			})
		]
	});
}
function SportChip({ active, emoji, label, offered = true, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		title: offered ? void 0 : `Not offered here — tap to see nearby venues with ${label}`,
		className: `relative flex shrink-0 snap-start items-center gap-1.5 rounded-full border px-3 py-1.5 text-sm font-medium transition ${active ? "border-primary bg-primary text-primary-foreground shadow" : offered ? "border-border bg-card text-foreground hover:border-primary/50 hover:bg-primary/5" : "border-dashed border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": true,
			children: emoji
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
	});
}
function EmptySport({ sportName, onClearFilter, suggestions, suggestLoading, usingPlayerLoc, anchorLabel }) {
	const count = suggestions.length;
	const closest = suggestions[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-dashed border-border bg-card/50 p-6 sm:p-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "h-6 w-6" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "mt-3 text-lg font-semibold",
					children: [
						"No ",
						sportName ?? "courts",
						" at this venue yet"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: [
						"But don't worry — ",
						sportName ?? "this sport",
						" is available at other venues on CourtHub."
					]
				}),
				!suggestLoading && count > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto mt-4 max-w-md rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-semibold text-foreground",
						children: [
							"✅ Found ",
							count,
							" nearby ",
							count === 1 ? "venue" : "venues",
							" offering ",
							sportName
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: [usingPlayerLoc ? "Sorted by distance from your current location." : `Sorted by distance from ${anchorLabel}.`, closest?.distanceKm != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							" ",
							"Closest is ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground",
								children: closest.name
							}),
							" ",
							"·",
							" ",
							closest.distanceKm < 1 ? `${Math.round(closest.distanceKm * 1e3)} m away` : `${closest.distanceKm.toFixed(1)} km away`,
							" ",
							"· from ₱",
							closest.minRate.toFixed(0),
							"/hr."
						] })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClearFilter,
					className: "mt-4 text-xs font-semibold text-primary hover:underline",
					children: "Or view all courts at this venue →"
				})
			]
		}), suggestLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
			children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-32 animate-pulse rounded-xl bg-muted" }, i))
		}) : suggestions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
			children: suggestions.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/venues/$venueId",
				params: { venueId: String(v.id) },
				className: "group flex gap-3 rounded-xl border border-border bg-background p-3 shadow-sm transition hover:border-primary/40 hover:shadow-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-muted",
					children: v.images[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: v.images[0],
						alt: v.name,
						className: "h-full w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-full w-full items-center justify-center text-2xl",
						children: v.emoji ?? "🏟️"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-semibold text-foreground group-hover:text-primary",
							children: v.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 flex items-center gap-1 truncate text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-3 w-3 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: v.address
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1.5 flex items-center justify-between gap-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-primary",
								children: [
									"from ₱",
									v.minRate.toFixed(0),
									"/hr"
								]
							}), v.distanceKm != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 font-medium text-primary",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "h-3 w-3" }), v.distanceKm < 1 ? `${Math.round(v.distanceKm * 1e3)} m` : `${v.distanceKm.toFixed(1)} km`]
							})]
						})
					]
				})]
			}, v.id))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-center text-sm text-muted-foreground",
			children: [
				"No venues offering ",
				sportName ?? "this sport",
				" yet in your area — check back soon."
			]
		})]
	});
}
//#endregion
export { VenueDetail as component };
