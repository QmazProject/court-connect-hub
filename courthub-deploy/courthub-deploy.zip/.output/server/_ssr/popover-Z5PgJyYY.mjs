import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Dd0V2lPq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as Trigger, n as Portal, r as Root2, t as Content2 } from "../_libs/radix-ui__react-popover.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/popover-Z5PgJyYY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var REPORT_CATEGORIES = [
	{
		icon: "📍",
		label: "Place address or location"
	},
	{
		icon: "🛣️",
		label: "Road or road name"
	},
	{
		icon: "🚫",
		label: "Explicit content (profanity, vandalism, hate speech)"
	},
	{
		icon: "🗺️",
		label: "Border of country, state, or city"
	},
	{
		icon: "🏷️",
		label: "Name of country, state, city, or landmark"
	},
	{
		icon: "🌳",
		label: "Feature such as water body, park, or terrain"
	},
	{
		icon: "📌",
		label: "Pin location is incorrect"
	},
	{
		icon: "❓",
		label: "Other"
	}
];
/**
* Floating "i" info button used on every map. Replaces Leaflet's built-in
* attribution overlay with a compact menu:
*   • Report a problem with map
*   • Map data legal notices
*   • OpenStreetMap
*/
function MapInfoButton({ getCenter, className, align = "right" }) {
	const [showAttrib, setShowAttrib] = (0, import_react.useState)(false);
	const [showLegal, setShowLegal] = (0, import_react.useState)(false);
	const [reportOpen, setReportOpen] = (0, import_react.useState)(false);
	const [reportCategory, setReportCategory] = (0, import_react.useState)(null);
	const [reportDesc, setReportDesc] = (0, import_react.useState)("");
	const [reportSubmitting, setReportSubmitting] = (0, import_react.useState)(false);
	const [reportSent, setReportSent] = (0, import_react.useState)(false);
	function closeReport() {
		setReportOpen(false);
		setReportCategory(null);
		setReportDesc("");
		setReportSent(false);
		setReportSubmitting(false);
	}
	async function submitReport() {
		if (!reportCategory || !reportDesc.trim()) return;
		setReportSubmitting(true);
		const center = getCenter?.() ?? null;
		const { data: userData } = await supabase.auth.getUser();
		const { error } = await supabase.from("map_problems").insert({
			category: reportCategory,
			description: reportDesc.trim().slice(0, 2e3),
			latitude: center?.lat ?? null,
			longitude: center?.lng ?? null,
			user_id: userData?.user?.id ?? null
		});
		setReportSubmitting(false);
		if (error) {
			alert("Could not send report: " + error.message);
			return;
		}
		setReportSent(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `absolute z-[500] ${className ?? "bottom-3 right-3"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setShowAttrib((s) => !s),
				"aria-label": "Map information",
				title: "Map information",
				className: `inline-flex h-8 w-8 items-center justify-center rounded-full border border-border bg-background/95 text-sm font-semibold shadow hover:bg-secondary ${showAttrib ? "ring-2 ring-primary" : ""}`,
				children: "i"
			}), showAttrib && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[600]",
				onClick: () => setShowAttrib(false)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `absolute bottom-10 z-[700] w-64 overflow-hidden rounded-xl border border-border bg-background shadow-xl ${align === "left" ? "left-0" : "right-0"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setShowAttrib(false);
							setReportOpen(true);
						},
						className: "flex w-full items-center gap-3 px-3 py-2.5 text-left text-sm hover:bg-secondary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: "text-base",
							children: "⚠️"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Report a problem with map" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setShowAttrib(false);
							setShowLegal(true);
						},
						className: "flex w-full items-center gap-3 border-t border-border px-3 py-2.5 text-left text-sm hover:bg-secondary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: "text-base",
							children: "📄"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Map data legal notices" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "https://www.openstreetmap.org/copyright/",
						target: "_blank",
						rel: "noreferrer",
						onClick: () => setShowAttrib(false),
						className: "flex w-full items-center gap-3 border-t border-border px-3 py-2.5 text-left text-sm hover:bg-secondary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: "text-base",
							children: "🗺️"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "OpenStreetMap" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `pointer-events-none absolute -bottom-1.5 h-3 w-3 rotate-45 border-b border-r border-border bg-background ${align === "left" ? "left-3" : "right-3"}` })
				]
			})] })]
		}),
		reportOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 z-[1000] flex items-end justify-center bg-black/50 p-3 sm:items-center",
			onClick: closeReport,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-h-[85vh] w-full max-w-md overflow-y-auto rounded-xl border border-border bg-background p-4 shadow-xl",
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base font-semibold",
						children: reportSent ? "Report sent" : reportCategory ? "Describe the issue" : "Report a problem with map"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: closeReport,
						className: "rounded-md px-2 py-1 text-sm hover:bg-secondary",
						"aria-label": "Close",
						children: "✕"
					})]
				}), reportSent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Thanks — your report has been sent. We'll review it shortly."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: closeReport,
							className: "rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90",
							children: "Done"
						})
					})]
				}) : !reportCategory ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm text-muted-foreground",
						children: "What's wrong with the map?"
					}), REPORT_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setReportCategory(c.label),
						className: "flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left text-sm hover:bg-secondary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							className: "text-base",
							children: c.icon
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.label })]
					}, c.label))]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border border-border bg-secondary/50 px-3 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Category: "
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: reportCategory
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-sm font-medium",
							children: "Describe the issue"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: reportDesc,
							onChange: (e) => setReportDesc(e.target.value.slice(0, 2e3)),
							rows: 5,
							maxLength: 2e3,
							placeholder: "Tell us what's incorrect or misleading on the map…",
							className: "w-full resize-none rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center justify-between text-xs text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [reportDesc.length, "/2000"] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 pt-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setReportCategory(null);
									setReportDesc("");
								},
								disabled: reportSubmitting,
								className: "rounded-md border border-border px-4 py-2 text-sm font-medium hover:bg-secondary disabled:opacity-50",
								children: "← Back"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: submitReport,
								disabled: reportSubmitting || !reportDesc.trim(),
								className: "rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50",
								children: reportSubmitting ? "Sending…" : "Send"
							})]
						})
					]
				})]
			})
		}),
		showLegal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 z-[1000] flex items-end justify-center bg-black/40 p-3 sm:items-center",
			onClick: () => setShowLegal(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-xl border border-border bg-background p-4 shadow-xl",
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base font-semibold",
						children: "Map Data Legal Notices"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setShowLegal(false),
						className: "rounded-md px-2 py-1 text-sm hover:bg-secondary",
						"aria-label": "Close",
						children: "✕"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium",
								children: "OpenStreetMap"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground",
								children: "© OpenStreetMap contributors"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://www.openstreetmap.org/copyright/",
								target: "_blank",
								rel: "noreferrer",
								className: "text-primary hover:underline",
								children: "openstreetmap.org/copyright"
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium",
								children: "Overture Maps Foundation"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground",
								children: "Buildings: © OSM contributors, Microsoft, Esri Community Maps, Google Open Buildings, USGS 3DEP. Transportation: © OSM contributors. Base: © OSM contributors, ESA WorldCover."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://docs.overturemaps.org/attribution/",
								target: "_blank",
								rel: "noreferrer",
								className: "text-primary hover:underline",
								children: "docs.overturemaps.org/attribution"
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium",
								children: "Natural Earth"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground",
								children: "Made with Natural Earth."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://www.naturalearthdata.com/",
								target: "_blank",
								rel: "noreferrer",
								className: "text-primary hover:underline",
								children: "naturalearthdata.com"
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: "Esri"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://www.esri.com/en-us/legal/requirements/open-source-acknowledgements",
							target: "_blank",
							rel: "noreferrer",
							className: "text-primary hover:underline",
							children: "Open source acknowledgements"
						})] })
					]
				})]
			})
		})
	] });
}
function MapPicker({ open, initialLat, initialLng, onClose, onSave, saving, title }) {
	const containerRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const markerRef = (0, import_react.useRef)(null);
	const streetLayerRef = (0, import_react.useRef)(null);
	const satelliteLayerRef = (0, import_react.useRef)(null);
	const highlightRef = (0, import_react.useRef)(null);
	const [pos, setPos] = (0, import_react.useState)(initialLat != null && initialLng != null ? {
		lat: initialLat,
		lng: initialLng
	} : null);
	const [locBusy, setLocBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	const [query, setQuery] = (0, import_react.useState)("");
	const [results, setResults] = (0, import_react.useState)([]);
	const [searching, setSearching] = (0, import_react.useState)(false);
	const [view, setView] = (0, import_react.useState)("street");
	const parseCoords = (s) => {
		const m = s.match(/-?\d+(?:\.\d+)?/g);
		if (!m || m.length < 2) return null;
		const lat = Number(m[0]);
		const lng = Number(m[1]);
		if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
		if (lat < -90 || lat > 90 || lng < -180 || lng > 180) return null;
		return {
			lat,
			lng
		};
	};
	const coordMatch = parseCoords(query.trim());
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const q = query.trim();
		if (q.length < 2) {
			setResults([]);
			return;
		}
		if (parseCoords(q)) {
			setResults([]);
			return;
		}
		const ctrl = new AbortController();
		const t = setTimeout(async () => {
			setSearching(true);
			try {
				const buildParams = (extra) => new URLSearchParams({
					format: "jsonv2",
					q,
					limit: "20",
					addressdetails: "1",
					polygon_geojson: "1",
					"accept-language": "en",
					...extra ?? {}
				});
				const [phRes, wwRes] = await Promise.all([fetch(`https://nominatim.openstreetmap.org/search?${buildParams({ countrycodes: "ph" }).toString()}`, {
					signal: ctrl.signal,
					headers: { Accept: "application/json" }
				}).then((r) => r.ok ? r.json() : []).catch(() => []), fetch(`https://nominatim.openstreetmap.org/search?${buildParams().toString()}`, {
					signal: ctrl.signal,
					headers: { Accept: "application/json" }
				}).then((r) => r.ok ? r.json() : []).catch(() => [])]);
				const merged = [...phRes, ...wwRes];
				const seen = /* @__PURE__ */ new Set();
				const deduped = [];
				for (const r of merged) {
					const key = `${r.display_name}|${Number(r.lat).toFixed(4)}|${Number(r.lon).toFixed(4)}`;
					if (seen.has(key)) continue;
					seen.add(key);
					deduped.push(r);
				}
				const qLower = q.toLowerCase();
				const nameOf = (r) => {
					const a = r.address ?? {};
					return (a.name || a.city || a.town || a.village || a.municipality || a.county || a.state || r.display_name.split(",")[0] || "").toLowerCase();
				};
				const rank = (r) => {
					const n = nameOf(r);
					const isArea = isAreaResult(r);
					const hasPoly = r.geojson && (r.geojson.type === "Polygon" || r.geojson.type === "MultiPolygon");
					let score = 0;
					if (n === qLower) score -= 100;
					else if (n.startsWith(qLower)) score -= 50;
					else if (n.includes(qLower)) score -= 20;
					if (isArea) score -= 30;
					if (hasPoly) score -= 15;
					return score;
				};
				deduped.sort((a, b) => rank(a) - rank(b));
				setResults(deduped.slice(0, 20));
			} catch {} finally {
				setSearching(false);
			}
		}, 350);
		return () => {
			ctrl.abort();
			clearTimeout(t);
		};
	}, [query, open]);
	const flyTo = async (lat, lng, zoom = 16) => {
		setPos({
			lat,
			lng
		});
		const L = (await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).default ?? await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
		if (!mapRef.current) return;
		mapRef.current.setView([lat, lng], zoom);
		if (markerRef.current) markerRef.current.setLatLng([lat, lng]);
		else {
			const icon = L.icon({
				iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
				iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
				shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
				iconSize: [25, 41],
				iconAnchor: [12, 41]
			});
			markerRef.current = L.marker([lat, lng], {
				icon,
				draggable: true
			}).addTo(mapRef.current);
			markerRef.current.on("dragend", () => {
				const p = markerRef.current.getLatLng();
				setPos({
					lat: p.lat,
					lng: p.lng
				});
			});
		}
	};
	const clearHighlight = () => {
		if (highlightRef.current && mapRef.current) {
			mapRef.current.removeLayer(highlightRef.current);
			highlightRef.current = null;
		}
	};
	const isAreaResult = (r) => {
		const cls = r.class ?? "";
		const t = r.type ?? "";
		if (cls === "boundary" || cls === "place") return true;
		return [
			"city",
			"town",
			"village",
			"municipality",
			"suburb",
			"neighbourhood",
			"county",
			"state",
			"region",
			"administrative"
		].includes(t);
	};
	const selectResult = async (r) => {
		const L = (await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).default ?? await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
		if (!mapRef.current) return;
		clearHighlight();
		const lat = Number(r.lat), lng = Number(r.lon);
		const area = isAreaResult(r);
		if (r.geojson && (r.geojson.type === "Polygon" || r.geojson.type === "MultiPolygon")) highlightRef.current = L.geoJSON(r.geojson, {
			style: {
				color: "#09e6d2",
				weight: 2,
				fillColor: "#09e6d2",
				fillOpacity: .15
			},
			interactive: false
		}).addTo(mapRef.current);
		else if (r.boundingbox) {
			const [s, n, w, e] = r.boundingbox.map(Number);
			highlightRef.current = L.rectangle([[s, w], [n, e]], {
				color: "#09e6d2",
				weight: 2,
				fillColor: "#09e6d2",
				fillOpacity: .15,
				interactive: false
			}).addTo(mapRef.current);
		}
		if (r.boundingbox) {
			const [s, n, w, e] = r.boundingbox.map(Number);
			mapRef.current.fitBounds([[s, w], [n, e]], {
				padding: [24, 24],
				maxZoom: area ? 15 : 18
			});
		} else mapRef.current.setView([lat, lng], area ? 13 : 17);
		if (!area) {
			setPos({
				lat,
				lng
			});
			if (markerRef.current) markerRef.current.setLatLng([lat, lng]);
			else {
				const icon = L.icon({
					iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
					iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
					shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
					iconSize: [25, 41],
					iconAnchor: [12, 41]
				});
				markerRef.current = L.marker([lat, lng], {
					icon,
					draggable: true
				}).addTo(mapRef.current);
				markerRef.current.on("dragend", () => {
					const p = markerRef.current.getLatLng();
					setPos({
						lat: p.lat,
						lng: p.lng
					});
				});
			}
		}
	};
	(0, import_react.useEffect)(() => {
		if (!open) return;
		let cancelled = false;
		(async () => {
			const L = (await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).default ?? await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (!document.getElementById("leaflet-css")) {
				const link = document.createElement("link");
				link.id = "leaflet-css";
				link.rel = "stylesheet";
				link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
				document.head.appendChild(link);
			}
			if (cancelled || !containerRef.current) return;
			const start = initialLat != null && initialLng != null ? [initialLat, initialLng] : [14.5995, 120.9842];
			const map = L.map(containerRef.current, {
				zoomControl: false,
				attributionControl: false
			}).setView(start, initialLat != null ? 15 : 11);
			L.control.zoom({ position: "bottomright" }).addTo(map);
			const street = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
				maxZoom: 19,
				attribution: ""
			});
			const satellite = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
				maxZoom: 19,
				attribution: ""
			});
			street.addTo(map);
			streetLayerRef.current = street;
			satelliteLayerRef.current = satellite;
			const icon = L.icon({
				iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
				iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
				shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
				iconSize: [25, 41],
				iconAnchor: [12, 41]
			});
			if (initialLat != null && initialLng != null) {
				markerRef.current = L.marker([initialLat, initialLng], {
					icon,
					draggable: true
				}).addTo(map);
				markerRef.current.on("dragend", () => {
					const { lat, lng } = markerRef.current.getLatLng();
					setPos({
						lat,
						lng
					});
				});
			}
			map.on("click", (e) => {
				const { lat, lng } = e.latlng;
				clearHighlight();
				setPos({
					lat,
					lng
				});
				if (markerRef.current) markerRef.current.setLatLng(e.latlng);
				else {
					markerRef.current = L.marker(e.latlng, {
						icon,
						draggable: true
					}).addTo(map);
					markerRef.current.on("dragend", () => {
						const p = markerRef.current.getLatLng();
						setPos({
							lat: p.lat,
							lng: p.lng
						});
					});
				}
			});
			mapRef.current = map;
			setTimeout(() => map.invalidateSize(), 100);
		})();
		return () => {
			cancelled = true;
			if (mapRef.current) {
				mapRef.current.remove();
				mapRef.current = null;
				markerRef.current = null;
			}
		};
	}, [open]);
	const useMyLocation = () => {
		if (!navigator.geolocation) {
			setErr("Geolocation not supported.");
			return;
		}
		setLocBusy(true);
		navigator.geolocation.getCurrentPosition(async (p) => {
			const lat = p.coords.latitude, lng = p.coords.longitude;
			setPos({
				lat,
				lng
			});
			setLocBusy(false);
			const L = (await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).default ?? await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (mapRef.current) {
				mapRef.current.setView([lat, lng], 16);
				if (markerRef.current) markerRef.current.setLatLng([lat, lng]);
				else {
					const icon = L.icon({
						iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
						iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
						shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
						iconSize: [25, 41],
						iconAnchor: [12, 41]
					});
					markerRef.current = L.marker([lat, lng], {
						icon,
						draggable: true
					}).addTo(mapRef.current);
				}
			}
		}, (e) => {
			setErr(e.message);
			setLocBusy(false);
		}, {
			enableHighAccuracy: true,
			timeout: 1e4
		});
	};
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[2000] flex items-end justify-center bg-black/60 p-0 sm:items-center sm:p-4",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-t-2xl bg-background shadow-xl sm:h-[70vh] sm:rounded-2xl",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold",
						children: title ?? "Pin venue location"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Tap the map to drop a pin. Drag to fine-tune."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						className: "rounded-md p-1 text-muted-foreground hover:bg-secondary",
						children: "✕"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-b border-border px-4 py-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: query,
								onChange: (e) => setQuery(e.target.value),
								onKeyDown: (e) => {
									if (e.key !== "Enter") return;
									if (coordMatch) {
										e.preventDefault();
										flyTo(coordMatch.lat, coordMatch.lng, 17);
										setResults([]);
										return;
									}
									if (results.length > 0) {
										e.preventDefault();
										const top = results[0];
										const a = top.address ?? {};
										const primary = a.name || a.city || a.town || a.village || a.municipality || a.county || a.state || top.display_name.split(",")[0];
										selectResult(top);
										setResults([]);
										setQuery(String(primary));
									}
								},
								placeholder: "Search a place, or paste coordinates (e.g. 14.5995, 120.9842)…",
								className: "w-full rounded-lg border border-border bg-background px-3 py-2 pr-8 text-sm outline-none focus:border-primary"
							}),
							query && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setQuery("");
									setResults([]);
								},
								className: "absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-xs text-muted-foreground hover:bg-secondary",
								"aria-label": "Clear",
								children: "✕"
							}),
							coordMatch && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "absolute left-0 right-0 top-full z-[1000] mt-1 overflow-hidden rounded-lg border border-border bg-background shadow-lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										flyTo(coordMatch.lat, coordMatch.lng, 17);
										setResults([]);
									},
									className: "block w-full px-3 py-2 text-left text-xs hover:bg-secondary",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold text-primary",
											children: "Go to coordinates"
										}),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-muted-foreground",
											children: [
												coordMatch.lat.toFixed(6),
												", ",
												coordMatch.lng.toFixed(6)
											]
										})
									]
								}) })
							}),
							!coordMatch && (results.length > 0 || searching) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "absolute left-0 right-0 top-full z-[1000] mt-1 max-h-60 overflow-auto rounded-lg border border-border bg-background shadow-lg",
								children: [searching && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "px-3 py-2 text-xs text-muted-foreground",
									children: "Searching…"
								}), results.map((r, i) => {
									const a = r.address ?? {};
									const primary = a.name || a.attraction || a.building || a.amenity || a.road || a.neighbourhood || a.suburb || a.village || a.town || a.city || a.municipality || a.county || a.state || r.display_name.split(",")[0];
									const secondary = r.display_name.split(",").map((s) => s.trim()).filter((s) => s && s.toLowerCase() !== String(primary).toLowerCase()).join(", ");
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => {
											selectResult(r);
											setResults([]);
											setQuery(String(primary));
										},
										className: "block w-full px-3 py-2 text-left text-xs hover:bg-secondary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-medium text-foreground",
											children: primary
										}), secondary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-0.5 truncate text-[11px] text-muted-foreground",
											children: secondary
										})]
									}) }, `${r.lat},${r.lon},${i}`);
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					style: { minHeight: 240 },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: containerRef,
							className: "absolute inset-0"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute left-3 top-3 z-[500] inline-flex overflow-hidden rounded-lg border border-border bg-background shadow",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									if (view === "street" || !mapRef.current) return;
									mapRef.current.removeLayer(satelliteLayerRef.current);
									streetLayerRef.current.addTo(mapRef.current);
									setView("street");
								},
								className: `px-3 py-1.5 text-xs font-medium ${view === "street" ? "bg-primary text-primary-foreground" : "hover:bg-secondary"}`,
								children: "🗺️ Street"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									if (view === "satellite" || !mapRef.current) return;
									mapRef.current.removeLayer(streetLayerRef.current);
									satelliteLayerRef.current.addTo(mapRef.current);
									setView("satellite");
								},
								className: `px-3 py-1.5 text-xs font-medium ${view === "satellite" ? "bg-primary text-primary-foreground" : "hover:bg-secondary"}`,
								children: "🛰️ Satellite"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapInfoButton, {
							className: "bottom-3 left-3",
							align: "left",
							getCenter: () => {
								const c = mapRef.current?.getCenter?.();
								return c ? {
									lat: c.lat,
									lng: c.lng
								} : null;
							}
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 border-t border-border bg-secondary/30 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: useMyLocation,
								disabled: locBusy,
								className: "rounded-md border border-border bg-background px-2 py-1 font-medium hover:border-primary hover:text-primary disabled:opacity-60",
								children: locBusy ? "Locating…" : "📍 Use my location"
							}), pos ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `https://www.google.com/maps/search/?api=1&query=${pos.lat},${pos.lng}`,
								target: "_blank",
								rel: "noreferrer",
								className: "rounded-md border border-border bg-background px-2 py-1 font-medium hover:border-primary hover:text-primary",
								children: "View on Google Maps ↗"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-muted-foreground",
								children: "No pin yet"
							})]
						}),
						pos && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-[11px] text-muted-foreground",
							children: [
								"📍 ",
								pos.lat.toFixed(6),
								", ",
								pos.lng.toFixed(6)
							]
						}),
						err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-md bg-destructive/10 px-2 py-1 text-xs text-destructive",
							children: err
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: !pos || saving,
								onClick: () => pos && onSave(pos.lat, pos.lng),
								className: "flex-1 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60",
								children: saving ? "Saving…" : "Save pin"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: onClose,
								className: "rounded-md border border-border px-3 py-2 text-sm",
								children: "Cancel"
							})]
						})
					]
				})
			]
		})
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var Popover = Root2;
var PopoverTrigger = Trigger;
var PopoverContent = import_react.forwardRef(({ className, align = "center", sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	align,
	sideOffset,
	className: cn("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-popover-content-transform-origin)", className),
	...props
}) }));
PopoverContent.displayName = Content2.displayName;
//#endregion
export { PopoverTrigger as a, PopoverContent as i, MapPicker as n, cn as o, Popover as r, MapInfoButton as t };
