import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { r as VenueExplorer } from "./routes-Dvn3UgEW.mjs";
import { t as Route } from "./explore-Dg0b7smx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/explore-CO5FjUWM.js
var import_jsx_runtime = require_jsx_runtime();
function ExplorerRoute() {
	const { sport } = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VenueExplorer, { sport });
}
//#endregion
export { ExplorerRoute as component };
