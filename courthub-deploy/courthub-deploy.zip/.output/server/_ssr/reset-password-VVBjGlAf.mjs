import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Dd0V2lPq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reset-password-VVBjGlAf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResetPasswordRoute() {
	const navigate = useNavigate();
	const [status, setStatus] = (0, import_react.useState)("checking");
	const [password, setPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let mounted = true;
		if (new URLSearchParams(window.location.hash.replace(/^#/, "")).get("error")) {
			setStatus("invalid");
			return;
		}
		supabase.auth.getSession().then(({ data: { session } }) => {
			if (!mounted) return;
			if (session) setStatus("ready");
		});
		const { data: subscription } = supabase.auth.onAuthStateChange((event, session) => {
			if (!mounted) return;
			if (event === "PASSWORD_RECOVERY" && session) setStatus("ready");
		});
		const timeout = window.setTimeout(() => {
			if (mounted) setStatus((current) => current === "checking" ? "invalid" : current);
		}, 4e3);
		return () => {
			mounted = false;
			subscription.subscription.unsubscribe();
			window.clearTimeout(timeout);
		};
	}, []);
	const submit = async (event) => {
		event.preventDefault();
		setError(null);
		if (password.length < 8) {
			setError("Use a password with at least 8 characters.");
			return;
		}
		if (password !== confirmPassword) {
			setError("Passwords don’t match.");
			return;
		}
		setBusy(true);
		const { error: updateError } = await supabase.auth.updateUser({ password });
		setBusy(false);
		if (updateError) {
			setError(updateError.message);
			return;
		}
		setStatus("done");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-svh flex-col items-center justify-center bg-[#f4f7f5] px-4 py-12 sm:px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md overflow-hidden rounded-3xl border border-[#d8e4df] bg-white shadow-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden bg-[#09231f] px-6 pb-8 pt-7 text-white sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-10 -top-16 h-44 w-44 rounded-full bg-[#b8f05a]/20 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "logo-glaze relative inline-block",
						style: { "--logo-glaze-src": "url(/courthub-wordmark.png)" },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/courthub-wordmark.png",
							alt: "CourtHub",
							className: "h-7 w-auto object-contain"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "relative mt-8 text-xs font-bold uppercase tracking-[.2em] text-[#b8f05a]",
						children: "Account security"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "relative mt-2 font-display text-3xl font-bold tracking-tight",
						children: status === "done" ? "Password updated" : "Set a new password"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "relative mt-3 text-sm leading-relaxed text-white/70",
						children: status === "invalid" ? "This link couldn’t be used." : status === "done" ? "You’re all set — this device is already signed in with it." : "Choose a new password for your CourtHub account."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-6 py-8 sm:px-8",
				children: [
					status === "checking" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-sm text-[#5e746e]",
						children: "Checking your reset link…"
					}),
					status === "invalid" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto grid h-14 w-14 place-items-center rounded-full bg-red-50 text-2xl",
								children: "⚠️"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-sm leading-relaxed text-[#5e746e]",
								children: "This link is invalid or has expired — reset links only work once. Head back to the sign-in screen and request a new one."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/landing",
								search: { signin: true },
								className: "mt-7 inline-block rounded-full bg-[#0b3d35] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#126152]",
								children: "Back to sign in"
							})
						]
					}),
					status === "ready" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "flex flex-col",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm font-bold text-[#102521]",
								children: ["New password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "password",
									autoComplete: "new-password",
									value: password,
									onChange: (event) => setPassword(event.target.value),
									className: "mt-2 w-full rounded-xl border border-[#d8e4df] bg-white px-3 py-3 outline-none transition focus:border-[#12806d] focus:ring-2 focus:ring-[#b8f05a]/50",
									placeholder: "At least 8 characters",
									required: true,
									minLength: 8
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-5 text-sm font-bold text-[#102521]",
								children: ["Confirm new password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "password",
									autoComplete: "new-password",
									value: confirmPassword,
									onChange: (event) => setConfirmPassword(event.target.value),
									className: "mt-2 w-full rounded-xl border border-[#d8e4df] bg-white px-3 py-3 outline-none transition focus:border-[#12806d] focus:ring-2 focus:ring-[#b8f05a]/50",
									placeholder: "Type it again",
									required: true,
									minLength: 8
								})]
							}),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-700",
								children: error
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								disabled: busy,
								className: "mt-7 rounded-full bg-[#0b3d35] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#126152] disabled:cursor-wait disabled:opacity-60",
								children: busy ? "Updating…" : "Update password"
							})
						]
					}),
					status === "done" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto grid h-14 w-14 place-items-center rounded-full bg-[#eaf5d8] text-2xl",
								children: "✅"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-sm leading-relaxed text-[#5e746e]",
								children: "Your password has been changed. Continue to CourtHub — you're already signed in."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => navigate({
									to: "/landing",
									search: {}
								}),
								className: "mt-7 rounded-full bg-[#0b3d35] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#126152]",
								children: "Continue to CourtHub"
							})
						]
					})
				]
			})]
		})
	});
}
//#endregion
export { ResetPasswordRoute as component };
