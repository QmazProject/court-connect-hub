import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-BFFE07zL.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-BwdutfJC.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-B3LTXT2r.mjs";
import { a as numberType, i as enumType, o as objectType, s as stringType, t as arrayType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/paymongo.functions-BVintJM4.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var StartCheckoutInput = objectType({
	courtId: numberType().int().positive(),
	date: stringType().regex(/^\d{4}-\d{2}-\d{2}$/),
	hours: arrayType(numberType().int().min(0).max(23)).min(1).max(12),
	method: enumType([
		"gcash",
		"paymaya",
		"grab_pay",
		"qrph",
		"card"
	]),
	origin: stringType().url(),
	voucherCode: stringType().trim().min(1).max(64).optional()
});
var startBookingCheckout = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => StartCheckoutInput.parse(data)).handler(createSsrRpc("26fd7c53c370fd96e0e67e35bf95d425edea2701038c7097f1bdf6cd22226fe6"));
var RetryInput = objectType({
	bookingIds: arrayType(numberType().int().positive()).min(1).max(12),
	method: enumType([
		"gcash",
		"paymaya",
		"grab_pay",
		"qrph",
		"card"
	]),
	origin: stringType().url()
});
var retryBookingPayment = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => RetryInput.parse(d)).handler(createSsrRpc("be439ce63edc5e5594bbd7284bd1ac44c879681c4b4dd145f5a24ed9cc21d269"));
var CancelInput = objectType({ bookingIds: arrayType(numberType().int().positive()).min(1).max(24) });
var cancelPendingBookings = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => CancelInput.parse(d)).handler(createSsrRpc("c2aa49c683db0cb78455296515329f39bb48aa934e9e71e23722a9e6e5eed05f"));
createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => objectType({ reference: stringType().min(1) }).parse(data)).handler(createSsrRpc("6081a66a0be53dc472b738bb285741ca4f94b199f4d4bf8e3ad705abfb1051c5"));
var RefundInput = objectType({ bookingId: numberType().int().positive() });
createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => RefundInput.parse(d)).handler(createSsrRpc("3be948fb1c3eba65ff6979d4d5666c9a95208cfe5a608cbc3a5239159e4a9362"));
//#endregion
export { startBookingCheckout as i, createSsrRpc as n, retryBookingPayment as r, cancelPendingBookings as t };
