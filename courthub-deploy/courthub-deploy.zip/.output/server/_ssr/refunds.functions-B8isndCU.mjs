import { c as createServerFn } from "./createServerFn-BFFE07zL.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-BwdutfJC.mjs";
import { a as numberType, i as enumType, o as objectType, s as stringType, t as arrayType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-MBa5GZ-L.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/refunds.functions-B8isndCU.js
var CancelInput = objectType({
	bookingIds: arrayType(numberType().int().positive()).min(1).max(100),
	reason: stringType().trim().max(500).optional(),
	refundMode: enumType([
		"auto",
		"manual",
		"none"
	])
});
/**
* Venue-staff cancellation. The RPC enforces that the caller is staff of the
* venue, flips the bookings to cancelled (never deletes them) and notifies the
* player. Automatic refunds are then pushed back to the original PayMongo
* payment — we never ask a player for a GCash or card number.
*/
var cancelBookingsWithRefund_createServerFn_handler = createServerRpc({
	id: "e6d797fc46af27ae0c4dcdb2f89d05cd9cd84f62316651b2a5967f2632668ebb",
	name: "cancelBookingsWithRefund",
	filename: "src/lib/refunds.functions.ts"
}, (opts) => cancelBookingsWithRefund.__executeServer(opts));
var cancelBookingsWithRefund = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((data) => CancelInput.parse(data)).handler(cancelBookingsWithRefund_createServerFn_handler, async ({ data, context }) => {
	const { supabase } = context;
	const { data: cancelledCount, error } = await supabase.rpc("staff_cancel_bookings", {
		_booking_ids: data.bookingIds,
		_reason: data.reason ?? "",
		_refund_mode: data.refundMode
	});
	if (error) throw new Error(error.message);
	let refunded = 0;
	const failures = [];
	if (data.refundMode === "auto") {
		const { data: txs, error: txErr } = await supabase.from("transactions").select("id, booking_id, amount, status, raw").in("booking_id", data.bookingIds).eq("status", "paid");
		if (txErr) throw new Error(txErr.message);
		if ((txs ?? []).length > 0) {
			const { refundPayment } = await import("./paymongo.server-iZzYBd36.mjs");
			const { supabaseAdmin } = await import("./client.server-Bw6iWMJ-.mjs");
			for (const t of txs ?? []) {
				const paymentId = t.raw?.payment_id;
				if (!paymentId) {
					failures.push(`Booking #${t.booking_id}: no payment reference on file — settle manually.`);
					continue;
				}
				try {
					await refundPayment({
						paymentId,
						amountCentavos: Math.round(Number(t.amount) * 100),
						reason: "requested_by_customer"
					});
					await supabaseAdmin.from("transactions").update({
						status: "refunded",
						refunded_at: (/* @__PURE__ */ new Date()).toISOString()
					}).eq("id", t.id);
					await supabaseAdmin.from("bookings").update({
						refund_status: "refunded",
						payment_status: "refunded"
					}).eq("id", t.booking_id);
					refunded += 1;
				} catch (e) {
					console.error("refund failed", t.booking_id, e);
					failures.push(`Booking #${t.booking_id}: ${e.message}`);
				}
			}
		}
	}
	return {
		cancelled: Number(cancelledCount) || 0,
		refunded,
		failures
	};
});
//#endregion
export { cancelBookingsWithRefund_createServerFn_handler };
