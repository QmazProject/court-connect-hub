import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Dd0V2lPq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { N as require_jsx_runtime, k as Slot } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { o as cn } from "./popover-Z5PgJyYY.mjs";
import { X as Heart } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/FavoriteButton-WKzUJGL1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
/**
* Court favorites — a player's shortlist of courts to book again.
*
* A favorite is a court, not a venue: what a player comes back for is the specific
* court they liked, and the venue is context for finding it. Everything here reads
* `public.court_favorites`, whose RLS restricts every row to `auth.uid()`, so no
* query needs its own `user_id` filter to be safe — the filters below are there so
* the cache key and the rows agree, not for access control.
*
* Two queries, deliberately:
*   - `useFavoriteCourtIds` is the one a court tile asks. It reads ids only, so
*     putting a heart on every tile of a venue page costs one small request.
*   - `useFavoriteCourts` joins court and venue, and only the favorites view needs
*     that much.
* The toggle writes through both: the id set optimistically (a heart that waits for
* the network reads as broken), the detail list by invalidation.
*/
var FAVORITE_SELECT = "court_id, created_at, courts(id, name, hourly_rate, rate_rules, images, map_emoji, is_indoor, is_active, coming_soon, operating_hours, inherit_venue_hours, sports(name, slug), venues(id, name, address, is_active, operating_hours))";
var favoriteIdsKey = (userId) => ["court-favorite-ids", userId];
var favoriteCourtsKey = (userId) => ["court-favorites", userId];
/** Which courts this player has favorited. A `Set` because every tile on a page
*  asks the same question about itself. */
function useFavoriteCourtIds(userId) {
	return useQuery({
		queryKey: favoriteIdsKey(userId),
		enabled: !!userId,
		queryFn: async () => {
			const { data, error } = await supabase.from("court_favorites").select("court_id").eq("user_id", userId);
			if (error) throw error;
			return new Set((data ?? []).map((r) => r.court_id));
		}
	});
}
/** The favorites list itself, newest first — the order a player added them is the
*  only order they have any memory of. */
function useFavoriteCourts(userId) {
	return useQuery({
		queryKey: favoriteCourtsKey(userId),
		enabled: !!userId,
		queryFn: async () => {
			const { data, error } = await supabase.from("court_favorites").select(FAVORITE_SELECT).eq("user_id", userId).order("created_at", { ascending: false });
			if (error) throw error;
			return (data ?? []).filter((r) => !!r.courts);
		}
	});
}
/** Add or remove one favorite. `favorite` is the state being moved *to*, so the
*  caller passes what it wants rather than what it currently has. */
function useFavoriteToggle(userId) {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: async ({ courtId, favorite }) => {
			if (!userId) throw new Error("Sign in to save favorites.");
			if (favorite) {
				const { error } = await supabase.from("court_favorites").upsert({
					user_id: userId,
					court_id: courtId
				}, { onConflict: "user_id,court_id" });
				if (error) throw error;
			} else {
				const { error } = await supabase.from("court_favorites").delete().eq("user_id", userId).eq("court_id", courtId);
				if (error) throw error;
			}
		},
		onMutate: async ({ courtId, favorite }) => {
			const key = favoriteIdsKey(userId);
			await qc.cancelQueries({ queryKey: key });
			const previous = qc.getQueryData(key);
			if (previous) {
				const next = new Set(previous);
				if (favorite) next.add(courtId);
				else next.delete(courtId);
				qc.setQueryData(key, next);
			}
			return { previous };
		},
		onError: (_err, _vars, ctx) => {
			if (ctx?.previous) qc.setQueryData(favoriteIdsKey(userId), ctx.previous);
		},
		onSettled: () => {
			qc.invalidateQueries({ queryKey: favoriteIdsKey(userId) });
			qc.invalidateQueries({ queryKey: favoriteCourtsKey(userId) });
		}
	});
}
/**
* The heart that marks one court as a favorite.
*
* Meant to sit on top of a court tile, so it stops the click from reaching whatever
* the tile itself does — on the venue page that is "open the court images", in the
* favorites list it is "go book this court", and neither is what a player pressing
* the heart is asking for.
*
* It renders nothing for a signed-out visitor. Favorites are stored per account, so
* an offer to save one is an offer we cannot keep until they sign in.
*
* Hidden until hover on a pointer device, always visible on touch (where there is no
* hover to reveal it) and always visible once the court is favorited — a mark that
* disappears when you move the mouse away is not a mark.
*/
function FavoriteButton({ courtId, courtName, userId, className = "" }) {
	const idsQ = useFavoriteCourtIds(userId ?? void 0);
	const toggle = useFavoriteToggle(userId ?? void 0);
	if (!userId) return null;
	const on = idsQ.data?.has(courtId) ?? false;
	const what = courtName ?? "this court";
	const label = on ? `Remove ${what} from favorites` : `Save ${what} to favorites`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		"aria-pressed": on,
		title: label,
		disabled: toggle.isPending,
		onClick: (e) => {
			e.preventDefault();
			e.stopPropagation();
			toggle.mutate({
				courtId,
				favorite: !on
			});
		},
		className: "z-10 grid h-9 w-9 place-items-center rounded-full bg-black/45 text-white shadow-lg backdrop-blur-sm transition hover:bg-black/70 focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70 active:scale-95 disabled:opacity-60 " + (on ? "text-rose-400 " : "opacity-0 max-md:opacity-100 group-hover:opacity-100 group-focus-within:opacity-100 ") + className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "h-4.5 w-4.5 " + (on ? "fill-current" : "") })
	});
}
//#endregion
export { useFavoriteCourts as i, FavoriteButton as n, buttonVariants as r, Button as t };
