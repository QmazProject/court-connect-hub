import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { o as objectType, r as coerce, s as stringType } from "../_libs/zod.mjs";
require_jsx_runtime();
var $$splitComponentImporter = () => import("./venues._venueId-DZejVXEr.mjs");
var searchSchema = objectType({
	sport: stringType().optional(),
	court: coerce.number().int().positive().optional()
});
var Route = createFileRoute("/venues/$venueId")({
	validateSearch: searchSchema,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
