import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as objectType, s as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/explore-Dg0b7smx.js
var $$splitComponentImporter = () => import("./explore-CO5FjUWM.mjs");
var explorerSearchSchema = objectType({ sport: stringType().optional() });
var Route = createFileRoute("/explore")({
	validateSearch: explorerSearchSchema,
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: () => ({ meta: [{ title: "Explore venues | CourtHub" }, {
		name: "description",
		content: "Find and book sports courts across the Philippines."
	}] })
});
//#endregion
export { Route as t };
