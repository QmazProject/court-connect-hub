//#region node_modules/.nitro/vite/services/ssr/assets/paymongo.server-iZzYBd36.js
var PAYMONGO_API = "https://api.paymongo.com/v1";
function auth() {
	const key = process.env.PAYMONGO_SECRET_KEY;
	if (!key) throw new Error("PAYMONGO_SECRET_KEY is not configured");
	return "Basic " + Buffer.from(`${key}:`).toString("base64");
}
function paymongoMode() {
	return (process.env.PAYMONGO_SECRET_KEY ?? "").startsWith("sk_live_") ? "live" : "test";
}
async function pmFetch(path, init = {}) {
	const res = await fetch(`${PAYMONGO_API}${path}`, {
		method: init.method ?? "GET",
		headers: {
			Authorization: auth(),
			"Content-Type": "application/json",
			Accept: "application/json"
		},
		body: init.body ? JSON.stringify(init.body) : void 0
	});
	const text = await res.text();
	if (!res.ok) {
		console.error(`[PayMongo ${init.method ?? "GET"} ${path}] ${res.status}: ${text}`);
		throw new Error(`PayMongo error ${res.status}: ${text}`);
	}
	return text ? JSON.parse(text) : {};
}
async function createCheckoutSession(args) {
	return pmFetch("/checkout_sessions", {
		method: "POST",
		body: { data: { attributes: {
			send_email_receipt: false,
			show_description: true,
			show_line_items: true,
			description: args.description,
			reference_number: args.referenceNumber,
			line_items: [{
				currency: "PHP",
				amount: args.amountCentavos,
				name: args.lineItemName,
				quantity: 1
			}],
			payment_method_types: args.methods,
			success_url: args.successUrl,
			cancel_url: args.cancelUrl,
			metadata: args.metadata ?? {}
		} } }
	});
}
async function refundPayment(args) {
	return pmFetch("/refunds", {
		method: "POST",
		body: { data: { attributes: {
			amount: args.amountCentavos,
			payment_id: args.paymentId,
			reason: args.reason ?? "requested_by_customer"
		} } }
	});
}
//#endregion
export { createCheckoutSession, paymongoMode, refundPayment };
