import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courts._courtId-Df7lJkRe.js
var $$splitComponentImporter = () => import("./courts._courtId-D_jaf1qB.mjs");
var Route = createFileRoute("/courts/$courtId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
