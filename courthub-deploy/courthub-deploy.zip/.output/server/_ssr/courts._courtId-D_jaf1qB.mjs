import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-Dd0V2lPq.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Route } from "./courts._courtId-Df7lJkRe.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courts._courtId-D_jaf1qB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CourtRedirect() {
	const { courtId } = Route.useParams();
	const navigate = useNavigate();
	const q = useQuery({
		queryKey: ["court-venue", courtId],
		queryFn: async () => {
			const { data, error } = await supabase.from("courts").select("id, venue_id, is_active").eq("id", Number(courtId)).eq("is_active", true).maybeSingle();
			if (error) throw error;
			return data;
		}
	});
	(0, import_react.useEffect)(() => {
		if (q.data?.venue_id) navigate({
			to: "/venues/$venueId",
			params: { venueId: String(q.data.venue_id) },
			search: { court: q.data.id },
			replace: true
		});
	}, [q.data, navigate]);
	if (q.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto max-w-4xl px-6 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-2xl bg-muted" })
	});
	if (!q.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-4xl px-6 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold",
				children: "Court unavailable"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "This court doesn’t exist or is not currently accepting bookings."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-4 inline-block text-primary hover:underline",
				children: "← Back to courts"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "mx-auto max-w-4xl px-6 py-10 text-center text-muted-foreground",
		children: "Opening booking panel…"
	});
}
//#endregion
export { CourtRedirect as component };
