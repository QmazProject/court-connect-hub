import { A as peso, I as rateInBounds, P as rateCardGroups, g as fmtHour12 } from "./court-pricing-CFeeeUa8.mjs";
import { N as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RateCard-BjVMWMb4.js
var import_jsx_runtime = require_jsx_runtime();
/** "₱25/hr and up", "up to ₱500/hr", "₱25–500/hr" — how the active filter reads
*  back to the person who typed it. */
function describeBounds({ min, max }) {
	if (min != null && max != null) return `₱${min}–${max}/hr`;
	if (min != null) return `₱${min}/hr and up`;
	return `up to ₱${max}/hr`;
}
/** The court's price per hour laid out day-group by day-group.
*
*  Shared by the booking panel and the explore sidebar so the two can never
*  disagree about what a court charges. `variant` only swaps the palette:
*  "light" sits on the app's card surfaces, "dark" on the explore panel's
*  teal-and-lime tiles.
*
*  Pass `highlight` to answer "why is this court in my results?" — the hours whose
*  rate falls inside the filter stay lit and the rest recede, so a ₱20 morning
*  visibly drops out while the ₱38 evening that earned the match stands out. */
function RateCard({ baseRate, rules, hours = null, variant = "light", highlight = null, className = "" }) {
	const dark = variant === "dark";
	const groups = rateCardGroups(baseRate, rules, hours);
	const bounds = highlight && (highlight.min != null || highlight.max != null) ? highlight : null;
	const bandClass = (rate) => {
		const base = "rounded-md px-2 py-0.5 text-[10px] font-medium transition-opacity ";
		if (!bounds) return base + (dark ? "border border-white/15 bg-white/5 text-white/85" : "border border-border bg-background");
		if (rateInBounds(rate, bounds)) return base + (dark ? "border border-[#b8f05a]/60 bg-[#b8f05a]/15 font-semibold text-[#b8f05a]" : "border border-primary/60 bg-primary/10 font-semibold text-primary");
		return base + (dark ? "border border-white/10 bg-transparent text-white/30" : "border border-border/50 bg-transparent text-muted-foreground/50");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: (dark ? "rounded-xl border border-[#b8f05a]/30 bg-[#09231f] p-3" : "rounded-xl border border-primary/30 bg-primary/5 p-3") + (className ? ` ${className}` : ""),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[11px] font-semibold uppercase tracking-wider " + (dark ? "text-[#b8f05a]" : "text-primary"),
				children: "Rate card"
			}),
			groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[10px] font-semibold uppercase tracking-wide " + (dark ? "text-white/50" : "text-muted-foreground"),
					children: g.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 flex flex-wrap gap-1",
					children: g.bands.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: bandClass(b.rate),
						title: bounds && !rateInBounds(b.rate, bounds) ? `Outside your ${describeBounds(bounds)} filter` : void 0,
						children: [
							fmtHour12(b.start),
							"–",
							fmtHour12(b.end % 24),
							" · ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: peso(b.rate) })
						]
					}, `${g.label}-${b.start}`))
				})]
			}, g.label)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-[10px] " + (dark ? "text-white/50" : "text-muted-foreground"),
				children: bounds ? `Highlighted hours match your ${describeBounds(bounds)} filter. Each hour is charged at its own rate; your total adds them up.` : "Each hour is charged at its own rate; your total adds them up."
			})
		]
	});
}
//#endregion
export { RateCard as t };
